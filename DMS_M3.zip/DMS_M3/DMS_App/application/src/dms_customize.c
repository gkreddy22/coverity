/***********************************************************************************************************************
* File Name    : dms_customize.c
* Version      : 1.0.0
* Product Name : DMS Application
* Device(s)    : R-Car V3h2
* Description  : Customize File
***********************************************************************************************************************/

/***********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 1.0.0   06.06.2022 Initial version 
***********************************************************************************************************************/

/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "common.h"
#include "customize.h"

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static char *getstr(char buf[], char tag[], char dest[]);
static int CustomizeRangeCheck( char * var, int val, int min, int max);
/**********************************************************************************************************************
* Function Name: getstr     
* Description  : Getting string
* Arguments    : char buf
* Arguments    : char tag  
* Arguments    : char dest                      
* Return Value : dest                       
**********************************************************************************************************************/
static char *getstr(char buf[], char tag[], char dest[])
{
    char  tmp[ 256 ] ;
    char  *po ;
    int   len ;

    len = strlen(tag);                                                                              /* tag name length */

    if (strncmp(buf, tag, len) == 0) {                                                              /* check for tag */
        buf = &buf[len];

        while (*buf == ' ') buf++;                                                                  /* skip space */
        if (*buf == '\0')   goto END_OF_FUNC;
        if (*buf == '\n')   goto END_OF_FUNC;

        po = tmp;

        if (*buf == '"') {
            buf++;
            while (*buf != '"' && *buf != '\0' && *buf != '\n') {
                *po++ = *buf++;
            }
            if (*buf != '"') {
                goto END_OF_FUNC ;
            }
        } else {
            while(*buf != ' ' && *buf != '\0' && *buf != '\n') {
                *po++ = *buf++;
            }
        }
        *po = '\0';
        strcpy(dest, tmp);
    }

END_OF_FUNC:
    return(dest);
}
/**********************************************************************************************************************
 End of function  getstr
 *********************************************************************************************************************/

/**********************************************************************************************************************
* Function Name: R_CustomizeInit
* Description  : default customization value
* Arguments    : void * cf
* Return Value : None
**********************************************************************************************************************/
void R_CustomizeInit(st_customize_t *cf)
{

    memset(cf , 0 , sizeof(st_customize_t));

    cf->VIN_Enable                  = 1;
    cf->VIN_Device                  = 0;
    cf->VIN_Capture_Format          = 0;
    cf->VIN_Capture_Width           = 1280;
    cf->VIN_Capture_Height          = 800;
    cf->VIN_Offset_X                = 0;
    cf->VIN_Offset_Y                = 0;
    cf->VIN_Req_Buffer_Num          = 0;
    /* Image */
    cf->Frame_Width                 = 1280;
    cf->Frame_Height                = 720;
    /* ISP */
    cf->ISP_Enable                  = 0;
    cf->ISP_Channel                 = 0;
    cf->ISP_RAW_IN_Format           = 0;
    cf->ISP_RAW_OUT_Format          = 0;
    /* IMR */
    cf->IMR_Channel                 = 0;
    cf->IMR_LDC                     = 0;
    cf->IMR_LDC_Params_k1           = 0.000023f;
    cf->IMR_LDC_Params_k2           = 0;
    cf->IMR_LDC_Params_k3           = 0;
    cf->IMR_LDC_Params_p1           = 0;
    cf->IMR_LDC_Params_p2           = 0;
    cf->IMR_LDC_Params_fx           = 0.3f;
    cf->IMR_LDC_Params_fy           = 0.5f;
    cf->IMR_LDC_Params_cx           = 0.4f;
    cf->IMR_LDC_Params_cy           = 0.4f;
    cf->IMR_Resize                  = 1;
    cf->IMR_Resize_Width            = 224;
    cf->IMR_Resize_Height           = 224;

    /* CNN */
    cf->CNN_Enable                  = 1;
    cf->CNN_NumberOfChannels        = 3;
    strcpy(cf->CNN_ChannelName,"data_memory");
    strcpy(cf->AI_Model_Name,"subn0_clbundle.pb");
    strcpy(cf->Inference_Output_File,"activation_11_memory");
    strcpy(cf->Inference_File_Format,"RGB24");

    /*OpenCV - Post Processing */
    cf->DMS_Text                    = 1;
    cf->DMS_Text_Position_X         = (cf->Frame_Width/2) - 120;
    cf->DMS_Text_Position_Y         = cf->Frame_Height - 40;
    cf->DMS_Text_Size               = 1;
    cf->DMS_Text_Font               = 2;
    strcpy(cf->DMS_Text_Color_Safe,"Green");
    strcpy(cf->DMS_Text_Color_Others,"Red");
    cf->DMS_Act_SafeDrive           = 1;
    cf->DMS_Act_Phone_call_Right    = 1;
    cf->DMS_Act_Phone_call_Left     = 1;
    cf->DMS_Act_Drinking            = 1;
    cf->DMS_Act_Reach_Side          = 1; 
    cf->DMS_Act_Hair_Makeup         = 1;
    cf->DMS_Act_Talking_Passenger   = 1;
    cf->DMS_Act_Reach_Backseat      = 1;
    cf->DMS_Act_Look_Down           = 1;
    /* VOUT */

    strcpy(cf->DRM_Module,"rcar-du");
    cf->VOUT_Display_Format         = 0;
    cf->VOUT_Display_Width          = 1920;
    cf->VOUT_Display_Height         = 1080;
    cf->VOUT_Pos_X                  = 0;
    cf->VOUT_Pos_Y                  = 0;
    /* Debug */
    cf->Debug_Enable                = 0;
    cf->Logging                     = 0;
    cf->Proc_Time                   = 0;
    strcpy(cf->Frame_File_Name,"frame_buffer_vin");
}
/**********************************************************************************************************************
 End of function  R_CustomizeInit
 *********************************************************************************************************************/

/* Function Name : R_CustomizeLoad */
/******************************************************************************************************************//**
 * @brief       Lading the customization parameters
 * @param[in]   cf           
 * @param[in]  file_name
 * @retval      true            success
 * @retval      false           fail
 *********************************************************************************************************************/
int R_CustomizeLoad(st_customize_t *cf, const char *file_name)
{
    int ret = 0;
    char buf[258];
    FILE *fp = NULL;

    fp = fopen(file_name, "r");
    if (fp == NULL) {
        return FAILED;
    }
    for(;;)
    {

        if (fgets(buf, 256, fp) == NULL) { break; }
        sscanf(buf, "VIN_Enable %d",&cf->VIN_Enable);
        sscanf(buf, "VIN_Device %d",&cf->VIN_Device);
        sscanf(buf, "VIN_Capture_Format %d",&cf->VIN_Capture_Format);
        sscanf(buf, "VIN_Capture_Width %d",&cf->VIN_Capture_Width);
        sscanf(buf, "VIN_Capture_Height %d",&cf->VIN_Capture_Height);
        sscanf(buf, "VIN_Offset_X %d",&cf->VIN_Offset_X);
        sscanf(buf, "VIN_Offset_Y %d",&cf->VIN_Offset_Y);
        sscanf(buf, "VIN_Req_Buffer_Num %d",&cf->VIN_Req_Buffer_Num);
        sscanf(buf, "Frame_Width %d",&cf->Frame_Width);
        sscanf(buf, "Frame_Height %d",&cf->Frame_Height);
        sscanf(buf, "ISP_Enable %d",&cf->ISP_Enable);
        sscanf(buf, "ISP_Channel %d",&cf->ISP_Channel);
        sscanf(buf, "ISP_RAW_IN_Format %d",&cf->ISP_RAW_IN_Format);
        sscanf(buf, "ISP_RAW_OUT_Format %d",&cf->ISP_RAW_OUT_Format);
        sscanf(buf, "IMR_Channel %d",&cf->IMR_Channel);
        sscanf(buf, "IMR_LDC %d",&cf->IMR_LDC);
        sscanf(buf, "IMR_LDC_Params_k1 %f",&cf->IMR_LDC_Params_k1);
        sscanf(buf, "IMR_LDC_Params_k2 %f",&cf->IMR_LDC_Params_k2);
        sscanf(buf, "IMR_LDC_Params_k3 %f",&cf->IMR_LDC_Params_k3);
        sscanf(buf, "IMR_LDC_Params_p1 %d",&cf->IMR_LDC_Params_p1);
        sscanf(buf, "IMR_LDC_Params_p2 %d",&cf->IMR_LDC_Params_p2);
        sscanf(buf, "IMR_LDC_Params_fx %f",&cf->IMR_LDC_Params_fx);
        sscanf(buf, "IMR_LDC_Params_fy %f",&cf->IMR_LDC_Params_fy);
        sscanf(buf, "IMR_LDC_Params_cx %f",&cf->IMR_LDC_Params_cx);
        sscanf(buf, "IMR_LDC_Params_cy %f",&cf->IMR_LDC_Params_cy);
        sscanf(buf, "IMR_Resize %d",&cf->IMR_Resize);
        sscanf(buf, "IMR_Resize_Width %d",&cf->IMR_Resize_Width);
        sscanf(buf, "IMR_Resize_Height %d",&cf->IMR_Resize_Height);
        sscanf(buf, "CNN_Enable %d",&cf->CNN_Enable);
        sscanf(buf, "CNN_Number_Of_Channels %d",&cf->CNN_NumberOfChannels);
        getstr(buf, "CNN_Name_Of_Channels",&cf->CNN_ChannelName);
        getstr(buf, "AI_Model_Name",&cf->AI_Model_Name);
        getstr(buf, "Inference_Output_File",cf->Inference_Output_File);
        getstr(buf, "Inference_File_Format",cf->Inference_File_Format);
        sscanf(buf, "DMS_Text %d",&cf->DMS_Text);
        sscanf(buf, "DMS_Text_Position_X %d",&cf->DMS_Text_Position_X);
        sscanf(buf, "DMS_Text_Position_Y %d",&cf->DMS_Text_Position_Y);
        sscanf(buf, "DMS_Text_Size %d",&cf->DMS_Text_Size);
        sscanf(buf, "DMS_Text_Font %d",&cf->DMS_Text_Font);
        getstr(buf, "DMS_Text_Color_Safe",&cf->DMS_Text_Color_Safe);
        getstr(buf, "DMS_Text_Color_Others",&cf->DMS_Text_Color_Others);
        sscanf(buf, "DMS_Act_SafeDrive %d",&cf->DMS_Act_SafeDrive);
        sscanf(buf, "DMS_Act_Phone_call_Right %d",&cf->DMS_Act_Phone_call_Right);
        sscanf(buf, "DMS_Act_Phone_call_Left %d",&cf->DMS_Act_Phone_call_Left);
        sscanf(buf, "DMS_Act_Drinking %d",&cf->DMS_Act_Drinking);
        sscanf(buf, "DMS_Act_Reach_Side %d",&cf->DMS_Act_Reach_Side);
        sscanf(buf, "DMS_Act_Hair_Makeup %d",&cf->DMS_Act_Hair_Makeup);
        sscanf(buf, "DMS_Act_Talking_Passenger %d",&cf->DMS_Act_Talking_Passenger);
        sscanf(buf, "DMS_Act_Reach_Backseat %d",&cf->DMS_Act_Reach_Backseat);
        sscanf(buf, "DMS_Act_Look_Down %d",&cf->DMS_Act_Look_Down);
        getstr(buf, "DRM_Module",cf->DRM_Module);
        sscanf(buf, "VOUT_Display_Format %d",&cf->VOUT_Display_Format);
        sscanf(buf, "VOUT_Display_Width %d",&cf->VOUT_Display_Width);
        sscanf(buf, "VOUT_Display_Height %d",&cf->VOUT_Display_Height);
        sscanf(buf, "VOUT_Pos_X %d",&cf->VOUT_Pos_X);
        sscanf(buf, "VOUT_Pos_Y %d",&cf->VOUT_Pos_Y);
        sscanf(buf, "Debug_Enable %d",&cf->Debug_Enable);
        sscanf(buf, "Logging %d",&cf->Logging);
        sscanf(buf, "Proc_Time %d",&cf->Proc_Time);
        getstr(buf, "Frame_File_Name ",cf->Frame_File_Name);
    }

    return SUCCESS;
}
/**********************************************************************************************************************
 End of function  R_CustomizeLoad
 *********************************************************************************************************************/

/* Function Name :R_CustomizeValidate */
/******************************************************************************************************************//**
 * @brief       Validating the customization parameters
 * @param[in]   cf
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
 *********************************************************************************************************************/
int R_CustomizeValidate(st_customize_t *cf)
{
    int ret =0;

    ret += CustomizeRangeCheck("VIN_Enable",cf->VIN_Enable,0,1);
    ret += CustomizeRangeCheck("VIN_Device",cf->VIN_Device,0,7);
    ret += CustomizeRangeCheck("VIN_Capture_Format",cf->VIN_Capture_Format,0,3);
    ret += CustomizeRangeCheck("ISP_Enable",cf->ISP_Enable,0,1);
    ret += CustomizeRangeCheck("ISP_Channel",cf->ISP_Channel,0,1);
    ret += CustomizeRangeCheck("ISP_RAW_IN_Format",cf->ISP_RAW_IN_Format,0,1);
    ret += CustomizeRangeCheck("ISP_RAW_OUT_Format",cf->ISP_RAW_OUT_Format,0,1);
    ret += CustomizeRangeCheck("IMR_Channel",cf->IMR_Channel,0,5);
    ret += CustomizeRangeCheck("IMR_LDC",cf->IMR_LDC,0,1);
    ret += CustomizeRangeCheck("IMR_Resize",cf->IMR_Resize,0,1);
    ret += CustomizeRangeCheck("CNN_Enable",cf->CNN_Enable,0,1);
    ret += CustomizeRangeCheck("CNN_NumberOfChannels",cf->CNN_NumberOfChannels,0,3);
    ret += CustomizeRangeCheck("DMS_Text",cf->DMS_Text,0,1);
    ret += CustomizeRangeCheck("DMS_Text_Font",cf->DMS_Text_Font,0,7);
    ret += CustomizeRangeCheck("DMS_Act_SafeDrive",cf->DMS_Act_SafeDrive,0,1);
    ret += CustomizeRangeCheck("DMS_Act_Phone_call_Right",cf->DMS_Act_Phone_call_Right,0,1);
    ret += CustomizeRangeCheck("DMS_Act_Phone_call_Left",cf->DMS_Act_Phone_call_Left,0,1);
    ret += CustomizeRangeCheck("DMS_Act_Drinking",cf->DMS_Act_Drinking,0,1);
    ret += CustomizeRangeCheck("DMS_Act_Reach_Side",cf->DMS_Act_Reach_Side,0,1);
    ret += CustomizeRangeCheck("DMS_Act_Hair_Makeup",cf->DMS_Act_Hair_Makeup,0,1);
    ret += CustomizeRangeCheck("DMS_Act_Talking_Passenger",cf->DMS_Act_Talking_Passenger,0,1);
    ret += CustomizeRangeCheck("DMS_Act_Reach_Backseat",cf->DMS_Act_Reach_Backseat,0,1);
    ret += CustomizeRangeCheck("DMS_Act_Look_Down",cf->DMS_Act_Look_Down,0,1);
    ret += CustomizeRangeCheck("VOUT_Display_Format",cf->VOUT_Display_Format,0,1);
    ret += CustomizeRangeCheck("Debug_Enable",cf->Debug_Enable,0,1);
    ret += CustomizeRangeCheck("Logging",cf->Logging,0,1);
    ret += CustomizeRangeCheck("Proc_Time",cf->Proc_Time,0,2);

    if(ret == 0)
    {
        return SUCCESS;
    }
    else
    {
        return FAILED;
    }

}
/**********************************************************************************************************************
 End of function  R_CustomizeValidate
 *********************************************************************************************************************/

/* Function Name : R_CustomizePrint*/
/******************************************************************************************************************//**
 * @brief       Printing the customization parameters
 * @param[in]   cf
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
 *********************************************************************************************************************/
int R_CustomizePrint(st_customize_t *cf)
{
    printf("DMS PIPE-LINE \n");
    printf("-------------------------------\n");

    if (true == cf->VIN_Enable)
    {
        printf("|VIN| --> ");
    }
    if (true == cf->ISP_Enable)
    {
        printf("|ISP| --> ");
    }
    if (true == cf->IMR_LDC)
    {
        printf("|IMR LDC| --> ");
    }
    if (true == cf->IMR_Resize)
    {
        printf("|IMR RES| --> ");
    }
    if (true == cf->CNN_Enable)
    {
        printf("|CNN| --> ");
    }
    printf("|VOUT| \n \n");

    printf("DMS Configuration \n");
    printf("-------------------------------\n");
    printf("\n[VIN] \n");
    printf("VIN_Enable                  : %d \n",cf->VIN_Enable);
    printf("VIN_Device                  : %d \n",cf->VIN_Device);
    printf("VIN_Capture_Format          : %d \n",cf->VIN_Capture_Format);
    printf("VIN_Capture_Width           : %d \n",cf->VIN_Capture_Width);
    printf("VIN_Capture_Height          : %d \n",cf->VIN_Capture_Height);
    printf("VIN_Offset_X                : %d \n",cf->VIN_Offset_X);
    printf("VIN_Offset_Y                : %d \n",cf->VIN_Offset_Y);
    printf("VIN_Req_Buffer_Num          : %d \n",cf->VIN_Req_Buffer_Num);
    printf("\n[Image] \n");
    printf("Frame_Width                 : %d \n",cf->Frame_Width);
    printf("Frame_Height                : %d \n",cf->Frame_Height);
    printf("\n[ISP] \n");
    printf("ISP_Enable                  : %d \n",cf->ISP_Enable);
    printf("ISP_Channel                 : %d \n",cf->ISP_Channel);
    printf("ISP_RAW_IN_Format           : %d \n",cf->ISP_RAW_IN_Format);
    printf("ISP_RAW_OUT_Format          : %d \n",cf->ISP_RAW_OUT_Format);
    printf("\n[IMR] \n");
    printf("IMR_Channel                 : %d \n",cf->IMR_Channel);
    printf("IMR_LDC                     : %d \n",cf->IMR_LDC);
    printf("IMR_LDC_Params_k1           : %f \n",cf->IMR_LDC_Params_k1);
    printf("IMR_LDC_Params_k2           : %f \n",cf->IMR_LDC_Params_k2);
    printf("IMR_LDC_Params_k3           : %f \n",cf->IMR_LDC_Params_k3);
    printf("IMR_LDC_Params_p1           : %d \n",cf->IMR_LDC_Params_p1);
    printf("IMR_LDC_Params_p2           : %d \n",cf->IMR_LDC_Params_p2);
    printf("IMR_LDC_Params_fx           : %f \n",cf->IMR_LDC_Params_fx);
    printf("IMR_LDC_Params_fy           : %f \n",cf->IMR_LDC_Params_fy);
    printf("IMR_LDC_Params_cx           : %f \n",cf->IMR_LDC_Params_cx);
    printf("IMR_LDC_Params_cy           : %f \n",cf->IMR_LDC_Params_cy);
    printf("IMR_Resize                  : %d \n",cf->IMR_Resize);
    printf("IMR_Resize_Width            : %d \n",cf->IMR_Resize_Width);
    printf("IMR_Resize_Height           : %d \n",cf->IMR_Resize_Height);
    printf("\n[CNN] \n");
    printf("CNN_Enable                  : %d \n",cf->CNN_Enable);
    printf("CNN_Number_Of_Channels      : %d \n",cf->CNN_NumberOfChannels);
    printf("CNN_ChannelName             : %s \n",cf->CNN_ChannelName);
    printf("AI_Model_Name               : %s \n",cf->AI_Model_Name);
    printf("Inference_Output_File       : %s \n",cf->Inference_Output_File);
    printf("Inference_File_Format       : %s \n",cf->Inference_File_Format);
    printf("\n[OpenCV - Post Processing] \n");
    printf("DMS_Text                    : %d \n",cf->DMS_Text);
    printf("DMS_Text_Position_X         : %d \n",cf->DMS_Text_Position_X);
    printf("DMS_Text_Position_Y         : %d \n",cf->DMS_Text_Position_Y);
    printf("DMS_Text_Size               : %d \n",cf->DMS_Text_Size);
    printf("DMS_Text_Font               : %d \n",cf->DMS_Text_Font);
    printf("DMS_Text_Color_Safe         : %s \n",cf->DMS_Text_Color_Safe);
    printf("DMS_Text_Color_Others       : %s \n",cf->DMS_Text_Color_Others);
    printf("DMS_Act_SafeDrive           : %d \n",cf->DMS_Act_SafeDrive);
    printf("DMS_Act_Phone_call_Right    : %d \n",cf->DMS_Act_Phone_call_Right);
    printf("DMS_Act_Phone_call_Left     : %d \n",cf->DMS_Act_Phone_call_Left);
    printf("DMS_Act_Drinking            : %d \n",cf->DMS_Act_Drinking);
    printf("DMS_Act_Reach_Side          : %d \n",cf->DMS_Act_Reach_Side);
    printf("DMS_Act_Hair_Makeup         : %d \n",cf->DMS_Act_Hair_Makeup);
    printf("DMS_Act_Talking_Passenger   : %d \n",cf->DMS_Act_Talking_Passenger);
    printf("DMS_Act_Reach_Backseat      : %d \n",cf->DMS_Act_Reach_Backseat);
    printf("DMS_Act_Look_Down           : %d \n",cf->DMS_Act_Look_Down);
    printf("\n[VOUT] \n");
    printf("DRM_Module                  : %s \n",cf->DRM_Module);
    printf("VOUT_Display_Format         : %d \n",cf->VOUT_Display_Format);
    printf("VOUT_Display_Width          : %d \n",cf->VOUT_Display_Width);
    printf("VOUT_Display_Height         : %d \n",cf->VOUT_Display_Height);
    printf("VOUT_Pos_X                  : %d \n",cf->VOUT_Pos_X);
    printf("VOUT_Pos_Y                  : %d \n",cf->VOUT_Pos_Y);
    printf("\n[DEBUG] \n");
    printf("Debug_Enable                : %d \n",cf->Debug_Enable);
    printf("Logging                     : %d \n",cf->Logging);
    printf("Proc_Time                   : %d \n",cf->Proc_Time);
    printf("\n[File] \n");
    printf("Frame_File_Name ............: %s \n",cf->Frame_File_Name);
    printf("-------------------------------\n");
    return 0;
}
/**********************************************************************************************************************
 End of function  R_CustomizePrint
 *********************************************************************************************************************/

/**********************************************************************************************************************
* Function Name: CustomizeRangeCheck    
* Description  : Checking the range
* Arguments    : char * var               
* Arguments    : int val
* Arguments    : int min
* Arguments    : int max
* Return Value : ret                       
**********************************************************************************************************************/
static int CustomizeRangeCheck( char * var, int val, int min, int max)
{
    int ret = (val < min) ? (FAILED):((val > max) ? (FAILED):(SUCCESS));
    if (ret == 1)
    {
        printf ("Customize Validation failed for %s \n",var);
    }
    return ret;
}
/**********************************************************************************************************************
 End of function CustomizeRangeCheck
 *********************************************************************************************************************/
 
