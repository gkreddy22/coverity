#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include ".librvxtarget/ince/rvx_target/ui.h"
#include "debug_helper.h"
#include "generic_api_memory.h"
#include "rcv_impdrv.h"
#include "rcv_impdrv_extensions.h"

#ifndef MIN
#    define MIN(a, b) (((a) < (b)) ? (a) : (b))
#endif
#ifndef MAX
#    define MAX(a, b) (((a) > (b)) ? (a) : (b))
#endif

void subsystem_traceback(RCvIMPDRVCTL * rcvdrv_ctl, RCvUint core_info)
{
    const size_t backtrace = 64 * 4;
    const size_t readahead = 14 * 4;

    /* CNN */
    if (core_info & (1U << RCVDRV_CNN_START_CORE))
    {
        const uint32_t vcr0 = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_CNN_START_CORE, 0x0000U);
        const uint32_t clpc = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_CNN_START_CORE, 0x0028U);
        const uint32_t sacl = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_CNN_START_CORE, 0x0080U);

        cinfov("CNN: 0x%08x 0x%08x 0x%08x\n", (unsigned int)vcr0, (unsigned int)sacl, (unsigned int)clpc);

        {
            const uint32_t * s = gf_GetVirtAddr(MAX((uintptr_t)sacl, (uintptr_t)clpc - backtrace));
            const uint32_t * e = gf_GetVirtAddr((uintptr_t)clpc);

            for (uint32_t * p = s; p <= e; p++)
            {
                cinfov("CNN: 0x%08x: 0x%08x\n", (unsigned int)gf_GetPhysAddr(p), *p);
            }
        }
        cinfov("-- ^^STOP^^ --\n");
        {
            const uint32_t * s = gf_GetVirtAddr((uintptr_t)clpc + sizeof(uint32_t));
            const uint32_t * e = gf_GetVirtAddr((uintptr_t)clpc + readahead);

            for (uint32_t * p = s; p <= e; p++)
            {
                cinfov("CNN: 0x%08x: 0x%08x\n", (unsigned int)gf_GetPhysAddr(p), *p);
            }
        }
    }

    /* CVE */
    if (core_info & (1U << RCVDRV_OCV_START_CORE))
    {
        const uint32_t vcr   = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_OCV_START_CORE, 0x0000U);
        const uint32_t dlsar = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_OCV_START_CORE, 0x0180U);
        const uint32_t dlfar = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_OCV_START_CORE, 0x0194U);
        const uint32_t dleir = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_OCV_START_CORE, 0x0198U);

        const uint32_t vpcsar = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_OCV_START_CORE, 0x0320U);
        const uint32_t vibar  = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_OCV_START_CORE, 0x0340U);
        const uint32_t vspc   = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_OCV_START_CORE, 0x11C0U);

        cinfov("CVE: VCR=0x%08x DLSAR=0x%08x DLFAR=0x%08x DLEIR=0x%08x\n", (unsigned int)vcr, (unsigned int)dlsar, (unsigned int)dlfar, (unsigned int)dleir);
        cinfov("CVE: VPCSAR=0x%08x VIBAR=0x%08x (0x%08x) VSPC=0x%08x (0x%08x)\n",
               (unsigned int)vpcsar,
               (unsigned int)vibar,
               (unsigned int) * ((uint32_t *)gf_GetVirtAddr(vibar)),
               (unsigned int)vspc,
               (unsigned int) * ((uint32_t *)gf_GetVirtAddr(vibar + vspc)));

        {
            const uint32_t * s = gf_GetVirtAddr(MAX((uintptr_t)dlsar, (uintptr_t)dlfar - backtrace));
            const uint32_t * e = gf_GetVirtAddr((uintptr_t)dlfar);

            for (uint32_t * p = s; p <= e; p++)
            {
                cinfov("CVE: 0x%08x (0x%08x): 0x%08x\n", (unsigned int)gf_GetPhysAddr(p), (unsigned int)((uintptr_t)p - (uintptr_t)dlsar), *p);
            }
        }
        cinfov("-- ^^STOP^^ --\n");
        {
            const uint32_t * s = gf_GetVirtAddr(((uintptr_t)dlfar + sizeof(uint32_t)));
            const uint32_t * e = gf_GetVirtAddr(((uintptr_t)dlfar + readahead));

            for (uint32_t * p = s; p <= e; p++)
            {
                cinfov("CVE: 0x%08x (0x%08x): 0x%08x\n", (unsigned int)gf_GetPhysAddr(p), (unsigned int)((uintptr_t)p - (uintptr_t)dlsar), *p);
            }
        }
    }


    /* DMA */
    if (core_info & (1U << RCVDRV_DMAC_START_CORE))
    {
        const uint32_t vcr   = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_DMAC_START_CORE, 0x0000U);
        const uint32_t clsar = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_DMAC_START_CORE, 0x0028U);
        const uint32_t clfar = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_DMAC_START_CORE, 0x00C8U);
        const uint32_t cleir = rcvdrv_reg_read(rcvdrv_ctl, RCVDRV_DMAC_START_CORE, 0x00CCU);

        cinfov("DMA: 0x%08x 0x%08x 0x%08x 0x%08x\n", (unsigned int)vcr, (unsigned int)clsar, (unsigned int)clfar, (unsigned int)cleir);

        {
            const uint32_t * s = gf_GetVirtAddr(MAX((uintptr_t)clsar, (uintptr_t)clfar - backtrace));
            const uint32_t * e = gf_GetVirtAddr((uintptr_t)clfar);

            for (uint32_t * p = s; p <= e; p++)
            {
                cinfov("DMA: 0x%08x (0x%08x): 0x%08x\n", (unsigned int)gf_GetPhysAddr(p), (unsigned int)((uintptr_t)p - (uintptr_t)clsar), *p);
            }

        }
        cinfov("-- ^^STOP^^ --\n");
        {
            const uint32_t * s = gf_GetVirtAddr(((uintptr_t)clfar + sizeof(uint32_t)));
            const uint32_t * e = gf_GetVirtAddr(((uintptr_t)clfar + readahead));

            for (uint32_t * p = s; p <= e; p++)
            {
                cinfov("DMA: 0x%08x (0x%08x): 0x%08x\n", (unsigned int)gf_GetPhysAddr(p), (unsigned int)((uintptr_t)p - (uintptr_t)clsar), *p);
            }

        }
    }
}
