#include <assert.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cmath>

#include "include/drawHelper.h"
#include "include/timerHelper.h"

#include "rcar-xos/osal/r_osal.h"
#include "include/pb.h"
#include ".librvxtarget/ince/rvx_target/bcl.h"
#include ".librvxtarget/ince/rvx_target/csvHelper.h"
#include ".librvxtarget/ince/rvx_target/device_info.h"
#include ".librvxtarget/ince/rvx_target/filesystem.h"
#include ".librvxtarget/ince/rvx_target/osal_helper.h"
#include ".librvxtarget/ince/rvx_target/pnmHelper.h"
#include ".librvxtarget/ince/rvx_target/r_cl_patch.h"
#include ".librvxtarget/ince/rvx_target/r_cl_patch_cnn.h"
#include ".librvxtarget/ince/rvx_target/r_cl_patch_cve.h"
#include ".librvxtarget/ince/rvx_target/r_cl_patch_dma.h"
#include ".librvxtarget/ince/rvx_target/r_cl_patch_imp.h"
#include ".librvxtarget/ince/rvx_target/rvxt_bcl.h"
#include ".librvxtarget/ince/rvx_target/rvxt_execute.h"
#include ".librvxtarget/ince/rvx_target/rvxt_md5.h"
#include ".librvxtarget/ince/rvx_target/ui.h"
#include "include/osal_debug.h"

#include "include/cnnip_target_project.h"
#include "include/helper.h"
#include "common.h"
#include "rcar-xos/rcar_xos_config.h"

#ifdef NDEBUG
#    define BUILD_TYPE_STRING "RELEASE"
#else
#    define BUILD_TYPE_STRING "DEBUG"
#endif   //NDEBUG


#if !defined(RCAR_XIL_SIL)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wstringop-truncation"
#endif

/* OSAL API*/
//#include "rcar-xos/impspm_mmngr/r_impspm_mmngr.h"

#if defined(__linux__) || defined(__QNX__)
#include <time.h>
#endif

#if defined(RCAR_XIL_SIL)
#ifndef MIN
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) > (bconst uint8_t *ptr = (const uint8_t *)data)) ? (a) : (b))
#endif
#endif

#define MAX_CL_NUMBER 32 //maximum number of command lists

#define elementsof(e) (sizeof(e) / sizeof(e[0]))

/*globals*/
static MemoryList * p_memoryList;
static ChannelSetupList  * p_channelSetupList;
static Commandlist * p_commandlists;
static rvxt_info_pb_t pbinfo;
static Cfg cfg = {1, 1, 1, 0, false, 0xFF000000U, g_customize.AI_Model_Name, "PGM,CSV,MD5", ".", true, 0, 5000, false, false, false}; /* global configuration */
static size_t commandlistCount                 = 0;
static const uint32_t memories_alloc_alignment = 4096;
static const uint32_t cl_alloc_alignment       = 4096;
//osal_memory_manager_handle_t osal_mmngr      = OSAL_MEMORY_MANAGER_HANDLE_INVALID;
static osal_axi_bus_id_t imp_dev_axi_bus_id    = OSAL_AXI_BUS_ID_INVALID;
cl_bundle_v3::cl_bundle_msg model;
_CnnChannelDetails CnnChannelDetails[NUM_CNN_CHANNELS]= {0};

extern bool fix_V3U1 (void);

//static void dumpMemoryContents (Cfg *cfg, MemoryList *list, bool no_detailed_dumping); // defination needs to be updated
static void zeroMemories (MemoryList * p_list);
static void flushMemories (MemoryList * p_list, const uint32_t memories_alloc_alignment);
static void invalidateMemories (MemoryList * p_list, const uint32_t memories_alloc_alignment);

static void allocateMemories (MemoryList * p_list, osal_axi_bus_id_t imp_dev_axi_bus_id, osal_memory_manager_handle_t handle_osalmmngr);
static bool loadCommandLists (const rvxt_info_pb_t * const pb_info, const char * p_filename, Commandlist ** p_commandlists, size_t * commandlistCount, osal_axi_bus_id_t imp_dev_axi_bus_id);
static bool fixBaseCL (const rvxt_info_pb_t * pb_info, Commandlist * p_commandlists, size_t const count, Cfg * cfg);
static void fixAddresses (const rvxt_info_pb_t * pb_info, Commandlist * p_commandlists, size_t const count, MemoryList * list);
static void multiplyCLsCOPY (Commandlist * p_commandlists, size_t const count, unsigned int const multiplier, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, const uint32_t cl_alloc_alignment);
static void multiplyCLsGOSUB (Commandlist * p_commandlists, size_t const count, unsigned int const multiplier, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, const uint32_t cl_alloc_alignment);
// static void moveCLs2addr (Commandlist* p_commandlists, size_t const count, uintptr_t const addr, osal_memory_manager_handle_t osal_mmngr, osal_axi_bus_id_t imp_dev_axi_bus_id);
static void flushCommandlists (Commandlist * p_commandlists, size_t const count, const uint32_t cl_alloc_alignment);
static void dumpCLs (Commandlist * p_commandlists, size_t const count);
static unsigned int popcount (unsigned int x);

static void flushRange (osal_memory_buffer_handle_t img_buffer, const size_t size);
static void invalidateRange (osal_memory_buffer_handle_t img_buffer, const size_t size);

static void freeCommandLists (Commandlist * p_commandlists, size_t count, osal_memory_manager_handle_t handle_osalmmngr);

static osal_memory_buffer_handle_t getbufobj (uint32_t physaddr, MemoryList * list, uint32_t * offset);

static bool getDriverActivity ();
static _driverActivity getHighestActivity(int curr_activity);

osal_memory_buffer_handle_t getbufobj(uint32_t physaddr, MemoryList * list, uint32_t * offset)
{
    MemoryListIterator * it = memoryListIteratorGet(list);

    while (NULL != it)
    {
        MemoryListEntry * e = memoryListIteratorGetValue(list, it);
        //cinfov("addressNew: %p, size: %08x, physaddr: %08x\n", (void*)e->addressNew, e->size, physaddr);   // XXX: DEBUG

        if (e->addressNew <= physaddr && physaddr < e->addressNew + e->size)
        {
            *offset = (uint32_t)(physaddr - e->addressNew);
            //cinfov("offset: %08x\n", *offset);   // XXX: DEBUG
            return e->base_new_buffer;
        }

        it = it->next;
    }

    return OSAL_MEMORY_BUFFER_HANDLE_INVALID;
}

void dumpRaw(const char * filename, const void * data, const size_t size)
{
#if defined(__linux__) || defined(__QNX__) || defined(__WIN64) || defined(__WIN32)
    FILE * fp = fopen(filename, "wb");

    if (NULL != fp)
    {
        fwrite(data, size, 1, fp);
        fclose(fp);
    }

#endif
}

void * memset_u32(void * const destination, const uint32_t pattern, size_t size)
{
    uint32_t * p = (uint32_t *)destination;

    while (size--)
    {
        *p++ = pattern;
    }

    return destination;
}

typedef struct
{
    uintptr_t old;     /* old physical address */
    uintptr_t newAddr; /* new physical address */
    size_t    size;       /* size of address range */
} linker_entry_t;

linker_entry_t linkerTable[4];
/* 0:CNN-CL, 1:DMA-CL, 2:IMPC, 3:DDR0, ... */

struct parameters
{
    int argc;
    char ** argv;
};

extern void pbParse (Cfg cfg, rvxt_info_pb_t * pbinfo, cl_bundle_v3::cl_bundle_msg &model, osal_memory_manager_handle_t handle_osalmmngr, Commandlist ** p_commandlists);
static bool pb_print (const rvxt_info_pb_t * pb_info);
static bool pb_alloc (const rvxt_info_pb_t * pb_info, MemoryList * list, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, const uint32_t memories_alloc_alignment);
static bool pb_setupInputMemories (const rvxt_info_pb_t * const pb_info, MemoryList * list, const uint32_t memories_alloc_alignment);

bool pb_fixMemoryAddresses(const rvxt_info_pb_t * pb_info, const uintptr_t base_old, const uintptr_t base_new, const size_t base_size)
{
    size_t memory_entry_count = pb_info->entry_memories_count;
    size_t memory_exit_count  = pb_info->exit_memories_count;

    for (size_t i = 0; i < memory_entry_count; i++)
    {
        const uintptr_t address_old = pb_info->entry_memories[i].base;

        if ((address_old >= base_old) && (address_old < (base_old + base_size)))
        {
            const uintptr_t address_new     = base_new + address_old - base_old;
            pb_info->entry_memories[i].base = (unsigned int)address_new;
        }

    }

    for (size_t j = 0; j < memory_exit_count; j++)
    {
        const uintptr_t address_old = pb_info->exit_memories[j].base;

        if ((address_old >= base_old) && (address_old < (base_old + base_size)))
        {
            const uintptr_t address_new    = base_new + address_old - base_old;
            pb_info->exit_memories[j].base = (unsigned int)address_new;
        }

    }

    return true;
}

/*!
 * @brief Apply all address re-mappings to Pb file
 * @param pbinfo_mem
 * @param list
 */
static void fixAddressesPb(const rvxt_info_pb_t * pbinfo, MemoryList * list)
{
    MemoryListIterator * it = memoryListIteratorGet(list);

    while (NULL != it)
    {
        MemoryListEntry * e = memoryListIteratorGetValue(list, it);

        pb_fixMemoryAddresses(pbinfo, e->addressOld, e->addressNew, e->size);

        it = it->next;
    }

}

/* ASDCNNTOOLRC-702 - pb_print function has been modified to fetch memory, entry_memory and exit_memory data
* from rvxt_info_pb_t structure instead of the bcl structure.
*/
static bool pb_print(const rvxt_info_pb_t * pb_info)
{

    if (NULL == pb_info)
    {
        return false;
    }

    bool result = true;

    // ASDCNNTOOLRC-702 - Printing memory resources data from pb_memres_info_t structure in pb_info
    for (size_t i = 0; i < pb_info->memory_ressources_count; i++)
    {
        cinfov("Physical address range at 0x%08x, size 0x%08x: ", (unsigned int)pb_info->memory_ressources[i].startaddress, (unsigned int)pb_info->memory_ressources[i].size);

        /* checking if the start address is in the range of IMPC */
        if (IS_IMPC(pb_info->memory_ressources[i].startaddress))
        {
            DEBUG_PRINT("IMPC [OK].\n");
        }
        else if (IS_IMPC_SHADOW(pb_info->memory_ressources[i].startaddress))
        {
            DEBUG_PRINT("IMPC shadow area [OK].\n");
        }
        else if (IS_IMP(pb_info->memory_ressources[i].startaddress))
        {
            DEBUG_PRINT("IMP subsystem area [OK].\n");
        }
        else
        {
            DEBUG_PRINT("assuming DDR.\n");
        }
    }

    //ASDCNNTOOLRC-702 - Printing entry_memory data from pb_mem_info_t structure in pb_info
    for (size_t i = 0; i < pb_info->entry_memories_count; i++)
    {

        if (0 != pb_info->entry_memories[i].name && pb_info->entry_memories[i].init_data_size > 0)
        {
            DEBUG_PRINT(" MD5 (payload): ");
            void * p_virt = (void *)pb_info->entry_memories[i].init_data;
            const size_t size   = (pb_info->entry_memories[i].size);
            const size_t width  = pb_info->entry_memories[i].tile.width;
            const size_t height = pb_info->entry_memories[i].tile.height * pb_info->entry_memories[i].channelCnt;
            const size_t stride = pb_info->entry_memories[i].tile.stride;
            unsigned int bytesPerPixel = pb_info->entry_memories[i].tile.bitpp / 8;

            bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);

            if (!match)
            {
                DEBUG_PRINT("\n");
                cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n",
                          (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
                rvxt_md5Dump(stdout, p_virt, size);
                DEBUG_PRINT("', new: '");
                rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
                DEBUG_PRINT("'");
            }
        }
    }

    // ASDCNNTOOLRC-702 - Printing exit_memory data from pb_mem_info_t structure in pb_info
    for (size_t i = 0; i < pb_info->exit_memories_count; i++)
    {

        if (0 != pb_info->exit_memories[i].name && pb_info->exit_memories[i].init_data_size > 0)
        {
            DEBUG_PRINT(" MD5 (payload): ");
            void * p_virt       = (void *)pb_info->exit_memories[i].init_data;
            const size_t size   = (pb_info->exit_memories[i].size);
            const size_t width  = pb_info->exit_memories[i].tile.width;
            const size_t height = pb_info->exit_memories[i].tile.height * pb_info->exit_memories[i].channelCnt;
            const size_t stride = pb_info->exit_memories[i].tile.stride;
            unsigned int bytesPerPixel = pb_info->exit_memories[i].tile.bitpp / 8;

            bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);

            if (!match)
            {
                DEBUG_PRINT("\n");
                cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n",
                          (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
                rvxt_md5Dump(stdout, p_virt, size);
                DEBUG_PRINT("', new: '");
                rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
                DEBUG_PRINT("'");
            }
        }

        DEBUG_PRINT("\n");
    }

    return result;
}

bool check_entry_memories(const rvxt_info_pb_t * pbinfo, const bool verbose, MemoryList * list)
{
    bool result = true;

    for (size_t i = 0; i < pbinfo->entry_memories_count; i++)
    {
        pb_mem_info_t entry = pbinfo->entry_memories[i];
        
        const char * p_name = entry.name;
        const uintptr_t dest = (uintptr_t)entry.base;

        void * p_virt = NULL;
        uint32_t offset;
        osal_memory_buffer_handle_t bufobj = getbufobj((uint32_t)dest, list, &offset);

        if (bufobj != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
        {
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufobj, &p_virt)));

            p_virt = ((char *)p_virt + offset);
        }

        if (NULL != p_virt)
        {
            int ret = memcmp(p_virt, (void *)((uintptr_t)entry.init_data), entry.size);

            if ((0 != ret) || (!result))
            {
                cwarningv("Entry mem: '%s' (@0x%08x): ", p_name, (unsigned int)dest);
                DEBUG_PRINT("[!!], ");
                result = false;
            }
            else
            {
                if (verbose)
                {
                    cinfov("Entry mem: '%s' (@0x%08x): ", p_name, (unsigned int)dest);
                    DEBUG_PRINT("[OK], ");
                }
            }

            if ((!result) || verbose)
            {
                DEBUG_PRINT("MD5: ");
                const size_t size   = entry.size;
                const size_t width  = entry.tile.width;
                const size_t height = entry.tile.height;
                const size_t stride = entry.tile.stride;
                unsigned int bytesPerPixel = entry.tile.bitpp / 8;

                const bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);

                if (!match)
                {
                    DEBUG_PRINT("\n");
                    cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n", (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
                    rvxt_md5Dump(stdout, p_virt, size);
                    DEBUG_PRINT("', new: '");
                    rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
                    DEBUG_PRINT("'");
                }

                DEBUG_PRINT("\n");
            }
        }
        else
        {

            if (IS_IMPC(dest) || IS_IMPC_SHADOW(dest) || IS_IMP(dest))
            {
                cinfov("Address resolution failed for '%s' in IMPC (mem->destination = 0x%08x), may be okay for DUMMY regions!\n", p_name, (unsigned int)dest);
            }
            else
            {
                cerrorv("Address resolution failed for '%s' mem->destination = 0x%08x!\n", p_name, (unsigned int)dest);
                return false;
            }
        }
    }

    return result;
}

bool check_exit_memories(const rvxt_info_pb_t * pbinfo, const bool verbose, MemoryList * list)
{
    bool result = true;

    for (size_t i = 0; i < pbinfo->exit_memories_count; i++)
    {
        pb_mem_info_t exit = pbinfo->exit_memories[i];
        const char * p_name = exit.name;
        const uintptr_t base = (uintptr_t)exit.base;
        void * p_virt = NULL;
        uint32_t offset;
        osal_memory_buffer_handle_t bufobj = getbufobj((uint32_t)base, list, &offset);

        DEBUG_PRINT("\r\n ___- exit file name :%s\n", pbinfo->exit_memories[i].name);

        if (0 != strcmp(pbinfo->exit_memories[i].name, g_customize.Inference_Output_File))
        {
            continue;
        }

        if (bufobj != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
        {
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufobj, &p_virt)));

            p_virt = ((char *)p_virt + offset);
        }

        if (NULL != p_virt)
        {
            if (exit.init_data_size > 0)
            {
                int ret = memcmp(p_virt, (void *)((uintptr_t)exit.init_data), exit.size);

                if (0 != ret)
                {
                    cwarningv("Exit mem: '%s' (@0x%08x): ", p_name, (unsigned int)base);
                    DEBUG_PRINT("[!!], ");
                    result = false;
                }
                else
                {
                    if (verbose)
                    {
                        cinfov("Exit mem: '%s' (@0x%08x): ", p_name, (unsigned int)base);
                        DEBUG_PRINT("[OK], ");
                    }
                }
            }
            else
            {
                if (verbose)
                    cwarningv("Exit mem: '%s' (@0x%08x): [??], no data provided.", p_name, (unsigned int)base);
            }

            if (((!result) || verbose) && exit.init_data_size > 0)
            {
                const size_t size   = exit.size;
                const size_t width  = exit.tile.width;
                const size_t height = exit.tile.height;
                const size_t stride = exit.tile.stride;
                unsigned int bytesPerPixel = exit.tile.bitpp / 8;

                const bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);

                if (!match)
                {
                    DEBUG_PRINT("\n");
                    cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n",
                              (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
                    rvxt_md5Dump(stdout, p_virt, size);
                    DEBUG_PRINT("', new: '");
                    rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
                    DEBUG_PRINT("'");
                }

                DEBUG_PRINT("\n");
            }
            break;
        }
        else
        {

            if (IS_IMPC(base) || IS_IMPC_SHADOW(base) || IS_IMP(base))
            {
                cinfov("Address resolution failed for '%s' in IMPC (mem->destination = 0x%08x), may be okay for DUMMY regions!\n", p_name, (unsigned int)base);
            }
            else
            {
                cerrorv("Address resolution failed for '%s' mem->destination = 0x%08x!\n", p_name, (unsigned int)base);
                return false;
            }
        }
    }

    return result;
}

/* ASDCNNTOOLRC-702 - pb_alloc function has been modified to fetch memory resource data 
* from rvxt_info_pb_t structure instead of the bcl structure.
*/
static bool pb_alloc(const rvxt_info_pb_t * pb_info, MemoryList * list, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, const uint32_t memories_alloc_alignment)
{
    size_t memres_count = pb_info->memory_ressources_count;

    for (size_t i = 0; i < memres_count; i++)
    {
        size_t          base_size = pb_info->memory_ressources[i].size;
        const uintptr_t base_old  = pb_info->memory_ressources[i].startaddress;

        cinfov("Physical address range at 0x%08x, size 0x%08x: ", (unsigned int)base_old, (unsigned int)base_size);

        if (IS_IMPC(base_old))
        {
            DEBUG_PRINT("IMPC [OK].\n");
        }
        else if (IS_IMPC_SHADOW(base_old))
        {
            DEBUG_PRINT("IMPC SHADOW [OK].\n");
        }
        else if (IS_IMP(base_old))
        {
            DEBUG_PRINT("IMP subsystem area [OK].\n");
        }
        else
        {
            MemoryListEntry entry;
            void * base_new_phys = NULL;
            unsigned int ret = R_OSAL_MmngrAlloc(handle_osalmmngr, base_size + memories_alloc_alignment - base_size % memories_alloc_alignment, memories_alloc_alignment, &entry.base_new_buffer);

            if (ret != OSAL_RETURN_OK)
            {
                DEBUG_PRINT("rvxt_bcl_alloc: R_OSAL_MmngrAlloc error code: %d\n", ret);
                return ret;
            }

            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(entry.base_new_buffer, &base_new_phys)));

            if (NULL != base_new_phys)
            {
                uintptr_t base_new = 0;
                ret = OSAL_RETURN_FAIL;
                CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetHwAddr(entry.base_new_buffer, imp_dev_axi_bus_id, &base_new)));

                entry.size         = base_size;
                entry.addressNew   = base_new;
                entry.addressOld   = base_old;
                entry.memres_index = (unsigned int)i;
                memoryListInsertSorted(list, &entry);

                if (base_old == base_new)
                {
                    DEBUG_PRINT("Allocated same range: 0x%08x, size=0x%08x\n", (unsigned int)base_old, (unsigned int)base_size);
                }
                else
                {
                    //r_cl_patch_CNN(&pb_info, base_old, base_new, base_size, false);
                    DEBUG_PRINT("Failed to allocate same range: 0x%08x -> 0x%08x, size=0x%08x\n", (unsigned int)base_old, (unsigned int)base_new, (unsigned int)base_size);
                    pb_info->memory_ressources[i].startaddress = (unsigned int)base_new;
                    pb_fixMemoryAddresses(pb_info, base_old, base_new, base_size);
                }
            }
            else
            {
                cerror("Failed to allocate memory!\n");
                return false;
            }
        }
    }

    return true;
}

/* ASDCNNTOOLRC-702 - pb_setupInputMemories function has been modified to fetch data 
* from rvxt_info_pb_t structure instead of the bcl structure.
*/
static bool pb_setupInputMemories(const rvxt_info_pb_t * pb_info, MemoryList * list, const uint32_t memories_alloc_alignment)
{
    if (NULL == pb_info)
    {
        return false;
    }

    bool result = true;

    if (result)
    {
        for (unsigned int i = 0; i < pb_info->entry_memories_count; i++)
        {

            void * p_virt = NULL;
            uint32_t offset;
            osal_memory_buffer_handle_t bufobj = getbufobj(pb_info->entry_memories[i].base, list, &offset);

            if (bufobj != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
            {
                CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufobj, &p_virt)));

                p_virt = ((char *)p_virt + offset);
            }

            if (1)
                DEBUG_PRINT("Entry memory content for 0x%08x, size 0x%08x, height 0x%08x, width 0x%08x\n",
                       pb_info->entry_memories[i].base,
                       pb_info->entry_memories[i].size,
                       pb_info->entry_memories[i].tile.height,
                       pb_info->entry_memories[i].tile.width);

            if (NULL == p_virt)
            {
                const char * p_name = pb_info->entry_memories[i].name;

                if (IS_IMPC(pb_info->entry_memories[i].base) || IS_IMPC_SHADOW(pb_info->entry_memories[i].base) || IS_IMP(pb_info->entry_memories[i].base))
                {
                    cinfov("Address resolution failed for '%s' in IMPC (mem->destination = 0x%08x), may be okay for DUMMY regions!\n", p_name, (unsigned int)pb_info->entry_memories[i].base);
                }
                else
                {
                    cerrorv("Address resolution failed for '%s' mem->destination = 0x%08x!\n", p_name, (unsigned int)pb_info->entry_memories[i].base);
                    return false;
                }
            }
            else
            {
                memcpy(p_virt, (void *)(uintptr_t)pb_info->entry_memories[i].init_data, pb_info->entry_memories[i].init_data_size);
                CHECK_OK(OSAL_CHECK(R_OSAL_MmngrFlush(bufobj, 0, pb_info->entry_memories[i].init_data_size + memories_alloc_alignment - pb_info->entry_memories[i].init_data_size % memories_alloc_alignment)));
            }
        }
    }

    return result;
}

extern "C" int cnn_application_init ();
int cnn_application_init()
{
    bool bRetVal = false;
    p_memoryList = memoryListCreate();
    mem_t IMPC;
    IMPC.virt = NULL;
    IMPC.phys = IMPC_BASE;
    IMPC.size = IMPC_SIZE;
    p_channelSetupList  = channelSetupListCreate();
    e_osal_return_t ret = OSAL_RETURN_FAIL;
    
    do
    {
        ret = OSAL_CHECK(R_OSAL_IoGetAxiBusIdFromDeviceName("imp_top_00", &imp_dev_axi_bus_id)); //cnn_0 device where to run

        if (ret != OSAL_RETURN_OK)
        {
            PRINT_ERROR("CNN_INIT Get Axi bus ID from device name failed \n");
            break;
        }

        bRetVal = fillChannelSetupList(p_channelSetupList);
        if (false == bRetVal)
        {
           PRINT_ERROR("CNN_INIT Fill channel setuplist failed \n");
            break;
        }

        if (channelSetupListSize(p_channelSetupList) > 0)
        {
            cinfo("Additional data for memory setup:\n");
            channelSetupListPrint(p_channelSetupList);
        }
        else
        {
            bRetVal = false;
            PRINT_ERROR("CNN_INIT Fillchannel setuplist failed \n");
            break;
        }

        p_commandlists = (Commandlist *)calloc(MAX_CL_NUMBER, sizeof(Commandlist));

        pbParse(cfg, &pbinfo, model, handle_osalmmngr, &p_commandlists);

        if (NULL == cfg.fileNamePb)
        {
            PRINT_ERROR("CNN_INIT No PB file provided \n");
            bRetVal = false;
            break;

        }

        bRetVal = loadCommandLists(&pbinfo, cfg.fileNamePb, &p_commandlists, &commandlistCount, imp_dev_axi_bus_id);
        if (false == bRetVal)
        {
            PRINT_ERROR("CNN_INIT Load commadlist failed \n");
            break;
        }

        bRetVal = fixBaseCL(&pbinfo, p_commandlists, commandlistCount, &cfg);
        if (false == bRetVal)
        {
            PRINT_ERROR("CNN_INIT fix base CL failed \n");
            break;
        }

        if (cfg.fakeIMPCinDDR)
        {
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrAlloc(handle_osalmmngr, IMPC.size, 4096, &IMPC.mem_buffer)));

            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(IMPC.mem_buffer, &IMPC.virt)));

            cinfo("Patching CNN-IP CL to not use IMPC:\n");

            uintptr_t impc_phys = 0;
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetHwAddr(IMPC.mem_buffer, imp_dev_axi_bus_id, &impc_phys)));

            /* add entry to memory map */
            MemoryListEntry entry;
            entry.size            = IMPC.size;
            entry.addressNew      = impc_phys;
            entry.addressOld      = IMPC.phys;
            entry.base_new_buffer = IMPC.mem_buffer;
            memoryListInsertSorted(p_memoryList, &entry);

            /* change pointer */
            IMPC.phys = impc_phys;
        }

        /* Determine memory regions */
        bool doAutodetetction = true;

        bRetVal = pb_print(&pbinfo); // cfg.verbosity); //todo debug for pb parse

        if (false == bRetVal)
        {
            PRINT_ERROR("CNN_INIT pb print failed \n");
            break;
        }

        bRetVal = pb_alloc(&pbinfo, p_memoryList, handle_osalmmngr, imp_dev_axi_bus_id, memories_alloc_alignment);
        if (false == bRetVal)
        {
            PRINT_ERROR("CNN_INIT pb alloc failed \n");
            break;
        }

        if (0 != memoryListSize(p_memoryList))
        {
            cinfo("The following regions were defined by PB:\n");
            memoryListPrint(p_memoryList);
            doAutodetetction = false;
        }

        if (doAutodetetction)
        {
            //TODO:FIXME: r_cl_CNN_FindRangesUsed(CNN0.virt, memoryList, 1024*1024*4, false);

            if (0 != memoryListSize(p_memoryList))
            {
                allocateMemories(p_memoryList, imp_dev_axi_bus_id, handle_osalmmngr);
                cinfo("The following regions were defined after autodetection:\n");
                memoryListPrint(p_memoryList);
            }
        }

        /* Fix addresses */
        cinfo("Fixing memory addresses in PB file...\n");
        fixAddressesPb(&pbinfo, p_memoryList);

        cinfo("Fixing memory addresses in command lists ...\n");
        fixAddresses(&pbinfo, p_commandlists, commandlistCount, p_memoryList);

        /* Multiply CLs */
        if (cfg.clxN > 1)
        {
            cinfov("Multiplying command lists %u times by physical copy...\n", cfg.clxN);
            multiplyCLsCOPY(p_commandlists, commandlistCount, cfg.clxN, handle_osalmmngr, imp_dev_axi_bus_id, cl_alloc_alignment);
        }

        if (cfg.clxM > 1)
        {
            cinfov("Multiplying command lists %u times by gosub routines...\n", cfg.clxM);
            multiplyCLsGOSUB(p_commandlists, commandlistCount, cfg.clxM, handle_osalmmngr, imp_dev_axi_bus_id, cl_alloc_alignment);
        }

        /* Flush CLs, will be done prior to execution anyways ... */
        flushCommandlists(p_commandlists, commandlistCount, cl_alloc_alignment);

        /* Dump CLs after patching for debugging */
        if (cfg.dumpCLs)
        {
            cinfo("Dumping CLs after patching for debugging...\n");
            dumpCLs(p_commandlists, commandlistCount);
        }

        cinfo("Running CLs:\n");

        /* resetting memory */
        cinfo("Zeroing memories...\n");
        zeroMemories(p_memoryList);

        /* use BCL data to set up input memories*/
        bRetVal &= pb_setupInputMemories(&pbinfo, p_memoryList, memories_alloc_alignment);

        if (bRetVal)
        {
            const bool ret = check_entry_memories(&pbinfo, false, p_memoryList);

            if (!ret)
            {
                cerror("Checking entry memories failed, this might be a problem. Continuing anyway...\n");
            }
        }
        
        bRetVal &= setupChannels(&pbinfo, p_channelSetupList, p_memoryList, CnnChannelDetails, NUM_CNN_CHANNELS);
        if(bRetVal)
        {
            bRetVal &= impdrv_start(commandlistCount,cfg.DTAenabled,p_commandlists, handle_osalmmngr, imp_dev_axi_bus_id);
        }

    } while (0);

     return bRetVal ? 0 : -1;
}

extern "C" int cnn_application_exec();
int cnn_application_exec()
{
    
    bool ok = true;
    do
    {
        ok = R_CNN_entrychannels_set(CnnChannelDetails, NUM_CNN_CHANNELS);
        if (!ok)
        {
            PRINT_ERROR("CNN_EXECUTE entry channel failed \n");
            break;
        }
        //memories and memeries metadata flush
        flushMemories(p_memoryList, memories_alloc_alignment);

        /* run cl */
        rvxt_cb_mem_t cb_mem;
        cb_mem.malloc     = NULL;
        cb_mem.free       = NULL;
        cb_mem.getPhys    = NULL;
        cb_mem.getVirt    = NULL;
        cb_mem.flush      = NULL;
        cb_mem.invalidate = NULL;

        if (ok)
        {
            ok &= executeCommandlists(p_commandlists, commandlistCount, &cb_mem, (cfg.clxN * cfg.clxM), handle_osalmmngr, imp_dev_axi_bus_id, cfg.timeout_ms, cl_alloc_alignment, cfg.DTAenabled);

        }

        if (!ok)
        {
            PRINT_ERROR("CNN_EXECUTE execute command list failed \n");
            break;
            
        }

        #if defined(RCAR_SOC_V3H1) && defined(RCAR_XIL_HIL)
        /* Check if there was a V3H IMPC bug related crash */

        if (!ok)
        {
            printf("\nCrash detected. Checking IMPC-bank availability:\n");

            for (int bank_nr = 0; bank_nr < 16; bank_nr++)
            {
                DEBUG_PRINT("Bank nr: %i:\n", bank_nr);
                void * IMPC_bank;
                osal_memory_buffer_handle_t handle = (osal_memory_buffer_handle_t)((uintptr_t)0xed000000 + (uintptr_t)bank_nr * (uintptr_t)0x00020000);
                OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(handle, &IMPC_bank));

                DEBUG_PRINT("reading  check: passed! (value @ %p = %04x) \n", IMPC_bank, * (uint8_t *)IMPC_bank);
                memset(IMPC_bank, 0xDD, 16 * 16 * sizeof(uint8_t));
                DEBUG_PRINT("writing  check: passed! (value @ %p = %04x) \n", IMPC_bank, * (uint8_t *)IMPC_bank);
                memset(IMPC_bank, 0xBB, 16 * 16 * sizeof(uint8_t));
                OSAL_CHECK(R_OSAL_MmngrInvalidate(handle, 0, 16 * 16));

                DEBUG_PRINT("cacheInv check: passed! (value @ %p = %04x) \n", IMPC_bank, * (uint8_t *)IMPC_bank);
            }

            DEBUG_PRINT("All tests passed! \n");
        }
        #endif
        //memories invalidation
        invalidateMemories(p_memoryList, cl_alloc_alignment);

        if (ok)
        {
            ok &= check_exit_memories(&pbinfo, false, p_memoryList);
        }
        if (!ok)
        {
            PRINT_ERROR("CNN_EXECUTE entry channel failed \n");
            break;
        }
        else
        {
            ok &=  getDriverActivity();
        }
        cinfo("Done!\n");
    } while (0);

    return ok ? 0 : -1;
}

static bool getDriverActivity()
{
    bool retValue = false;
    char filepath[DATA_LEN_128];
    char filename[DATA_LEN_128];
    size_t out_index = 0;

    size_t index       = 0;
    pb_mem_info_t exit = pbinfo.exit_memories[index];

    for (unsigned int i = 0; i < pbinfo.exit_memories_count; i++) 
    {
        char * p_name = exit.name;

        if ((strstr(p_name, "(") != NULL && strstr(p_name, ")") != NULL) || (strstr(p_name, "weights") != NULL))
        {
            exit = pbinfo.exit_memories[++index];
            continue;
        }

        if (NULL != p_name)
        {
#ifdef __linux__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wstringop-truncation"
#endif
            strncpy(filename, p_name, sizeof(filename) / sizeof(filename[0]));
#ifdef __linux__
#pragma GCC diagnostic pop
#endif
        }
        else
        {
            snprintf(filename, sizeof(filename) / sizeof(filename[0]), "output_%02u", (unsigned int)index);
        }

        if (0 != strcmp(filename, g_customize.Inference_Output_File))
        {
            exit = pbinfo.exit_memories[++index];
            continue;
        }

        retValue = true;
        const uintptr_t base = exit.base;
        void * p_data        = NULL;

        uint32_t offset = 0;
        osal_memory_buffer_handle_t bufobj = getbufobj(exit.base, p_memoryList, &offset);

        if (bufobj != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
        {
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufobj, &p_data)));
        }

        if (NULL != p_data)
        {
            void * p_newPdata = ((char *)p_data + offset);
            uint16_t * p_data = ( uint16_t *)p_newPdata;
            exit.tile.height  = (uint16_t)(exit.tile.height * exit.channelCnt);

            uint16_t max = 0;

            for (size_t y = 0; y < exit.tile.height; y++)
            {
                DEBUG_PRINT("index values of [%d] = ", y);

                for (size_t x = 0; x < exit.tile.width; x++)
                {
                    DEBUG_PRINT("[%d] ",p_data[y]);

                    if (p_data[y] > max)
                    {
                        max = p_data[y];
                        out_index = y;
                    }
                }

                DEBUG_PRINT("\n");
            }
            
            det_accuracy = (max * 100) / pow(2,7);
            
            if (det_accuracy > 60)
            {  
                driverActivity = getHighestActivity(out_index);
            }
            else
            {
                driverActivity = eNone;
            }

            printf("Current Activity: %d, Prediction: %d%, Predicted Activity: %d \n", out_index, det_accuracy, driverActivity);

            break;
    #ifdef __linux__
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wstringop-truncation"
    #endif
    #ifdef __linux__
    #pragma GCC diagnostic pop
    #endif
        }
        else
        {
            if (IS_IMPC(base) || IS_IMPC_SHADOW(base) || IS_IMP(base))
            {
                cinfov("Address resolution failed for '%s' in IMPC (entry->destination = 0x%08x), may be okay for DUMMY regions!\n", p_name, (unsigned int)base);
            }
            else
            {
                cerrorv("Address resolution failed for '%s' entry->destination = 0x%08x!\n", p_name, (unsigned int)base);
            }
        }
            exit = pbinfo.exit_memories[++index];
    }


    return retValue;
}

static _driverActivity getHighestActivity(int curr_activity)
{

    const unsigned int det_max = 0;
    static unsigned int det_count = 0;
    static int prev_activity = -1;

    _driverActivity activity = eNone;
    if(prev_activity == curr_activity)
    {
        det_count++;
    }
    else
    {
        det_count = 0;
    }
    prev_activity = curr_activity;
    if(det_count >= det_max){
        activity = (_driverActivity)curr_activity;
    }

    return activity;
}

/*!
 * @brief Apply all address re-mappings to p_commandlists
 * @param p_commandlists
 * @param count
 * @param list
 */
static void fixAddresses(const rvxt_info_pb_t * pb_info, Commandlist * p_commandlists, size_t const count, MemoryList * list)
{
    for (unsigned int itr = 0; itr < pb_info->subnet_cout; itr++)
    {
        MemoryListIterator * it = memoryListIteratorGet(list);

        while (NULL != it)
        {
            MemoryListEntry * entry = memoryListIteratorGetValue(list, it);

            for (size_t i = 0; i < count; i++)
            {
                r_cl_patch_core_t const core = p_commandlists[i].core;

                cinfov("Fixing addresses for CL[%u], core: %u\n", (unsigned int)i, (unsigned int)core);

                switch (core)
                {
                case CORE_TYPE_CNN:

                    if (pb_info->subnet_info[itr].cmdlistinfo[i].cl_data_size == 0)
                    {
                        r_cl_patch_CNN(p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);
                        r_cl_patch_CNN_patchGOSUB(p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);
                    }
                    else
                    {
                        pb_cl_patch_CNN(pb_info->subnet_info[itr].cmdlistinfo[i], p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);
                        pb_cl_patch_CNN_patchGOSUB(pb_info->subnet_info[itr].cmdlistinfo[i], p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);
                    }

                    break;
                case CORE_TYPE_DMA:

                    if (pb_info->subnet_info[itr].cmdlistinfo[i].cl_data_size == 0)
                        r_cl_patch_DMA(p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);
                    else
                        pb_cl_patch_DMA(pb_info->subnet_info[itr].cmdlistinfo[i], p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);

                    break;
                case CORE_TYPE_OCV:

                    if (pb_info->subnet_info[itr].cmdlistinfo[i].cl_data_size == 0)
                        r_cl_patch_CVE(p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);
                    else
                        pb_cl_patch_CVE(pb_info->subnet_info[itr].cmdlistinfo[i], p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);

                    break;
                case CORE_TYPE_IMP:

                    if (pb_info->subnet_info[itr].cmdlistinfo[i].cl_data_size == 0)
                        r_cl_patch_IMP(p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);
                    else
                        pb_cl_patch_IMP(pb_info->subnet_info[itr].cmdlistinfo[i], p_commandlists[i].virt, entry->addressOld, entry->addressNew, entry->size, false);

                    break;
                default:
                    cerror("Unknown CL type!\n");
                }
            }

            it = it->next;
        }
    }
}

static void multiplyCLsCOPY(Commandlist * p_commandlists, size_t const count, unsigned int const multiplier, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, const uint32_t cl_alloc_alignment)
{
    bool trapcheck = true;
    //e_osal_return_t ret       = OSAL_RETURN_FAIL;

    for (size_t i = 0; i < count; i++)
    {
        uint32_t * p_trapaddress = (uint32_t *)((uintptr_t)p_commandlists[i].virt + p_commandlists[i].size - 4);
        uint32_t trapcode = ((p_commandlists[i].core == CORE_TYPE_IMP) ? (0x4F000000) : (0x88000000));

        if ((*p_trapaddress & 0xFF000000) != trapcode)
        {
            trapcheck = false;
            cwarningv("Unable to multiply command lists as core (%d) doesn't end with TRAP.\n", (int)i);
        }
    }

    if (trapcheck)
    {
        for (size_t i = 0; i < count; i++)
        {
            uint32_t multiplier_l = (p_commandlists[i].core == CORE_TYPE_IMP) ? (multiplier / 3) : (multiplier);
            uint32_t nopcode      = ((p_commandlists[i].core == CORE_TYPE_IMP) ? (0x40000000) : (0x80000000));
            uint32_t new_size     = (unsigned int)p_commandlists[i].size * multiplier_l;
            osal_memory_buffer_handle_t buf_obj = OSAL_MEMORY_BUFFER_HANDLE_INVALID;
            void * p_new_virt = NULL;
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrAlloc(handle_osalmmngr, new_size + cl_alloc_alignment - new_size % cl_alloc_alignment, cl_alloc_alignment, &buf_obj)));
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(buf_obj, &p_new_virt)));

            uintptr_t new_phys = 0;
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetHwAddr(buf_obj, imp_dev_axi_bus_id, &new_phys)));

            memset(p_new_virt, 0, new_size);

            for (size_t cnt = 0; cnt < multiplier_l; cnt++)
            {
                uintptr_t iterationaddress = (uintptr_t)p_new_virt + cnt * p_commandlists[i].size;

                if (cnt != 0)
                {
                    * (uint32_t *)(iterationaddress - 4) = nopcode;
                }
                memcpy((void *)iterationaddress, p_commandlists[i].virt, p_commandlists[i].size);
            }

            OSAL_CHECK(R_OSAL_MmngrDealloc(handle_osalmmngr, p_commandlists[i].cmd_buffer));
            p_commandlists[i].cmd_buffer = buf_obj;
            p_commandlists[i].size       = new_size;
            p_commandlists[i].virt       = p_new_virt;
            p_commandlists[i].phys       = new_phys;
        }
    }
}

static void multiplyCLsGOSUB(Commandlist * p_commandlists, size_t const count, unsigned int const multiplier, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, const uint32_t cl_alloc_alignment)
{
    bool trapcheck = true;
    //e_osal_return_t ret       = OSAL_RETURN_FAIL;

    for (size_t i = 0; i < count; i++)
    {
        uint32_t * p_trapaddress = (uint32_t *)((uintptr_t)p_commandlists[i].virt + p_commandlists[i].size - 4);
        uint32_t trapcode = ((p_commandlists[i].core == CORE_TYPE_IMP) ? (0x4F000000) : (0x88000000));

        if ((*p_trapaddress & 0xFF000000) != trapcode)
        {
            trapcheck = false;
            cwarningv("Unable to multiply command lists as core (%d) doesn't end with TRAP.\n", (int)i);
        }
    }

    if (trapcheck)
    {
        for (size_t i = 0; i < count; i++)
        {
            uint32_t new_size = (unsigned int)p_commandlists[i].size + (multiplier * 8) + 4; // 8 as 2 commands (GOSUB+ADDR) and 4 Byte per command + trap
            osal_memory_buffer_handle_t buf_obj = OSAL_MEMORY_BUFFER_HANDLE_INVALID;
            void * p_new_virt = NULL;
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrAlloc(handle_osalmmngr, new_size + cl_alloc_alignment - new_size % cl_alloc_alignment, cl_alloc_alignment, &buf_obj)));
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(buf_obj, &p_new_virt)));

            uintptr_t curr_addr = (uintptr_t)p_new_virt;
            uintptr_t new_phys  = 0;
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetHwAddr(buf_obj, imp_dev_axi_bus_id, &new_phys)));

            memset(p_new_virt, 0, new_size);

            // Make Trap a Return
            uint32_t * p_trapaddress = (uint32_t *)((uintptr_t)p_commandlists[i].virt + p_commandlists[i].size - 4);
            uint32_t trapcode        = * p_trapaddress;
            uint32_t returncode      = ((p_commandlists[i].core == CORE_TYPE_IMP) ? (0x47000000) : (0x99000000));
            *p_trapaddress = returncode;

            // Check if first 4 cmds are NOPS
            bool nopcheck = true;

            for (size_t j = 0; j < 4; j++)
            {
                uint8_t * nopaddress = (uint8_t *)((uintptr_t)p_commandlists[i].virt + (4 * j) + 3);

                if (*nopaddress != 0x80)
                {
                    nopcheck = false;
                }
            }

            // If yes memcpy first 4 cmds
            if (nopcheck)
            {
                memcpy(p_new_virt, p_commandlists[i].virt, 4 * sizeof(uint32_t));
                curr_addr += (4 * 4);
            }

            // Add GOSUB multiplier times to curr_addr +  gosubcnt
            uintptr_t gosub_address = (new_phys + (nopcheck ? 16 : 0) + (multiplier * 8) + 4);

            for (size_t j = 0; j < multiplier; j++)
            {
                uint32_t gosubcode = ((p_commandlists[i].core == CORE_TYPE_IMP) ? (0x46000000) : (0x91000000));
                * (uint32_t *)curr_addr = gosubcode;
                curr_addr += 4;
                * (uint32_t *)curr_addr = (uint32_t)gosub_address;
                curr_addr += 4;
            }

            // Add Trap
            * (uint32_t *)curr_addr = trapcode;
            curr_addr += 4;
            // cpy rest of cl
            uintptr_t subaddress = ((uintptr_t)p_commandlists[i].virt + (nopcheck ? 16 : 0));
            memcpy((void *)curr_addr, (void *)subaddress, (p_commandlists[i].size - (subaddress - (uintptr_t)p_commandlists[i].virt)));

            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrDealloc(handle_osalmmngr, p_commandlists[i].cmd_buffer))); //to be done
            p_commandlists[i].cmd_buffer = buf_obj;
            p_commandlists[i].size       = new_size;
            p_commandlists[i].virt       = p_new_virt;
            p_commandlists[i].phys       = new_phys;
        }
    }
}

static void flushCommandlists(Commandlist * p_commandlists, size_t const count, const uint32_t cl_alloc_alignment)
{
    for (size_t i = 0; i < count; i++)
    {
        flushRange(p_commandlists[i].cmd_buffer, p_commandlists[i].size + cl_alloc_alignment - p_commandlists[i].size % cl_alloc_alignment); //must be mutliple of 64
    }
}

static void dumpCLs(Commandlist * p_commandlists, size_t const count)
{
    char filename[32] = "";

    for (size_t i = 0; i < count; i++)
    {
        FILE * write_ptr;

        switch (p_commandlists[i].core)
        {
        case CORE_TYPE_CNN:
            snprintf(filename, 32, "cnn_sid%u_dump.bin", p_commandlists[i].syncid);
            break;
        case CORE_TYPE_DMA:
            snprintf(filename, 32, "dma_sid%u_dump.bin", p_commandlists[i].syncid);
            break;
        case CORE_TYPE_OCV:
            snprintf(filename, 32, "ocv_sid%u_dump.bin", p_commandlists[i].syncid);
            break;
        case CORE_TYPE_IMP:
            snprintf(filename, 32, "imp_sid%u_dump.bin", p_commandlists[i].syncid);
            break;
        default:
            snprintf(filename, 32, "unknown_sid%u_dump.bin", p_commandlists[i].syncid);
            break;
        }

        write_ptr = fopen(filename, "wb");
        fwrite(p_commandlists[i].virt, p_commandlists[i].size, 1, write_ptr);
        fclose(write_ptr);
    }
}

static void zeroMemories(MemoryList * p_list)
{
    //e_osal_return_t ret = OSAL_RETURN_FAIL;

    MemoryListIterator * it = memoryListIteratorGet(p_list);

    while (NULL != it)
    {
        MemoryListEntry * e = memoryListIteratorGetValue(p_list, it);
        void * virt = NULL;
        CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(e->base_new_buffer, &virt)));
        uintptr_t base_new = 0;
        CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetHwAddr(e->base_new_buffer, OSAL_AXI_BUS_ID_IPA_MAIN_MEMORY, &base_new)));

        const size_t size = e->size;
        memset(virt, 0, size);

        it = it->next;
    }
}

static void flushMemories(MemoryList * p_list, const uint32_t memories_alloc_alignment)
{
    MemoryListIterator * it = memoryListIteratorGet(p_list);

    while (NULL != it)
    {
        MemoryListEntry * e = memoryListIteratorGetValue(p_list, it);
        flushRange(e->base_new_buffer, e->size + memories_alloc_alignment - e->size % memories_alloc_alignment);
        it = it->next;
    }
}

static void invalidateMemories(MemoryList * p_list, const uint32_t memories_alloc_alignment)
{
    MemoryListIterator * it = memoryListIteratorGet(p_list);

    while (NULL != it)
    {
        MemoryListEntry * e = memoryListIteratorGetValue(p_list, it);
        invalidateRange(e->base_new_buffer, e->size + memories_alloc_alignment - e->size % memories_alloc_alignment); //must be multiple of 64
        it = it->next;
    }
}

static void flushRange(osal_memory_buffer_handle_t img_buffer, const size_t size)
{
    e_osal_return_t ret = OSAL_RETURN_FAIL;

    if (img_buffer != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
    {
        cinfov("R_OSAL_MmngrFlush(img_buffer, 0, size=0x%08x)\n", (unsigned int)size);
        ret = OSAL_CHECK(R_OSAL_MmngrFlush(img_buffer, 0, size));

        if (ret != OSAL_RETURN_OK)
        {
            cinfov("OSAL_CHECK(R_OSAL_MmngrFlush error code: %u\n", ret);
        }
    }
    else
    {
        cinfov("OSAL_CHECK(R_OSAL_MmngrFlush: buffer handle invalid  %u \n", ret);
    }
}

static void invalidateRange(osal_memory_buffer_handle_t img_buffer, const size_t size)
{
    e_osal_return_t ret = OSAL_RETURN_FAIL;

    if (img_buffer != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
    {
        CHECK_OK(OSAL_CHECK(R_OSAL_MmngrInvalidate(img_buffer, 0, size)));
    }
    else
    {
        cinfov("OSAL_CHECK(R_OSAL_MmngrInvalidate: buffer handle invalid  %u \n", ret);
    }

}

static void allocateMemories(MemoryList * p_list, osal_axi_bus_id_t imp_dev_axi_bus_id, osal_memory_manager_handle_t handle_osalmmngr)
{
    MemoryListIterator * it = memoryListIteratorGet(p_list);
    //e_osal_return_t     ret = OSAL_RETURN_FAIL;

    while (NULL != it)
    {
        MemoryListEntry * e = memoryListIteratorGetValue(p_list, it);

        const size_t size = e->size;
        CHECK_OK(OSAL_CHECK(R_OSAL_MmngrAlloc(handle_osalmmngr, size + 4096 - size % 4096, sizeof(char), &e->base_new_buffer)));
        CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetHwAddr(e->base_new_buffer, imp_dev_axi_bus_id, &e->addressNew)));

        it = it->next;
    }
}

static bool loadCommandLists(const rvxt_info_pb_t * pbinfo, const char * p_filename, Commandlist ** p_commandlists, size_t * commandlistCount, osal_axi_bus_id_t imp_dev_axi_bus_id)
{
    bool result      = true;
    assert(0 == *commandlistCount);
    size_t count     = 0;
    size_t countPrev = 0;
    uint16_t cmdCnt  = 0;

    for (unsigned int itr = 0; itr < pbinfo->subnet_cout; itr++)
    {
        countPrev = count;
        count = count + pbinfo->subnet_info[itr].cmdL_size;
        *p_commandlists = (Commandlist *)realloc(*p_commandlists, (count - countPrev) * sizeof(Commandlist));
        cinfov("Executing one set consisting of %u commandlist(s):\n", (unsigned int)pbinfo->subnet_info[itr].cmdL_size);

        for (unsigned int itrCmdL = 0; itrCmdL < pbinfo->subnet_info[itr].cmdL_size; itrCmdL++)
        {
            const unsigned int syncid   = pbinfo->subnet_info[itr].cmdlistinfo[itrCmdL].syncid;
            const unsigned int coretype = pbinfo->subnet_info[itr].cmdlistinfo[itrCmdL].core_type;

            if (popcount(syncid) != 1)
            {
                cerrorv("Sync-ID '%u' for core \"%d\" is not allowd. Only a single bit must be set!\n", syncid, coretype);
            }

            assert(syncid != 0);

            void * p_dataptr = pbinfo->subnet_info[itr].cmdlistinfo[itrCmdL].p_data;

            //osal_memory_buffer_handle_t buf_obj_fread = OSAL_MEMORY_BUFFER_HANDLE_INVALID;
            (*p_commandlists)[cmdCnt].virt = p_dataptr; //readFileToMemory_OSAL(filename, &size, osal_mmngr, &(*p_commandlists)[i].cmd_buffer, cl_alloc_alignment);

            if (NULL == (*p_commandlists)[cmdCnt].virt)
            {
                cerrorv("Failed to read '%s'!\n", p_filename);
                result = false;
                return result;
            }

            (*p_commandlists)[cmdCnt].size = pbinfo->subnet_info[itr].cmdlistinfo[itrCmdL].cl_data_size;
            (*p_commandlists)[cmdCnt].syncid = syncid;

            e_osal_return_t ret = OSAL_RETURN_FAIL;
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetHwAddr((*p_commandlists)[cmdCnt].cmd_buffer, imp_dev_axi_bus_id, &(*p_commandlists)[cmdCnt].phys)));
            DEBUG_PRINT("loadCommandLists: GetHwAddr: ret: %d, phys: 0x%08x\n", ret, (unsigned int)(*p_commandlists)[cmdCnt].phys);

            if (coretype == 6)
            {
                (*p_commandlists)[cmdCnt].core = CORE_TYPE_CNN;
            }
            else if (coretype == 3)
            {
                (*p_commandlists)[cmdCnt].core = CORE_TYPE_DMA;
            }
            else if (coretype == 2)
            {
                (*p_commandlists)[cmdCnt].core = CORE_TYPE_OCV;
            }
            else if (coretype == 1)
            {
                (*p_commandlists)[cmdCnt].core = CORE_TYPE_IMP;
            }
            else
            {
                cerrorv("Failed to determine core identification '%d'!\n", (*p_commandlists)[cmdCnt].core);
                result = false;
                return result;
            }

            DEBUG_PRINT("Commandlist %d ---- syncid = %d coretype = %u\n", cmdCnt, (*p_commandlists)[cmdCnt].syncid, (*p_commandlists)[cmdCnt].core); //TEL
            cmdCnt++;
        }
    }

    *commandlistCount = count;

    return result;
}

static void freeCommandLists(Commandlist * p_commandlists, size_t count, osal_memory_manager_handle_t handle_osalmmngr)
{
    (void)handle_osalmmngr;

    for (int i = (int)count - 1; i >= 0; i--)
    {
        CHECK_OK(OSAL_CHECK(R_OSAL_MmngrDealloc(handle_osalmmngr, p_commandlists[i].cmd_buffer)));
        p_commandlists[i].virt = NULL;
        p_commandlists[i].phys = 0;
        p_commandlists[i].size = 0;
    }
}

/*!
 * @brief Fix base address of CNN IP CL in DMA CLs
 * @param p_commandlists
 * @param count
 * @return
 */
static bool fixBaseCL(const rvxt_info_pb_t * pb_info, Commandlist * p_commandlists, size_t const count, Cfg * cfg)
{
    /* find CNN CL */
    bool result      = false;
    size_t index_CNN = 0;

    for (size_t i = 0; i < count; i++)
    {
        if (p_commandlists[i].core == CORE_TYPE_CNN)
        {
            if (result == false)
            {
                result = true;
                index_CNN = i;
            }
            else
            {
                /* more than one CNN CL found */
                result = false;
                break;
            }
        }
    }

    if (result)
    {
        for (unsigned int itr = 0; itr < pb_info->subnet_cout; itr++)
        {
            for (size_t i = 0; i < count; i++)
            {
                if (p_commandlists[i].core == CORE_TYPE_DMA || p_commandlists[i].core == CORE_TYPE_CNN)
                {
                    if (pb_info->subnet_info[itr].cmdlistinfo[i].cl_data_size == 0)
                        r_cl_patch_DMA(p_commandlists[i].virt, cfg->CNNclBase, p_commandlists[index_CNN].phys, p_commandlists[index_CNN].size, false);
                    else
                        pb_cl_patch_DMA(pb_info->subnet_info[itr].cmdlistinfo[i], p_commandlists[i].virt, cfg->CNNclBase, p_commandlists[index_CNN].phys, p_commandlists[index_CNN].size, false);
                }
            }
        }
    }

    return result;
}

static unsigned int popcount(unsigned int x)
{
    unsigned int c = 0;

    for (c = 0; x != 0; x >>= 1)
    {
        if (x & 1)
        {
            c++;
        }
    }

    return c;
}

#if !defined(RCAR_XIL_SIL)
#pragma GCC diagnostic pop
#endif

extern "C" int R_CNN_DeInitialize ();
int R_CNN_DeInitialize()
{
    /*Freeing memory*/

    imp_stop(commandlistCount);
    memoryListFree(p_memoryList);
    channelSetupListFree(p_channelSetupList);
    freeCommandLists(p_commandlists, commandlistCount, handle_osalmmngr);
    return 0;
}
