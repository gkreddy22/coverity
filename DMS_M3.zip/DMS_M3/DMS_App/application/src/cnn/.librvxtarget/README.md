RVX target library. 

This library contains functions to support CommandList generation 
and debugging on the target.