#include <errno.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if __has_include("byteswap.h")
#include <byteswap.h>
#else
#define __bswap_16(x) ((uint16_t)((((x) >> 8) & 0xff) | (((x)&0xff) << 8)))
#endif

#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) > (b)) ? (a) : (b))

#include "../ince/rvx_target/aifHelper.h"
#include "../ince/rvx_target/filesystem.h"
#include "../ince/rvx_target/imageHelper.h"
#include "../ince/rvx_target/pnmHelper.h"
#include "../ince/rvx_target/ui.h"
#include "common.h"
#include "customize.h"

static bool memCopyLine(void * p_dst, void * p_src, unsigned int const bytePerPixel, size_t const dst_width_px, const size_t dst_height_px, const size_t dst_stride_px, const size_t src_width_px, const size_t src_height_px, const size_t src_stride_px, const bool addZeroPadding)
{
    const size_t width_px  = MIN(src_width_px, dst_width_px);
    const size_t height_px = MIN(src_height_px, dst_height_px);

    uint8_t * dst_b = (uint8_t *)p_dst;
    uint8_t * src_b = (uint8_t *)p_src;

    for (size_t h = 0; h < height_px; h++)
    {
        memcpy(dst_b, src_b, width_px * bytePerPixel);
        dst_b += (uintptr_t)(width_px * bytePerPixel);

        if (addZeroPadding)
        {
            memset(dst_b, 0, (dst_stride_px - width_px) * bytePerPixel);
        }

        dst_b += (dst_stride_px - width_px) * bytePerPixel;
        src_b += src_stride_px * bytePerPixel;
    }

    return true;
}

static inline bool bswap16(uint16_t * p_dst, uint16_t * p_src, size_t size)
{
    //TODO:FIXME: Volatile required for release build.
    for (volatile size_t idx = 0; idx < size; idx++)
    {
        *p_dst = __bswap_16(*p_src);
        p_src++;
        p_dst++;
    }

    return true;
}

bool setupChannelFromData(void * p_destination, const size_t width, const size_t height, const unsigned int bytesPerPixel, const unsigned int channel, const void * p_data)
{
    bool    retVal = true;
    size_t  w      = g_customize.IMR_Resize_Width;
    size_t  h      = g_customize.IMR_Resize_Height;
    uint8_t bpp    = 1;

        
    if ((width == w) && (height == h) && (channel < NUM_CNN_CHANNELS) && (bytesPerPixel == bpp))
    {

        if (bpp == 1)
        {
            uint8_t * c[NUM_CNN_CHANNELS] = {NULL, NULL, NULL};
            c[channel] = p_destination;
            seperatePPMChannel(p_data, w, h, c[0], c[1], c[2]);
        }
        else if (bpp == 2)
        {
            uint16_t * c[NUM_CNN_CHANNELS] = {NULL, NULL, NULL};
            c[channel] = p_destination;
            seperatePPMChannelU16(p_data, w, h, c[0], c[1], c[2]);
        }
        else
        {
            cerror("Unsupported Bpp!\n");
            retVal = false;
        }
    }
    else
    {
        cerror("Format does not meet channel properties!\n");        
        retVal = false;
    }
    
    return retVal;
    
}
