
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "../ince/rvx_target/list.h"
#include "../ince/rvx_target/r_cl_patch_helper.h"
#include "../ince/rvx_target/ui.h"

static size_t getSize(const void *data)
{
    (void)data;
    return sizeof(MemoryListEntry);
}

MemoryList *memoryListCreate()
{
    MemoryList *list = (MemoryList *)malloc(sizeof(MemoryList));
    listCreate(list, getSize);
    return list;
}

void memoryListFree(MemoryList *list)
{
    listDestroy(list);
    free(list);
}

bool memoryListAppend(MemoryList *list, const MemoryListEntry *entry)
{
    return listAppend(list, (void *)entry);
}

size_t memoryListSize(MemoryList *list)
{
    return listSize(list);
}

MemoryListIterator *memoryListIteratorGet(MemoryList *list)
{
    return listIteratorGet(list);
}

MemoryListIterator *memoryListIteratorNext(MemoryList *list, MemoryListIterator *iterator)
{
    return listIteratorNext(list, iterator);
}

MemoryListEntry *memoryListIteratorGetValue(MemoryList *list, MemoryListIterator *iterator)
{
    return (MemoryListEntry *)listIteratorGetValue(list, iterator);
}

bool memoryListIteratorInsertAt(MemoryList *list, MemoryListIterator *iterator, const MemoryListEntry *entry)
{
    return listIteratorInsertBefore(list, iterator, (void *)entry);
}

MemoryListEntry *memoryListAt(MemoryList *list, size_t index)
{
    return (MemoryListEntry *)listAt(list, index);
}

bool memoryListInsertSorted(MemoryList *list, const MemoryListEntry *entry)
{
    bool result;
    bool found = false;

    MemoryListIterator *it = memoryListIteratorGet(list);
    while (NULL != it)
    {
        MemoryListEntry *e = memoryListIteratorGetValue(list, it);
        if (e->addressNew > entry->addressNew)
        {
            result = memoryListIteratorInsertAt(list, it, entry);
            found = true;
        }
        it = memoryListIteratorNext(list, it);
    }

    if (false == found)
    {
        result = memoryListAppend(list, entry);
    }

    return result;
}

void memoryListPrint(MemoryList *list)
{
    MemoryListIterator *it = memoryListIteratorGet(list);
    while (NULL != it)
    {
        MemoryListEntry *e = memoryListIteratorGetValue(list, it);
        cinfov(".addressOld = %p, .addressNew = %p, .size = 0x%08x\n", (void *)e->addressOld, (void *)e->addressNew, (unsigned int)e->size);
        it = memoryListIteratorNext(list, it);
    }
}
