#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/r_cl_patch.h"

/*!
 * @brief Remap WUP/SLP accroding to in and utput map
 * @param inst
 * @param map_in
 * @param map_out
 * @param verbose
 * @return
 */
uint32_t r_cl_patch_remapSync(uint32_t inst, const cl_patch_core_map_t *map_in, const cl_patch_core_map_t *map_out, const bool verbose)
{
    (void)verbose;

    uint32_t result = 0;

    /* set up mapping table */
    unsigned int map[16];
    for (unsigned int i = 0; i < 16; i++)
    {
        map[i] = 0;
        for (unsigned int j = 0; j < 16; j++)
        {
            if ((map_in->entry[i].type == map_out->entry[j].type) && (map_in->entry[i].index == map_out->entry[j].index))
            {
                map[i] = j;
                break;
            }
        }
    }

    /* do sync bit remapping */
    uint32_t val = R_CL_SYNC_BITS(inst);
    uint32_t ret = 0;

    for (int i = 0; i < 16; i++)
    {
        if (1 == (val & 1))
        {
            ret = ret | (unsigned int)(1 << map[i]);
        }
        val = val >> 1;
    }

    result = (inst & 0xFFFF0000U) | ret;

    return result;
}
