#include <ctype.h>
#include <inttypes.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Atomic library */
#include "r_atmlib_types.h"
#include "rcar-xos/atmlib/r_atmlib_prot.h"

/* rcar-environment */
//#include "generic_api_memory.h"

/* RVX Target interface */
#include "../ince/rvx_target/atmlib_cnn_user_functions.h"
#include "../ince/rvx_target/filesystem.h"
#include "../ince/rvx_target/info.h"
#include "../ince/rvx_target/rvx_target_int.h"
#include "../ince/rvx_target/rvxt_csv.h"
#include "../ince/rvx_target/rvxt_csv_helper.h"
#include "../ince/rvx_target/rvxt_string_helper.h"
#include "../ince/rvx_target/ui.h"

/*Global defines */
#define LINESIZE (1024) // Some lines containing weights can get huge
#define MAX_PARAMS_PER_LINE (64)
#define ELEMENTS(array) (sizeof(array) / sizeof(array[0]))

#define RETURN_IF_FALSE(val)                \
    {                                       \
        if (!val)                           \
        {                                   \
            cerror("'" #val "' failed!\n"); \
            return val;                     \
        }                                   \
    }

#define RETURN_ATMLIB_E_NG_IF_FALSE(val)    \
    {                                       \
        if (!val)                           \
        {                                   \
            cerror("'" #val "' failed!\n"); \
            return R_ATMLIB_E_NG;           \
        }                                   \
    }

#define RETURN_IF_NOT_ATMLIB_E_OK(val)      \
    {                                       \
        if (R_ATMLIB_E_OK != val)           \
        {                                   \
            cerror("'" #val "' failed!\n"); \
            return val;                     \
        }                                   \
    }

/* Common */
R_ATMLIB_RETURN_VALUE Add_NOP(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_core_group_e coretype);
R_ATMLIB_RETURN_VALUE Add_WUP(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, const rvxt_core_group_e coretype);
R_ATMLIB_RETURN_VALUE Add_SLP(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, const rvxt_core_group_e coretype);

/* DMA */
R_ATMLIB_RETURN_VALUE Add_DMA_operation(char *params[MAX_PARAMS_PER_LINE], uint32_t param_count, R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info);

/* CNN */
R_ATMLIB_RETURN_VALUE Add_CNNPictureProlog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CNNPictureEpilog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CNNLayerProlog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CNNLayerEpilog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CNNSetupWeights(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info);
R_ATMLIB_RETURN_VALUE Add_CNNSetupBiases(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CNNSetupShifts(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
#if defined(RCAR_SOC_V3H2) || defined(RCAR_SOC_V3U)
/* CNNIPv2 */
R_ATMLIB_RETURN_VALUE Add_CNNSetupARI(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CNNSetupLut(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CNNSetupChannelDMAI(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes);
R_ATMLIB_RETURN_VALUE Add_CNNSetupChannelDMAC(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes);
R_ATMLIB_RETURN_VALUE Add_CNNSetupChannelDMAO(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes);
R_ATMLIB_RETURN_VALUE Add_CNNStartSubcore(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CNNSyncs(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
#elif defined(RCAR_SOC_V3H1) || defined(RCAR_SOC_V3M2)
/* CNNIPv1 */
R_ATMLIB_RETURN_VALUE Add_DMA_Config_disabled(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes);
R_ATMLIB_RETURN_VALUE Add_DMA_Config(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes);
R_ATMLIB_RETURN_VALUE Add_CNNProcessTile(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes);
#endif
/* CVe */
R_ATMLIB_RETURN_VALUE Add_CVE_WPR(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CVE_WPR_addr(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info);
R_ATMLIB_RETURN_VALUE Add_CVE_GWMDMAC(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CVE_Rect(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_CVE_Sync(R_ATMLIB_CLData *cl);

/* IMP */
R_ATMLIB_RETURN_VALUE Add_IMP_Config(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_IMP_Image(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info);
R_ATMLIB_RETURN_VALUE Add_IMP_Pre(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);
R_ATMLIB_RETURN_VALUE Add_IMP_Post(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl);

static bool range_check(intmax_t value, intmax_t min, intmax_t max)
{
    bool result = false;
    if ((value >= min) && (value <= max))
    {
        result = true;
    }
    else
    {
        cerror("Value out of range!");
    }
    return result;
}

static int _strtoi(const char *__restrict__ nptr, char **__restrict__ endptr, int base)
{
    int result = 0;
    intmax_t const val = strtoimax(nptr, endptr, base);
    if (range_check(val, INT_MIN, INT_MAX))
    {
        result = (int)val;
    }
    return result;
}

static inline int16_t _strtoi16(const char *__restrict__ nptr, char **__restrict__ endptr, int base)
{
    int16_t result = 0;
    intmax_t const val = strtoimax(nptr, endptr, base);
    if (range_check(val, INT16_MIN, INT16_MAX))
    {
        result = (int16_t)val;
    }
    return result;
}

static inline uint16_t _strtoui16(const char *__restrict__ nptr, char **__restrict__ endptr, int base)
{
    uint16_t result = 0;
    intmax_t const val = strtoimax(nptr, endptr, base);
    if (range_check(val, 0, UINT16_MAX))
    {
        result = (uint16_t)val;
    }
    return result;
}

static inline int8_t _strtoi8(const char *__restrict__ nptr, char **__restrict__ endptr, int base)
{
    int8_t result = 0;
    intmax_t const val = strtoimax(nptr, endptr, base);
    if (range_check(val, INT8_MIN, INT8_MAX))
    {
        result = (int8_t)val;
    }
    return result;
}

static inline uint8_t _strtoui8(const char *__restrict__ nptr, char **__restrict__ endptr, int base)
{
    uint8_t result = 0;
    intmax_t const val = strtoimax(nptr, endptr, base);
    if (range_check(val, 0, UINT8_MAX))
    {
        result = (uint8_t)val;
    }
    return result;
}

static inline unsigned int _strtoui(const char *__restrict__ nptr, char **__restrict__ endptr, int base)
{
    unsigned int result = 0;
    intmax_t const val = strtoimax(nptr, endptr, base);
    if (range_check(val, 0, UINT_MAX))
    {
        result = (unsigned int)val;
    }
    return result;
}

static inline uint32_t _strtoui32(const char *__restrict__ nptr, char **__restrict__ endptr, int base)
{
    uint32_t result = 0;
    intmax_t const val = strtoimax(nptr, endptr, base);
    if (range_check(val, 0, UINT32_MAX))
    {
        result = (uint32_t)val;
    }
    return result;
}

static inline int32_t _strtoi32(const char *__restrict__ nptr, char **__restrict__ endptr, int base)
{
    int32_t result = 0;
    intmax_t const val = strtoimax(nptr, endptr, base);
    if (range_check(val, INT32_MIN, INT32_MAX))
    {
        result = (int32_t)val;
    }
    return result;
}

R_ATMLIB_RETURN_VALUE rvxt_csv_cl_gen_by_corename(R_ATMLIB_CLData *cl, const char *const corename, const rvxt_info_t *const p_info, const rvxt_core_group_e coretype, const bool noWeights, const bool noSync)
{
    R_ATMLIB_RETURN_VALUE result = R_ATMLIB_E_OK;

    char *lowercase_corename = rvxt_to_lower(rvxt_strdup(corename));
    char *filename = rvxt_sprintf_dup("commandlist_%s.csv", lowercase_corename);

    result = rvxt_cl_from_csv(cl, filename, p_info, coretype, noWeights, noSync);

    if (result != R_ATMLIB_E_OK)
    {
        DEBUG_PRINT("[ERROR] Could not build cl for: %s\n", lowercase_corename);
    }

    free(filename);
    free(lowercase_corename);

    return result;
}

R_ATMLIB_RETURN_VALUE rvxt_cl_from_csv(R_ATMLIB_CLData *cl, char *csv_filepath, const rvxt_info_t *const p_info, const rvxt_core_group_e coretype, const bool noWeights, const bool noSync)
{
    FILE *pFile_read;

    char cLine[LINESIZE];
    char cLine_cpy[LINESIZE];
    char *ptr_to_param;
    const char delimiter[] = ","; //divide csv line in params divided by these symbols

    size_t linecounter = 0;
    R_ATMLIB_RETURN_VALUE ret = R_ATMLIB_E_OK;
    ClofsListCNNEntryMems_t ClofsList_indexes;
    memset(&ClofsList_indexes, 255, sizeof(ClofsListCNNEntryMems_t));

    cinfov("Reading CSV '%s'\n", csv_filepath);

    if (noWeights && (coretype == RVXT_CORE_GROUP_CNN))
    {
        cinfo("Not adding weights...\n");
    }
    if (noSync)
    {
        cinfo("Not adding WUP/SLP synchronization...\n");
    }
    pFile_read = rvxtfs_openFirst(csv_filepath, "r+");
    if (pFile_read == NULL)
    {
        cerrorv("Error opening file: %s\n", csv_filepath);
        return R_ATMLIB_E_NG_ARG1;
    }
    else
    {
        while (fgets(cLine, LINESIZE, pFile_read) != NULL)
        {
            /// Copy the line into an array divided by delimiter
            strcpy(cLine_cpy, cLine); // Copy of line needed, because strtok works on string
            ptr_to_param = strtok(cLine_cpy, delimiter);
            uint32_t paramcount = 0;
            char *params[MAX_PARAMS_PER_LINE];
            while (ptr_to_param != NULL)
            {
                params[paramcount] = ptr_to_param;
                ptr_to_param = strtok(NULL, delimiter);
                paramcount++;
            }

            /// Run csv-line command
            const int command_id = _strtoi(params[0], NULL, 10);
            // Non Core-specific commands
            if (command_id < 4)
            {
                switch (command_id)
                {
                case 0: /* strtoimax error / Comment */
                    // puts (cLine);
                    ret = 0;
                    break;
                case 1: /* NOP */
                    ret = Add_NOP(params, cl, coretype);
                    break;
                case 2: /* WUP */
                    if (!noSync)
                    {
                        ret = Add_WUP(params, cl, p_info, coretype);
                    }
                    break;
                case 3: /* SLP */
                    if (!noSync)
                    {
                        ret = Add_SLP(params, cl, p_info, coretype);
                    }
                    break;
                default: /* unknown command_id */
                    cerrorv("Unknown command_id: %i\n", command_id);
                    ret = R_ATMLIB_E_NG_ARG1;
                }
            }
            else
            {
                // Core-specific commands
                switch (coretype)
                {
                case RVXT_CORE_GROUP_DMA:
                    switch (command_id)
                    {
                    case 4: /* DMA */
                        ret = Add_DMA_operation(params, paramcount, cl, p_info);
                        break;
                    default: /* unknown command_id */
                        cerrorv("Unknown command_id: %i\n", command_id);
                        ret = R_ATMLIB_E_NG_ARG1;
                    }
                    break;
                case RVXT_CORE_GROUP_CNN:
                    switch (command_id)
                    {
                    case RVXT_CORE_GROUP_CNN:
                    case 4: /* CNNPictureProlog */
                        ret = Add_CNNPictureProlog(params, cl);
                        break;
                    case 5: /* CNNPictureEpilog */
                        ret = Add_CNNPictureEpilog(params, cl);
                        break;
                    case 6: /* CNNLayerProlog */
                        ret = Add_CNNLayerProlog(params, cl);
                        break;
                    case 7: /* CNNLayerEpilog */
                        ret = Add_CNNLayerEpilog(params, cl);
                        break;
                    case 10: /* r_atmlib_CNNSetupWeights */
                        if (!noWeights)
                        {
                            ret = Add_CNNSetupWeights(params, cl, p_info);
                        }
                        break;
                    case 11: /* r_atmlib_CNNSetupBiases */
                        ret = Add_CNNSetupBiases(params, cl);
                        break;
                    case 12: /* r_atmlib_CNNSetupShifts */
                        ret = Add_CNNSetupShifts(params, cl);
                        break;
#if defined(RCAR_SOC_V3H2) || defined(RCAR_SOC_V3U)
                    case 8: /* r_atmlib_CNNSetupChannelDMAI */
                        ret = Add_CNNSetupChannelDMAI(params, cl, p_info, &ClofsList_indexes);
                        break;
                    case 9: /* r_atmlib_CNNSetupChannelDMAC */
                        ret = Add_CNNSetupChannelDMAC(params, cl, p_info, &ClofsList_indexes);
                        break;
                    case 13: /* r_atmlib_CNNSetupChannelDMAO */
                        ret = Add_CNNSetupChannelDMAO(params, cl, p_info, &ClofsList_indexes);
                        break;
                    case 14: /* r_atmlib_CNNSetupLUT */
                        ret = Add_CNNSetupLut(params, cl);
                        break;
                    case 15: /* r_atmlib_CNNSetupARI */
                        ret = Add_CNNSetupARI(params, cl);
                        break;
                    case 16: /* r_atmlib_CNNStartDMAx/Tile */
                        ret = Add_CNNStartSubcore(params, cl);
                        break;
                    case 17: /* r_atmlib_CNN_SYNCS */
                        ret = Add_CNNSyncs(params, cl);
                        break;
#elif defined(RCAR_SOC_V3H1) || defined(RCAR_SOC_V3M2)
                    case 8: /* DMA_Config_disabled */
                        ret = Add_DMA_Config_disabled(params, cl, p_info, &ClofsList_indexes);
                        break;
                    case 9: /* DMA_Config */
                        ret = Add_DMA_Config(params, cl, p_info, &ClofsList_indexes);
                        break;
                    case 13: /* r_atmlib_CNNProcessTile */
                        ret = Add_CNNProcessTile(params, cl, p_info, &ClofsList_indexes);
                        break;
#endif
                    default: /* unknown command_id */
                        cerrorv("Unknown command_id: %i\n", command_id);
                        ret = R_ATMLIB_E_NG_ARG1;
                        break;
                    }
                    break;
                case RVXT_CORE_GROUP_CVE:
                    switch (command_id)
                    {
                    case 4: /* CVE WPR*/
                        ret = Add_CVE_WPR(params, cl);
                        break;
                    case 5: /* CVE with address*/
                        ret = Add_CVE_WPR_addr(params, cl, p_info);
                        break;
                    case 6: /* CVE Rect*/
                        ret = Add_CVE_Rect(params, cl);
                        break;
                    case 7: /* CVE Sync*/
                        ret = Add_CVE_Sync(cl);
                        break;
                    case 8: /* CVE Rect*/
                        ret = Add_CVE_GWMDMAC(params, cl);
                        break;
                    default: /* unknown command_id */
                        cerrorv("Unknown command_id: %i\n", command_id);
                        ret = R_ATMLIB_E_NG_ARG1;
                    }
                    break;
                case RVXT_CORE_GROUP_IMP:
                    switch (command_id)
                    {
                    case 4: /* IMP Config*/
                        ret = Add_IMP_Config(params, cl);
                        break;
                    case 5: /* IMP Image Config*/
                        ret = Add_IMP_Image(params, cl, p_info);
                        break;
                    case 6: /* IMP pre-processing Config*/
                        ret = Add_IMP_Pre(params, cl);
                        break;
                    case 7: /* IMP post-processing Config*/
                        ret = Add_IMP_Post(params, cl);
                        break;
                    default: /* unknown command_id */
                        cerrorv("Unknown command_id: %i\n", command_id);
                        ret = R_ATMLIB_E_NG_ARG1;
                    }
                    break;
                default:
                    cerrorv("Unsupported coretype: %i\n", coretype);
                    ret = R_ATMLIB_E_NG_ARG1;
                }
            }

            if (ret != R_ATMLIB_E_OK)
            {
                cerrorv("Error(%i) occurred at csv-line %u:\n[ERROR] ", (int)ret, (unsigned int)linecounter);
                puts(cLine);
                cerror("Params: [");
                for (uint32_t paramcnt = 0; paramcnt < paramcount - 1; paramcnt++)
                {
                    DEBUG_PRINT("%s,", (params[paramcnt] == NULL) ? ("") : (params[paramcnt]));
                }
                DEBUG_PRINT("]\n");
                return ret;
            }
            linecounter++;
        }
        fclose(pFile_read);

        cinfo("Done reading CSV file.\n");
    }
    return R_ATMLIB_E_OK;
}

/**
/ NOP params: [command_id, count]
**/
R_ATMLIB_RETURN_VALUE Add_NOP(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_core_group_e coretype)
{
    const unsigned int totalCnt = _strtoui(params[1], NULL, 10);
    const unsigned int maxBatchSize = (totalCnt == 8) ? 1 : 16;
    unsigned int cnt = 0;

    while (cnt < totalCnt)
    {
        unsigned int batch = ((totalCnt - cnt) > maxBatchSize) ? maxBatchSize : (totalCnt - cnt);
        cnt += batch;
        switch (coretype)
        {
        case RVXT_CORE_GROUP_DMA:
            RVXT_ATMLIB_ASSERT_OK(r_atmlib_DMA_NOP(cl, batch));
            break;
        case RVXT_CORE_GROUP_CNN:
            RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNN_NOP(cl, (uint8_t)batch));
            break;
        case RVXT_CORE_GROUP_CVE:
            RVXT_ATMLIB_ASSERT_OK(r_atmlib_OCV_NOP(cl, batch));
            break;
        case RVXT_CORE_GROUP_IMP:
            RVXT_ATMLIB_ASSERT_OK(r_atmlib_IMP_NOP(cl, batch));
            break;
        default:
            cerrorv("Unsupported coretype: %i\n", coretype);
            return R_ATMLIB_E_NG_CLTYPE;
        }
    }
    return R_ATMLIB_E_OK;
}

/**
/ WUP params: [command_id, core_this, core_others_only]
**/
R_ATMLIB_RETURN_VALUE Add_WUP(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, const rvxt_core_group_e coretype)
{
    uint32_t sync_bits = 0x0U;
    uint32_t core_caller = 0;
    uint32_t core_others = 0;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[1], &core_caller));
    RETURN_ATMLIB_E_NG_IF_FALSE(set_bits_from_define_string(params[2], &core_others));
    RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_getSyncBits(p_info, core_caller, core_others, &sync_bits));

    switch (coretype)
    {
    case RVXT_CORE_GROUP_DMA:
        return r_atmlib_DMA_WUP(cl, sync_bits);
    case RVXT_CORE_GROUP_CNN:
        return r_atmlib_CNN_WUP(cl, sync_bits);
    case RVXT_CORE_GROUP_CVE:
        return r_atmlib_OCV_WUP(cl, sync_bits);
    case RVXT_CORE_GROUP_IMP:
        return r_atmlib_IMP_WUP(cl, sync_bits);
    default:
        cerrorv("Unsupported coretype: %i\n", coretype);
        return R_ATMLIB_E_NG_CLTYPE;
    }
}

/**
/ SLP params: [command_id, core_this, core_others_only]
**/
R_ATMLIB_RETURN_VALUE Add_SLP(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, const rvxt_core_group_e coretype)
{
    uint32_t sync_bits = 0x0U;
    uint32_t core_caller = 0;
    uint32_t core_others = 0;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[1], &core_caller));
    RETURN_ATMLIB_E_NG_IF_FALSE(set_bits_from_define_string(params[2], &core_others));
    RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_getSyncBits(p_info, core_caller, core_others, &sync_bits));

    switch (coretype)
    {
    case RVXT_CORE_GROUP_DMA:
        return r_atmlib_DMA_SLP(cl, sync_bits);
    case RVXT_CORE_GROUP_CNN:
        return r_atmlib_CNN_SLP(cl, sync_bits);
    case RVXT_CORE_GROUP_CVE:
        return r_atmlib_OCV_SLP(cl, sync_bits);
    case RVXT_CORE_GROUP_IMP:
        return r_atmlib_IMP_SLP(cl, sync_bits);
    default:
        cerrorv("Unsupported coretype: %i\n", coretype);
        return R_ATMLIB_E_NG_CLTYPE;
    }
}

/**
/ DMA params: [command_id, dma_param.leng, dma_param.lop, ...] (see below)
**/
R_ATMLIB_RETURN_VALUE Add_DMA_operation(char *params[MAX_PARAMS_PER_LINE], uint32_t const param_count, R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info)
{
    uint32_t value = 0;
    R_ATMLIB_DMASubsetParam dma_param;
    dma_param.leng = _strtoui(params[1], NULL, 16);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[2], &value));
    dma_param.lop = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[3], &value));
    dma_param.src_mode = value;
    dma_param.srca_data = _strtoui(params[4], NULL, 10);
    dma_param.srcb_data = _strtoui(params[5], NULL, 10);
    dma_param.shift = _strtoi(params[6], NULL, 10);
    dma_param.round = _strtoi(params[7], NULL, 10);
    dma_param.sat = _strtoi(params[8], NULL, 10);
    dma_param.trans_size = _strtoui(params[9], NULL, 10);

    R_ATMLIB_ImageParam img_param;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[10], &value));
    img_param.srca_type = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[11], &value));
    img_param.srcb_type = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[12], &value));
    img_param.dst_type = value;
    img_param.srca_stride = _strtoui(params[13], NULL, 16);
    img_param.srcb_stride = _strtoui(params[14], NULL, 10);
    if (_strtoi(params[15], NULL, 10) == 0)
    {
        cerror("This is not supported!\n");
        uint32_t address = 0;
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[16], &address));
        //img_param.srca_addr = (uint32_t)(gf_GetPhysAddr((void*)(uintptr_t)address) + _strtoui(params[17], NULL, 16));
    }
    else
    {
        img_param.srca_addr = (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, _strtoui(params[16], NULL, 10)) + _strtoui(params[17], NULL, 16));
    }
    img_param.srcb_addr = _strtoui(params[18], NULL, 10);
    if (_strtoi(params[19], NULL, 10) == 0)
    {
        cerror("This is not supported!\n");
        uint32_t address = 0;
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[20], &address));
        //img_param.dst_addr = (uint32_t)(gf_GetPhysAddr((void*)(uintptr_t)address) + _strtoui(params[21], NULL, 16));
    }
    else
    {
        img_param.dst_addr = (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, _strtoui(params[20], NULL, 10)) + _strtoui(params[21], NULL, 16));
    }
    img_param.dst_stride = _strtoui(params[22], NULL, 16);

    RETURN_IF_NOT_ATMLIB_E_OK(r_atmlib_SetDataDMACL(cl, R_ATMLIB_DMA_PXALIGN, &dma_param, &img_param));
    RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendDMAClof(cl, p_info, _strtoui(params[16], NULL, 10), img_param.clofs_srca_addr, 0));
    RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendDMAClof(cl, p_info, _strtoui(params[20], NULL, 10), img_param.clofs_dst_addr, 0));

    if (param_count > 23)
    {
        const unsigned int index = _strtoui(params[23], NULL, 10);

        uint32_t offset = img_param.clofs_srca_addr - 8U /*R_ATMLIB_DMA_CLOFS_S0SAR*/;
        RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendDMAClof(cl, p_info, _strtoui(params[16], NULL, 10), offset + 2U /* R_ATMLIB_DMA_CLOFS_IMGSIZER*/, index * 3 + 1));
        RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendDMAClof(cl, p_info, _strtoui(params[16], NULL, 10), img_param.clofs_srca_addr, index * 3 + 2));
        RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendDMAClof(cl, p_info, _strtoui(params[16], NULL, 10), img_param.clofs_dst_addr, index * 3 + 3));
    }
    return R_ATMLIB_E_OK;
}

#if defined(RCAR_SOC_V3H2) || defined(RCAR_SOC_V3U)
/* ------------------------------ */
/* ---------- CNNIP V2 ---------- */
/* ------------------------------ */
/**
/ CNNPictureProlog params: [command_id, layer_count]
**/
R_ATMLIB_RETURN_VALUE Add_CNNPictureProlog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNPictureProlog(cl, NULL, strtoimax(params[1], NULL, 10)));
    return R_ATMLIB_E_OK;
}

/**
/ CNNPictureEpilog params: [command_id, layer_count]
**/
R_ATMLIB_RETURN_VALUE Add_CNNPictureEpilog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNPictureEpilog(cl, strtoimax(params[1], NULL, 10), NULL));
    return R_ATMLIB_E_OK;
}

/**
/ CNNLayerProlog params: [command_id, maxsum_cnt_thres, minsum_cnt_thres, scres_mode_str, max_val_thres, min_val_thres]
**/
R_ATMLIB_RETURN_VALUE Add_CNNLayerProlog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    uint32_t scresmode = 0;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[3], &scresmode));
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNLayerProlog(cl,
                                                  strtoimax(params[1], NULL, 10),
                                                  strtoimax(params[2], NULL, 10),
                                                  scresmode,
                                                  strtoimax(params[4], NULL, 10),
                                                  strtoimax(params[5], NULL, 10)));
    return R_ATMLIB_E_OK;
}

/**
/ CNNLayerEpilog params: [command_id, fp_handle]
**/
R_ATMLIB_RETURN_VALUE Add_CNNLayerEpilog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNLayerEpilog(cl, strtoimax(params[1], NULL, 10)));
    return R_ATMLIB_E_OK;
}

/**
/ CNNSetupWeights params: [command_id, weight_1, ..., weight_25, input, output]
**/

R_ATMLIB_RETURN_VALUE Add_CNNSetupWeights(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info)
{
    static R_ATMLIB_CNNWeightInfo weight_container;
    static int it = 0;
    if (0 == strtoimax(params[1], NULL, 10))
    {
        /* parsing weights */
        int32_t weights[R_ATMLIB_CNN_FILTER_SIZE] = {0};
        for (uint32_t cnt = 0; cnt < R_ATMLIB_CNN_FILTER_SIZE; cnt++)
        {
            weights[cnt] = strtoimax(params[cnt + 2], NULL, 10);
        }
        weight_container.ch_weight[it].in_id = R_ATMLIB_CNN_DMAI0 + strtoimax(params[0 + 27 + 2], NULL, 10);
        weight_container.ch_weight[it].out_id = R_ATMLIB_CNN_ARI0 + strtoimax(params[1 + 27 + 2], NULL, 10);
        memcpy(weight_container.ch_weight[it].value, weights, R_ATMLIB_CNN_FILTER_SIZE * sizeof(uint32_t));
        it++;
    }
    else if (1 == strtoimax(params[1], NULL, 10))
    {
        // /* Clear Weights */
        // RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNN_CLW(cl));
        /* wrapping up */
        uint32_t weight_format = 0;
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[2], &weight_format));
        weight_container.weight_format = weight_format;
        weight_container.ch_cnt = strtoimax(params[3], NULL, 10);
        RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupWeights(cl, NULL, &weight_container, NULL));
        memset(&weight_container, 0, sizeof(R_ATMLIB_CNNWeightInfo));
        it = 0;
    }
    else if (2 == strtoimax(params[1], NULL, 10))
    {
        // /* Clear Weights */
        // RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNN_CLW(cl));
        /* Set up using DMARF */
        uint32_t value = 0;
        static R_ATMLIB_CNNDMARFParam dmarf_param;

        const size_t index = strtoimax(params[3], NULL, 10);

        dmarf_param.external_sa = (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, index) + strtoumax(params[4], NULL, 16));
        dmarf_param.internal_sa = strtoumax(params[5], NULL, 16);
        dmarf_param.length = strtoumax(params[6], NULL, 10);
        dmarf_param.start_pos = strtoumax(params[7], NULL, 10);
        dmarf_param.end_pos = strtoumax(params[8], NULL, 10);
        uint32_t weight_format = 0;
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[9], &weight_format));
        dmarf_param.format = weight_format;
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[10], &value));
        dmarf_param.data_mode = value;

        /* create empty list of indexes */
        ClofsListCNNEntryMems_t ClofsList_indexes;
        memset(&ClofsList_indexes, 255, sizeof(ClofsListCNNEntryMems_t));

        /* mis-using DMAI[0] for index */
        ClofsList_indexes.dmai[0] = index;

        /* allocate buffer for clofs */
        R_ATMLIB_CNNCLofs_ImageAddr *p_cnnCLofsImgAddr = NULL;
        RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendCNNClofs(cl, p_info, &p_cnnCLofsImgAddr, &ClofsList_indexes));

        RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupWeights(cl, &dmarf_param, NULL, p_cnnCLofsImgAddr->clofs_dmai));
    }

    return R_ATMLIB_E_OK;
}

/**
/ CNNSetupBiases params: [command_id, bias_1, ..., bias_8]
**/
R_ATMLIB_RETURN_VALUE Add_CNNSetupBiases(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    int16_t biases[32] = {0};
    for (uint32_t cnt = 0; cnt < 32; cnt++)
    {
        biases[cnt] = strtoimax(params[cnt + 1], NULL, 10);
    }

    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupBiases(cl, biases));
    return R_ATMLIB_E_OK;
}

/**
/ CNNSetupShifts params: [command_id, wgt_frac, bias_frac]
**/
R_ATMLIB_RETURN_VALUE Add_CNNSetupShifts(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    R_ATMLIB_CNNShiftConfig shift_config;
    shift_config.dmao_frac = strtoimax(params[1], NULL, 10);
    shift_config.weight_frac = strtoimax(params[2], NULL, 10);
    shift_config.bias_frac = strtoimax(params[3], NULL, 10);
    shift_config.lut_frac = strtoimax(params[4], NULL, 10);
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupShifts(cl, &shift_config, RVXT_ATMLIB_CNN_USER_SHIFT_FUNC));
    return R_ATMLIB_E_OK;
}

/**
/ CNNSetupBiases params: [command_id, bias_1, ..., bias_8]
**/
R_ATMLIB_RETURN_VALUE Add_CNNSetupLut(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    (void)(params); // unused
    (void)(cl);     // unused
    // int16_t R_ATMLIB_LUT_POSTOPT[32] = {0};
    // for (uint32_t cnt = 0; cnt < 32; cnt++)
    // {
    //     biases[cnt] = strtoimax(params[cnt + 1], NULL, 10);
    // }

    // RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupBiases(cl, biases));
    return R_ATMLIB_E_OK;
}

/**
/ CNNSetupARI params: [ari_cnt, ch_id x ari_cnt, ari_format, ...]
**/
static uint32_t node_cnt = 0;
R_ATMLIB_RETURN_VALUE Add_CNNSetupARI(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    uint32_t value = 0;
    int ari_cnt = strtoimax(params[1], NULL, 10);

    R_ATMLIB_CNNARIParam ari_param;
    ari_param.ari_cnt = ari_cnt;
    for (int i_ch = 0; i_ch < ari_cnt; i_ch++)
    {
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[i_ch + 2], &value));
        ari_param.ch_id[i_ch] = value;
    }
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 2], &value));
    ari_param.ari_format = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 3], &value));
    ari_param.acti_mode = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 4], &value));
    ari_param.lut_lin_int = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 5], &value));
    ari_param.pad_mode = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 6], &value));
    ari_param.bias_en = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 7], &value));
    ari_param.xypool_mode = value;
    ari_param.xpool = strtoumax(params[ari_cnt + 8], NULL, 10);
    ari_param.ypool = strtoumax(params[ari_cnt + 9], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 10], &value));
    ari_param.cpool_mode = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 11], &value));
    ari_param.label_info = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 12], &value));
    ari_param.maxout_group = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 13], &value));
    ari_param.next_ari_format = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 14], &value));
    ari_param.sftm_round_mode = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ari_cnt + 15], &value));
    ari_param.cpool_ui = value;
    ari_param.upper_bound = strtoumax(params[ari_cnt + 16], NULL, 10);
    ari_param.lower_bound = strtoumax(params[ari_cnt + 17], NULL, 10);
    ari_param.mult_val = strtoimax(params[ari_cnt + 18], NULL, 10);
    ari_param.mult_frac = strtoumax(params[ari_cnt + 19], NULL, 10);

    // Write node count for debug
    uint32_t node_nr = (0xABC00000 + node_cnt);
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNN_WPR(cl, 0x836, 1, &node_nr));
    node_cnt++;

    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupARI(cl, &ari_param, NULL));

    return R_ATMLIB_E_OK;
}

R_ATMLIB_RETURN_VALUE Add_CNNSetupChannelDMAI(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes)
{
    //(void)(ClofsList_indexes);   // unused    uint32_t value = 0;

    static R_ATMLIB_CNNDMAIParam dmai_param;
    static int it = 0;
    static size_t mem_indices[R_ATMLIB_CNN_DMAI_MAX_CH];
    static size_t                mem_indices[R_ATMLIB_CNN_DMAI_MAX_CH];
    if (0 == strtoimax(params[1], NULL, 10))
    {
        /* parsing channel config */
        if (strtoimax(params[2], NULL, 10) == 0)
        {
            uint32_t address = 0;
            RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[3], &address));
            dmai_param.dmai_ch[it].ptr = (uint32_t)(gf_GetPhysAddr((void*)(uintptr_t)address) + strtoumax(params[4], NULL, 16));
        }
        else
        {
            dmai_param.dmai_ch[it].ptr = (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, strtoimax(params[3], NULL, 10)) + strtoumax(params[4], NULL, 16));
        }
        dmai_param.dmai_ch[it].image_x      = strtoimax(params[5], NULL, 10);
        dmai_param.dmai_ch[it].image_y      = strtoimax(params[6], NULL, 10);
        dmai_param.dmai_ch[it].image_stride = strtoimax(params[7], NULL, 10);
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[8], &value));
        dmai_param.dmai_ch[it].image_format = value;
        dmai_param.dmai_ch[it].pad_t = strtoimax(params[9], NULL, 10);
        dmai_param.dmai_ch[it].pad_l = strtoimax(params[10], NULL, 10);
        dmai_param.dmai_ch[it].pad_b = strtoimax(params[11], NULL, 10);
        dmai_param.dmai_ch[it].pad_r = strtoimax(params[12], NULL, 10);
        dmai_param.dmai_ch[it].stride_x = strtoimax(params[13], NULL, 10);
        dmai_param.dmai_ch[it].stride_y = strtoimax(params[14], NULL, 10);
        dmai_param.dmai_ch[it].repeat_skip_x = strtoimax(params[15], NULL, 10);
        dmai_param.dmai_ch[it].repeat_skip_y = strtoimax(params[16], NULL, 10);
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[17], &value));
        dmai_param.dmai_ch[it].mag_type = value;
        dmai_param.dmai_ch[it].dmai_frac = strtoimax(params[18], NULL, 10);
        dmai_param.dmai_ch[it].start_pos = strtoimax(params[19], NULL, 10);
        mem_indices[it] = strtoimax(params[3], NULL, 10);
        it++;
    }
    else
    {
        /* wrapping up */
        int ch_cnt = strtoumax(params[2], NULL, 10);
        dmai_param.ch_count = ch_cnt;
        dmai_param.param_count = strtoumax(params[3], NULL, 10);
        for (int i_ch = 0; i_ch < ch_cnt; i_ch++)
        {
            RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[i_ch + 4], &value));
            dmai_param.ch_id[i_ch]                          = value;
            ClofsList_indexes->dmai[dmai_param.ch_id[i_ch]] = mem_indices[i_ch];
            ClofsList_indexes->dmai[dmai_param.ch_id[i_ch]] = mem_indices[i_ch];
        }
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ch_cnt + 4], &value));
        dmai_param.data_mode = value;
        dmai_param.dil_conv = strtoimax(params[ch_cnt + 5], NULL, 10);
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ch_cnt + 6], &value));
        dmai_param.kernel_mode = value;
        dmai_param.channel_offset = strtoumax(params[ch_cnt + 7], NULL, 16);
        dmai_param.ARI_xLen       = strtoumax(params[ch_cnt + 8], NULL, 10);
        dmai_param.ARI_yLen       = strtoumax(params[ch_cnt + 9], NULL, 10);

        R_ATMLIB_CNNCLofs_ImageAddr *p_cnnCLofsImgAddr = NULL;
        RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendCNNClofs(cl, p_info, &p_cnnCLofsImgAddr, ClofsList_indexes));
        memset(ClofsList_indexes, 255, sizeof(ClofsListCNNEntryMems_t));

        //RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupChannelDMAI(cl, &dmai_param, NULL));
        RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupChannelDMAI(cl, &dmai_param, p_cnnCLofsImgAddr->clofs_dmai));        memset(&dmai_param, 0, sizeof(R_ATMLIB_CNNDMAIParam));
        it = 0;
    }

    return R_ATMLIB_E_OK;
}

R_ATMLIB_RETURN_VALUE Add_CNNSetupChannelDMAC(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes)
{
    //(void)(ClofsList_indexes);   // unused    uint32_t value = 0;

    static R_ATMLIB_CNNDMACParam dmac_param;
    static int it = 0;
    static size_t mem_indices[R_ATMLIB_CNN_DMAC_MAX_CH];
    static size_t                mem_indices[R_ATMLIB_CNN_DMAC_MAX_CH];
    if (0 == strtoimax(params[1], NULL, 10))
    {
        /* parsing channel config */
        dmac_param.dmac_ch[it].ptr = (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, strtoimax(params[3], NULL, 10)) + strtoumax(params[4], NULL, 16));
        dmac_param.dmac_ch[it].image_x = strtoimax(params[5], NULL, 10);
        dmac_param.dmac_ch[it].image_y = strtoimax(params[6], NULL, 10);
        dmac_param.dmac_ch[it].image_stride = strtoimax(params[7], NULL, 10);
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[8], &value));
        dmac_param.dmac_ch[it].image_format = value;
        dmac_param.dmac_ch[it].repeat_skip_x = strtoimax(params[9], NULL, 10);
        dmac_param.dmac_ch[it].repeat_skip_y = strtoimax(params[10], NULL, 10);
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[11], &value));
        dmac_param.dmac_ch[it].mag_type = value;
        dmac_param.dmac_ch[it].dmac_frac = strtoimax(params[12], NULL, 10);
        mem_indices[it]                  = strtoimax(params[3], NULL, 10);
        it++;
    }
    else
    {
        /* wrapping up */
        int ch_cnt = strtoumax(params[2], NULL, 10);
        dmac_param.ch_count = ch_cnt;
        dmac_param.param_count = strtoimax(params[3], NULL, 10);
        for (int i_ch = 0; i_ch < ch_cnt; i_ch++)
        {
            RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[i_ch + 4], &value));
            dmac_param.ch_id[i_ch]                                               = value;
            ClofsList_indexes->dmac[dmac_param.ch_id[i_ch] - R_ATMLIB_CNN_DMAC0] = mem_indices[i_ch];
            ClofsList_indexes->dmac[dmac_param.ch_id[i_ch] - R_ATMLIB_CNN_DMAC0] = mem_indices[i_ch];
        }
        dmac_param.channel_offset = strtoumax(params[ch_cnt + 4], NULL, 16);
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ch_cnt + 5], &value));
        dmac_param.data_mode = value;

        R_ATMLIB_CNNCLofs_ImageAddr *p_cnnCLofsImgAddr = NULL;
        RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendCNNClofs(cl, p_info, &p_cnnCLofsImgAddr, ClofsList_indexes));
        memset(ClofsList_indexes, 255, sizeof(ClofsListCNNEntryMems_t));

        //RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupChannelDMAC(cl, &dmac_param, NULL));
        RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupChannelDMAC(cl, &dmac_param, p_cnnCLofsImgAddr->clofs_dmac));
        memset(&dmac_param, 0, sizeof(R_ATMLIB_CNNDMACParam));
        it = 0;
    }

    return R_ATMLIB_E_OK;
}
R_ATMLIB_RETURN_VALUE Add_CNNSetupChannelDMAO(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes)
{
    //(void)(ClofsList_indexes);   // unused    uint32_t value = 0;

    static R_ATMLIB_CNNDMAOParam dmao_param;
    static int it = 0;
    static size_t mem_indices[R_ATMLIB_CNN_DMAO_MAX_CH];
    static size_t                mem_indices[R_ATMLIB_CNN_DMAO_MAX_CH];
    if (0 == strtoimax(params[1], NULL, 10))
    {
        /* parsing channel config */
        dmao_param.ptr[it] = (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, strtoimax(params[3], NULL, 10)) + strtoumax(params[4], NULL, 16));
        mem_indices[it] = strtoimax(params[3], NULL, 10);
        it++;
    }
    else
    {
        /* wrapping up */
        int ch_cnt = strtoumax(params[2], NULL, 10);
        dmao_param.ch_count = ch_cnt;
        dmao_param.param_count = strtoimax(params[3], NULL, 10);
        for (int i_ch = 0; i_ch < ch_cnt; i_ch++)
        {
            RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[i_ch + 4], &value));
            dmao_param.ch_id[i_ch]                                               = value;
            ClofsList_indexes->dmao[dmao_param.ch_id[i_ch] - R_ATMLIB_CNN_DMAO0] = mem_indices[i_ch];
            ClofsList_indexes->dmao[dmao_param.ch_id[i_ch] - R_ATMLIB_CNN_DMAO0] = mem_indices[i_ch];
        }
        dmao_param.channel_offset = strtoumax(params[ch_cnt + 4], NULL, 16);
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ch_cnt + 5], &value));
        dmao_param.data_mode = value;
        dmao_param.image_x = strtoimax(params[ch_cnt + 6], NULL, 10);
        dmao_param.image_y = strtoimax(params[ch_cnt + 7], NULL, 10);
        dmao_param.image_stride = strtoimax(params[ch_cnt + 8], NULL, 10);
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ch_cnt + 9], &value));
        dmao_param.image_format = value;
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[ch_cnt + 10], &value));
        dmao_param.next_layer_kernel_mode = value;

        R_ATMLIB_CNNCLofs_ImageAddr* p_cnnCLofsImgAddr = NULL;
        RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendCNNClofs(cl, p_info, &p_cnnCLofsImgAddr, ClofsList_indexes));
        memset(ClofsList_indexes, 255, sizeof(ClofsListCNNEntryMems_t));

        //RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupChannelDMAO(cl, &dmao_param, NULL));
        RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupChannelDMAO(cl, &dmao_param, p_cnnCLofsImgAddr->clofs_dmao));

        RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAI(cl));
        RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAC(cl));
        RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAO(cl));

        // RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAI(cl));
        // RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAC(cl));
        // RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAO(cl));

        // RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartTile(cl));
        // RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNN_SYNCS(cl, 0));
        memset(&dmao_param, 0, sizeof(R_ATMLIB_CNNDMAOParam));
        it = 0;
    }

    return R_ATMLIB_E_OK;
}

R_ATMLIB_RETURN_VALUE Add_CNNStartSubcore(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    int subcore = strtoimax(params[1], NULL, 10);
    switch (subcore)
    {
        case 0:
            // RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupARI(cl, &%s, NULL));
            break;
        case 1:
            RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAI(cl));
            break;
        // case 5:
        //     // Set DMAIE to 0 to start DummyDMAI
        //     cl->cnn_data->channel_props.DMAIE = 0;
        //     RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAI(cl));
        //     break;
        case 2:
            RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAC(cl));
            break;
        case 3:
            RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartDMAO(cl));
            break;
        case 4:
            RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNStartTile(cl));
            break;
        default:
            cerrorv("No start sequence available for gerneic-node: '%d'!\n", subcore);
            return R_ATMLIB_E_NG;
    }
    return R_ATMLIB_E_OK;
}
R_ATMLIB_RETURN_VALUE Add_CNNSyncs(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    uint32_t value = 0;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[1], &value));
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNN_SYNCS(cl, value));
    return R_ATMLIB_E_OK;
}

#elif defined(RCAR_SOC_V3H1) || defined(RCAR_SOC_V3M2)
/* ------------------------------ */
/* ---------- CNNIP V1 ---------- */
/* ------------------------------ */
/**
/ CNNPictureProlog params: [command_id, layer_count]
**/
R_ATMLIB_RETURN_VALUE Add_CNNPictureProlog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNPictureProlog(cl, NULL, _strtoui8(params[1], NULL, 10), R_ATMLIB_CNN_DISABLE));
    return R_ATMLIB_E_OK;
}

/**
/ CNNPictureEpilog params: [command_id, layer_count]
**/
R_ATMLIB_RETURN_VALUE Add_CNNPictureEpilog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNPictureEpilog(cl, _strtoui8(params[1], NULL, 10), RVXT_ATMLIB_CNN_USER_FRAC_ADJ_FUNC));
    return R_ATMLIB_E_OK;
}

/**
/ CNNLayerProlog params: [command_id, maxsum_cnt_thres, minsum_cnt_thres, scres_mode_str, max_val_thres, min_val_thres]
**/
R_ATMLIB_RETURN_VALUE Add_CNNLayerProlog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    uint32_t mode = 0;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[3], &mode));
    return r_atmlib_CNNLayerProlog(cl,
                                   _strtoui32(params[1], NULL, 10),
                                   _strtoui32(params[2], NULL, 10),
                                   mode,
                                   _strtoui16(params[4], NULL, 10),
                                   _strtoui16(params[5], NULL, 10));
}

/**
/ CNNLayerEpilog params: [command_id, fp_handle]
**/
R_ATMLIB_RETURN_VALUE Add_CNNLayerEpilog(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    uint32_t value = 0;
    RETURN_ATMLIB_E_NG_IF_FALSE(handle_fp_handle_string(params[1], &value));
    return r_atmlib_CNNLayerEpilog(cl, (uint8_t)value);
}

/**
/ DMA_Config_disabled params: [command_id, CNNPlaneParam.fp_handle, CNNPlaneParam.id, ...] (see below)
**/
R_ATMLIB_RETURN_VALUE Add_DMA_Config_disabled(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes)
{
    (void)p_info;
    uint32_t value = 0;

    R_ATMLIB_CNNPlaneParam CNNPlaneParam;
    CNNPlaneParam.fp_handle = RVX_FP_FIXED_START + 1;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[2], &value));
    CNNPlaneParam.id = value;
    CNNPlaneParam.ptr = R_ATMLIB_CNN_MEM_INVALID;
    CNNPlaneParam.image_x = _strtoui16(params[4], NULL, 10);
    CNNPlaneParam.image_y = _strtoui16(params[5], NULL, 10);
    CNNPlaneParam.image_stride = _strtoui16(params[6], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[7], &value));
    CNNPlaneParam.image_format = value;

    if (CNNPlaneParam.id < R_ATMLIB_CNN_DMAO0) // DMAI
    {
        ClofsList_indexes->dmai[CNNPlaneParam.id] = R_ATMLIB_CNN_MEM_INVALID; //strtoimax(params[14], NULL, 10);
    }
    else if (CNNPlaneParam.id < R_ATMLIB_CNN_DMAC0) // DMAO
    {
        ClofsList_indexes->dmao[CNNPlaneParam.id - R_ATMLIB_CNN_DMAO0] = R_ATMLIB_CNN_MEM_INVALID; // strtoimax(params[14], NULL, 10);
    }
    else // DMAC
    {
        ClofsList_indexes->dmac[CNNPlaneParam.id - R_ATMLIB_CNN_DMAC0] = R_ATMLIB_CNN_MEM_INVALID; //strtoimax(params[14], NULL, 10);
    }

    return r_atmlib_CNNSetupChannel(cl, &CNNPlaneParam);
}

/**
/ DMA_Config params: [command_id, CNNPlaneParam.pad_t, CNNPlaneParam.pad_l, ...] (see below)
**/
R_ATMLIB_RETURN_VALUE Add_DMA_Config(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *ClofsList_indexes)
{
    uint32_t value = 0;

    R_ATMLIB_CNNPlaneParam CNNPlaneParam;
    CNNPlaneParam.pad_t = _strtoui8(params[1], NULL, 10);
    CNNPlaneParam.pad_l = _strtoui8(params[2], NULL, 10);
    CNNPlaneParam.pad_b = _strtoui8(params[3], NULL, 10);
    CNNPlaneParam.pad_r = _strtoui8(params[4], NULL, 10);
    CNNPlaneParam.stride_x = _strtoui8(params[5], NULL, 10);
    CNNPlaneParam.stride_y = _strtoui8(params[6], NULL, 10);
    CNNPlaneParam.repeat_x = _strtoui8(params[7], NULL, 10);
    CNNPlaneParam.repeat_y = _strtoui8(params[8], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[9], &value));
    CNNPlaneParam.repeat_fill = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[10], &value));
    CNNPlaneParam.repeat_skip = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(handle_fp_handle_string(params[11], &value));
    CNNPlaneParam.fp_handle = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[12], &value));
    CNNPlaneParam.id = value;
    if (_strtoi(params[13], NULL, 10) == 0)
    {
        cerror("Not supported!\n");
        uint32_t address = 0;
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[14], &address));
        //CNNPlaneParam.ptr = (uint32_t)(gf_GetPhysAddr((void*)(uintptr_t)address) + strtoumax(params[15], NULL, 16));
    }
    else
    {
        CNNPlaneParam.ptr = (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, _strtoui(params[14], NULL, 10)) + strtoumax(params[15], NULL, 16));
    }
    CNNPlaneParam.image_x = _strtoui16(params[16], NULL, 10);
    CNNPlaneParam.image_y = _strtoui16(params[17], NULL, 10);
    CNNPlaneParam.image_stride = _strtoui16(params[18], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[19], &value));
    CNNPlaneParam.image_format = value;

    if (CNNPlaneParam.id < R_ATMLIB_CNN_DMAO0) // DMAI
    {
        ClofsList_indexes->dmai[CNNPlaneParam.id] = _strtoui16(params[14], NULL, 10);
    }
    else if (CNNPlaneParam.id < R_ATMLIB_CNN_DMAC0) // DMAO
    {
        ClofsList_indexes->dmao[CNNPlaneParam.id - R_ATMLIB_CNN_DMAO0] = _strtoui16(params[14], NULL, 10);
    }
    else // DMAC
    {
        ClofsList_indexes->dmac[CNNPlaneParam.id - R_ATMLIB_CNN_DMAC0] = _strtoui16(params[14], NULL, 10);
    }

    return r_atmlib_CNNSetupChannel(cl, &CNNPlaneParam);
}

/**
/ CNNSetupWeights params: [command_id, weight_1, ..., weight_25, input, output]
**/

R_ATMLIB_RETURN_VALUE Add_CNNSetupWeights(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info)
{
    (void)(p_info);

    int16_t weights[25] = {0};
    for (uint32_t cnt = 0; cnt < 25; cnt++)
    {
        weights[cnt] = _strtoi16(params[cnt + 1], NULL, 10);
    }

    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupWeights(cl, R_ATMLIB_CNN_DMAI0 + strtoimax(params[26], NULL, 10), R_ATMLIB_CNN_DMAO0 + strtoimax(params[27], NULL, 10), weights));
    return R_ATMLIB_E_OK;
}

/**
/ CNNSetupBiases params: [command_id, bias_1, ..., bias_8]
**/
R_ATMLIB_RETURN_VALUE Add_CNNSetupBiases(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    int16_t biases[8] = {0};
    for (uint32_t cnt = 0; cnt < 8; cnt++)
    {
        biases[cnt] = _strtoi16(params[cnt + 1], NULL, 10);
    }

    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupBiases(cl, biases));
    return R_ATMLIB_E_OK;
}

/**
/ CNNSetupShifts params: [command_id, wgt_frac, bias_frac]
**/
R_ATMLIB_RETURN_VALUE Add_CNNSetupShifts(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_CNNSetupShifts(cl, _strtoui8(params[1], NULL, 10), _strtoui8(params[2], NULL, 10), RVXT_ATMLIB_CNN_USER_SHIFT_FUNC));
    return R_ATMLIB_E_OK;
}

/**
/ CNNProcessTile params: [command_id, CNNConvParam.breluval, CNNConvParam.bias, ...] (see below)
**/
R_ATMLIB_RETURN_VALUE Add_CNNProcessTile(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info, ClofsListCNNEntryMems_t *p_clofsList_indexes)
{
    uint32_t value = 0;

    R_ATMLIB_CNNCLofs_ImageAddr *p_cnnCLofsImgAddr = NULL;
    R_ATMLIB_CNNConvParam CNNConvParam;
    if (strcmp(params[1], "RVXT_ATMLIB_CNN_BRELU_INVALID") == 0)
    {
        RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[1], &value));
        CNNConvParam.breluval = (uint16_t)value;
    }
    else
    {
        CNNConvParam.breluval = _strtoui16(params[1], NULL, 10);
    }
    CNNConvParam.bias = strtoimax(params[2], NULL, 10);
    CNNConvParam.xpool = _strtoui8(params[3], NULL, 10);
    CNNConvParam.ypool = _strtoui8(params[4], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[5], &value));
    CNNConvParam.ranksel = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[6], &value));
    CNNConvParam.rankmode = value;
    CNNConvParam.custom_label = strtoimax(params[7], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[8], &value));
    CNNConvParam.maxout_group = value;

    RETURN_ATMLIB_E_NG_IF_FALSE(rvxt_int_appendCNNClofs(cl, p_info, &p_cnnCLofsImgAddr, p_clofsList_indexes));
    memset(p_clofsList_indexes, 255, sizeof(ClofsListCNNEntryMems_t));
    return r_atmlib_CNNProcessTile(cl, &CNNConvParam, p_cnnCLofsImgAddr);
}
#endif

/**
/ OCV_WPR params: [command_id, addr, datacount, data...]
**/
R_ATMLIB_RETURN_VALUE Add_CVE_WPR(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    const int val = _strtoi(params[2], NULL, 10);
    if (0 < val)
    {
        const unsigned int datacount = (unsigned int)val;
        uint32_t *data = (uint32_t *)malloc(sizeof(uint32_t) * (unsigned int)datacount);
        for (unsigned int i_data = 0; i_data < datacount; i_data++)
        {
            data[i_data] = _strtoui(params[3 + i_data], NULL, 10);
        }
        RVXT_ATMLIB_ASSERT_OK(r_atmlib_OCV_WPR(cl, _strtoui(params[1], NULL, 10), datacount, &data[0]));
        free(data);
        return R_ATMLIB_E_OK;
    }
    else
    {
        cerror("Datacount for CVE WPR needs to be above 0!");
    }
    return R_ATMLIB_E_NG_ARG2;
}

/**
/ OCV_WPR with address params: [command_id, addr, unused, memory_index, Offset1, Offset2, datacount, data...]
**/
R_ATMLIB_RETURN_VALUE Add_CVE_WPR_addr(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info)
{
    const int val = _strtoi(params[5], NULL, 10) + 1;
    if (0 < val)
    {
        const unsigned int datacount = (unsigned int)val;
        uint32_t *data = (uint32_t *)malloc(sizeof(uint32_t) * datacount);
        // uint32_t data[datacount];
        data[0] = (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, _strtoui(params[3], NULL, 10)) + _strtoui(params[4], NULL, 16));
        for (unsigned int i_data = 1; i_data < datacount; i_data++)
        {
            data[i_data] = _strtoui(params[5 + i_data], NULL, 10);
        }
        RVXT_ATMLIB_ASSERT_OK(r_atmlib_OCV_WPR(cl, _strtoui(params[1], NULL, 10), datacount, &data[0]));
        free(data);
        return R_ATMLIB_E_OK;
    }
    else
    {
        cerror("Datacount for CVE WPR needs to be above 0!");
    }
    return R_ATMLIB_E_NG_ARG2;
}

/**
/ OCV_GWMDMAC params: [command_id, start_ext_x, start_ext_y, start_gwm, stride_gwm, length_x, length_y, direction, plane_number]
**/
R_ATMLIB_RETURN_VALUE Add_CVE_GWMDMAC(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    uint32_t data[10];
    data[0] = (_strtoui(params[1], NULL, 10) << 16) + _strtoui(params[2], NULL, 10);                       /* start_ext[0] bytes offset in X, start_ext[1] in Y */
    data[1] = _strtoui(params[3], NULL, 10);                                                               /* start_gwm bytes offset in GWM */
    data[2] = _strtoui(params[4], NULL, 10);                                                               /* stride_gwm bytes stride in GWM */
    data[3] = (_strtoui(params[5], NULL, 10) << 16) + _strtoui(params[6], NULL, 10);                       /* ROI dimension to copy, in length[0] bytes columns, on length[1] lines */
    r_atmlib_OCV_WPR(cl, 0x03A4U, 4, data);                                                                // R_IMPX5P_REG_OCV_DMEXTMEMOFSADDR = 0x03A4U
    data[0] = (3 << 12) + (_strtoui(params[7], NULL, 10) << 8) + (_strtoui(params[8], NULL, 10) << 4) + 1; // (3 << 12) + (direction << 8) + (plane_number << 4) + 1 =0x3101;
    r_atmlib_OCV_WPR(cl, 0x03A0U, 1, data);                                                                // R_IMPX5P_REG_OCV_DMCR0 = 0x03A0U
    r_atmlib_OCV_SYNCS(cl, R_ATMLIB_OCVSYNCS_GWMTGDMAC);                                                   // R_ATMLIB_OCVSYNCS_GWMTGDMAC = 0

    return R_ATMLIB_E_OK;
}

/**
/ OCV_RECT params: [command_id, dx1, dy1, dx2, dy2, xlen, ylen, xstart, ystart]
**/
R_ATMLIB_RETURN_VALUE Add_CVE_Rect(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    R_ATMLIB_OCVRectParam rect;
    rect.dx1 = _strtoi16(params[1], NULL, 10);   // step x1
    rect.dy1 = _strtoi16(params[2], NULL, 10);   // step y1
    rect.dx2 = _strtoi16(params[3], NULL, 10);   // step x2
    rect.dy2 = _strtoi16(params[4], NULL, 10);   // step y2
    rect.xlen = _strtoui16(params[5], NULL, 10); // length x
    rect.ylen = _strtoui16(params[6], NULL, 10); // length y
    rect.xs = _strtoi16(params[7], NULL, 10);    // start x
    rect.ys = _strtoi16(params[8], NULL, 10);    // start y
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_OCV_RECT(cl, 0, 0, 0, &rect));
    return R_ATMLIB_E_OK;
}

/**
/ OCV_SYNC params: [command_id]
**/
R_ATMLIB_RETURN_VALUE Add_CVE_Sync(R_ATMLIB_CLData *cl)
{
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_OCV_SYNCS(cl, 2));
    RVXT_ATMLIB_ASSERT_OK(r_atmlib_OCV_SYNCM(cl, 1, 1, 1, 1, 1));
    return R_ATMLIB_E_OK;
}

/**
/ IMP_Config: [command_id, size_x, size_y, mag_x, mag_y, width, scale, const_a, const_b, binthr_min, binthr_max, opt, srca_unpack, srcb_unpack, dst_pack, subset]
**/
R_ATMLIB_RETURN_VALUE Add_IMP_Config(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    uint32_t value = 0;

    R_ATMLIB_IMPSubsetParam2 imp_param;
    imp_param.leng = (uint32_t)((uint32_t)_strtoui16(params[1], NULL, 16) << 16) | _strtoui16(params[2], NULL, 16);
    imp_param.mag = (uint32_t)((uint32_t)_strtoui16(params[3], NULL, 10) << 16) | _strtoui16(params[4], NULL, 10);
    imp_param.scale = _strtoui32(params[5], NULL, 10);
    imp_param.const_a = _strtoi32(params[6], NULL, 10);
    imp_param.const_b = _strtoi32(params[7], NULL, 10);
    imp_param.binthr_min = _strtoi32(params[8], NULL, 10);
    imp_param.binthr_max = _strtoi32(params[9], NULL, 10);
    imp_param.opt = _strtoui32(params[10], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[11], &value));
    imp_param.pack_en = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[12], &value));
    imp_param.srca_unpack = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[13], &value));
    imp_param.srcb_unpack = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[14], &value));
    imp_param.dst_pack = value;

    if (_strtoi(params[16], NULL, 10) > 0)
    {
        for (size_t i_coeff = 0; i_coeff < _strtoui(params[16], NULL, 10); i_coeff++)
        {
            imp_param.COEFF[i_coeff] = _strtoi32(params[17 + i_coeff], NULL, 10);
        }
    }

    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[15], &value));
    return r_atmlib_SetDataIMPCL2(cl, value, &imp_param);
}

/**
/ IMP_Image: [command_id, IMPSubSet, height, width, srca_type, srcb_type, dst_type, srca_stride, srcb_stride, dst_stride, srca_addr[3], use_srcB, srcb_addr[3], dst_addr[3]...]
**/
R_ATMLIB_RETURN_VALUE Add_IMP_Image(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl, const rvxt_info_t *const p_info)
{
    uint32_t value = 0;

    R_ATMLIB_ImageParam img_param;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[1], &value));
    img_param.srca_type = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[2], &value));
    img_param.srcb_type = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[3], &value));
    img_param.dst_type = value;
    img_param.srca_stride = _strtoui32(params[4], NULL, 16);
    img_param.srcb_stride = _strtoui32(params[5], NULL, 16);
    img_param.dst_stride = _strtoui32(params[6], NULL, 16);
    img_param.srca_addr = (_strtoi(params[7], NULL, 10) == 0) ? 0 : (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, _strtoui(params[8], NULL, 10)) + _strtoui(params[9], NULL, 16));
    img_param.srcb_addr = (_strtoi(params[10], NULL, 10) == 0) ? 0 : (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, _strtoui(params[11], NULL, 10)) + _strtoui(params[12], NULL, 16));
    img_param.dst_addr = (uint32_t)(rvxt_int_calculateMemoryAddressPhys(p_info, _strtoui(params[14], NULL, 10)) + _strtoui(params[15], NULL, 16));
    img_param.clip_min = _strtoui16(params[16], NULL, 10);
    img_param.clip_max = _strtoui16(params[17], NULL, 10);
    img_param.srca_mag_x = _strtoi8(params[18], NULL, 10);
    img_param.srca_mag_y = _strtoi8(params[19], NULL, 10);
    img_param.srcb_mag_x = _strtoi8(params[20], NULL, 10);
    img_param.srcb_mag_y = _strtoi8(params[21], NULL, 10);
    img_param.dst_mag_x = _strtoi8(params[22], NULL, 10);
    img_param.dst_mag_y = _strtoi8(params[23], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[24], &value));
    img_param.srca_unpack = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[25], &value));
    img_param.srcb_unpack = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[26], &value));
    img_param.dst_pack = value;
    return r_atmlib_SetImageIMPCL(cl, &img_param);
}

/**
/ IMP_Pre: [command_id]
**/
R_ATMLIB_RETURN_VALUE Add_IMP_Pre(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    uint32_t value = 0;

    R_ATMLIB_IMPPreProcParam param_pre;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[1], &value));
    param_pre.srca_lut = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[2], &value));
    param_pre.srcb_lut = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[3], &value));
    param_pre.bnr_en = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[4], &value));
    param_pre.bin_em = value;
    param_pre.binthr_max = _strtoi32(params[5], NULL, 10);
    param_pre.binthr_min = _strtoi32(params[6], NULL, 10);
    param_pre.shift = _strtoi32(params[7], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[8], &value));
    param_pre.round = value;
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[9], &value));
    param_pre.sat = value;
    param_pre.sat_width = _strtoui32(params[10], NULL, 10);
    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[11], &value));
    param_pre.scale_type = value;

    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[12], &value));
    return r_atmlib_SetPreProcess(cl, value, &param_pre);
}

/**
/ IMP_Post: [command_id]
**/
R_ATMLIB_RETURN_VALUE Add_IMP_Post(char *params[MAX_PARAMS_PER_LINE], R_ATMLIB_CLData *cl)
{
    uint32_t value = 0;

    R_ATMLIB_IMPPostProcParam2 param_post;
    param_post.scale = _strtoui32(params[1], NULL, 10);
    param_post.binthr_max = _strtoi32(params[2], NULL, 10);
    param_post.binthr_min = _strtoi32(params[3], NULL, 10);
    param_post.constant = _strtoi32(params[4], NULL, 10);

    RETURN_ATMLIB_E_NG_IF_FALSE(stringtodef(params[5], &value));
    return r_atmlib_SetPostProcess2(cl, value, &param_post);
}

R_ATMLIB_RETURN_VALUE rvxt_csv_DMA_cl_from_csv(R_ATMLIB_CLData *cl, char *corename, const rvxt_info_t *const p_info)
{
    return rvxt_cl_from_csv(cl, corename, p_info, RVXT_CORE_GROUP_DMA, false, false);
}
R_ATMLIB_RETURN_VALUE rvxt_csv_CNN_cl_from_csv(R_ATMLIB_CLData *cl, char *corename, const rvxt_info_t *const p_info)
{
    return rvxt_cl_from_csv(cl, corename, p_info, RVXT_CORE_GROUP_CNN, false, false);
}
R_ATMLIB_RETURN_VALUE rvxt_csv_CVE_cl_from_csv(R_ATMLIB_CLData *cl, char *corename, const rvxt_info_t *const p_info)
{
    return rvxt_cl_from_csv(cl, corename, p_info, RVXT_CORE_GROUP_CVE, false, false);
}
R_ATMLIB_RETURN_VALUE rvxt_csv_IMP_cl_from_csv(R_ATMLIB_CLData *cl, char *corename, const rvxt_info_t *const p_info)
{
    return rvxt_cl_from_csv(cl, corename, p_info, RVXT_CORE_GROUP_IMP, false, false);
}
