
#include <assert.h>
#include <limits.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "r_atmlib_types.h"
#include "rcar-xos/atmlib/r_atmlib_prot.h"
#include "../ince/rvx_target/info.h"

//#include "../commandlist/user_ocfp_table.h"

#ifdef UNUSED
#elif defined(__GNUC__)
#define UNUSED(x) UNUSED_##x __attribute__((unused))
#elif defined(__LCLINT__)
#define UNUSED(x) /*@unused@*/ x
#else
#define UNUSED(x) x
#endif

#ifndef MAX
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#endif

#define cerror printf

#if defined(HAVE_ATMLIB_CNNIPv1)

#define RETURN_IF_NOT_ATMLIB_E_OK(val)      \
    {                                       \
        if (R_ATMLIB_E_OK != val)           \
        {                                   \
            cerror("'" #val "' failed!\n"); \
            return val;                     \
        }                                   \
    }

// register offsets needed here: Is this private?
#define ATMLIB_CNN_R0 (0x0300U)
#define ATMLIB_CNN_R1 (0x0304U)
#define ATMLIB_CNN_R2 (0x0308U)
#define ATMLIB_CNN_SFTI_CH(ch) (0x0200U + 0x0004U * ch)
#define ATMLIB_CNN_SFTB (0x0220U)
#define ATMLIB_CNN_SFTM (0x0224U)
#define ATMLIB_CNN_SFTC (0x0228U)
#define ATMLIB_CNN_SFTC_CH(ch) (0x0230U + 0x0004U * ch)

#define ATMLIB_CNN_OCFP (0x0400U)

#define R_ATMLIB_CNN_OCFP_TABLE(dynocfp) ((ATMLIB_CNN_OCFP + dynocfp * 4U) / 4U)

R_ATMLIB_RETURN_VALUE CNN_UserShiftFuncFixed(
    R_ATMLIB_CLData *const cldata,
    const uint32_t *const ch_fp_handles,
    int8_t weight_frac,
    int8_t bias_frac);

R_ATMLIB_RETURN_VALUE CNN_UserShiftFuncStatic(
    R_ATMLIB_CLData *const cldata,
    const uint32_t *const ch_fp_handles,
    int8_t weight_frac,
    int8_t bias_frac);

R_ATMLIB_RETURN_VALUE CNN_UserShiftFuncDyn(
    R_ATMLIB_CLData *const cldata,
    const uint32_t *const ch_fp_handles,
    int8_t weight_frac,
    int8_t bias_frac);

R_ATMLIB_RETURN_VALUE CNN_UserShiftFunc(
    R_ATMLIB_CLData *const cldata,
    const uint32_t *const ch_fp_handles,
    int8_t weight_frac,
    int8_t bias_frac)
{
    //return CNN_UserShiftFuncFixed(cldata, ch_fp_handles, weight_frac, bias_frac);
    return CNN_UserShiftFuncStatic(cldata, ch_fp_handles, weight_frac, bias_frac);
    //return CNN_UserShiftFuncDynamic(cldata, ch_fp_handles, weight_frac, bias_frac);
}

R_ATMLIB_RETURN_VALUE CNN_UserShiftFuncFixed(
    R_ATMLIB_CLData *const cldata,
    const uint32_t *const ch_fp_handles,
    int8_t weight_frac,
    int8_t bias_frac)
{
    assert(ch_fp_handles != NULL);

    int16_t dmai_frac = 0;
    int16_t dmac_frac = 0;
    int16_t dmao_frac = 0;

    {
        uint32_t fp_handle;
        int dmao_start_index = cldata->cnn_data->dmach_max[R_ATMLIB_CNN_TYPE_DMAI];
        int dmac_start_index = dmao_start_index + cldata->cnn_data->dmach_max[R_ATMLIB_CNN_TYPE_DMAO];
        fp_handle = ch_fp_handles[0]; // DMAI fp_handle
        assert(fp_handle >= (RVX_FP_FIXED_START - RVX_FP_FIXED_MAX_NEGATIVE));
        dmai_frac = (int16_t)(fp_handle - RVX_FP_FIXED_START);
        fp_handle = ch_fp_handles[dmac_start_index]; // DMAC fp_handle
        if (R_ATMLIB_CNN_CHANNEL_UNUSED != fp_handle)
        {
            if (fp_handle < (RVX_FP_FIXED_START - RVX_FP_FIXED_MAX_NEGATIVE))
            {
                return R_ATMLIB_E_NG_PLANE_FP_HANDLE;
            }
            dmac_frac = (int16_t)(fp_handle - RVX_FP_FIXED_START);
        }
        fp_handle = ch_fp_handles[dmao_start_index]; // DMAO
        assert(fp_handle >= (RVX_FP_FIXED_START - RVX_FP_FIXED_MAX_NEGATIVE));
        dmao_frac = (int16_t)(fp_handle - RVX_FP_FIXED_START);
    }

    /* find min FP value for DMAI */
    bool do_sfti = false;
    {
        int fp_value_dmai_min = INT_MAX;
        int fp_value_dmai_max = INT_MIN;

        for (unsigned int i = 0; i < cldata->cnn_data->dmach_max[R_ATMLIB_CNN_TYPE_DMAI]; i++)
        {
            uint32_t fp_handle = ch_fp_handles[i];
            if (R_ATMLIB_CNN_CHANNEL_UNUSED != fp_handle)
            {
                int fp_value = ((int)fp_handle) - RVX_FP_FIXED_START;

                if (fp_value < (0 - RVX_FP_FIXED_MAX_NEGATIVE))
                {
                    return R_ATMLIB_E_NG_PLANE_FP_HANDLE;
                }

                fp_value_dmai_max = MAX(fp_value_dmai_max, fp_value);
                fp_value_dmai_min = MIN(fp_value_dmai_min, fp_value);
            }
        }
        dmai_frac = (int16_t)fp_value_dmai_min;
        do_sfti = fp_value_dmai_min != fp_value_dmai_max;
    }

    /* MAC shift */
    int16_t mac_shift = (int16_t)(weight_frac + dmai_frac - dmao_frac);

    /* Carry shift */
    int16_t carry_shift = (int16_t)(mac_shift + dmao_frac - dmac_frac);

    /* Bias shift */
    int16_t bias_shift = (int16_t)(weight_frac + dmai_frac - bias_frac);

    if ((mac_shift < 0) || (carry_shift < 0) || (bias_shift < 0))
    {
        return R_ATMLIB_E_NG_PLANE_FP_HANDLE;
    }

    /* Set shift registers */
    {
        if (do_sfti)
        {
            for (unsigned int i = 0; i < cldata->cnn_data->dmach_max[R_ATMLIB_CNN_TYPE_DMAI]; i++)
            {
                const int fp_handle = (int)ch_fp_handles[i];
                const int fp_value = fp_handle - RVX_FP_FIXED_START;
                const int16_t shift = (int16_t)(dmai_frac - fp_value);
                RETURN_IF_NOT_ATMLIB_E_OK(r_atmlib_CNN_WRI(cldata, (uint16_t)(ATMLIB_CNN_SFTI_CH(i) / 4U), shift, 1));
            }
        }
        else
        {
            RETURN_IF_NOT_ATMLIB_E_OK(r_atmlib_CNN_WRI(cldata, (uint16_t)(ATMLIB_CNN_SFTI_CH(0) / 4U), 0, 4));
        }
    }

    RETURN_IF_NOT_ATMLIB_E_OK(r_atmlib_CNN_WRI(cldata, (uint16_t)(ATMLIB_CNN_SFTM / 4U), mac_shift, 1));
    RETURN_IF_NOT_ATMLIB_E_OK(r_atmlib_CNN_WRI(cldata, (uint16_t)(ATMLIB_CNN_SFTC / 4U), carry_shift, 1));
    RETURN_IF_NOT_ATMLIB_E_OK(r_atmlib_CNN_WRI(cldata, (uint16_t)(ATMLIB_CNN_SFTB / 4U), bias_shift, 1));

    return R_ATMLIB_E_OK;
}

R_ATMLIB_RETURN_VALUE CNN_UserShiftFuncStatic(
    R_ATMLIB_CLData *const cldata,
    const uint32_t *const ch_fp_handles,
    int8_t weight_frac,
    int8_t bias_frac)
{
    assert(ch_fp_handles != NULL);

    unsigned int fp_handle;
    int dmao_start_index = cldata->cnn_data->dmach_max[R_ATMLIB_CNN_TYPE_DMAI];
    int dmac_start_index = dmao_start_index + cldata->cnn_data->dmach_max[R_ATMLIB_CNN_TYPE_DMAO];
    fp_handle = ch_fp_handles[0];                                      // DMAI fp_handle
    if (fp_handle >= (RVX_FP_FIXED_START - RVX_FP_FIXED_MAX_NEGATIVE)) // assume fixed case...
    {
        return CNN_UserShiftFuncFixed(cldata, ch_fp_handles, weight_frac, bias_frac);
    }
    uint16_t icfp_h = (uint16_t)fp_handle;
    fp_handle = ch_fp_handles[dmac_start_index]; // DMAC fp_handle
    if (fp_handle != R_ATMLIB_CNN_CHANNEL_UNUSED)
    {
        assert(fp_handle < R_ATMLIB_MAX_DYN_FP_HANDLE);
    }
    uint32_t ccfp_h = fp_handle;
    fp_handle = ch_fp_handles[dmao_start_index]; // DMAO fp_handle
    assert(fp_handle < R_ATMLIB_MAX_DYN_FP_HANDLE);
    uint16_t ocfp_h = (uint16_t)fp_handle;

    uint16_t r0_add = ATMLIB_CNN_R0 / 4U;
    uint16_t r1_add = ATMLIB_CNN_R1 / 4U;
    uint16_t sftm_add = ATMLIB_CNN_SFTM / 4U;
    uint16_t sftc_add = ATMLIB_CNN_SFTC / 4U;
    uint16_t sftb_add = ATMLIB_CNN_SFTB / 4U;
    uint16_t icfp_add = (uint16_t)(R_ATMLIB_CNN_OCFP_TABLE(icfp_h));
    uint16_t ccfp_add = (uint16_t)(R_ATMLIB_CNN_OCFP_TABLE((uint16_t)ccfp_h));
    uint16_t ocfp_add = (uint16_t)(R_ATMLIB_CNN_OCFP_TABLE(ocfp_h));

    /*-- MAC shift --*/
    r_atmlib_CNN_WRI(cldata, r0_add, (uint16_t)weight_frac, 1);
    r_atmlib_CNN_ADD(cldata, r0_add, icfp_add, 1);
    r_atmlib_CNN_SUB(cldata, r0_add, ocfp_add, 1);
    r_atmlib_CNN_WR(cldata, sftm_add, r0_add, 1);

    /*-- Carry shift --*/
    if (ccfp_h != R_ATMLIB_CNN_CHANNEL_UNUSED)
    {
        r_atmlib_CNN_WRI(cldata, r0_add, (uint16_t)weight_frac, 1);
        r_atmlib_CNN_ADD(cldata, r0_add, icfp_add, 1);
        r_atmlib_CNN_SUB(cldata, r0_add, ccfp_add, 1);
        r_atmlib_CNN_WR(cldata, sftc_add, r0_add, 1);
    }

    /*-- Bias shift --*/
    r_atmlib_CNN_WRI(cldata, r0_add, (uint16_t)weight_frac, 1);
    r_atmlib_CNN_ADD(cldata, r0_add, icfp_add, 1);
    r_atmlib_CNN_WRI(cldata, r1_add, (uint16_t)bias_frac, 1);
    r_atmlib_CNN_SUB(cldata, r0_add, r1_add, 1);
    r_atmlib_CNN_WR(cldata, sftb_add, r0_add, 1);

    return R_ATMLIB_E_OK;
}

R_ATMLIB_RETURN_VALUE CNN_UserShiftFuncDyn(
    R_ATMLIB_CLData *const cldata,
    const uint32_t *const ch_fp_handles,
    int8_t UNUSED(weight_frac),
    int8_t UNUSED(bias_frac))
{
    assert(cldata != NULL);
    assert(ch_fp_handles != NULL);
    (void)cldata;
    (void)ch_fp_handles;
    /* TODO: implement */
    return R_ATMLIB_E_OK;
}

R_ATMLIB_RETURN_VALUE CNN_UserFracAdjFunc(R_ATMLIB_CLData *cldata, uint8_t UNUSED(layer_count))
{
    assert(cldata != NULL);
    (void)cldata;

    return R_ATMLIB_E_OK;
}

#elif defined(HAVE_ATMLIB_CNNIPv2)

#define RETURN_IF_NOT_ATMLIB_CNN_E_OK(val)  \
    {                                       \
        if (R_ATMLIB_CNN_E_OK != val)       \
        {                                   \
            cerror("'" #val "' failed!\n"); \
            return val;                     \
        }                                   \
    }

// register offsets needed here: Is this private?
#define ATMLIB_CNN_R0 (0x20D0U)
#define ATMLIB_CNN_R1 (0x20D4U)
#define ATMLIB_CNN_R2 (0x20D8U)
#define ATMLIB_CNN_SFTI (0x2000U)
#define ATMLIB_CNN_SFTI_CH(ch) (0x2010U + 0x0004U * ch)
#define ATMLIB_CNN_SFTB (0x2008U)
#define ATMLIB_CNN_SFTM (0x200CU)
#define ATMLIB_CNN_SFTC (0x2004U)
#define ATMLIB_CNN_SFTC_CH(ch) (0x2050U + 0x0004U * ch)

R_ATMLIB_CNN_RETURN_VALUE CNN_UserShiftFunc(R_ATMLIB_CLData *cldata, const R_ATMLIB_CNNShiftConfig *shift_cfg)
{
    // cldata->cnn_data->dmai_frac[R_ATMLIB_CNN_DMAI_MAX_CH]; /* Fractional position array of input DMAI */
    // cldata->cnn_data->dmac_frac[R_ATMLIB_CNN_DMAC_MAX_CH]; /* Fractional position array of input DMA3DC */

    int16_t weight_frac = shift_cfg->weight_frac;
    int16_t bias_frac = shift_cfg->bias_frac;
    int16_t dmai_frac = cldata->cnn_data->dmai_frac[0];
    int16_t dmac_frac = cldata->cnn_data->dmac_frac[0];
    int16_t dmao_frac = shift_cfg->dmao_frac;

    /* MAC shift */
    int16_t mac_shift = weight_frac + dmai_frac - dmao_frac;

    /* Carry shift */
    int16_t carry_shift = (cldata->cnn_data->channel_props.DMA3DCE != 0) ? mac_shift + dmao_frac - dmac_frac : 0;

    /* Bias shift */
    int16_t bias_shift = weight_frac + dmai_frac - bias_frac;

    if ((mac_shift < 0) || (carry_shift < 0) || (bias_shift < 0))
    {
        cerror("ERROR: Can't set negative shift values (mac:%i|carry:%i|bias:%i) !\n", mac_shift, carry_shift, bias_shift);
        return R_ATMLIB_E_NG;
    }

    RETURN_IF_NOT_ATMLIB_CNN_E_OK(r_atmlib_CNN_WRI(cldata, ATMLIB_CNN_SFTM / 4U, mac_shift, 1));
    RETURN_IF_NOT_ATMLIB_CNN_E_OK(r_atmlib_CNN_WRI(cldata, ATMLIB_CNN_SFTB / 4U, bias_shift, 1));
    RETURN_IF_NOT_ATMLIB_CNN_E_OK(r_atmlib_CNN_WRI(cldata, ATMLIB_CNN_SFTC / 4U, carry_shift, 1));

    if ((cldata->cnn_data->setup_mode_dmac != R_ATMLIB_CNN_CHSET_FAST) && (cldata->cnn_data->channel_props.DMA3DCE != 0))
    {
        for (unsigned int i_ch = 0; i_ch < R_ATMLIB_CNN_DMAC_MAX_CH; i_ch++)
        {
            RETURN_IF_NOT_ATMLIB_CNN_E_OK(r_atmlib_CNN_WRI(cldata, ATMLIB_CNN_SFTC_CH(i_ch) / 4U, carry_shift, 1));
        }
    }

    return R_ATMLIB_E_OK;
}

#endif
