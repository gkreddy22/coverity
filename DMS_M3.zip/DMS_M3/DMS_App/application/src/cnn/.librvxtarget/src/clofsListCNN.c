#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/clofsListCNN.h"
#include "../ince/rvx_target/list.h"

static size_t _sizeFunction(const void *str)
{
    (void)str;
    return sizeof(ClofsListCNNEntry);
}

ClofsListCNN *clofsListCNNCreate()
{
    ClofsListCNN *list = (ClofsListCNN *)malloc(sizeof(ClofsListCNN));
    listCreate(list, _sizeFunction);
    return list;
}

void clofsListCNNFree(ClofsListCNN *list)
{
    listDestroy(list);
    free(list);
}

ClofsListCNNEntry *clofsListCNNAppend(ClofsListCNN *list, const ClofsListCNNEntry *entry)
{
    ListEntry *p_e = listAppend(list, (const void *)entry);
    return (ClofsListCNNEntry *)p_e->data;
}

size_t clofsListCNNSize(ClofsListCNN *list)
{
    return listSize(list);
}

ClofsListCNNIterator *clofsListCNNIteratorGet(ClofsListCNN *list)
{
    return listIteratorGet(list);
}

ClofsListCNNIterator *clofsListCNNIteratorNext(ClofsListCNN *list, ClofsListCNNIterator *iterator)
{
    return listIteratorNext(list, iterator);
}

ClofsListCNNEntry *clofsListCNNIteratorGetValue(ClofsListCNN *list, ClofsListCNNIterator *iterator)
{
    return (ClofsListCNNEntry *)listIteratorGetValue(list, iterator);
}
//#endif
