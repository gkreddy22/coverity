#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/list.h"
#include "../ince/rvx_target/rvxt_string_helper.h"
#include "../ince/rvx_target/stringList.h"

static size_t _sizeFunction(const void *str)
{
    return strlen((const char *)str) + 1;
}

StringList *stringListCreate()
{
    StringList *list = (StringList *)malloc(sizeof(StringList));
    listCreate(list, _sizeFunction);
    return list;
}

StringList *stringListCreateFromString(const char *const p_string, const char *separators)
{
    StringList *p_list = stringListCreate();

    /* create a list with memory resources to be linearized */
    {
        char *linear_cpy = rvxt_strdup(p_string); // preserve constantness
        char *val = strtok(linear_cpy, separators);
        while (val)
        {
            stringListAppend(p_list, val);
            val = strtok(NULL, separators);
        }

        free(linear_cpy);
    }

    return p_list;
}

void stringListFree(StringList *list)
{
    listDestroy(list);
    free(list);
}

StringListEntry *stringListAppend(StringList *list, const char *str)
{
    ListEntry *p_e = listAppend(list, (void *)str);
    if (NULL == p_e)
    {
        return NULL;
    }

    return (StringListEntry *)p_e->data;
}

size_t stringListSize(StringList *list)
{
    return listSize(list);
}

StringListIterator *stringListIteratorGet(StringList *list)
{
    return listIteratorGet(list);
}

StringListIterator *stringListIteratorGetLast(StringList *list)
{
    return listIteratorGetLast(list);
}

StringListIterator *stringListIteratorGetEnd(StringList *list)
{
    return listIteratorGetEnd(list);
}

StringListIterator *stringListIteratorNext(StringList *list, StringListIterator *iterator)
{
    return listIteratorNext(list, iterator);
}

char *stringListIteratorGetValue(StringList *list, StringListIterator *iterator)
{
    return (char *)listIteratorGetValue(list, iterator);
}

bool stringListIteratorInsertBefore(StringList *list, StringListIterator *iterator, const char *str)
{
    return listIteratorInsertBefore(list, iterator, (void *)str);
}

bool stringListIteratorInsertAfter(StringList *list, StringListIterator *iterator, const char *str)
{
    return listIteratorInsertAfter(list, iterator, (void *)str);
}

char *stringListAt(StringList *list, size_t index)
{
    return (char *)listAt(list, index)->data;
}

void stringListPrint(StringList *list)
{
    StringListIterator *it = stringListIteratorGet(list);
    while (NULL != it)
    {
        char *e = stringListIteratorGetValue(list, it);
        DEBUG_PRINT("'%s'\n", e);
        it = stringListIteratorNext(list, it);
    }
}

StringListIterator *stringListFind(StringList *list, const char *str)
{
    StringListIterator *result = NULL;
    StringListIterator *it = stringListIteratorGet(list);
    while (NULL != it)
    {
        char *e = stringListIteratorGetValue(list, it);
        if (strcmp(e, str) == 0)
        {
            result = it;
            break;
        }
        it = stringListIteratorNext(list, it);
    }
    return result;
}

bool stringListAppendUnique(StringList *list, const char *str)
{
    bool result = false;

    if (stringListFind(list, str) == NULL)
    {
        result = stringListAppend(list, str);
    }

    return result;
}

bool stringListAppendList(StringList *list, StringList *appendList)
{
    StringListIterator *it = stringListIteratorGet(appendList);
    while (NULL != it)
    {
        char *e = stringListIteratorGetValue(appendList, it);
        if (stringListAppend(list, e) == NULL)
        {
            return false;
        }
        it = stringListIteratorNext(appendList, it);
    }
    return true;
}
