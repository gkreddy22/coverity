/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
 * No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
 **********************************************************************************************************************/

/**
  *    @file ${file_name}
  *
  *   @brief Functions for handling CSV files.
  */

/* *****************************************************************************************************************
 * Includes
 *******************************************************************************************************************/
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/csvHelper.h"

bool writeCSVu16(FILE *fp, const uint16_t *data, const size_t width, const size_t height)
{
    if ((fp == NULL) || (data == NULL))
    {
        return false;
    }

    fprintf(fp, "address = %p, (%u,%u)\n", (const void *)data, (unsigned int)width, (unsigned int)height);

    const uint16_t *ptr = (const uint16_t *)data;
    for (size_t y = 0; y < height; y++)
    {
        for (size_t x = 0; x < width; x++)
        {
            fprintf(fp, "0x%04x, ", *ptr++);
        }
        fprintf(fp, "\n");
    }
    return true;
}

bool writeCSVu8(FILE *fp, const uint8_t *data, const size_t width, const size_t height)
{
    if ((fp == NULL) || (data == NULL))
    {
        return false;
    }

    fprintf(fp, "address = %p, (%u,%u)\n", (const void *)data, (unsigned int)width, (unsigned int)height);

    const uint8_t *ptr = (const uint8_t *)data;
    for (size_t y = 0; y < height; y++)
    {
        for (size_t x = 0; x < width; x++)
        {
            fprintf(fp, "0x%02x, ", *ptr++);
        }
        fprintf(fp, "\n");
    }
    return true;
}

bool writeCSVf32(FILE *fp, const float *data, const size_t width, const size_t height)
{
    if ((fp == NULL) || (data == NULL))
    {
        return false;
    }

    fprintf(fp, "address = %p, (%u,%u)\n", (const void *)data, (unsigned int)width, (unsigned int)height);

    const float *ptr = (const float *)data;
    for (size_t y = 0; y < height; y++)
    {
        for (size_t x = 0; x < width; x++)
        {
            fprintf(fp, "0x%e, ", *ptr++);
        }
        fprintf(fp, "\n");
    }
    return true;
}
