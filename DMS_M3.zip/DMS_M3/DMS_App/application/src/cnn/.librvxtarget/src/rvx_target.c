#if defined(__STDC_LIB_EXT1__)
#if (__STDC_LIB_EXT1__ >= 201112L)
#define USE_EXT1 1
#define __STDC_WANT_LIB_EXT1__ 1 /* Want the ext1 functions */
#endif
#endif

#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/filesystem.h"
#include "../ince/rvx_target/info.h"
#include "../ince/rvx_target/rvx_target.h"
#include "../ince/rvx_target/rvxt_md5.h"
#include "../ince/rvx_target/ui.h"

#ifndef PATH_MAX
#define PATH_MAX (1024)
#endif

#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) > (b)) ? (a) : (b))

#define RETURN_FALSE_IF_NOT(arg)        \
    if (!(arg))                         \
    {                                   \
        cerror("'" #arg "' failed!\n"); \
        return false;                   \
    }

size_t rvx_target_getMemresPeakUsage(const rvxt_info_t *const info, const size_t index_memres)
{
    size_t result = 0;
    assert(NULL != info);

    const rvxt_memres_info_t *memres = &(info->memory_ressources[index_memres]);

    for (size_t j = 0; j < info->memories_count; j++)
    {
        const rvxt_mem_info_t *memory = &(info->memories[j]);
        if (memory->base == memres)
        {
            result = MAX(result, memory->offset + memory->size);
        }
    }

    return result;
}

void rvx_target_summary(const rvxt_info_t *const info)
{
    assert(NULL != info);

    cinfo("Memory ressources:\n");
    for (size_t i = 0; i < info->memory_ressources_count; i++)
    {
        const rvxt_memres_info_t *memres = &(info->memory_ressources[i]);
        size_t size_tot = 0;
        size_t size_eff = 0;
        size_t count = 0;

        for (size_t j = 0; j < info->memories_count; j++)
        {
            const rvxt_mem_info_t *memory = &(info->memories[j]);
            if (memory->base == memres)
            {
                size_tot += memory->size;
                size_eff = MAX(size_eff, memory->offset + memory->size);
                count++;
            }
        }

        clinev("[%2u] %8s: base=0x%08x, size=0x%08x (eff=0x%08x, tot=0x%08x), count=%5u.\n",
               (unsigned int)i,
               memres->name,
               (unsigned int)memres->address.phys,
               (unsigned int)memres->size,
               (unsigned int)size_eff,
               (unsigned int)size_tot,
               (unsigned int)count);
    }

    cinfo("Input memories:\n");
    for (size_t i = 0; i < info->entry_memories_count; i++)
    {
        const size_t idx = rvxt_getEntryMemoryIndex(info, i);
        const rvxt_mem_info_t *memory = info->entry_memories[i];
        size_t width = 0;
        size_t height = 0;
        size_t stride = 0;
        rvxt_getMemoryTileWidth(info, idx, &width);
        rvxt_getMemoryTileHeight(info, idx, &height);
        rvxt_getMemoryTileStride(info, idx, &stride);

        clinev("[%2u] %8s: base=0x%08x, size=0x%08x. (w=%u,h=%u,s=%u,bpp=%u,f=%u).\n",
               (unsigned int)i,
               memory->name,
               (unsigned int)(memory->base->address.phys + memory->offset),
               (unsigned int)memory->size,
               (unsigned int)width,
               (unsigned int)height,
               (unsigned int)stride,
               (unsigned int)rvxt_getMemoryTileFormatBitpp(info, idx),
               (unsigned int)rvxt_getMemoryTileFormatType(info, idx));
    }

    cinfo("Output memories:\n");
    for (size_t i = 0; i < info->exit_memories_count; i++)
    {
        const rvxt_mem_info_t *memory = info->exit_memories[i];
        clinev("[%2u] %8s: base=0x%08x, size=0x%08x.\n",
               (unsigned int)i,
               memory->name,
               (unsigned int)(memory->base->address.phys + memory->offset),
               (unsigned int)memory->size);
    }
}

void rvx_target_linearizeMemoryAllocation(rvxt_info_t *const info, const size_t index_memres)
{
    assert(NULL != info);
    assert(index_memres < info->memory_ressources_count);

    rvxt_memres_info_t *memres = &(info->memory_ressources[index_memres]);

    /* calculate total size for linear allocation */
    size_t size_tot = 0;

    for (size_t i = 0; i < info->memories_count; i++)
    {
        const rvxt_mem_info_t *memory = &(info->memories[i]);
        if (memory->base == memres)
        {
            size_tot += memory->size;
        }
    }

    memres->size = size_tot;

    /* set linear addressing */
    uintptr_t offset = 0;

    for (size_t i = 0; i < info->memories_count; i++)
    {
        rvxt_mem_info_t *memory = &(info->memories[i]);
        if (memory->base == memres)
        {
            uintptr_t offset_new = offset;
            clinev("Moving '%32s': 0x%08x [0x%08x] -> 0x%08x [0x%08x] (size=0x%08x).\n",
                   memory->name,
                   (unsigned int)memory->offset,
                   (unsigned int)(memres->address.phys + memory->offset),
                   (unsigned int)offset_new,
                   (unsigned int)(memres->address.phys + offset_new),
                   (unsigned int)memory->size);
            memory->offset = offset_new;
            offset += memory->size;
        }
    }
}

/*
 * @brief Appends all memories within a memres to a string list.
 */
bool rvx_target_appendMemoriesFromMemres(
    rvxt_info_t *const p_info,
    const size_t index_memres,
    StringList *p_list)
{
    assert(NULL != p_info);
    assert(NULL != p_list);
    assert(index_memres < p_info->memory_ressources_count);

    rvxt_memres_info_t *p_memres = &(p_info->memory_ressources[index_memres]);

    for (size_t i = 0; i < p_info->memories_count; i++)
    {
        rvxt_mem_info_t *p_memory = &(p_info->memories[i]);
        if (p_memory->base == p_memres)
        {
            stringListAppend(p_list, p_memory->name);
        }
    }

    return true;
}

const char *rvxt_getMemoryName(const rvxt_info_t *const info, const size_t index)
{
    assert(NULL != info);
    assert(index < info->memories_count);

    return info->memories[index].name;
}

uintptr_t rvxt_getMemoryAddressPhys(const rvxt_info_t *const info, const size_t index)
{
    assert(NULL != info);
    assert(index < info->memories_count);

    uintptr_t memres_base = info->memories[index].base->address.phys;
    uintptr_t memory_offset = info->memories[index].offset;

    return memres_base + memory_offset;
}

void *rvxt_getMemoryAddressVirt(const rvxt_info_t *const info, const size_t index)
{
    assert(NULL != info);
    assert(index < info->memories_count);

    uintptr_t memres_base = (uintptr_t)info->memories[index].base->address.virt;
    uintptr_t memory_offset = info->memories[index].offset;

    return (void *)(memres_base + memory_offset);
}

void rvxt_setMemresAddressVirt(const rvxt_info_t *const info, const size_t index, void *address)
{
    assert(NULL != info);
    assert(index < info->memory_ressources_count);

    info->memory_ressources[index].address.virt = address;
}

void rvxt_setMemresAddressPhys(const rvxt_info_t *const info, const size_t index, uintptr_t phys)
{
    assert(NULL != info);
    assert(index < info->memory_ressources_count);

    info->memory_ressources[index].address.phys = phys;
}

uintptr_t rvxt_getMemresAddressPhys(const rvxt_info_t *const info, const size_t index)
{
    assert(NULL != info);
    assert(index < info->memory_ressources_count);

    return info->memory_ressources[index].address.phys;
}

size_t rvxt_getMemorySize(const rvxt_info_t *const info, const size_t index)
{
    assert(NULL != info);
    assert(index < info->memories_count);

    return info->memories[index].size;
}

bool rvxt_getMemoryTileWidth(const rvxt_info_t *const info, const size_t index, size_t *p_width)
{
    RETURN_FALSE_IF_NOT(NULL != info);
    RETURN_FALSE_IF_NOT(NULL != p_width);
    RETURN_FALSE_IF_NOT(index < info->memories_count);

    bool result = false;

    if ((info->memories[index].tensor.dim_count == 1) && (strncmp(info->memories[index].tensor.layout, "W", 1) == 0))
    {
        *p_width = info->memories[index].tensor.size[0];
        result = true;
    }
    else if ((info->memories[index].tensor.dim_count >= 2) && (strncmp(info->memories[index].tensor.layout, "WH", 2) == 0))
    {
        *p_width = info->memories[index].tensor.size[0];
        result = true;
    }
    else if ((info->memories[index].tensor.dim_count >= 3) && (strncmp(info->memories[index].tensor.layout, "CWH", 3) == 0))
    {
        *p_width = (unsigned int)info->memories[index].tensor.size[0] * (unsigned int)info->memories[index].tensor.size[1];
        result = true;
    }
    else if ((info->memories[index].tensor.dim_count >= 3) && (strncmp(info->memories[index].tensor.layout, "WCH", 3) == 0))
    {
        *p_width = (unsigned int)info->memories[index].tensor.size[0] * (unsigned int)info->memories[index].tensor.size[1];
        result = true;
    }

    return result;
}

bool rvxt_getMemoryTileHeight(const rvxt_info_t *const info, const size_t index, size_t *p_height)
{
    RETURN_FALSE_IF_NOT(NULL != info);
    RETURN_FALSE_IF_NOT(NULL != p_height);
    RETURN_FALSE_IF_NOT(index < info->memories_count);

    bool result = false;

    if ((info->memories[index].tensor.dim_count == 1) && (strncmp(info->memories[index].tensor.layout, "W", 1) == 0))
    {
        *p_height = 1;
        result = true;
    }
    else if ((info->memories[index].tensor.dim_count == 2) && (strncmp(info->memories[index].tensor.layout, "WH", 2) == 0))
    {
        *p_height = info->memories[index].tensor.size[1];
        result = true;
    }
    else if (info->memories[index].tensor.dim_count >= 3)
    {
        if (strncmp(info->memories[index].tensor.layout, "WHC", 3) == 0)
        {
            *p_height = (unsigned int)info->memories[index].tensor.size[1] * (unsigned int)info->memories[index].tensor.size[2];
            result = true;
        }
        else if (strncmp(info->memories[index].tensor.layout, "CWH", 3) == 0)
        {
            *p_height = info->memories[index].tensor.size[2];
            result = true;
        }
        else if (strncmp(info->memories[index].tensor.layout, "WCH", 3) == 0)
        {
            *p_height = info->memories[index].tensor.size[2];
            result = true;
        }
    }

    return result;
}

bool rvxt_getMemoryTileStride(const rvxt_info_t *const info, const size_t index, size_t *p_stride)
{
    RETURN_FALSE_IF_NOT(NULL != info);
    RETURN_FALSE_IF_NOT(NULL != p_stride);
    RETURN_FALSE_IF_NOT(index < info->memories_count);

    bool result = false;

    if ((info->memories[index].tensor.dim_count == 1) && (strncmp(info->memories[index].tensor.layout, "W", 1) == 0))
    {
        *p_stride = info->memories[index].tensor.size[0];
        result = true;
    }
    else if ((info->memories[index].tensor.dim_count >= 2) && (strncmp(info->memories[index].tensor.layout, "WH", 2) == 0))
    {
        *p_stride = info->memories[index].tensor.size[0];
        result = true;
    }
    else if ((info->memories[index].tensor.dim_count >= 3) && (strncmp(info->memories[index].tensor.layout, "CWH", 3) == 0))
    {
        *p_stride = (unsigned int)info->memories[index].tensor.size[0] * (unsigned int)info->memories[index].tensor.size[1];
        result = true;
    }
    else if ((info->memories[index].tensor.dim_count >= 3) && (strncmp(info->memories[index].tensor.layout, "WCH", 3) == 0))
    {
        *p_stride = (unsigned int)info->memories[index].tensor.size[0] * (unsigned int)info->memories[index].tensor.size[1];
        result = true;
    }
    else if ((info->memories[index].tensor.dim_count >= 3) && (strncmp(info->memories[index].tensor.layout, "WHC", 3) == 0))
    {
        *p_stride = (unsigned int)info->memories[index].tensor.size[1] * (unsigned int)info->memories[index].tensor.size[2];
        result = true;
    }

    return result;
}

unsigned int rvxt_getMemoryTileFormatBitpp(const rvxt_info_t *const info, const size_t index)
{
    unsigned int result = 0;
    assert(NULL != info);
    assert(index < info->memories_count);

    if (info->memories[index].tensor.dim_count != 0)
    {
        result = info->memories[index].tensor.format.bitpp;
    }
    return result;
}

rvx_format_type_e rvxt_getMemoryTileFormatType(const rvxt_info_t *const info, const size_t index)
{
    rvx_format_type_e result = RVX_UNSIGNED;
    assert(NULL != info);
    assert(index < info->memories_count);

    if (info->memories[index].tensor.dim_count != 0)
    {
        result = info->memories[index].tensor.format.format_type;
    }
    return result;
}

size_t rvxt_getEntryMemoryIndex(const rvxt_info_t *const info, const size_t index)
{
    const rvxt_mem_info_t *p = info->entry_memories[index];
    const size_t result = ((uintptr_t)p - (uintptr_t)info->memories) / sizeof(rvxt_mem_info_t);
    assert(result < info->memories_count);
    return result;
}

size_t rvxt_getExitMemoryIndex(const rvxt_info_t *const info, const size_t index)
{
    const rvxt_mem_info_t *p = info->exit_memories[index];
    const size_t result = ((uintptr_t)p - (uintptr_t)info->memories) / sizeof(rvxt_mem_info_t);
    assert(result < info->memories_count);
    return result;
}

size_t rvxt_getEntryMemoryMemresIndex(const rvxt_info_t *const info, const size_t index)
{
    const rvxt_memres_info_t *p = info->entry_memories[index]->base;
    const size_t result = ((uintptr_t)p - (uintptr_t)info->memory_ressources) / sizeof(rvxt_memres_info_t);
    assert(result < info->memory_ressources_count);
    return result;
}

size_t rvxt_getExitMemoryMemresIndex(const rvxt_info_t *const info, const size_t index)
{
    const rvxt_memres_info_t *p = info->exit_memories[index]->base;
    const size_t result = ((uintptr_t)p - (uintptr_t)info->memory_ressources) / sizeof(rvxt_memres_info_t);
    assert(result < info->memory_ressources_count);
    return result;
}

bool rvxt_getMemresByName(const rvxt_info_t *const info, const char *const name, size_t *index)
{
    bool result = false;
    assert(NULL != info);

    for (size_t i = 0; i < info->memory_ressources_count; i++)
    {
        if (strcmp(info->memory_ressources[i].name, name) == 0)
        {
            result = true;
            if (NULL != index)
            {
                *index = i;
            }
        }
    }
    return result;
}

bool rvxt_getMemoryByName(const rvxt_info_t *const info, const char *const name, size_t *index)
{
    assert(NULL != info);

    /* test for empty string */
    if (strcmp(name, "") == 0)
    {
        return false;
    }

    for (size_t i = 0; i < info->memories_count; i++)
    {
        if (strcmp(info->memories[i].name, name) == 0)
        {
            if (NULL != index)
            {
                *index = i;
            }
            return true;
        }
    }
    return false;
}

bool rvxt_allocateMemresByIndex(const rvxt_info_t *const info, const size_t index_memres, rvxt_cb_mem_t *p_cb_mem, bool setPhysAddress)
{
    /* checks */
    assert(index_memres < info->memory_ressources_count);
    assert(NULL != p_cb_mem);
    assert(NULL != p_cb_mem->malloc);

    /* allocate memory resource */
    const size_t size_peak = rvx_target_getMemresPeakUsage(info, index_memres);
    void *virt = p_cb_mem->malloc(size_peak);
    if (NULL == virt)
    {
        cerror("Failed to allocate memory!\n");
        return false;
    }

    memset(virt, 0, size_peak);

    rvxt_setMemresAddressVirt(info, index_memres, virt);

    if (true == setPhysAddress)
    {
        assert(p_cb_mem->getPhys);
        uintptr_t phys = p_cb_mem->getPhys(virt);
        assert(0 != phys);

        rvxt_setMemresAddressPhys(info, index_memres, phys);
    }

    return true;
}

bool rvxt_allocateMemres(const rvxt_info_t *const info, rvxt_cb_mem_t *p_cb_mem, bool setPhysAddress)
{
    for (size_t i = 0; i < info->memory_ressources_count; i++)
    {
        if (!rvxt_allocateMemresByIndex(info, i, p_cb_mem, setPhysAddress))
        {
            return false;
        }
    }
    return true;
}

bool rvxt_getCoreNumberInGroup(const rvxt_info_t *const p_info, const size_t index, size_t *number)
{
    if (index > p_info->core_count)
    {
        return false;
    }

    rvxt_core_info_t *p_core_index = &(p_info->cores[index]);
    const rvxt_core_group_e g_index = rvxt_getCoreGroup(p_core_index->core);

    size_t idx = 0;

    for (size_t idx_core = 0; idx_core < index; idx_core++)
    {
        rvxt_core_info_t *p_core = &(p_info->cores[idx_core]);
        const rvxt_core_group_e g = rvxt_getCoreGroup(p_core->core);

        if (g_index == g)
        {
            idx++;
        }
    }

    if (NULL != number)
    {
        *number = idx;
    }
    return true;
}

bool rvxt_printCoreMaps(const rvxt_info_t *const p_info)
{
    for (size_t idx_core = 0; idx_core < p_info->core_count; idx_core++)
    {
        rvxt_core_info_t *p_core = &(p_info->cores[idx_core]);
        const rvxt_core_group_e g = rvxt_getCoreGroup(p_core->core);

        size_t core_number = 0;
        rvxt_getCoreNumberInGroup(p_info, idx_core, &core_number);

        cinfov("Core #%u, %s%u:\n", (unsigned int)idx_core, rvxt_getCoreGroupName(g), (unsigned int)core_number);
        cinfo("core map:");
        for (size_t idx_core_map = 0; idx_core_map < p_info->core_count; idx_core_map++)
        {
            const size_t index = p_core->core_map[idx_core_map];
            const rvxt_core_info_t *const p_core_map = &(p_info->cores[index]);
            const rvxt_core_group_e g_map = rvxt_getCoreGroup(p_core_map->core);

            size_t number = 0;
            rvxt_getCoreNumberInGroup(p_info, idx_core_map, &number);
            DEBUG_PRINT("%s%u(%u), ", rvxt_getCoreGroupName(g_map), (unsigned int)number, (unsigned int)index);
        }
        DEBUG_PRINT("\n");
    }
    return true;
}

const char *rvxt_getCoreName(rvxt_core_e core)
{
    switch (core)
    {
    case RVXT_CORE_NONE:
        return "NONE";
        break;
    case RVXT_CORE_IMP0:
        return "IMP0";
        break;
    case RVXT_CORE_IMP1:
        return "IMP1";
        break;
    case RVXT_CORE_IMP2:
        return "IMP2";
        break;
    case RVXT_CORE_IMP3:
        return "IMP3";
        break;
    case RVXT_CORE_IMP4:
        return "IMP4";
        break;
    case RVXT_CORE_IMP5:
        return "IMP5";
        break;
    case RVXT_CORE_IMP6:
        return "IMP6";
        break;
    case RVXT_CORE_IMP7:
        return "IMP7";
        break;
    case RVXT_CORE_CVE0:
        return "CVE0";
        break;
    case RVXT_CORE_CVE1:
        return "CVE1";
        break;
    case RVXT_CORE_CVE2:
        return "CVE2";
        break;
    case RVXT_CORE_CVE3:
        return "CVE3";
        break;
    case RVXT_CORE_CVE4:
        return "CVE4";
        break;
    case RVXT_CORE_CVE5:
        return "CVE5";
        break;
    case RVXT_CORE_CVE6:
        return "CVE6";
        break;
    case RVXT_CORE_CVE7:
        return "CVE7";
        break;
    case RVXT_CORE_DMA0:
        return "DMA0";
        break;
    case RVXT_CORE_DMA1:
        return "DMA1";
        break;
    case RVXT_CORE_DMA2:
        return "DMA2";
        break;
    case RVXT_CORE_DMA3:
        return "DMA3";
        break;
    case RVXT_CORE_PSC0:
        return "PSC0";
        break;
    case RVXT_CORE_PSC1:
        return "PSC1";
        break;
    case RVXT_CORE_PSC2:
        return "PSC2";
        break;
    case RVXT_CORE_PSC3:
        return "PSC3";
        break;
    case RVXT_CORE_CNN0:
        return "CNN0";
        break;
    case RVXT_CORE_CNN1:
        return "CNN1";
        break;
    case RVXT_CORE_CNN2:
        return "CNN2";
        break;
    case RVXT_CORE_CNN3:
        return "CNN3";
        break;
    case RVXT_CORE_DTA:
        return "DTA";
        break;
    default:
        return "INVALID";
    }
    return NULL;
}

const char *rvxt_getCoreGroupName(rvxt_core_group_e core)
{
    switch (core)
    {
    case RVXT_CORE_GROUP_NONE:
        return "NONE";
        break;
    case RVXT_CORE_GROUP_IMP:
        return "IMP";
        break;
    case RVXT_CORE_GROUP_CVE:
        return "CVE";
        break;
    case RVXT_CORE_GROUP_DMA:
        return "DMA";
        break;
    case RVXT_CORE_GROUP_PSC:
        return "PSC";
        break;
    case RVXT_CORE_GROUP_CNN:
        return "CNN";
        break;
    case RVXT_CORE_GROUP_DTA:
        return "DAT";
        break;
    default:
        return "INVALID";
    }
    return NULL;
}

unsigned int rvxt_getCoreGroupNumber(rvxt_core_group_e core)
{
    switch (core)
    {
    case RVXT_CORE_GROUP_NONE:
        return 0;
        break;
    case RVXT_CORE_GROUP_IMP:
        return 1;
        break;
    case RVXT_CORE_GROUP_CVE:
        return 2;
        break;
    case RVXT_CORE_GROUP_DMA:
        return 3;
        break;
    case RVXT_CORE_GROUP_PSC:
        return 4;
        break;
    case RVXT_CORE_GROUP_CNN:
        return 6;
        break;
    case RVXT_CORE_GROUP_DTA:
        return 99;
        break;
    default:
        return 0;
    }
    return 0;
}

rvxt_core_group_e rvxt_getCoreGroup(rvxt_core_e core)
{
    switch (core)
    {
    case RVXT_CORE_NONE:
        return RVXT_CORE_GROUP_NONE;
        break;
    case RVXT_CORE_IMP0:
    case RVXT_CORE_IMP1:
    case RVXT_CORE_IMP2:
    case RVXT_CORE_IMP3:
    case RVXT_CORE_IMP4:
    case RVXT_CORE_IMP5:
    case RVXT_CORE_IMP6:
    case RVXT_CORE_IMP7:
        return RVXT_CORE_GROUP_IMP;
        break;
    case RVXT_CORE_CVE0:
    case RVXT_CORE_CVE1:
    case RVXT_CORE_CVE2:
    case RVXT_CORE_CVE3:
    case RVXT_CORE_CVE4:
    case RVXT_CORE_CVE5:
    case RVXT_CORE_CVE6:
    case RVXT_CORE_CVE7:
        return RVXT_CORE_GROUP_CVE;
        break;
    case RVXT_CORE_DMA0:
    case RVXT_CORE_DMA1:
    case RVXT_CORE_DMA2:
    case RVXT_CORE_DMA3:
        return RVXT_CORE_GROUP_DMA;
        break;
    case RVXT_CORE_PSC0:
    case RVXT_CORE_PSC1:
    case RVXT_CORE_PSC2:
    case RVXT_CORE_PSC3:
        return RVXT_CORE_GROUP_PSC;
        break;
    case RVXT_CORE_CNN0:
    case RVXT_CORE_CNN1:
    case RVXT_CORE_CNN2:
    case RVXT_CORE_CNN3:
        return RVXT_CORE_GROUP_CNN;
        break;
    case RVXT_CORE_DTA:
        return RVXT_CORE_GROUP_DTA;
        break;
    default:
        return RVXT_CORE_GROUP_NONE;
    }
    return RVXT_CORE_GROUP_NONE;
}

unsigned int rvxt_getCoreCount(const rvxt_info_t *const p_info, const rvxt_core_group_e group)
{
    unsigned int result = 0;
    for (size_t idx_core = 0; idx_core < p_info->core_count; idx_core++)
    {
        rvxt_core_info_t *p_core = &(p_info->cores[idx_core]);
        const rvxt_core_group_e g = rvxt_getCoreGroup(p_core->core);
        if (g == group)
        {
            result++;
        }
    }
    return result;
}

bool rvxt_getCoreIndex(const rvxt_info_t *const p_info, const rvxt_core_group_e group, unsigned int number, size_t *index)
{
    for (size_t idx_core = 0; idx_core < p_info->core_count; idx_core++)
    {
        rvxt_core_info_t *p_core = &(p_info->cores[idx_core]);
        const rvxt_core_group_e g = rvxt_getCoreGroup(p_core->core);
        if (g == group)
        {
            if (number == 0)
            {
                if (NULL != index)
                {
                    *index = idx_core;
                    return true;
                }
            }
            number--;
        }
    }
    return false;
}

bool rvxt_setGlobalCoreMap(rvxt_info_t *const p_info, rvxt_core_map_t p_core_map)
{
    for (size_t idx_core = 0; idx_core < p_info->core_count; idx_core++)
    {
        rvxt_core_info_t *p_core = &(p_info->cores[idx_core]);
        for (size_t idx_core_map = 0; idx_core_map < p_info->core_count; idx_core_map++)
        {
            p_core->core_map[idx_core_map] = p_core_map[idx_core_map];
        }
    }
    return true;
}

bool rvxt_printEntryMemoryHashes(rvxt_info_t *const p_info)
{
    for (size_t idx = 0; idx < p_info->entry_memories_count; idx++)
    {
        size_t idx_mem = rvxt_getEntryMemoryIndex(p_info, idx);
        const char *name = rvxt_getMemoryName(p_info, idx_mem);
        void *p_virt = rvxt_getMemoryAddressVirt(p_info, idx_mem);
        const size_t size = rvxt_getMemorySize(p_info, idx_mem);
        size_t width = 0;
        size_t height = 0;
        size_t stride = 0;
        RETURN_FALSE_IF_NOT(rvxt_getMemoryTileWidth(p_info, idx_mem, &width));
        RETURN_FALSE_IF_NOT(rvxt_getMemoryTileHeight(p_info, idx_mem, &height));
        RETURN_FALSE_IF_NOT(rvxt_getMemoryTileStride(p_info, idx_mem, &stride));
        const unsigned int bytesPerPixel = rvxt_getMemoryTileFormatBitpp(p_info, idx_mem) / 8;

        cinfov("MD5 %s: ", name);
        const bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);
        if (!match)
        {
            DEBUG_PRINT("\n");
            cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n",
                      (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
            rvxt_md5Dump(stdout, p_virt, size);
            DEBUG_PRINT("', new: '");
            rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
            DEBUG_PRINT("'");
        }
        DEBUG_PRINT("\n");
    }
    return true;
}

bool rvxt_printExitMemoryHashes(rvxt_info_t *const p_info)
{
    for (size_t idx = 0; idx < p_info->exit_memories_count; idx++)
    {
        size_t idx_mem = rvxt_getExitMemoryIndex(p_info, idx);
        const char *name = rvxt_getMemoryName(p_info, idx_mem);
        void *p_virt = rvxt_getMemoryAddressVirt(p_info, idx_mem);
        const size_t size = rvxt_getMemorySize(p_info, idx_mem);
        size_t width = 0;
        size_t height = 0;
        size_t stride = 0;
        RETURN_FALSE_IF_NOT(rvxt_getMemoryTileWidth(p_info, idx_mem, &width));
        RETURN_FALSE_IF_NOT(rvxt_getMemoryTileHeight(p_info, idx_mem, &height));
        RETURN_FALSE_IF_NOT(rvxt_getMemoryTileStride(p_info, idx_mem, &stride));
        const unsigned int bytesPerPixel = rvxt_getMemoryTileFormatBitpp(p_info, idx_mem) / 8;

        cinfov("MD5 %s: ", name);
        const bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);
        if (!match)
        {
            DEBUG_PRINT("\n");
            cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n",
                      (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
            rvxt_md5Dump(stdout, p_virt, size);
            DEBUG_PRINT("', new: '");
            rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
            DEBUG_PRINT("'");
        }
        DEBUG_PRINT("\n");
    }
    return true;
}

size_t rvxt_fileSize(FILE *p_file)
{
    size_t result = 0;
    fseek(p_file, 0L, SEEK_END);
    const long ret = ftell(p_file);
    fseek(p_file, 0L, SEEK_SET);

    if (ret > 0)
    {
        result = (size_t)ret;
    }

    return result;
}

uint8_t *rvxt_loadFile(const char *filename)
{
    /* try to open the file */
    FILE *p_file = rvxtfs_openFirst(filename, "rb");
    if (NULL == p_file)
    {
        cerrorv("Failed to open \"%s\". %s", filename, strerror(errno));
        return NULL;
    }

    /* load file content into memory */
    size_t size = rvxt_fileSize(p_file);
    uint8_t *p_data = (uint8_t *)malloc(size);
    size_t ret = fread(p_data, 1, size, p_file);
    if (ret != 0)
    {
        cerrorv("Failed to open file %s", filename);
    }
    fclose(p_file);

    return p_data;
}

bool rvxt_parseChannel(char *const str, int *const p_channel)
{
    if (NULL == p_channel)
    {
        return false;
    }

    if (NULL == str)
    {
        return false;
    }

    const size_t str_len = strlen(str);

    char *pos_l = NULL;
    char *pos_r = NULL;
#if !defined(RCAR_XIL_SIL)
    pos_l = strchr(str, '[');
#else
    pos_l = strchr(str, '(');
#endif
    if (NULL != pos_l)
    {
#if !defined(RCAR_XIL_SIL)
        pos_r = strchr(str, ']');
#else
        pos_r = strchr(str, ')');
#endif
    }
    else
    {
        pos_l = strchr(str, ':');
        if (NULL != pos_l)
        {
            pos_r = &str[str_len];
        }
        else
        {
            pos_l = strchr(str, '[');
            if (NULL != pos_l)
            {
                pos_r = strchr(str, ']');
            }
        }
    }

    if ((NULL == pos_l) || (NULL == pos_r))
    {
        return false;
    }

    *pos_l = '\0';

    if (2 > pos_r - pos_l) //  channel number needs to have at least 1 digit
    {
        return false;
    }

    char str_channel[(pos_r - pos_l)]; // c-string with length same as channel number has digits + 1 for '\0'

#if defined(USE_EXT1)
#ifdef __linux__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wstringop-truncation"
#endif
    strncpy_s(str_channel, elementsof(str_channel), pos_l + 1, pos_r - pos_l - 1);
#ifdef __linux__
#pragma GCC diagnostic pop
#endif
#else
#ifdef __linux__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wstringop-truncation"
#endif
    strncpy(str_channel, pos_l + 1, (uintptr_t)pos_r - (uintptr_t)pos_l - 1);
#ifdef __linux__
#pragma GCC diagnostic pop
#endif
#endif
    str_channel[(pos_r - pos_l - 1)] = '\0'; // set '\0' for clean string to int conversion
    const long channel = strtol(str_channel, NULL, 10);

    if ((0 == channel) && (str_channel[0] != '0')) // if number could not be read
    {
        cerrorv("'%s' is not a channel number!", str_channel);
        return false;
    }
    else
    {
        *p_channel = (int)channel;
    }

    return true;
}
