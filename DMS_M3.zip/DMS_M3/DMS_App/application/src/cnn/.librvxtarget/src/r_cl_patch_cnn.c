/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/r_cl_patch.h"
#include "../ince/rvx_target/r_cl_patch_cnn.h"
#include "../ince/rvx_target/r_cl_patch_helper.h"
#include "../ince/rvx_target/ui.h"
#include "common.h"

/*!
 * @brief Test if given address refers to a register containing an address value
 * @param reg
 * @return
 */
static bool isAddressRegisterCNN(const uintptr_t reg)
{
    bool result;

    switch (reg)
    {
#if defined(RCAR_SOC_V3U) || defined(RCAR_SOC_V3H2)
    case CNNIP_DMAISA:
    case CNNIP_DMARFESA:
#endif
    case CNNIP_DMAISA0:
    case CNNIP_DMAISA1:
    case CNNIP_DMAISA2:
    case CNNIP_DMAISA3:
#if defined(RCAR_SOC_V3U) || defined(RCAR_SOC_V3H2)
    case CNNIP_DMAISA4:
    case CNNIP_DMAISA5:
    case CNNIP_DMAISA6:
    case CNNIP_DMAISA7:
    case CNNIP_DMAISA8:
    case CNNIP_DMAISA9:
    case CNNIP_DMAISA10:
    case CNNIP_DMAISA11:
    case CNNIP_DMAISA12:
    case CNNIP_DMAISA13:
    case CNNIP_DMAISA14:
    case CNNIP_DMAISA15:
    case CNNIP_DMA3DCSA:
#endif
    case CNNIP_DMA3DCSA0:
    case CNNIP_DMA3DCSA1:
    case CNNIP_DMA3DCSA2:
    case CNNIP_DMA3DCSA3:
    case CNNIP_DMA3DCSA4:
    case CNNIP_DMA3DCSA5:
    case CNNIP_DMA3DCSA6:
    case CNNIP_DMA3DCSA7:
#if defined(RCAR_SOC_V3U) || defined(RCAR_SOC_V3H2)
    case CNNIP_DMA3DCSA8:
    case CNNIP_DMA3DCSA9:
    case CNNIP_DMA3DCSA10:
    case CNNIP_DMA3DCSA11:
    case CNNIP_DMA3DCSA12:
    case CNNIP_DMA3DCSA13:
    case CNNIP_DMA3DCSA14:
    case CNNIP_DMA3DCSA15:
    case CNNIP_DMA3DCSA16:
    case CNNIP_DMA3DCSA17:
    case CNNIP_DMA3DCSA18:
    case CNNIP_DMA3DCSA19:
    case CNNIP_DMA3DCSA20:
    case CNNIP_DMA3DCSA21:
    case CNNIP_DMA3DCSA22:
    case CNNIP_DMA3DCSA23:
    case CNNIP_DMA3DCSA24:
    case CNNIP_DMA3DCSA25:
    case CNNIP_DMA3DCSA26:
    case CNNIP_DMA3DCSA27:
    case CNNIP_DMA3DCSA28:
    case CNNIP_DMA3DCSA29:
    case CNNIP_DMA3DCSA30:
    case CNNIP_DMA3DCSA31:
    case CNNIP_DMAOSA:
#endif
    case CNNIP_DMAOSA0:
    case CNNIP_DMAOSA1:
    case CNNIP_DMAOSA2:
    case CNNIP_DMAOSA3:
    case CNNIP_DMAOSA4:
    case CNNIP_DMAOSA5:
    case CNNIP_DMAOSA6:
    case CNNIP_DMAOSA7:
#if defined(RCAR_SOC_V3U) || defined(RCAR_SOC_V3H2)
    case CNNIP_DMAOSA8:
    case CNNIP_DMAOSA9:
    case CNNIP_DMAOSA10:
    case CNNIP_DMAOSA11:
    case CNNIP_DMAOSA12:
    case CNNIP_DMAOSA13:
    case CNNIP_DMAOSA14:
    case CNNIP_DMAOSA15:
    case CNNIP_DMAOSA16:
    case CNNIP_DMAOSA17:
    case CNNIP_DMAOSA18:
    case CNNIP_DMAOSA19:
    case CNNIP_DMAOSA20:
    case CNNIP_DMAOSA21:
    case CNNIP_DMAOSA22:
    case CNNIP_DMAOSA23:
    case CNNIP_DMAOSA24:
    case CNNIP_DMAOSA25:
    case CNNIP_DMAOSA26:
    case CNNIP_DMAOSA27:
    case CNNIP_DMAOSA28:
    case CNNIP_DMAOSA29:
    case CNNIP_DMAOSA30:
    case CNNIP_DMAOSA31:
#endif
        result = true;
        break;
    default:
        result = false;
    }
    return result;
}

/*!
 * @brief Patch CL for CNN-IP
 * @details Interprets CL to identify WPR to DMAxSA
 * @details Changes all address in the range [base_old,base_old+size) -> [base_new,base_new+size)
 * @param data Pointer to CL
 * @param base_old Base address of old address base
 * @param base_new Base address of new address base
 * @param size Size of address range to consider.
 * @return
 */
bool r_cl_patch_CNN(void *data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */
    if (verbose)
        DEBUG_PRINT("Patching from 0x%08x to 0x%08x (size 0x%08x)\n", (unsigned int)(base_old), (unsigned int)(base_new), (unsigned int)(size));

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    unsigned int error_cnt_jump = 0;
    unsigned int error_cnt_gosub = 0;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            if (isAddressRegisterCNN(wpr_addr * 4))
            {
                const uintptr_t address_old = *inst;
                if ((address_old >= base_old) && (address_old < (base_old + size)))
                {
                    const uintptr_t address_new = base_new + address_old - base_old;
                    if (verbose)
                        cinfov("Fixing write to 0x%08x from 0x%08x to 0x%08x.\n", (unsigned int)(uintptr_t)(wpr_addr * 4), (unsigned int)(address_old), (unsigned int)address_new);
                    *inst = (uint32_t)address_new;
                }
                else
                {
                    if (verbose)
                        cinfo("Address not in range, ignoring\n");
                }
            }
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_BRC:
        {
            uint8_t cond = R_CNNIP_CL_BRC_COND(*inst);

            if (R_CNNIP_BRC_ALWAYS == cond)
            {
                int16_t offset = SIGN_EXT16(R_CNNIP_CL_BRC_DIST(*inst), 13);
                inst = (uint32_t *)(uintptr_t)((long long int)(uintptr_t)inst + offset);

                continue;
            }
            else
            {
                cwarning("BRC ignored, stepping over.\n");
            }

            break;
        }

        case R_CNNIP_CL_WPR:
        case R_CNNIP_CL_WPRNBSY:
            wpr_addr = R_CNNIP_CL_WPR_ADDR(*inst);
            wpr_cnt = R_CNNIP_CL_WPR_N(*inst);
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
            break;
        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
            break;
        case R_CNNIP_CL_SLP:
            break;
        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:
            if (error_cnt_jump == 0)
                cerror("JUMP is not supported! Stepping over, you have been warned!\n");
            wpr_cnt = 1;
            error_cnt_jump++;
            break;

        case R_CNNIP_CL_GOSUB:
            if (error_cnt_gosub == 0)
                cerror("GOSUB is not supported! Stepping over, you have been warned!\n");
            wpr_cnt = 1;
            error_cnt_gosub++;
            break;

        case R_CNNIP_CL_RET:
            cerror("RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}

/*!
 * @brief Patch all WUP/SLP according to provided core maps
 * @param data
 * @param verbose
 * @return
 */
bool r_cl_patch_CNN_sync(void *data, const cl_patch_core_map_t *map_in, const cl_patch_core_map_t *map_out, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    unsigned int error_cnt_jump = 0;
    unsigned int error_cnt_gosub = 0;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_BRC:
        {
            uint8_t cond = R_CNNIP_CL_BRC_COND(*inst);

            if (R_CNNIP_BRC_ALWAYS == cond)
            {
                int16_t offset = SIGN_EXT16(R_CNNIP_CL_BRC_DIST(*inst), 13);
                inst = (uint32_t *)(uintptr_t)((long long int)(uintptr_t)inst + offset);

                continue;
            }
            else
            {
                cwarning("BRC ignored, stepping over.\n");
            }

            break;
        }

        case R_CNNIP_CL_WPR:
        case R_CNNIP_CL_WPRNBSY:
            wpr_addr = R_CNNIP_CL_WPR_ADDR(*inst);
            wpr_cnt = R_CNNIP_CL_WPR_N(*inst);
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
            break;
        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
        case R_CNNIP_CL_SLP:
        {
            uint32_t ret = r_cl_patch_remapSync(*inst, map_in, map_out, verbose);
            if (verbose)
                cinfov("Fixing WUP/SLP from 0x%08x to 0x%08x.\n", (unsigned int)*inst, (unsigned int)ret);
            *inst = ret;
            break;
        }

        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:
            if (error_cnt_jump == 0)
                cerror(" JUMP is not supported! Stepping over, you have been warned!\n");
            wpr_cnt = 1;
            error_cnt_jump++;
            break;

        case R_CNNIP_CL_GOSUB:
            if (error_cnt_gosub == 0)
                cerror(" GOSUB is not supported! Stepping over, you have been warned!\n");
            wpr_cnt = 1;
            error_cnt_gosub++;
            break;

        case R_CNNIP_CL_RET:
            cerror(" RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            break;
            // return false;
        }
        ++inst;
    } while (okay);
    return true;
}

bool r_cl_patch_CNN_removeGOSUB(void *data, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_BRC:
        {
            uint8_t cond = R_CNNIP_CL_BRC_COND(*inst);

            if (R_CNNIP_BRC_ALWAYS == cond)
            {
                int16_t offset = SIGN_EXT16(R_CNNIP_CL_BRC_DIST(*inst), 13);
                inst = (uint32_t *)(uintptr_t)((long long int)(uintptr_t)inst + offset);

                continue;
            }
            else
            {
                cwarning("BRC ignored, stepping over.\n");
            }

            break;
        }

        case R_CNNIP_CL_WPR:
        case R_CNNIP_CL_WPRNBSY:
            wpr_addr = R_CNNIP_CL_WPR_ADDR(*inst);
            wpr_cnt = R_CNNIP_CL_WPR_N(*inst);
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
            break;
        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
            break;
        case R_CNNIP_CL_SLP:
            break;
        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:
            cerror(" JUMP is not supported!.\n");
            return false;
            break;

        case R_CNNIP_CL_GOSUB:
            cinfo("Removing GOSUB!\n");
            inst[0] = 0x80000001U;
            inst[1] = 0x80000001U;
            wpr_cnt = 1;
            break;

        case R_CNNIP_CL_RET:
            cerror(" RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}

bool r_cl_patch_CNN_patchGOSUB(void *data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_BRC:
        {
            uint8_t cond = R_CNNIP_CL_BRC_COND(*inst);

            if (R_CNNIP_BRC_ALWAYS == cond)
            {
                int16_t offset = SIGN_EXT16(R_CNNIP_CL_BRC_DIST(*inst), 13);
                inst = (uint32_t *)(uintptr_t)((long long int)(uintptr_t)inst + offset);

                continue;
            }
            else
            {
                cwarning("BRC ignored, stepping over.\n");
            }

            break;
        }

        case R_CNNIP_CL_WPR:
        case R_CNNIP_CL_WPRNBSY:
            wpr_addr = R_CNNIP_CL_WPR_ADDR(*inst);
            wpr_cnt = R_CNNIP_CL_WPR_N(*inst);
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
            break;
        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
            break;
        case R_CNNIP_CL_SLP:
            break;
        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:
            cerror("JUMP is not supported!.\n");
            return false;
            break;

        case R_CNNIP_CL_GOSUB:
            cinfo("Patching GOSUB!\n");
            const uintptr_t address_old = inst[1];
            if ((address_old >= base_old) && (address_old < (base_old + size)))
            {
                const uintptr_t address_new = base_new + address_old - base_old;
                //if(verbose)cinfov("Fixing write to 0x%08x from 0x%08x to 0x%08x.\n",(unsigned int)(uintptr_t)(wpr_addr*4),(unsigned int)(address_old),(unsigned int)address_new);
                inst[1] = (uint32_t)address_new;
            }
            wpr_cnt = 1;
            break;

        case R_CNNIP_CL_RET:
            cerror("RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}
/* remove write of 1 to SLSP, invalidate syncs */
bool r_cl_patch_CNN_removeStart(void *data, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            if (CNNIP_SLSP == (wpr_addr * 4))
            {
                cinfov("Writing 0 to 0x%08x (was 0x%08x).\n", (unsigned int)(uintptr_t)(wpr_addr * 4), (unsigned int)(*inst));
                *inst = 0;
            }
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_BRC:
        {
            uint8_t cond = R_CNNIP_CL_BRC_COND(*inst);

            if (R_CNNIP_BRC_ALWAYS == cond)
            {
                int16_t offset = SIGN_EXT16(R_CNNIP_CL_BRC_DIST(*inst), 13);
                inst = (uint32_t *)(uintptr_t)((long long int)(uintptr_t)inst + offset);

                continue;
            }
            else
            {
                cwarning("BRC ignored, stepping over.\n");
            }

            break;
        }

        case R_CNNIP_CL_WPR:
        case R_CNNIP_CL_WPRNBSY:
            wpr_addr = R_CNNIP_CL_WPR_ADDR(*inst);
            wpr_cnt = R_CNNIP_CL_WPR_N(*inst);
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
            cinfo("Invalidating SYNCS.\n");
            *inst = 0x80000001U;
            break;

        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
            break;
        case R_CNNIP_CL_SLP:
            break;
        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:
            cerror(" JUMP is not supported!.\n");
            return false;
            break;

        case R_CNNIP_CL_GOSUB:
            cerror(" GOSUB is not supported! Stepping over, you have been warned!\n");
            wpr_cnt = 1;
            break;

        case R_CNNIP_CL_RET:
            cerror(" RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}

bool r_cl_patch_CNN_patchGOSUB2JUMP(void *data, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_BRC:
        {
            uint8_t cond = R_CNNIP_CL_BRC_COND(*inst);

            if (R_CNNIP_BRC_ALWAYS == cond)
            {
                int16_t offset = SIGN_EXT16(R_CNNIP_CL_BRC_DIST(*inst), 13);
                inst = (uint32_t *)(uintptr_t)((long long int)(uintptr_t)inst + offset);

                continue;
            }
            else
            {
                cwarning("BRC ignored, stepping over.\n");
            }

            break;
        }

        case R_CNNIP_CL_WPR:
        case R_CNNIP_CL_WPRNBSY:
            wpr_addr = R_CNNIP_CL_WPR_ADDR(*inst);
            wpr_cnt = R_CNNIP_CL_WPR_N(*inst);
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
            break;
        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
            break;
        case R_CNNIP_CL_SLP:
            break;
        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:
            cerror(" JUMP is not supported!.\n");
            return false;
            break;

        case R_CNNIP_CL_GOSUB:
        {
            cinfo("Patching GOSUB -> JUMP!\n");
            *inst = 0x90000000U;
            wpr_cnt = 1;
            break;
        }

        case R_CNNIP_CL_RET:
            cerror(" RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}

bool r_cl_patch_CNN_findSYNCS(void *data, MemoryList *list, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    unsigned int error_cnt_jump = 0;
    unsigned int error_cnt_gosub = 0;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_BRC:
        {
            uint8_t cond = R_CNNIP_CL_BRC_COND(*inst);

            if (R_CNNIP_BRC_ALWAYS == cond)
            {
                int16_t offset = SIGN_EXT16(R_CNNIP_CL_BRC_DIST(*inst), 13);
                inst = (uint32_t *)(uintptr_t)((long long int)(uintptr_t)inst + offset);

                continue;
            }
            else
            {
                cwarning("BRC ignored, stepping over.\n");
            }

            break;
        }

        case R_CNNIP_CL_WPR:
        case R_CNNIP_CL_WPRNBSY:
            wpr_addr = R_CNNIP_CL_WPR_ADDR(*inst);
            wpr_cnt = R_CNNIP_CL_WPR_N(*inst);
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
        {
            MemoryListEntry entry;
            entry.size = 1;
            entry.addressNew = (uintptr_t)inst;
            entry.addressOld = (uintptr_t)inst;
            memoryListAppend(list, &entry);
            break;
        }
        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
            break;
        case R_CNNIP_CL_SLP:
            break;
        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:
            if (error_cnt_jump == 0)
                cwarning("JUMP is not supported! Stepping over, you have been warned!\n");
            wpr_cnt = 1;
            error_cnt_jump++;
            break;

        case R_CNNIP_CL_GOSUB:
        {
            if (error_cnt_gosub == 0)
                cwarning("GOSUB is supported rudimentary only: stepping over. You have been warned!\n");
            wpr_cnt = 1;
            error_cnt_gosub++;
            break;
        }

        case R_CNNIP_CL_RET:
            cerror(" RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}

static bool _r_cl_CNN_FindRangesUsed(void *data, uint8_t *map, const size_t granularity, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    if (NULL == data)
    {
        return false;
    }

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;
    bool result = false;

    unsigned int error_cnt_jump = 0;
    unsigned int error_cnt_gosub = 0;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            if (isAddressRegisterCNN(wpr_addr * 4))
            {
                const uintptr_t address = *inst;
                const size_t index = address / granularity;
                map[index] = 1;
            }
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_BRC:
        {
            uint8_t cond = R_CNNIP_CL_BRC_COND(*inst);

            if (R_CNNIP_BRC_ALWAYS == cond)
            {
                int16_t offset = SIGN_EXT16(R_CNNIP_CL_BRC_DIST(*inst), 13);
                inst = (uint32_t *)(uintptr_t)((long long int)(uintptr_t)inst + offset);

                continue;
            }
            else
            {
                cwarning("BRC ignored, stepping over.\n");
            }

            break;
        }

        case R_CNNIP_CL_WPR:
        case R_CNNIP_CL_WPRNBSY:
            wpr_addr = R_CNNIP_CL_WPR_ADDR(*inst);
            wpr_cnt = R_CNNIP_CL_WPR_N(*inst);
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
            break;
        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
            break;
        case R_CNNIP_CL_SLP:
            break;
        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:
            if (error_cnt_jump == 0)
                cwarning("JUMP is not supported! Stepping over, you have been warned!\n");
            wpr_cnt = 1;
            error_cnt_jump++;
            break;

        case R_CNNIP_CL_GOSUB:
        {
            if (error_cnt_gosub == 0)
                cwarning("GOSUB is supported rudimentary only: stepping over. You have been warned!\n");
            wpr_cnt = 1;
            error_cnt_gosub++;
            break;
        }

        case R_CNNIP_CL_RET:
            cerror(" RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return result;
}

bool r_cl_CNN_FindRangesUsed(void *data, MemoryList *list, const size_t granularity, const bool verbose)
{
    (void)granularity;

    const size_t ddr_size_max = 0x100000000ULL;
    const size_t ddr_size_granularity = 0x000100000ULL;
    const size_t entries = ddr_size_max / ddr_size_granularity;
    uint8_t *map = (uint8_t *)calloc(entries, sizeof(uint8_t));

    _r_cl_CNN_FindRangesUsed(data, map, ddr_size_granularity, false);

    size_t count = 0;
    size_t size = 0;
    uintptr_t base = 0;

    for (size_t i = 0; i < entries; i++)
    {
        if (0 != map[i])
        {
            /* set base only for first occurrence */
            if (0 == count)
            {
                base = i * ddr_size_granularity;
                size = ddr_size_granularity;
            }
            /* test for concatenated blocks */
            if ((i > 0) && (map[i - 1] != 0))
            {
                size += ddr_size_granularity;
            }
            else
            {
                count++;
            }
        }
        else
        {
            if (0 != size) /* Append entry */
            {
                MemoryListEntry entry;
                entry.size = size;
                entry.addressNew = base;
                entry.addressOld = base;
                memoryListInsertSorted(list, &entry);

                size = 0;
                base = 0;
            }
        }
    }

    if (0 != size) /* Append entry */
    {
        MemoryListEntry entry;
        entry.size = size;
        entry.addressNew = base;
        entry.addressOld = base;
        memoryListInsertSorted(list, &entry);
    }

    free(map);

    if (verbose)
        cinfov("Found %u blocks:\n", (unsigned int)count);
    memoryListPrint(list);
    return true;
}
