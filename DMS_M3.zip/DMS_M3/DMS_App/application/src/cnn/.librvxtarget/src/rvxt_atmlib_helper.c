#include "../ince/rvx_target/rvxt_atmlib_helper.h"

#if defined(RCAR_SOC_V3H1) || defined(RCAR_SOC_V3M2) || defined(RCAR_SOC_V3U)

char *rvxt_atmlib_getErrorString(R_ATMLIB_RETURN_VALUE value)
{
    switch (value)
    {
    case R_ATMLIB_E_OK:
        return "OK";
        break;
    case R_ATMLIB_E_NG:
        return "NG";
        break;
    case R_ATMLIB_E_NG_CLTYPE:
        return "wrong type of CL";
        break;
    case R_ATMLIB_E_NG_CLSIZE:
        return "size of CL is not sufficient";
        break;
    case R_ATMLIB_E_NG_STATE:
        return "invalid state";
        break;
    case R_ATMLIB_E_NG_ARG1:
        return "invalid argument 1";
        break;
    case R_ATMLIB_E_NG_ARG2:
        return "invalid argument 2";
        break;
    case R_ATMLIB_E_NG_ARG3:
        return "invalid argument 3";
        break;
    case R_ATMLIB_E_NG_ARG4:
        return "invalid argument 4";
        break;
    case R_ATMLIB_E_NG_ARG5:
        return "invalid argument 5";
        break;
    case R_ATMLIB_E_NG_ARG6:
        return "invalid argument 6";
        break;
    case R_ATMLIB_E_NG_ARG7:
        return "invalid argument 7";
        break;
    case R_ATMLIB_E_NG_ARG8:
        return "invalid argument 8";
        break;
    case R_ATMLIB_E_NG_CONV_BIAS:
        return "invalid convolution bias";
        break;
    case R_ATMLIB_E_NG_CONV_XPOOL:
        return "invalid XPOOL";
        break;
    case R_ATMLIB_E_NG_CONV_YPOOL:
        return "invalid YPOOL";
        break;
    case R_ATMLIB_E_NG_CONV_MAXOUT_GROUP:
        return "invalid MAXOUT group";
        break;
    case R_ATMLIB_E_NG_DUPLICATE_LABEL:
        return "duplicate label";
        break;
    case R_ATMLIB_E_NG_LABEL_SIZE:
        return "invalid label size";
        break;
    case R_ATMLIB_E_NG_UNDEFINE_LABEL:
        return "undefined value";
        break;
    case R_ATMLIB_E_NG_ADDR_RANGE:
        return "invalid address range";
        break;
    default:
        return "(undefined)";
    }
    return NULL;
}
#endif
