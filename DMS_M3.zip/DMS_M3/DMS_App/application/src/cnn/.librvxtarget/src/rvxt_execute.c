#include <assert.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "config.h"

#if defined(HAS_R_IMPDRV_H)
#include "rcar-xos/imp/r_impdrv.h"
#elif defined(HAS_RCV_IMPDRV_H)
#include "rcar-xos/imp/rcv_impdrv.h"
#endif

#include "../ince/rvx_target/bcl.h"
#include "../ince/rvx_target/device_info.h"
#include "../ince/rvx_target/info.h"
#include "../ince/rvx_target/rvx_target.h"
//#include "../ince/rvx_target/rvxt_debug.h"
#include "../ince/rvx_target/impdrv_helper.h"
#include "../ince/rvx_target/osal_helper.h"
#include "../ince/rvx_target/rvxt_execute.h"
#include "../ince/rvx_target/rvxt_time.h"
#include "../ince/rvx_target/ui.h"

#include "../../include/osal_debug.h"
#include "common.h"

#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) > (b)) ? (a) : (b))

#if defined(XOS_VERSION_2_8_0)

#define R_IMPDRV_ATTRSETCOREMAP(impdrvctl, core_map, idx_core_map, cl_count) \
    R_IMPDRV_AttrSetCoreMap(*impdrvctl, &core_map[idx_core_map], core_map, cl_count)

#elif !defined(XOS_VERSION_2_7_0) && !defined(XOS_VERSION_2_8_0)

#define R_IMPDRV_ATTRSETCOREMAP(impdrvctl, core_map, idx_core_map, cl_count) \
    R_IMPDRV_AttrSetCoreMap(*impdrvctl, &core_map[idx_core_map], core_map)

#endif

#if !defined(XOS_VERSION_2_7_0)
#define IMPDRV_CRTL_HANDLE impdrv_ctrl_handle_t

#define R_IMPDRV_ATTRSETCL(impdrvctl, core_map, idx_core_map, phys) \
    R_IMPDRV_AttrSetCl(*impdrvctl, &core_map[idx_core_map], phys)

#define R_IMPDRV_EXECUTE(handle, core_info, callback_func, callback_args) \
    R_IMPDRV_Execute(*handle, core_info, callback_func, callback_args)

#define R_IMPDRV_START(impdrvctl, core_map, i) \
    R_IMPDRV_Start(impdrvctl, &core_map[i])

#define R_IMPDRV_STOP(impdrvctl, core_map, i) \
    R_IMPDRV_Stop(impdrvctl, &core_map[i])

#define R_IMPDRV_QUIT(impdrvctl) \
    R_IMPDRV_Quit(impdrvctl)

#else
#define IMPDRV_CRTL_HANDLE st_impdrv_ctrl_handle_t

#define R_IMPDRV_ATTRSETCOREMAP(impdrvctl, core_map, idx_core_map, cl_count) \
    R_IMPDRV_AttrSetCoreMap(impdrvctl, &core_map[idx_core_map], cl_count, core_map)

#define R_IMPDRV_ATTRSETCL(impdrvctl, core_map, idx_core_map, phys) \
    R_IMPDRV_AttrSetCL(impdrvctl, &core_map[idx_core_map], phys)

#define R_IMPDRV_EXECUTE(handle, core_info, callback_func, callback_args) \
    R_IMPDRV_Execute(handle, core_info, callback_func, callback_args)

#define R_IMPDRV_START(impdrvctl, core_map, i) \
    R_IMPDRV_Start(&impdrvctl, &core_map[i])

#define R_IMPDRV_STOP(impdrvctl, core_map, i) \
    R_IMPDRV_Stop(&impdrvctl, &core_map[i])

#define R_IMPDRV_QUIT(impdrvctl) \
    R_IMPDRV_Quit(&impdrvctl)

#endif

#define IMPDRV_WORKSIZE 32768
#define ALIGNMENT (64u)

static uint64_t work_impdrvinit[IMPDRV_WORKSIZE / sizeof(uint64_t)];
static rvx_time_t time_trap[RVXT_CORE_NUM];
static volatile bool running[RVXT_CORE_NUM];

uintptr_t clPhysAddrArray[IMPDRV_INNER_FIXED_VALUE];
unsigned int cl_count;

static char *getCoreName(char *buffer, const size_t size, const st_impdrv_core_info_t *core);

//static char* getCoreName_rcv(char* buffer, const size_t size, const RCvIMPDRVCOREINFO* core);

IMPDRV_CRTL_HANDLE impdrvctl;
st_impdrv_initdata_t impdrvinit;
st_impdrv_core_info_t * core_map;

size_t getAllocatedSize(size_t size)
{
    size_t tmp = size;

    if ((tmp % ALIGNMENT) == 0)
    {
        return size;
    }
    else
    {
        tmp = size / ALIGNMENT;
        tmp = (tmp + 1) * ALIGNMENT;
        return tmp;
    }
}

uintptr_t getPhysAddrOfCl(uint32_t *staticClAddr, size_t sizeBytes, unsigned int idx, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id)
{
    e_osal_return_t ret_osal = OSAL_RETURN_FAIL;
    osal_memory_buffer_handle_t bufHndl;
    uint32_t *virtAddr;
    uintptr_t ret;

    ret_osal = OSAL_CHECK(R_OSAL_MmngrAlloc(handle_osalmmngr, getAllocatedSize(sizeBytes), 64, &bufHndl));
    assert(ret_osal == OSAL_RETURN_OK);

    ret_osal = OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufHndl, (void **)(&virtAddr)));
    assert(ret_osal == OSAL_RETURN_OK);

    memcpy(virtAddr, staticClAddr, sizeBytes);

    ret_osal = OSAL_CHECK(R_OSAL_MmngrGetHwAddr(bufHndl, imp_dev_axi_bus_id, &ret));
    assert(ret_osal == OSAL_RETURN_OK);

    if (ret_osal == OSAL_RETURN_OK)
        clPhysAddrArray[idx] = ret;

    return ret;
}

#if !defined(XOS_VERSION_2_7_0) && !defined(XOS_VERSION_2_8_0)

static void CallBackFuncFatal(const st_impdrv_core_info_t *const p_core_info,
                              const e_impdrv_fatalcode_t fc_code,
                              const e_impdrv_errorcode_t ercd,
                              void *const p_callback_args)
{
    (void)p_core_info;
    (void)p_callback_args;
    DEBUG_PRINT("CallBackFuncFatal(code=%i, code=%i)\n", (int)fc_code, (int)ercd);
}

#else

static void CallBackFuncFatal(st_impdrv_fatalcode_t code, int32_t info)
{
    DEBUG_PRINT("CallBackFuncFatal(code.fatal_code=%i, info=%i)\n", (int)code.fatal_code, (int)info);
}

typedef void (*p_impdrv_cbfunc_fatal_t)(
    st_impdrv_fatalcode_t code, /**< Error code							*/
    int32_t info                /**< Detail information					*/
);

#endif

inline static bool getCoreIndex(const st_impdrv_core_info_t *const p_core, size_t *p_index)
{
    switch (p_core->core_type)
    {
    case IMPDRV_CORE_TYPE_IMP:
    {
        if (p_core->core_num >= RVXT_CORE_IMP_NUM)
        {
            return false;
        }
        *p_index = p_core->core_num;
        break;
    }
    case IMPDRV_CORE_TYPE_OCV:
    {
        if (p_core->core_num >= RVXT_CORE_CVE_NUM)
        {
            return false;
        }
        *p_index = p_core->core_num + RVXT_CORE_IMP_NUM;
        break;
    }
    case IMPDRV_CORE_TYPE_DMAC:
    {
        if (p_core->core_num >= RVXT_CORE_DMA_NUM)
        {
            return false;
        }
        *p_index = p_core->core_num + RVXT_CORE_IMP_NUM + RVXT_CORE_CVE_NUM;
        break;
    }
    case IMPDRV_CORE_TYPE_CNN:
    {
        if (p_core->core_num >= RVXT_CORE_CNN_NUM)
        {
            return false;
        }
        *p_index = p_core->core_num + RVXT_CORE_IMP_NUM + RVXT_CORE_CVE_NUM + RVXT_CORE_DMA_NUM;
        break;
    }
    default:
        return false;
    }
    return true;
}

#if !defined(XOS_VERSION_2_7_0) && !defined(XOS_VERSION_2_8_0)

static int32_t cb_fun(const st_impdrv_core_info_t *const p_core, const e_impdrv_cb_ret_t ercd, const int32_t code, void *const p_callback_args)
{
    (void)code;
    (void)p_callback_args;
    if ((IMPDRV_CB_RET_OK == ercd) || (IMPDRV_CB_RET_ILLEGAL == ercd))
    {
        size_t index = 0;
        if (getCoreIndex(p_core, &index))
        {
            rvxt_time_getCurrentTime(&(time_trap[index]));
            running[index] = false;
        }
    }
    return (int32_t)ercd;
}

#else

static void cb_fun(const st_impdrv_core_info_t *const p_core, const e_impdrv_cb_ret_t ercd, const int32_t code, const void *p_callback_args)
{
    (void)code;
    (void)p_callback_args;
    if ((IMPDRV_CB_RET_OK == ercd) || (IMPDRV_CB_RET_ILLEGAL == ercd))
    {
        size_t index = 0;
        if (getCoreIndex(p_core, &index))
        {
            rvxt_time_getCurrentTime(&(time_trap[index]));
            running[index] = false;
        }
    }
}

#endif

inline static void set_time_trap(const st_impdrv_core_info_t *const p_core) //const e_impdrv_cb_ret_t ercd,
{
    size_t index = 0;
    if (getCoreIndex(p_core, &index))
    {
        rvxt_time_getCurrentTime(&(time_trap[index]));
        running[index] = false;
    }
}

inline static bool check_done(void)
{
    for (size_t index = 0; index < RVXT_CORE_NUM; index++)
    {
        if (running[index])
        {
            return false;
        }
    }
    return true;
}

#if defined(RCAR_SOC_V3H)
static uint32_t rcvdrv_reg_read(
    const RCvIMPDRVCTL *const p_rcvdrvctl,
    const RCvIMPDRVCOREINFO *const p_core,
    uintptr_t const offset)
{
    uint32_t index = rcvdrv_CoreToIndex(p_rcvdrvctl, p_core);
    return drvCommon_ReadReg32(p_rcvdrvctl->RegBase[index] + offset);
}
#endif

bool rvxt_invalidateMemres(const rvxt_info_t *const p_info, rvxt_cb_mem_t *p_cb_mem)
{
    for (size_t i = 0; i < p_info->memory_ressources_count; i++)
    {
        void *const virt = p_info->memory_ressources[i].address.virt;
        const size_t size = p_info->memory_ressources[i].size;

        if (NULL != virt)
        {
            if (NULL != p_cb_mem->invalidate)
            {
                p_cb_mem->invalidate(virt, size);
            }
        }
    }
    return true;
}

static bool flush(void *const virt, const size_t size, rvxt_cb_mem_t *p_cb_mem)
{
    if (NULL != virt)
    {
        if (NULL != p_cb_mem->flush)
        {
            p_cb_mem->flush(virt, size);
        }
    }
    return true;
}

static bool executeCL(Commandlist *const cl, st_impdrv_core_info_t core_map[16], rvxt_cb_mem_t *p_cb_mem, rvx_time_t time_start[RVXT_CORE_NUM], IMPDRV_CRTL_HANDLE *impdrvctl, void *CallBackArgs, uintptr_t *clPhysAddrArray, const uint32_t cl_alloc_alignment, bool DTAenabled)
{
    (void)CallBackArgs;
    (void)clPhysAddrArray;
    int idx_core_map = __builtin_ctz(cl->syncid);
    const st_impdrv_core_info_t *const p_core = &(core_map[idx_core_map]);

    size_t index = 0;
    e_impdrv_errorcode_t impdrv_ret;
    //st_impdrv_core_info_t* p_core_map;

    if (!getCoreIndex(p_core, &index))
    {
        DEBUG_PRINT("Error in getCoreIndex\n");
        return false;
    }

#if defined(RCAR_XIL_SIL)
#if defined(RCAR_SOC_V3U) || defined(RCAR_SOC_V3U)
    /* V3U simulator limitations check */
    if (p_core->core_type == IMPDRV_CORE_TYPE_CNN)
    {
        cwarning("CNNIP_V3U WUP/SLP is currently limited to work with a single other IP. If more IPs are used, synchonization will break.\n");
    }
#endif
#endif

    p_impdrv_cbfunc_t cb = cb_fun;

    st_impdrv_core_info_t coreMap_full[IMPDRV_COREMAP_MAXID];
    for (unsigned int i = 0; i < IMPDRV_COREMAP_MAXID; i++)
    {
        if (i < cl_count)
        {
            coreMap_full[i].core_num = core_map[i].core_num;
            coreMap_full[i].core_type = core_map[i].core_type;
        }
        else if (i == cl_count && DTAenabled)
        {
            coreMap_full[i].core_num = 0;
            coreMap_full[i].core_type = IMPDRV_CORE_TYPE_DTA;
        }
        else
        {
            coreMap_full[i].core_num = 0;
            coreMap_full[i].core_type = 0;
        }
    }

    flush(cl->virt, cl->size + cl_alloc_alignment - cl->size % cl_alloc_alignment, p_cb_mem);

    const uint32_t phys = (uint32_t)cl->phys;
    running[index] = true;
    rvxt_time_getCurrentTime(&(time_start[index]));

    DEBUG_PRINT("core: %d, core_type: %d, core_num: %d\n", idx_core_map, core_map[idx_core_map].core_type, core_map[idx_core_map].core_num);
    DEBUG_PRINT("phys: 0x%08x, size: 0x%08x\n", phys, (unsigned int)cl->size);

    /* Cache maintenance before HW execution */
    impdrv_ret = IMPDRV_CHECK(R_IMPDRV_ATTRSETCOREMAP(impdrvctl, coreMap_full, idx_core_map, cl_count));
    if (impdrv_ret != IMPDRV_EC_OK)
    {
        DEBUG_PRINT("<< [ERROR] R_IMPFW_AttrInit  : code %d>>\n", impdrv_ret);
        return false;
    }

    impdrv_ret = IMPDRV_CHECK(R_IMPDRV_ATTRSETCL(impdrvctl, core_map, idx_core_map, phys)); //clPhysAddrArray[idx_core_map]);
    if (impdrv_ret != IMPDRV_EC_OK)
    {
        DEBUG_PRINT("<< [ERROR] R_IMPFW_AttrSetCl  : code %d>>\n", impdrv_ret);
        return false;
    }

    impdrv_ret = IMPDRV_CHECK(R_IMPDRV_EXECUTE(impdrvctl, &core_map[idx_core_map], cb, NULL));
    DEBUG_PRINT("R_IMPDRV_Execute, drv_ret=%d for core %d\n", impdrv_ret, idx_core_map);
    if (impdrv_ret != IMPDRV_EC_OK)
    {
        DEBUG_PRINT("<< [ERROR] R_IMPDRV_Execute  : code %d>>\n", impdrv_ret);
        return false;
    }

    return true;
}

static void setCoreMap2(Commandlist *commandlists, size_t const count, st_impdrv_core_info_t core_map[16], bool DTAenabled)
{
    unsigned int count_DMA = 0;
    unsigned int count_CNN = 0;
    unsigned int count_OCV = 0;
    unsigned int count_IMP = 0;

    for (size_t i = 0; i < count; i++)
    {
        int index = __builtin_ctz(commandlists[i].syncid);

        if (commandlists[i].core == CORE_TYPE_DMA)
        {
            core_map[index].core_type = IMPDRV_CORE_TYPE_DMAC;
            core_map[index].core_num = count_DMA;
            count_DMA += 2;
        }
        else if (commandlists[i].core == CORE_TYPE_CNN)
        {
            core_map[index].core_type = IMPDRV_CORE_TYPE_CNN;
            core_map[index].core_num = count_CNN;
            count_CNN++;
        }
        else if (commandlists[i].core == CORE_TYPE_OCV)
        {
            core_map[index].core_type = IMPDRV_CORE_TYPE_OCV;
            core_map[index].core_num = count_OCV;
            count_OCV++;
        }
        else if (commandlists[i].core == CORE_TYPE_IMP)
        {
            core_map[i].core_type = IMPDRV_CORE_TYPE_IMP;
            core_map[i].core_num = count_IMP;
            count_IMP++;
        }
        else
        {
            cerrorv("ERROR: Unsupported core type: %d!\n", core_map[i].core_type);
        }
        if (DTAenabled)
        {
            core_map[count].core_type = IMPDRV_CORE_TYPE_DTA;
            core_map[count].core_num = 0;
        }
    }
}

#if !defined(RCAR_XIL_SIL)
extern void cdbg_debug(int const core, int const index, osal_axi_bus_id_t imp_dev_axi_bus_id);
static void debugCores(Commandlist *commandlists, unsigned int count, osal_axi_bus_id_t imp_dev_axi_bus_id)
{
    int coreCounts[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    for (unsigned int i = 0; i < count; i++)
    {
        cdbg_debug(commandlists[i].core, coreCounts[commandlists[i].core], imp_dev_axi_bus_id);
        coreCounts[commandlists[i].core]++;
    }
}
#endif

bool impdrv_start(size_t const count,bool DTAenabled,Commandlist *commandlists, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id)
{
     cl_count = (unsigned int)count;
     unsigned int cl_count_wDTA = cl_count + (DTAenabled ? 1 : 0);
     e_impdrv_errorcode_t drv_ret = IMPDRV_EC_OK;

    core_map = (st_impdrv_core_info_t *) malloc(cl_count_wDTA);
    if(NULL == core_map)
    {
        DEBUG_PRINT("Failed to allocate coremap Buffer \n");
        return false;
    }

    memset(core_map, 0, sizeof(core_map));
    setCoreMap2(commandlists, count, core_map, DTAenabled);

    /*----- IMP Framework Initialization -----*/
    memset(&impdrvinit, 0, sizeof(impdrvinit));

    impdrvinit.p_work_addr = (void *)work_impdrvinit;
    impdrvinit.work_size = sizeof(work_impdrvinit);
    impdrvinit.out_work_size = 0u;
#if !defined(XOS_VERSION_2_7_0) && !defined(XOS_VERSION_2_8_0)
    impdrvinit.instance_num = IMPDRV_INSTANCE_0;
#else
    impdrvinit.instance_num = IMPDRV_INSTANCE_6;
#endif
    impdrvinit.use_core_num = cl_count; //sizeof(core_map) / sizeof(core_map[0]);
    memset(impdrvinit.core_info, 0, sizeof(st_impdrv_core_info_t) * IMPDRV_INNER_FIXED_VALUE);
    for (unsigned int i = 0; i < cl_count_wDTA /*go through the coremap excl the last entry which is reserved for DTA*/; i++)
    {
        impdrvinit.core_info[i].core_type = core_map[i].core_type;
        impdrvinit.core_info[i].core_num = core_map[i].core_num;
    }
    impdrvinit.callback_func_fatal = CallBackFuncFatal;

    impdrvinit.osal_resource.mutex_id = 0; //20u;
    impdrvinit.osal_resource.mutex_time_period = 10000;

    DEBUG_PRINT("calling R_IMPDRV_Init\n"); // XXX: DEBUG

    drv_ret = (R_IMPDRV_Init(&impdrvinit, &impdrvctl));

    DEBUG_PRINT("R_IMPDRV_Init, drv_ret: %d\n", drv_ret);
    if (drv_ret != IMPDRV_EC_OK)
    {
        DEBUG_PRINT("<< [ERROR] R_IMPDRV_Init  : code %d>>\n", drv_ret);
    }
    DEBUG_PRINT("R_IMPDRV_Init finish\n"); // XXX: DEBUG

    for (unsigned int i = 0; i < cl_count; i++)
    {
        if (IMPDRV_EC_OK != (R_IMPDRV_START(impdrvctl, core_map, i)))
        {
            char name[8];
            cerrorv("R_IMPDRV_Start(%s, %u) failed!\n", getCoreName(name, 8, &(core_map[i])), (unsigned int)i);
            clPhysAddrArray[i] = getPhysAddrOfCl((uint32_t *)commandlists[i].phys, commandlists[i].size, i, handle_osalmmngr, imp_dev_axi_bus_id);

            return false;
        }
    }

    return true;

}

bool imp_stop(size_t const count)
{
     e_impdrv_errorcode_t drv_ret = IMPDRV_EC_OK;

    for (uint8_t i = 0; i < count; i++)
    {
        if (0 != core_map[i].core_type)
        {
            drv_ret = (R_IMPDRV_STOP(impdrvctl, core_map, i));
        }
    }

    DEBUG_PRINT("R_IMPDRV_Quit\n");
    drv_ret = (R_IMPDRV_QUIT(impdrvctl));

    return true;
}

bool executeCommandlists(Commandlist *commandlists, size_t const count, rvxt_cb_mem_t *p_cb_mem, size_t clxX, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, int timeout_ms, const uint32_t cl_alloc_alignment, bool DTAenabled)
{

    bool result = true;
    rvx_time_t time_start[RVXT_CORE_NUM];
    rvx_time_t start, end;
    size_t masterClIdx = count; /* invalid value */
    cl_count = (unsigned int)count;
    unsigned int cl_count_wDTA = cl_count + (DTAenabled ? 1 : 0);
    int additional_data = 42;
    void *CallBackArgs = &additional_data;
    e_impdrv_errorcode_t drv_ret = IMPDRV_EC_OK;

    // fix();

    rvxt_time_getCurrentTime(&end);

    /* Execute the IMP task				*/
    //ret = RCV_EC_OK_DRV;

    if (cl_count > 1)
    {
        /* search for Master CL */
        for (unsigned int i = 0; i < cl_count; i++)
        {
            const uint16_t slaveStr = 0xAFFE;
            const uint16_t masterStr = 0xBABE;
            uint16_t buffer = 0;
            uint32_t *clPtr = commandlists[i].virt;

            for (size_t j = 0; j < 4; j++)
            {
                const uint8_t opcode = (uint8_t)((clPtr[j] >> 24) & 0xFFU);
                if (0x80 == opcode)
                {
                    const uint8_t c = (uint8_t)(clPtr[j] & 0x000000FFU);
                    buffer |= (uint16_t)((uint16_t)(c & 0xFU) << (4 * (3 - j)));
                }
                else
                {
                    /* required NOP instruction at the beginning */
                    break;
                }
            }
            if (masterStr == buffer)
            {
                /* found master CL */
                if (masterClIdx != cl_count) /* check if we already found one */
                {
                    cerror("Multiple Master CL's found. Only one Master CL is allowed!\n");
                    return false;
                }
                masterClIdx = i; /* save the index of the master cl */
            }
            else if (slaveStr != buffer)
            {
                cwarning("CL type could not be identified as master or slave CL. Assuming Slave CL!\n");
            }
        }
        if (masterClIdx == cl_count) /* check if we found master cl */
        {
            cwarning("No Master/Slave CL found. Last given CL on commandline is assumed to be master CL!\n");
            cwarning("Synconization is not guaranteed without Master/Slave CL information.\n");
            masterClIdx = cl_count - 1;
        }
        /* start all slave CL's */
        for (size_t i = 0; i < count; i++)
        {
            if (i == masterClIdx)
            {
                /* skipping master CL --> will be issued last */
                continue;
            }
            char name[8];
            cinfov("Starting %s...\n", getCoreName(name, 8, &(core_map[i])));
            if (executeCL(&commandlists[i], core_map, p_cb_mem, time_start, &impdrvctl, CallBackArgs, clPhysAddrArray, cl_alloc_alignment, DTAenabled) == false)
            {
                cinfo("fail to start slave CL.\n");
                return false;
            }
        }
        /* start master cl execution */
        char name[8];
        cinfov("Starting %s...\n", getCoreName(name, 8, &(core_map[masterClIdx])));
        if (executeCL(&commandlists[masterClIdx], core_map, p_cb_mem, time_start, &impdrvctl, CallBackArgs, clPhysAddrArray, cl_alloc_alignment, DTAenabled) == false)
        {
            cinfo("fail to start master CL.\n");
            return false;
        }
    }
    else
    {
        /* Only one cl. Execute it */
        char name[8];
        cinfov("Starting %s...\n", getCoreName(name, 8, &(core_map[0])));
        if (executeCL(&commandlists[0], core_map, p_cb_mem, time_start, &impdrvctl, CallBackArgs, clPhysAddrArray, cl_alloc_alignment, DTAenabled) == false)
        {
            DEBUG_PRINT("execute_cl error \n");
            return false;
        }
    }

#if defined(RCAR_XIL_SIL)
    timeout_ms *= 1000;
#endif

    while ((!check_done()) && (timeout_ms > 0))
    {
        OSAL_CHECK(R_OSAL_ThreadSleepForTimePeriod(1));
        timeout_ms -= 100;
    }

    if (timeout_ms <= 0)
    {
        cerror("Timeout!\n");
        result = false;
    }

    {
#if !defined(RCAR_XIL_SIL)
        if (!result)
        {
            debugCores(commandlists, (unsigned int)count, imp_dev_axi_bus_id);
        }
#endif
    }

    rvxt_time_getCurrentTime(&start);

    cinfo("Runtime:\n");
    for (size_t i = 0; i < count; i++)
    {
        const st_impdrv_core_info_t *const p_core = &(core_map[i]);
        size_t index = 0;
        char name[8];

        getCoreIndex(p_core, &index);
        getCoreName(name, 8, p_core);

        unsigned int runtime = rvxt_time_getTimeDelta(time_start[index], time_trap[index]);
        start = rvxt_time_min(start, time_start[index]);
        end = rvxt_time_max(end, time_trap[index]);
        cinfov("Core (%u:%u %s): runtime %u us\n", (unsigned int)p_core->core_type, (unsigned int)p_core->core_num, name, runtime);
    }
    cinfov("Total runtime (from start of first core till TRAP of last core): %u us\n", (unsigned int)rvxt_time_getTimeDelta(start, end));
    if (clxX > 1)
    {
        cinfov("Total runtime / (%u runs/execution) = %u us average runtime for a single run.\n", (unsigned int)(clxX), (unsigned int)(rvxt_time_getTimeDelta(start, end) / clxX));
    }

    DEBUG_PRINT("R_IMPDRV_Stop\n");

    return result;
}

static const char *getCoreType(const st_impdrv_core_info_t *core)
{
    char *result;

    switch (core->core_type)
    {
    case IMPDRV_CORE_TYPE_DMAC:
        result = "DMAC";
        break;
    case IMPDRV_CORE_TYPE_CNN:
        result = "CNN";
        break;
    case IMPDRV_CORE_TYPE_IMP:
        result = "IMP";
        break;
    case IMPDRV_CORE_TYPE_OCV:
        result = "CVE";
        break;
    default:
        result = "NONE";
    }

    return result;
}

static char *getCoreName(char *buffer, const size_t size, const st_impdrv_core_info_t *core)
{
    snprintf(buffer, size, "%s%u", getCoreType(core), (const int)core->core_num);
    return buffer;
}
