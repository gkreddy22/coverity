#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/list.h"
#include "../ince/rvx_target/stringList.h"

size_t writeStringList(FILE *fp, StringList *stringList)
{
    size_t result = 0;

    if (stringList == NULL)
    {
        return result;
    }

    if (fputc('S', fp) != EOF)
    {
        result++;
    }
    if (fputc('L', fp) != EOF)
    {
        result++;
    }

    uint16_t count = (uint16_t)stringListSize(stringList);

    result += fwrite((void *)&count, 1, sizeof(count), fp);

    StringListIterator *it = stringListIteratorGet(stringList);
    while (NULL != it)
    {
        char *e = stringListIteratorGetValue(stringList, it);
        size_t length = strlen(e) + 1;
        uint16_t _length = (uint16_t)(length + (length % 2));
        result += fwrite((void *)&_length, 1, sizeof(_length), fp);
        result += fwrite((void *)e, 1, length, fp);
        if ((length % 2) == 1)
        {
            if (fputc('\0', fp) != EOF)
            {
                result++;
            }
        }
        it = stringListIteratorNext(stringList, it);
    }

    const size_t remainder = (result % 4);
    assert((remainder == 0) || (remainder == 2));

    if (remainder == 2)
    {
        if (fputc('s', fp) != EOF)
        {
            result++;
        }
        if (fputc('l', fp) != EOF)
        {
            result++;
        }
    }

    return result;
}

size_t calculateStringListFileSize(StringList *stringList)
{
    size_t result = 4; /*header*/
    StringListIterator *it = stringListIteratorGet(stringList);
    while (NULL != it)
    {
        char *e = stringListIteratorGetValue(stringList, it);
        size_t length = strlen(e) + 1;
        result += sizeof(uint16_t) + length + (length % 2);
        it = stringListIteratorNext(stringList, it);
    }

    result += (result % 4); /* add two byte padding if required */

    return result;
}
