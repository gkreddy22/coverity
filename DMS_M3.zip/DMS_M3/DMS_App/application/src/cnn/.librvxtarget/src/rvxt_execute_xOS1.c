#include <assert.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rcar-xos/imp/rcv_impdrv.h"

#include "../ince/rvx_target/bcl.h"
#include "../ince/rvx_target/device_info.h"
#include "../ince/rvx_target/info.h"
#include "../ince/rvx_target/rvx_target.h"
#include "../ince/rvx_target/rvxt_execute.h"
#include "../ince/rvx_target/rvxt_time.h"
#include "../ince/rvx_target/ui.h"

#include "osal_debug.h"

#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) > (b)) ? (a) : (b))

static RCvIMPDRVCTL rcvdrv_ctl;
static rvx_time_t time_trap[RVXT_CORE_NUM];
static volatile bool running[RVXT_CORE_NUM];

static char *getCoreName(char *buffer, const size_t size, const RCvIMPDRVCOREINFO *core);

inline static bool getCoreIndex(const RCvIMPDRVCOREINFO *const p_core, size_t *p_index)
{
    switch (p_core->CoreType)
    {
    case RCVDRV_CORE_TYPE_IMP:
    {
        if (p_core->CoreNum >= RVXT_CORE_IMP_NUM)
        {
            return false;
        }
        *p_index = p_core->CoreNum;
        break;
    }
    case RCVDRV_CORE_TYPE_OCV:
    {
        if (p_core->CoreNum >= RVXT_CORE_CVE_NUM)
        {
            return false;
        }
        *p_index = p_core->CoreNum + RVXT_CORE_IMP_NUM;
        break;
    }
    case RCVDRV_CORE_TYPE_DMAC:
    {
        if (p_core->CoreNum >= RVXT_CORE_DMA_NUM)
        {
            return false;
        }
        *p_index = p_core->CoreNum + RVXT_CORE_IMP_NUM + RVXT_CORE_CVE_NUM;
        break;
    }
    case RCVDRV_CORE_TYPE_CNN:
    {
        if (p_core->CoreNum >= RVXT_CORE_CNN_NUM)
        {
            return false;
        }
        *p_index = p_core->CoreNum + RVXT_CORE_IMP_NUM + RVXT_CORE_CVE_NUM + RVXT_CORE_DMA_NUM;
        break;
    }
    default:
        return false;
    }
    return true;
}

inline static void set_time_trap(const RCvIMPDRVCOREINFO *const p_core)
{
    size_t index = 0;
    if (getCoreIndex(p_core, &index))
    {
        rvxt_time_getCurrentTime(&(time_trap[index]));
        running[index] = false;
    }
}

inline static bool check_done(void)
{
    for (size_t index = 0; index < RVXT_CORE_NUM; index++)
    {
        if (running[index])
        {
            return false;
        }
    }
    return true;
}

#if defined(DRV_ARCH_RCAR_V3H)
// static uint32_t rcvdrv_reg_read(
//     const RCvIMPDRVCTL *const p_rcvdrvctl,
//     const RCvIMPDRVCOREINFO *const p_core,
//     uintptr_t const offset)
// {
//     uint32_t index = rcvdrv_CoreToIndex(p_rcvdrvctl, p_core);
//     return drvCommon_ReadReg32(p_rcvdrvctl->RegBase[index] + offset);
// }
#endif

inline static void cbFunc(int32_t ercd, int32_t code, const RCvIMPDRVCOREINFO *const p_core)
{
    char name[8];
    getCoreName(name, 8, p_core);

    if (RCVDRV_CB_RET_INT == ercd)
    {
        DEBUG_PRINT("[%u:%u] %s: INT(%i)\n", (unsigned int)p_core->CoreType, (unsigned int)p_core->CoreNum, name, (int)code);
        rcv_impdrv_ResumeCL(&rcvdrv_ctl, p_core);
    }
    else if (RCVDRV_CB_RET_OK == ercd)
    {
        set_time_trap(p_core);
        DEBUG_PRINT("%u, %d: CORE FINISHED\n", p_core->CoreType, code);
        DEBUG_PRINT("[%u:%u] %s: TRAP(%i)\n", (unsigned int)p_core->CoreType, (unsigned int)p_core->CoreNum, name, (int)code);
    }
    else if (RCVDRV_CB_RET_ILLEGAL == ercd)
    {
        DEBUG_PRINT("[%u:%u] %s: IER(%i)\n", (unsigned int)p_core->CoreType, (unsigned int)p_core->CoreNum, name, (int)code);
    }
#if defined(RCAR_SOC_V3H)
    else if (RCVDRV_CB_RET_BEFORE_EXEC == ercd)
    {
        if (RCVDRV_CORE_TYPE_CNN == p_core->CoreType)
        {
            uint16_t busprio[] = {0x09A8, 0x09B0, 0x09B4, 0x09C0, 0x09C4, 0x09D0};
            for (size_t i = 0; i < sizeof(busprio) / sizeof(busprio[0]); i++)
            {
                const uint32_t reg = busprio[i];
                // const uint32_t value = rcvdrv_reg_read(&rcvdrv_ctl, p_core, reg);
                // cinfov("State of BUSPRIO register 0x%04x: 0x%08x.\n", (unsigned int)reg, (unsigned int)value);
            }
        }
    }
#endif
}

#define CALLBACK(core, id)                                   \
    static void cbFunc##core##id(int32_t ercd, int32_t code) \
    {                                                        \
        RCvIMPDRVCOREINFO core_info;                         \
        core_info.CoreType = RCVDRV_CORE_TYPE_##core;        \
        core_info.CoreNum = id;                              \
        cbFunc(ercd, code, &core_info);                      \
    }

#if defined(RCAR_SOC_V3U)
CALLBACK(IMP, 0)
CALLBACK(IMP, 1)
CALLBACK(IMP, 2)
CALLBACK(IMP, 3)
CALLBACK(OCV, 0)
CALLBACK(OCV, 1)
CALLBACK(OCV, 2)
CALLBACK(OCV, 3)
CALLBACK(OCV, 4)
CALLBACK(OCV, 5)
CALLBACK(OCV, 6)
CALLBACK(OCV, 7)
CALLBACK(DMAC, 0)
CALLBACK(DMAC, 1)
CALLBACK(DMAC, 2)
CALLBACK(DMAC, 3)
CALLBACK(CNN, 0)
CALLBACK(CNN, 1)
CALLBACK(CNN, 2)

static RCVIMPDRV_CBFUNC callbacks[RVXT_CORE_NUM] = {
    cbFuncIMP0,
    cbFuncIMP1,
    cbFuncIMP2,
    cbFuncIMP3,
    cbFuncOCV0,
    cbFuncOCV1,
    cbFuncOCV2,
    cbFuncOCV3,
    cbFuncOCV4,
    cbFuncOCV5,
    cbFuncOCV6,
    cbFuncOCV7,
    cbFuncDMAC0,
    cbFuncDMAC1,
    cbFuncDMAC2,
    cbFuncDMAC3,
    cbFuncCNN0,
    cbFuncCNN1,
    cbFuncCNN2,
};
#elif defined(RCAR_SOC_V3H2)
CALLBACK(IMP, 0)
CALLBACK(IMP, 1)
CALLBACK(IMP, 2)
CALLBACK(IMP, 3)
CALLBACK(IMP, 4)
CALLBACK(OCV, 0)
CALLBACK(OCV, 1)
CALLBACK(OCV, 2)
CALLBACK(OCV, 3)
CALLBACK(OCV, 4)
CALLBACK(DMAC, 0)
CALLBACK(DMAC, 1)
CALLBACK(DMAC, 2)
CALLBACK(DMAC, 3)
CALLBACK(CNN, 0)

static RCVIMPDRV_CBFUNC callbacks[RVXT_CORE_NUM] = {
    cbFuncIMP0,
    cbFuncIMP1,
    cbFuncIMP2,
    cbFuncIMP3,
    cbFuncIMP4,
    cbFuncOCV0,
    cbFuncOCV1,
    cbFuncOCV2,
    cbFuncOCV3,
    cbFuncOCV4,
    cbFuncDMAC0,
    cbFuncDMAC1,
    cbFuncDMAC2,
    cbFuncDMAC3,
    cbFuncCNN0,
};
#elif defined(RCAR_SOC_V3M2)
CALLBACK(IMP, 0)
CALLBACK(IMP, 1)
CALLBACK(IMP, 2)
CALLBACK(IMP, 3)
CALLBACK(OCV, 0)
CALLBACK(OCV, 1)
CALLBACK(DMAC, 0)
CALLBACK(DMAC, 1)
CALLBACK(CNN, 0)

static RCVIMPDRV_CBFUNC callbacks[RVXT_CORE_NUM] = {
    cbFuncIMP0,
    cbFuncIMP1,
    cbFuncIMP2,
    cbFuncIMP3,
    cbFuncOCV0,
    cbFuncOCV1,
    cbFuncDMAC0,
    cbFuncDMAC1,
    cbFuncCNN0,
};
#else
#error "Unknwon architecture!"
#endif

static bool rvxt_flushMemres(const rvxt_info_t *const p_info, rvxt_cb_mem_t *p_cb_mem)
{
    for (size_t i = 0; i < p_info->memory_ressources_count; i++)
    {
        void *const virt = p_info->memory_ressources[i].address.virt;
        const size_t size = p_info->memory_ressources[i].size;

        if (NULL != virt)
        {
            if (NULL != p_cb_mem->flush)
            {
                p_cb_mem->flush(virt, size);
            }
        }
    }
    return true;
}

bool rvxt_invalidateMemres(const rvxt_info_t *const p_info, rvxt_cb_mem_t *p_cb_mem)
{
    for (size_t i = 0; i < p_info->memory_ressources_count; i++)
    {
        void *const virt = p_info->memory_ressources[i].address.virt;
        const size_t size = p_info->memory_ressources[i].size;

        if (NULL != virt)
        {
            if (NULL != p_cb_mem->invalidate)
            {
                p_cb_mem->invalidate(virt, size);
            }
        }
    }
    return true;
}

static void setCoreMap(const rvxt_info_t *const p_info, RCvIMPDRVCOREINFO core_map[16])
{
    unsigned int count_DMA = 0;
    unsigned int count_CNN = 0;
    unsigned int count_OCV = 0;
    unsigned int count_IMP = 0;

    for (size_t i = 0; i < p_info->core_count; i++)
    {
        switch (rvxt_getCoreGroup(p_info->cores[i].core))
        {
        case RVXT_CORE_GROUP_DMA:
        {
            core_map[i].CoreType = RCVDRV_CORE_TYPE_DMAC;
            core_map[i].CoreNum = count_DMA;
            count_DMA += 2;
            break;
        }
        case RVXT_CORE_GROUP_CNN:
        {
            core_map[i].CoreType = RCVDRV_CORE_TYPE_CNN;
            core_map[i].CoreNum = count_CNN;
            count_CNN++;
            break;
        }
        case RVXT_CORE_GROUP_CVE:
        {
            core_map[i].CoreType = RCVDRV_CORE_TYPE_OCV;
            core_map[i].CoreNum = count_OCV;
            count_OCV++;
            break;
        }
        case RVXT_CORE_GROUP_IMP:
        {
            core_map[i].CoreType = RCVDRV_CORE_TYPE_IMP;
            core_map[i].CoreNum = count_IMP;
            count_IMP++;
            break;
        }
        default:
        {
            cerrorv("ERROR: Unsupported core type: %d!\n", core_map[i].CoreType);
            break;
        }
        }
    }
}

static bool flush(void *const virt, const size_t size, rvxt_cb_mem_t *p_cb_mem)
{
    if (NULL != virt)
    {
        if (NULL != p_cb_mem->flush)
        {
            p_cb_mem->flush(virt, size);
        }
    }
    return true;
}

static void fix(void)
{
    // const uint32_t rev = drvCommon_ReadReg32(0xfff00044U);
    // cinfov("rev = 0x%08x.\n", (unsigned int)rev);
    // if ((rev & 0xFFFFU) == 0x5600U)
    // {
    //     cinfo("Found V3H1.0, applying fix...\n");
    //     drvCommon_WriteReg32(0xffa00000U + 0x0510, 0xFFFFFFFF);
    //     drvCommon_WriteReg32(0xffa00000U + 0x0514, 0xFFFFFFFF);
    // }
}

static bool executeCL(Commandlist *const cl, RCvIMPDRVCOREINFO core_map[16], rvxt_cb_mem_t *p_cb_mem, rvx_time_t time_start[RVXT_CORE_NUM], const uint32_t cl_alloc_alignment)
{
    RCvDrvErrorCode ret;

    int idx_core_map = __builtin_ctz(cl->syncid);

    const RCvIMPDRVCOREINFO *const p_core = &(core_map[idx_core_map]);
    size_t index = 0;

    if (!getCoreIndex(p_core, &index))
    {
        return false;
    }
#if defined(RCAR_XIL_SIL)
#if defined(RCAR_SOC_V3U) || defined(RCAR_V3U)
    /* V3U simulator limitations check */
    if (p_core->CoreType == RCVDRV_CORE_TYPE_CNN)
    {
        cwarning("CNNIP_V3U WUP/SLP is currently limited to work with a single other IP. If more IPs are used, synchonization will break.\n");
    }
    if ((!(p_core->CoreType == RCVDRV_CORE_TYPE_DMAC) && !(p_core->CoreType == RCVDRV_CORE_TYPE_CNN)) || (p_core->CoreNum > 0))
    {
        char name[8];
        getCoreName(name, 8, p_core);
        cerrorv("As of now, only one CNN-IP and one DMAC are supported for V3U simulator! %s is not supported.\n", name);
        return false;
    }
#endif
#endif

    RCVIMPDRV_CBFUNC cb = callbacks[index];

    flush(cl->virt, cl->size + cl_alloc_alignment - cl->size % cl_alloc_alignment, p_cb_mem);

    const uint32_t phys = (uint32_t)cl->phys;
    running[index] = true;
    rvxt_time_getCurrentTime(&(time_start[index]));

    ret = rcv_impdrv_ExecuteCB(
        &rcvdrv_ctl,
        phys,
        &core_map[idx_core_map],
        cb);

    if (!(ret == RCV_EC_OK_DRV))
    {
        cerrorv("rcv_impdrv_ExecuteCB() failed with code %i!\n", (int)ret);
        return false;
    }
    return true;
}

static void setCoreMap2(Commandlist *commandlists, size_t const count, RCvIMPDRVCOREINFO core_map[16])
{
    unsigned int count_DMA = 0;
    unsigned int count_CNN = 0;
    unsigned int count_OCV = 0;
    unsigned int count_IMP = 0;

    for (size_t i = 0; i < count; i++)
    {
        int index = __builtin_ctz(commandlists[i].syncid);

        if (commandlists[i].core == CORE_TYPE_DMA)
        {
            core_map[index].CoreType = RCVDRV_CORE_TYPE_DMAC;
            core_map[index].CoreNum = count_DMA;
            count_DMA += 2;
        }
        else if (commandlists[i].core == CORE_TYPE_CNN)
        {
            core_map[index].CoreType = RCVDRV_CORE_TYPE_CNN;
            core_map[index].CoreNum = count_CNN;
            count_CNN++;
        }
        else if (commandlists[i].core == CORE_TYPE_OCV)
        {
            core_map[index].CoreType = RCVDRV_CORE_TYPE_OCV;
            core_map[index].CoreNum = count_OCV;
            count_OCV++;
        }
        else if (commandlists[i].core == CORE_TYPE_IMP)
        {
            core_map[i].CoreType = RCVDRV_CORE_TYPE_IMP;
            core_map[i].CoreNum = count_IMP;
            count_IMP++;
        }
        else
        {
            cerrorv("ERROR: Unsupported core type: %d!\n", core_map[i].CoreType);
        }
    }
    core_map[count].CoreType = RCVDRV_CORE_TYPE_DTA;
    core_map[count].CoreNum = 0;
}

bool executeCommandlists(Commandlist *commandlists, size_t const count, rvxt_cb_mem_t *p_cb_mem, size_t clxX, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, int timeout_ms, uint32_t const cl_alloc_alignment)
{
    bool result = true;
    RCvIMPDRVCOREINFO core_map[16] = {{0, 0}};
    rvx_time_t time_start[RVXT_CORE_NUM];
    RCvDrvErrorCode ret;
    rvx_time_t start, end;
    size_t masterClIdx = count; /* invalid value */

    setCoreMap2(commandlists, count, core_map);

    memset(&rcvdrv_ctl, 0, sizeof(rcvdrv_ctl));

    // if (!(rcv_impdrv_IMP_InitDevice(&rcvdrv_ctl) == RCV_EC_OK_DRV))
    // {
    //     cerror("rcv_impdrv_IMP_InitDevice() failed!\n");
    //     return false;
    // }

    RCvIMPDRVOSALID osalid = {
        1,
        2,
        3,
        4};
    if (!(rcv_impdrv_Init(&rcvdrv_ctl, &osalid) == RCV_EC_OK_DRV))
    {
        cerror("rcv_impdrv_Init() failed!\n");
        return false;
    }

    for (size_t i = 0; i < count; i++)
    {
        if (RCV_EC_OK_DRV != rcv_impdrv_Start(&rcvdrv_ctl, &(core_map[i]), core_map))
        {
            char name[8];
            cerrorv("rcv_impdrv_Start(%s @ %u) failed!\n", getCoreName(name, 8, &(core_map[i])), (unsigned int)i);
            return false;
        }
    }

    fix();

    rvxt_time_getCurrentTime(&end);

    /* Execute the IMP task				*/
    ret = RCV_EC_OK_DRV;

    if (count > 1)
    {
        /* search for Master CL */
        for (size_t i = 0; i < count; i++)
        {
            const uint16_t slaveStr = 0xAFFE;
            const uint16_t masterStr = 0xBABE;
            uint16_t buffer = 0;
            uint32_t *clPtr = commandlists[i].virt;

            for (size_t j = 0; j < 4; j++)
            {
                const uint8_t opcode = (clPtr[j] & 0xFF000000U) >> 24;
                if (0x80 == opcode)
                {
                    const uint8_t c = (uint8_t)(clPtr[j] & 0x000000FFU);
                    buffer |= ((uint16_t)((uint16_t)c & 0x0000FU)) << (4 * (3 - j));
                }
                else
                {
                    /* required NOP instruction at the beginning */
                    break;
                }
            }
            if (masterStr == buffer)
            {
                /* found master CL */
                if (masterClIdx != count) /* check if we already found one */
                {
                    cerror("Multiple Master CL's found. Only one Master CL is allowed!\n");
                    return false;
                }
                masterClIdx = i; /* save the index of the master cl */
            }
            else if (slaveStr != buffer)
            {
                cwarning("CL type could not be identified as master or slave CL. Assuming Slave CL!\n");
            }
        }
        if (masterClIdx == count) /* check if we found master cl */
        {
            cwarning("No Master/Slave CL found. Last given CL on commandline is assumed to be master CL!\n");
            cwarning("Synconization is not guaranteed without Master/Slave CL information.\n");
            masterClIdx = count - 1;
        }
        /* start all slave CL's */
        for (size_t i = 0; i < count; i++)
        {
            if (i == masterClIdx)
            {
                /* skipping master CL --> will be issued last */
                continue;
            }
            char name[8];
            cinfov("Starting %s...\n", getCoreName(name, 8, &(core_map[i])));
            if (executeCL(&commandlists[i], core_map, p_cb_mem, time_start, cl_alloc_alignment) == false)
            {
                return false;
            }
        }
        /* start master cl execution */
        char name[8];
        cinfov("Starting %s...\n", getCoreName(name, 8, &(core_map[masterClIdx])));
        if (executeCL(&commandlists[masterClIdx], core_map, p_cb_mem, time_start, cl_alloc_alignment) == false)
        {
            return false;
        }
    }
    else
    {
        /* Only one cl. Execute it */
        char name[8];
        cinfov("Starting %s...\n", getCoreName(name, 8, &(core_map[0])));
        if (executeCL(&commandlists[0], core_map, p_cb_mem, time_start, cl_alloc_alignment) == false)
        {
            return false;
        }
    }

    //int timeout = 50;
#if defined(RCAR_XIL_SIL)
    timeout_ms *= 1000;
#endif

    while ((!check_done()) && (timeout_ms > 0))
    {
        //gf_SuspendTask(100);
        R_OSAL_ThreadSleepForTimePeriod(100);

        timeout_ms -= 100;
    }

    if (timeout_ms <= 0)
    {
        cerror("Timeout!\n");

        for (size_t i = 0; i < count; i++)
        {
            // rvxt_debug(&rcvdrv_ctl, &core_map[i]);
        }
        result = false;
    }

    rvxt_time_getCurrentTime(&start);

    cinfo("Runtime:\n");
    for (size_t i = 0; i < count; i++)
    {
        const RCvIMPDRVCOREINFO *const p_core = &(core_map[i]);
        size_t index = 0;
        char name[8];

        getCoreIndex(p_core, &index);
        getCoreName(name, 8, p_core);

        unsigned int runtime = rvxt_time_getTimeDelta(time_start[index], time_trap[index]);
        start = rvxt_time_min(start, time_start[index]);
        end = rvxt_time_max(end, time_trap[index]);
        cinfov("Core (%u:%u %s): runtime %u us\n", (unsigned int)p_core->CoreType, (unsigned int)p_core->CoreNum, name, runtime);
    }
    cinfov("Total runtime (from start of first core till TRAP of last core): %u us\n", (unsigned int)rvxt_time_getTimeDelta(start, end));
    if (clxX > 1)
    {
        cinfov("Total runtime / (%u runs/execution) = %u us average runtime for a single run.\n", (unsigned int)(clxX), (unsigned int)(rvxt_time_getTimeDelta(start, end) / clxX));
    }

    for (size_t i = 0; i < count; i++)
    {
        ret = rcv_impdrv_Stop(&rcvdrv_ctl, &core_map[i]);
        if (RCV_EC_OK_DRV != ret)
        {
            cerrorv("rcv_impdrv_Quit() failed: %d\n", (unsigned int)ret);
            return false;
        }
    }

    ret = rcv_impdrv_Quit(&rcvdrv_ctl);
    if (RCV_EC_OK_DRV != ret)
    {
        cerrorv("rcv_impdrv_Quit() failed: %d\n", (unsigned int)ret);
        return false;
    }

    return result;
}

static const char *getCoreType(const RCvIMPDRVCOREINFO *core)
{
    char *result;

    switch (core->CoreType)
    {
    case RCVDRV_CORE_TYPE_DMAC:
        result = "DMAC";
        break;
    case RCVDRV_CORE_TYPE_CNN:
        result = "CNN";
        break;
    case RCVDRV_CORE_TYPE_IMP:
        result = "IMP";
        break;
    case RCVDRV_CORE_TYPE_OCV:
        result = "CVE";
        break;
    default:
        result = "NONE";
    }
    return result;
}

static char *getCoreName(char *buffer, const size_t size, const RCvIMPDRVCOREINFO *core)
{
    snprintf(buffer, size, "%s%u", getCoreType(core), (const unsigned int)core->CoreNum);
    return buffer;
}
