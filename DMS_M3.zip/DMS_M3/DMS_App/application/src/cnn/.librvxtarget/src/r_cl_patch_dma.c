/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/r_cl_patch.h"
#include "../ince/rvx_target/r_cl_patch_dma.h"
#include "../ince/rvx_target/ui.h"
#include "common.h"

/*!
 * @brief Test if given address refers to a register containing an address value
 * @param reg
 * @return
 */
static bool isAddressRegisterDMA(const uintptr_t reg, const bool verbose)
{
    bool result;

    switch (reg)
    {
    case IDMA_D0SAR:
        if (verbose)
            cinfo("     D0SAR.\n");
        result = true;
        break;
    case IDMA_S0SAR:
        if (verbose)
            cinfo("     S0SAR.\n");
        result = true;
        break;
    case IDMA_S1SAR:
        if (verbose)
            cinfo("     S1SAR.\n");
        result = true;
        break;
    default:
        result = false;
    }
    return result;
}

/*!
 * @brief Patch CL for CNN-IP
 * @details Interprets CL to identify WPR to DMAxSA
 * @details Changes all address in the range [base_old,base_old+size) -> [base_new,base_new+size)
 * @param data Pointer to CL
 * @param base_old Base address of old address base
 * @param base_new Base address of new address base
 * @param size Size of address range to consider.
 * @return
 */
bool r_cl_patch_DMA(void *data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose)
{
    /* based on cl_step of r_IDMA_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_IDMA_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            if (isAddressRegisterDMA(wpr_addr, verbose))
            {
                const uintptr_t address_old = *inst;
                if ((address_old >= base_old) && (address_old < (base_old + size)))
                {
                    const uintptr_t address_new = base_new + address_old - base_old;
                    if (verbose)
                        cinfov("Fixing write to 0x%08x from 0x%08x to 0x%08x.\n", (unsigned int)(uintptr_t)(wpr_addr), (unsigned int)(address_old), (unsigned int)address_new);
                    *inst = (uint32_t)address_new;
                }
                else
                {
                    if (verbose)
                        cinfo("Address not in range, ignoring\n");
                }
            }
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_IDMA_CL_WPR:
            wpr_addr = R_IDMA_CL_WPR_ADDR(*inst);
            wpr_cnt = R_IDMA_CL_WPR_N(*inst);
            if (verbose)
                DEBUG_PRINT("   WPR[0x55]: %d  0x%04x .\n", (unsigned int)wpr_cnt, (unsigned int)wpr_addr);
            break;
        case R_IDMA_CL_SYNCS:
            break;

        case R_IDMA_CL_SYNCCC:
            break;

        case R_IDMA_CL_SYNCCF:
            break;

        case R_IDMA_CL_INT:
            break;

        case R_IDMA_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_IDMA_CL_WUP:
            if (verbose)
                DEBUG_PRINT("   WUP[0xA0]: %d  0x%04x .\n", (unsigned int)R_IDMA_CL_WPR_N(*inst), (unsigned int)R_IDMA_CL_WPR_ADDR(*inst));
            break;
        case R_IDMA_CL_SLP:
            if (verbose)
                DEBUG_PRINT("   SLP[0xA1]: %d  0x%04x .\n", (unsigned int)R_IDMA_CL_WPR_N(*inst), (unsigned int)R_IDMA_CL_WPR_ADDR(*inst));
            break;

        case R_IDMA_CL_JUMP:
            cerror("JUMP is not supported!.\n");
            return false;
            break;

        case R_IDMA_CL_GOSUB:
            cerror("GOSUB is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_RET:
            cerror("RET is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_NOP:
            break;

        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}

bool r_cl_patch_DMA_sync(void *data, const cl_patch_core_map_t *map_in, const cl_patch_core_map_t *map_out, const bool verbose)
{
    /* based on cl_step of r_IDMA_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_IDMA_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_IDMA_CL_WPR:
            wpr_addr = R_IDMA_CL_WPR_ADDR(*inst);
            wpr_cnt = R_IDMA_CL_WPR_N(*inst);
            break;

        case R_IDMA_CL_SYNCS:
            break;

        case R_IDMA_CL_SYNCCC:
            break;

        case R_IDMA_CL_SYNCCF:
            break;

        case R_IDMA_CL_INT:
            break;

        case R_IDMA_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_IDMA_CL_WUP:
        case R_IDMA_CL_SLP:
        {
            uint32_t ret = r_cl_patch_remapSync(*inst, map_in, map_out, verbose);
            if (verbose)
                cinfov("Fixing WUP/SLP from 0x%08x to 0x%08x.\n", (unsigned int)*inst, (unsigned int)ret);
            *inst = ret;
            break;
        }
        case R_IDMA_CL_JUMP:
            cerror("JUMP is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_GOSUB:
            cerror("GOSUB is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_RET:
            cerror("RET is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}

/*!
 * @brief Patch CL for CNN-IP to use 4xSLP, each SLP must be followed by 3 NOPs.
 */
bool r_cl_patch_DMA_SLP(void *data, const bool verbose)
{
    /* based on cl_step of r_IDMA_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    do
    {
        if (verbose)
            DEBUG_PRINT("  [0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_IDMA_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_IDMA_CL_WPR:
            wpr_addr = R_IDMA_CL_WPR_ADDR(*inst);
            wpr_cnt = R_IDMA_CL_WPR_N(*inst);
            break;

        case R_IDMA_CL_SYNCS:
            break;

        case R_IDMA_CL_SYNCCC:
            break;

        case R_IDMA_CL_SYNCCF:
            break;

        case R_IDMA_CL_INT:
            break;

        case R_IDMA_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_IDMA_CL_WUP:
            break;
        case R_IDMA_CL_SLP:
        {
            const uint32_t nop = 0x80000001U;
            if (nop == inst[1] && nop == inst[2] && nop == inst[3])
            {                if (verbose)
                    cinfo("SLP patched.\n");
                inst[1] = inst[0];
                inst[2] = inst[0];
                inst[3] = inst[0];
            }
            else
            {
                //					cerror("Failed to patch SLP!\n");
            }
            break;
        }

        case R_IDMA_CL_JUMP:
            cerror("JUMP is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_GOSUB:
            cerror("GOSUB is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_RET:
            cerror("RET is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}
