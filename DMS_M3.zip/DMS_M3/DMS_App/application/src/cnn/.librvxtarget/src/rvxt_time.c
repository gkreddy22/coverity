#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#include "timerHelper.h"

#include "../ince/rvx_target/rvxt_time.h"
#include "../ince/rvx_target/ui.h"

#include <stddef.h>
#include <stdint.h>

#if !defined(RVXT_TIME_USE_TIMESPEC)
#if defined(__aarch64__)
static uint64_t getSystimerValTick(void)
{
    uint64_t curr = 0;
    __asm volatile("isb;mrs %0, cntpct_el0"
                   : "=r"(curr));
    return curr;
}

static uint32_t getSystimerFreqHz(void)
{
    uint32_t curr = 0;
    __asm volatile("isb;mrs %0, cntfrq_el0"
                   : "=r"(curr));
    return curr;
}
#endif

static uint64_t getSystimerVal_us(void)
{
    uint64_t freq = getSystimerFreqHz();
    uint64_t currTick = getSystimerValTick();
    return (1000 * 1000) * currTick / freq;
}
#endif

static bool isLowerThan(const rvx_time_t lhs, const rvx_time_t rhs)
{
#if defined(RVXT_TIME_USE_TIMESPEC)
    if (lhs.tv_sec == rhs.tv_sec)
        return lhs.tv_nsec < rhs.tv_nsec;
    else
        return lhs.tv_sec < rhs.tv_sec;
#else
    return lhs < rhs;
#endif
}

rvx_time_t rvxt_time_max(const rvx_time_t lhs, const rvx_time_t rhs)
{
    if (isLowerThan(lhs, rhs))
    {
        return rhs;
    }
    return lhs;
}

rvx_time_t rvxt_time_min(const rvx_time_t lhs, const rvx_time_t rhs)
{
    if (isLowerThan(lhs, rhs))
    {
        return lhs;
    }
    return rhs;
}

unsigned int rvxt_time_getTimeDelta(rvx_time_t start, rvx_time_t stop)
{
    unsigned int result = 0;
#if defined(RVXT_TIME_USE_TIMESPEC)
    int64_t diffTime_ns;
    diffTime_ns = (stop.tv_sec - start.tv_sec) * 1000 * 1000 * 1000;
    diffTime_ns += (stop.tv_nsec - start.tv_nsec);
    if (diffTime_ns < 0)
    {
        diffTime_ns = -diffTime_ns;
    }
    result = (unsigned int)(diffTime_ns / 1000);
#else
    result = (unsigned int)(stop - start);
#endif
    return result;
}

bool rvxt_time_getCurrentTime(rvx_time_t *p_time)
{
#if defined(RVXT_TIME_USE_TIMESPEC)
    clock_gettime(CLOCK_MONOTONIC, p_time);
#else
    *p_time = getSystimerVal_us();
#endif
    return true;
}
