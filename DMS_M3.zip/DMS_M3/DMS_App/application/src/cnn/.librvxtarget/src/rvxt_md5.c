#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/md5.h"
#include "../ince/rvx_target/rvxt_md5.h"
#include "../ince/rvx_target/ui.h"

void rvxt_md5Calculate(md5_t *p_md5, const void *base, const size_t size)
{
    MD5_CTX md5;
    memset(p_md5->hash, 0, sizeof(p_md5->hash) / sizeof(p_md5->hash[0]));

    MD5_Init(&md5);
    MD5_Update(&md5, base, (unsigned long)size);
    MD5_Final(p_md5->hash, &md5);
}

bool rvxt_md5CalculateTile(md5_t *p_md5, const void *data, const size_t width, const size_t height, const size_t stride, const unsigned int bytesPerPixel)
{
    if (0 == bytesPerPixel)
    {
        cerrorv("Invalid bytesPerPixel = %u!\n", bytesPerPixel);
        return false;
    }
    if (stride < width)
    {
        cerrorv("Invalid stride value = %u!\n", (unsigned int)stride);
        return false;
    }

    MD5_CTX md5;
    memset(p_md5->hash, 0, sizeof(p_md5->hash) / sizeof(p_md5->hash[0]));

    MD5_Init(&md5);

    uintptr_t ptr = (uintptr_t)data;
    uintptr_t inc = stride * bytesPerPixel;

    for (size_t y = 0; y < height; y++)
    {
        MD5_Update(&md5, (void *)ptr, (unsigned long)width * bytesPerPixel);
        ptr += inc;
    }

    MD5_Final(p_md5->hash, &md5);
    return true;
}

void rvxt_md5Print(FILE *fp, md5_t *p_md5)
{
    for (size_t i = 0; i < sizeof(p_md5->hash) / sizeof(p_md5->hash[0]); i++)
    {
        fprintf(fp, "%02x", (unsigned int)p_md5->hash[i]);
    }
}

bool rvxt_md5Compare(md5_t *p_md5a, md5_t *p_md5b)
{
    for (size_t i = 0; i < sizeof(p_md5a->hash) / sizeof(p_md5a->hash[0]); i++)
    {
        if (p_md5a->hash[i] != p_md5b->hash[i])
        {
            return false;
        }
    }
    return true;
}

void rvxt_md5Dump(FILE *fp, const void *p_data, const size_t size)
{
    md5_t md5;
    rvxt_md5Calculate(&md5, p_data, size);
    rvxt_md5Print(fp, &md5);
}

void rvxt_md5DumpTile(FILE *fp, const void *p_data, const size_t width, const size_t height, const size_t stride, const unsigned int bytesPerPixel)
{
    md5_t md5;
    rvxt_md5CalculateTile(&md5, p_data, width, height, stride, bytesPerPixel);
    rvxt_md5Print(fp, &md5);
}

bool rvxt_md5DumpTileCheck(FILE *fp, const void *p_data, const size_t size, const size_t width, const size_t height, const size_t stride, const unsigned int bytesPerPixel)
{
    md5_t md5[2];
    rvxt_md5Calculate(&md5[0], p_data, size);
    rvxt_md5CalculateTile(&md5[1], p_data, width, height, stride, bytesPerPixel);
    rvxt_md5Print(fp, &md5[1]);
    return rvxt_md5Compare(&md5[0], &md5[1]);
}
