#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/list.h"

bool listCreate(List *list, size_t (*sizeFunction)(const void *))
{
    if (NULL == list)
    {
        return false;
    }

    list->elementCount = 0;
    list->sizeFunction = sizeFunction;
    list->head = NULL;
    list->tail = NULL;

    return true;
}

void listEntryDestroy(List *list, ListEntry *entry)
{
    (void)list;

    if (NULL != entry)
    {
        if (NULL != entry->data)
        {
            free(entry->data);
            entry->data = NULL;
        }
        free(entry);
    }
}

void listDestroy(List *list)
{
    if (NULL != list)
    {
        ListEntry *e = list->head;

        while (NULL != e)
        {
            ListEntry *n = e->next;
            listEntryDestroy(list, e);
            e = n;
        }
    }
}

ListEntry *listEntryCreate(List *list, const void *data)
{
    ListEntry *e = (ListEntry *)malloc(sizeof(ListEntry));
    if (NULL != e)
    {
        size_t elementSize = list->sizeFunction(data);
        e->data = malloc(elementSize);
        if (NULL == e->data)
        {
            free(e);
            return NULL;
        }

        if (NULL != data)
        {
            memcpy(e->data, data, elementSize);
        }
    }
    return e;
}

ListEntry *listAppend(List *list, const void *data)
{
    ListEntry *result = listEntryCreate(list, data);

    if (NULL == result)
    {
        return result;
    }

    ListEntry *p = list->tail;

    result->prev = p;
    result->next = NULL;

    if (NULL == p)
    {
        assert(0 == list->elementCount);
    }
    else
    {
        p->next = result;
    }

    list->tail = result;

    if (NULL == list->head)
    {
        assert(0 == list->elementCount);
        list->head = result;
    }

    list->elementCount++;

    return result;
}

size_t listSize(const List *list)
{
    size_t result = 0;

    if (NULL != list)
    {
        result = list->elementCount;
    }
    return result;
}

ListEntry *listAt(List *list, size_t index)
{
    ListEntry *e = list->head;

    while ((index > 0) && (NULL != e))
    {
        e = e->next;
        index--;
    }

    return e;
}

bool listInsertBefore(List *list, ListEntry *pos, ListEntry *entry)
{
    ListEntry *prev = pos->prev;

    if (NULL != prev)
    {
        prev->next = entry;
    }
    else
    {
        assert(list->head == pos);
        list->head = entry;
    }

    entry->next = pos;
    entry->prev = prev;
    pos->prev = entry;

    list->elementCount++;

    return true;
}

bool listInsertAfter(List *list, ListEntry *pos, ListEntry *entry)
{
    ListEntry *next = pos->next;

    if (NULL != next)
    {
        next->prev = entry;
    }
    else
    {
        assert(list->tail == pos);
        list->tail = entry;
    }

    entry->prev = pos;
    entry->next = next;
    pos->next = entry;

    list->elementCount++;

    return true;
}

bool listRemoveAt(List *list, ListEntry *pos)
{
    if (NULL == pos)
    {
        return false;
    }

    ListEntry *prev = pos->prev;
    ListEntry *next = pos->next;

    if (NULL == prev)
    {
        assert(list->head == pos);
        list->head = pos->next;
    }
    else
    {
        prev->next = pos->next;
    }

    if (NULL == next)
    {
        assert(list->tail == pos);
        list->tail = pos->prev;
    }
    else
    {
        next->prev = prev;
    }

    list->elementCount--;

    return true;
}

ListIterator *listIteratorGet(List *list)
{
    return list->head;
}

ListIterator *listIteratorGetLast(List *list)
{
    return list->tail;
}

ListIterator *listIteratorGetEnd(List *list)
{
    (void)list;
    return NULL;
}

ListIterator *listIteratorNext(List *list, ListIterator *iterator)
{
    (void)list;
    if (iterator == NULL)
    {
        return NULL;
    }
    return iterator->next;
}

bool listIteratorInsertBefore(List *list, ListIterator *iterator, const void *data)
{
    ListEntry *e = listEntryCreate(list, data);
    return listInsertBefore(list, iterator, e);
}

bool listIteratorInsertAfter(List *list, ListIterator *iterator, const void *data)
{
    ListEntry *e = listEntryCreate(list, data);
    return listInsertAfter(list, iterator, e);
}

void *listIteratorGetValue(List *list, ListIterator *iterator)
{
    (void)list;
    return iterator->data;
}
