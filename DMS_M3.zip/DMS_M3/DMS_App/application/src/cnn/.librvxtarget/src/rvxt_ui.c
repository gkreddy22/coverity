#include <stdio.h>

#include "../ince/rvx_target/ui.h"

static FILE *g_p_stderr = NULL;

void rvxtui_setErrorFile(FILE *const p_file)
{
    g_p_stderr = p_file;
}

FILE *rvxtui_get_stderr(void)
{
    if (NULL == g_p_stderr)
    {
        /* set to stdout by default */
        g_p_stderr = stdout;
    }
    return g_p_stderr;
}
