#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Atomic library */
#include "r_atmlib_types.h"
#include "rcar-xos/atmlib/r_atmlib_prot.h"

/* RVX Target interface */
#include "../ince/rvx_target/atmlib_cnn_user_functions.h"
#include "../ince/rvx_target/info.h"
#include "../ince/rvx_target/rvx_target_int.h"
#include "../ince/rvx_target/rvxt_csv_helper.h"
#include "../ince/rvx_target/rvxt_string_helper.h"

#define RETURN_IF_FALSE(val)                \
    {                                       \
        if (!val)                           \
        {                                   \
            cerror("'" #val "' failed!\n"); \
            return val;                     \
        }                                   \
    }

#define RETURN_VALUE_IF_NULL(eval, val)      \
    {                                        \
        if (NULL == eval)                    \
        {                                    \
            cerror("'" #eval "' failed!\n"); \
            return val;                      \
        }                                    \
    }

// #if !defined(RVXTARGET_HAVE_STRDUP)
// static char* strdup(const char* str)
// {
//     int   n   = strlen(str) + 1;
//     char* dup = (char*)malloc(n);
//     if (dup)
//     {
//         strcpy(dup, str);
//     }
//     return dup;
// }
// #else
// extern char* strdup(const char* str);
// #endif

bool stringtodef(const char *const string, uint32_t *const p_value)
{
    if ((string == NULL) || (NULL == p_value))
    {
        return false;
    }

    for (size_t cnt = 0; cnt < sizeof(strtodef_) / sizeof(strtodef_[0]); cnt++)
    {
        if (strcmp(string, strtodef_[cnt].string) == 0)
        {
            *p_value = strtodef_[cnt].value;
            return true;
        }
    }
    cerrorv("stringtodef('%s') failed!\n", string);
    return false;
}

bool set_bits_from_define_string(const char *const string, uint32_t *const p_value)
{
    bool result = true;
    if ((string == NULL) || (NULL == p_value))
    {
        return false;
    }

    *p_value = 0;
    char delimiter[] = " |";
    char *ptr_to_section;

    char *_string = rvxt_strdup(string);

    ptr_to_section = strtok(_string, delimiter);
    while (ptr_to_section != NULL)
    {
        uint32_t value = 0;
        result &= stringtodef(ptr_to_section, &value);
        *p_value = *p_value | value;
        ptr_to_section = strtok(NULL, delimiter);
    }
    if (!result)
    {
        cerrorv("set_bits_from_define_string('%s') failed!\n", string);
    }

    free(_string);

    return result;
}

bool handle_fp_handle_string(const char *const string, uint32_t *const p_value)
{
    if ((NULL == string) || (NULL == p_value))
    {
        return false;
    }

    *p_value = 0;
    char delimiter[] = " +";
    char *ptr_to_section;

    char *_string = rvxt_strdup(string);

    //Get the define
    ptr_to_section = strtok(_string, delimiter);
    RETURN_IF_FALSE(stringtodef(ptr_to_section, p_value));
    //Add the offset
    ptr_to_section = strtok(NULL, delimiter);
    if (NULL != ptr_to_section)
    {
        *p_value += (uint32_t)strtoumax(ptr_to_section, NULL, 10);
    }

    free(_string);

    return true;
}
