// derived from R_CNN_Load_tiles()

#include "../ince/rvx_target/aifHelper.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

bool getAIFImageInfo(const void *aifBuffer, void **dataBuffer, size_t *width, size_t *height, uint32_t *maxval)
{
    const int16_t *cPtr = (const int16_t *)aifBuffer;
    size_t coffset = 0;
    int16_t w, h, m;

    h = cPtr[coffset];
    coffset += 2;
    w = cPtr[coffset];
    coffset += 2;
    m = cPtr[coffset];
    coffset += 2;

    if (!((h) > 0 && (w) > 0 && (m) > 0))
        return false;

    *width = (size_t)w;
    *height = (size_t)h;
    *maxval = (unsigned int)m;

    *dataBuffer = (void *)(cPtr + coffset);
    return true;
}

bool testAIFImageFormat(const void *data)
{
    const uint32_t *p = (const uint32_t *)data;
    uint32_t w = *p++;
    uint32_t h = *p++;
    uint32_t m = *p;

    return (w > 0) && (w < UINT16_MAX) && (h > 0) && (h < UINT16_MAX) && (m > 0) && (m < UINT16_MAX);
}
