#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#include "generic_api_memory.h"
#include "../ince/rvx_target/r_cl_patch_cnn.h"

#include "../ince/md5.h"
#include "../ince/rvx_target/bcl.h"
#include "../ince/rvx_target/device_info.h"
#include "../ince/rvx_target/osal_helper.h"
#include "../ince/rvx_target/rvxt_bcl.h"
#include "../ince/rvx_target/rvxt_md5.h"
#include "../ince/rvx_target/stringList.h"
#include "../ince/rvx_target/ui.h"

#include "../../include/osal_debug.h"

#ifdef UNUSED
#elif defined(__GNUC__)
#define UNUSED(x) UNUSED_##x __attribute__((unused))
#elif defined(__LCLINT__)
#define UNUSED(x) /*@unused@*/ x
#elif defined(__cplusplus)
#define UNUSED(x)
#else
#define UNUSED(x) x
#endif

static inline bool rvxt_bcl_checkHeader(bcl_header_t *header);
static osal_memory_buffer_handle_t getbufobj(uint32_t physaddr, MemoryList *list, uint32_t *offset);

static osal_memory_buffer_handle_t getbufobj(uint32_t physaddr, MemoryList *list, uint32_t *offset)
{
    MemoryListIterator *it = memoryListIteratorGet(list);
    while (NULL != it)
    {
        MemoryListEntry *e = memoryListIteratorGetValue(list, it);
        // cinfov("addressNew: %p, size: %08x, physaddr: %08x\n", (void*)e->addressNew, e->size, physaddr);   // XXX: DEBUG
        if (e->addressNew <= physaddr && physaddr < e->addressNew + e->size)
        {
            *offset = (uint32_t)(physaddr - e->addressNew);
            // cinfov("offset: %08x\n", *offset);   // XXX: DEBUG
            return e->base_new_buffer;
        }
        it = it->next;
    }
    return OSAL_MEMORY_BUFFER_HANDLE_INVALID;
}

/*!
 * @brief Setup input memories, must be done after CL patching.
 * @param data
 * @param size
 * @return
 */
bool rvxt_bcl_setupInputMemories(void *data, const size_t UNUSED(size), const bool verbose, MemoryList *list, const uint32_t memories_alloc_alignment)
{
    if (NULL == data)
    {
        return false;
    }

    //e_osal_return_t ret = OSAL_RETURN_FAIL;
    bool result;
    bcl_header_t *header = (bcl_header_t *)data;

    result = rvxt_bcl_checkHeader(header);

    if (result)
    {
        const unsigned int memres_count = header->count.memres;
        const unsigned int memory_entry_count = header->count.mem_entry;

        for (size_t i = 0; i < memory_entry_count; i++)
        {
            bcl_mem_entry_t *mem = (bcl_mem_entry_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count + sizeof(bcl_mem_entry_t) * i);
            if (verbose)
                cinfov("Entry memory content for 0x%08x, size 0x%08x, located at 0x%08x.\n",
                       (unsigned int)mem->destination,
                       (unsigned int)mem->size,
                       (unsigned int)mem->position);

            void *virt = NULL;
            uint32_t offset;
            osal_memory_buffer_handle_t bufobj = getbufobj(mem->destination, list, &offset);

            if (bufobj != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
            {
                CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufobj, &virt)));

                virt = ((char *)virt + offset);
            }
            if (NULL == virt)
            {
                const char *name = rvxt_bcl_getEntryMemoryName(data, 0, i);
                if (IS_IMPC(mem->destination) || IS_IMPC_SHADOW(mem->destination) || IS_IMP(mem->destination))
                {
                    cinfov("Address resolution failed for '%s' in IMPC (mem->destination = 0x%08x), may be okay for DUMMY regions!\n", name, (unsigned int)mem->destination);
                }
                else
                {
                    cerrorv("Address resolution failed for '%s' mem->destination = 0x%08x!\n", name, (unsigned int)mem->destination);
                    return false;
                }
            }
            else
            {
                memcpy(virt, (void *)((uintptr_t)data + mem->position), mem->size);
                CHECK_OK(OSAL_CHECK(R_OSAL_MmngrFlush(bufobj, 0, mem->size + memories_alloc_alignment - mem->size % memories_alloc_alignment)));
            }
        }
    }

    return result;
}

bool rvxt_bcl_print(void *data, const size_t UNUSED(size), unsigned int const verbosity)
{
    if (NULL == data)
    {
        return false;
    }

    bool result = true;

    bcl_header_t *header = (bcl_header_t *)data;

    result = rvxt_bcl_checkHeader(header);

    const unsigned int memres_count = header->count.memres;
    const unsigned int memory_entry_count = header->count.mem_entry;
    const unsigned int memory_exit_count = header->count.mem_exit;

    cinfov("memres count: %u, entry memory count: %u, exit memory count: %u\n", memres_count, memory_entry_count, memory_exit_count);

    /* memory resources */
    for (size_t i = 0; i < memres_count; i++)
    {
        bcl_memres_t *memres = (bcl_memres_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * i);
        cinfov("Physical address range at 0x%08x, size 0x%08x: ", memres->base, memres->size);

        /* checking if the start address is in the range of IMPC */
        if (IS_IMPC(memres->base))
        {
            DEBUG_PRINT("IMPC [OK].\n");
        }
        else if (IS_IMPC_SHADOW(memres->base))
        {
            DEBUG_PRINT("IMPC shadow area [OK].\n");
        }
        else if (IS_IMP(memres->base))
        {
            DEBUG_PRINT("IMP subsystem area [OK].\n");
        }
        else
        {
            DEBUG_PRINT("assuming DDR.\n");
        }
    }

    /* show entries */
    bcl_mem_entry_t *entry = (bcl_mem_entry_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count);
    bcl_mem_exit_t *exit = (bcl_mem_exit_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count + sizeof(bcl_mem_entry_t) * memory_entry_count);

    for (size_t i = 0; i < memory_entry_count; i++)
    {
        if (verbosity > 1) // Verbosity check
        {
            cinfov("Entry memory %2u: \"%s\" dst=0x%08x, pos=0x%08x (@0x%08x), size=0x%08x. ",
                   (unsigned int)i,
                   rvxt_bcl_getEntryMemoryName(data, 0, i),
                   (unsigned int)entry[i].destination,
                   (unsigned int)entry[i].position,
                   (unsigned int)((uintptr_t)data + entry[i].position),
                   (unsigned int)entry[i].size);
            if (0 != entry[i].position)
            {
                DEBUG_PRINT("MD5 (payload): ");
                void *p_virt = (void *)((uintptr_t)data + entry[i].position);
                const size_t size = entry[i].size;
                const size_t width = entry[i].tile.width;
                const size_t height = entry[i].tile.height;
                const size_t stride = entry[i].tile.stride;
                unsigned int bytesPerPixel = entry[i].tile.bitpp / 8;

                const bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);

                if (!match)
                {
                    DEBUG_PRINT("\n");
                    cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n",
                              (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
                    rvxt_md5Dump(stdout, p_virt, size);
                    DEBUG_PRINT("', new: '");
                    rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
                    DEBUG_PRINT("'");
                }
            }
            DEBUG_PRINT("\n");
        }
    }

    for (size_t i = 0; i < memory_exit_count; i++)
    {
        if ((verbosity > 1) || (0 != exit[i].position)) // Verbosity check
        {
            cinfov("Exit memory  %2u: \"%s\" dst=0x%08x, pos=0x%08x (@0x%08x), size=0x%08x. ",
                   (unsigned int)i,
                   rvxt_bcl_getExitMemoryName(data, 0, i),
                   (unsigned int)exit[i].base,
                   (unsigned int)exit[i].position,
                   (unsigned int)((uintptr_t)data + exit[i].position),
                   (unsigned int)exit[i].size);
            if (0 != exit[i].position)
            {
                DEBUG_PRINT("MD5 (payload): ");

                void *p_virt = (void *)((uintptr_t)data + exit[i].position);
                const size_t size = exit[i].size;
                const size_t width = exit[i].tile.width;
                const size_t height = exit[i].tile.height;
                const size_t stride = exit[i].tile.stride;
                unsigned int bytesPerPixel = exit[i].tile.bitpp / 8;

                const bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);

                if (!match)
                {
                    DEBUG_PRINT("\n");
                    cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n",
                              (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
                    rvxt_md5Dump(stdout, p_virt, size);
                    DEBUG_PRINT("', new: '");
                    rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
                    DEBUG_PRINT("'");
                }
            }
            DEBUG_PRINT("\n");
        }
    }
    return result;
}

// /*!
//  * @brief Set up entry memories.
//  * @param data
//  * @param size
//  * @return
//  */
// bool rvxt_bcl_setup(void* data, const size_t UNUSED(size))
// {
//     bool result = true;

//     bcl_header_t* header = (bcl_header_t*)data;

//     result = rvxt_bcl_checkHeader(header);

//     const unsigned int memres_count       = header->count.memres;
//     const unsigned int memory_entry_count = header->count.mem_entry;

//     /* show entries */
//     bcl_mem_entry_t* entry = (bcl_mem_entry_t*)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count);

//     for (size_t i = 0; i < memory_entry_count; i++)
//     {
//         const uintptr_t dest   = (uintptr_t)entry[i].destination;
//         void*           p_virt = gf_GetVirtAddr(dest);

//         if (NULL == p_virt)
//         {
//             const char* name = rvxt_bcl_getEntryMemoryName(data, 0, i);
//             if (IS_IMPC(dest) || IS_IMPC_SHADOW(dest) || IS_IMP(dest))
//             {
//                 cinfov("Address resolution failed for '%s' in IMPC (mem->destination = 0x%08x), may be okay for DUMMY regions!\n", name, (const unsigned int)dest);
//             }
//             else
//             {
//                 cerrorv("Address resolution failed for '%s' mem->destination = 0x%08x!\n", name, (const unsigned int)dest);
//                 return false;
//             }
//         }
//         else
//         {
//             memcpy(p_virt, (void*)((uintptr_t)data + entry[i].position), entry[i].size);
//             gf_DCacheFlushRange(p_virt, entry[i].size);
//         }
//     }

//     return result;
// }

/*!
 * @brief Check results.
 * @param data
 * @param size
 * @return
 */
bool rvxt_bcl_check_entry(void *data, const size_t data_size, const bool verbose, osal_memory_manager_handle_t UNUSED(img_buffer), MemoryList *list)
{
    bool result = true;

    bcl_header_t *header = (bcl_header_t *)data;

    //e_osal_return_t ret = OSAL_RETURN_FAIL;
    result = rvxt_bcl_checkHeader(header);

    const unsigned int memres_count = header->count.memres;
    const unsigned int memory_entry_count = header->count.mem_entry;

    /* show entries */
    bcl_mem_entry_t *entry = (bcl_mem_entry_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count);

    for (size_t i = 0; i < memory_entry_count; i++)
    {
        const char *name = rvxt_bcl_getEntryMemoryName(data, data_size, i);
        const uintptr_t dest = (uintptr_t)entry[i].destination;

        void *p_virt = NULL;
        uint32_t offset;
        osal_memory_buffer_handle_t bufobj = getbufobj((uint32_t)dest, list, &offset);

        if (bufobj != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
        {
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufobj, &p_virt)));

            p_virt = ((char *)p_virt + offset);
        }

        if (NULL != p_virt)
        {
            int ret = memcmp(p_virt, (void *)((uintptr_t)data + entry[i].position), entry[i].size);
            if ((0 != ret) || (!result))
            {
                cwarningv("Entry mem: '%s' (@0x%08x): ", name, (const unsigned int)dest);
                DEBUG_PRINT("[!!], ");
                result = false;
            }
            else
            {
                if (verbose)
                {
                    cinfov("Entry mem: '%s' (@0x%08x): ", name, (const unsigned int)dest);
                    DEBUG_PRINT("[OK], ");
                }
            }
            if ((!result) || verbose)
            {
                DEBUG_PRINT("MD5: ");
                const size_t size = entry[i].size;
                const size_t width = entry[i].tile.width;
                const size_t height = entry[i].tile.height;
                const size_t stride = entry[i].tile.stride;
                unsigned int bytesPerPixel = entry[i].tile.bitpp / 8;

                const bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);

                if (!match)
                {
                    DEBUG_PRINT("\n");
                    cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n",
                              (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
                    rvxt_md5Dump(stdout, p_virt, size);
                    DEBUG_PRINT("', new: '");
                    rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
                    DEBUG_PRINT("'");
                }
                DEBUG_PRINT("\n");
            }
        }
        else
        {
            if (IS_IMPC(dest) || IS_IMPC_SHADOW(dest) || IS_IMP(dest))
            {
                cinfov("Address resolution failed for '%s' in IMPC (mem->destination = 0x%08x), may be okay for DUMMY regions!\n", name, (const unsigned int)dest);
            }
            else
            {
                cerrorv("Address resolution failed for '%s' mem->destination = 0x%08x!\n", name, (const unsigned int)dest);
                return false;
            }
        }
    }
    return result;
}

bool rvxt_bcl_check_exit(void *data, const size_t data_size, const bool verbose, osal_memory_manager_handle_t UNUSED(handle_osalmmngr), MemoryList *list)
{
    bool result = true;

    bcl_header_t *header = (bcl_header_t *)data;

    //e_osal_return_t ret = OSAL_RETURN_FAIL;
    result = rvxt_bcl_checkHeader(header);

    const unsigned int memres_count = header->count.memres;
    const unsigned int memory_entry_count = header->count.mem_entry;
    const unsigned int memory_exit_count = header->count.mem_exit;

    /* show entries */
    bcl_mem_exit_t *exit = (bcl_mem_exit_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count + sizeof(bcl_mem_entry_t) * memory_entry_count);

    for (size_t i = 0; i < memory_exit_count; i++)
    {
        const char *name = rvxt_bcl_getExitMemoryName(data, data_size, i);
        const uintptr_t base = exit[i].base;
        void *p_virt = NULL;
        uint32_t offset;
        osal_memory_buffer_handle_t bufobj = getbufobj((uint32_t)base, list, &offset);

        if (bufobj != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
        {
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufobj, &p_virt)));

            p_virt = ((char *)p_virt + offset);
        }
        if (NULL != p_virt)
        {
            if (exit[i].position)
            {
                int ret = memcmp(p_virt, (void *)((uintptr_t)data + exit[i].position), exit[i].size);
                if (0 != ret)
                {
                    cwarningv("Exit mem: '%s' (@0x%08x): ", name, (const unsigned int)base);
                    DEBUG_PRINT("[!!], ");
                    result = false;
                }
                else
                {
                    if (verbose)
                    {
                        cinfov("Exit mem: '%s' (@0x%08x): ", name, (const unsigned int)base);
                        DEBUG_PRINT("[OK], ");
                    }
                }
            }
            else
            {
                if (verbose)
                    cwarningv("Exit mem: '%s' (@0x%08x): [??], no data provided by BCL file.", name, (unsigned int)base);
            }
            if ((!result) || verbose)
            {
                DEBUG_PRINT(" MD5: ");
                const size_t size = exit[i].size;
                const size_t width = exit[i].tile.width;
                const size_t height = exit[i].tile.height;
                const size_t stride = exit[i].tile.stride;
                unsigned int bytesPerPixel = exit[i].tile.bitpp / 8;

                const bool match = rvxt_md5DumpTileCheck(stdout, p_virt, size, width, height, stride, bytesPerPixel);

                if (!match)
                {
                    DEBUG_PRINT("\n");
                    cwarningv("MD5 calculation MISMATCH (s=%u,w=%u,h=%u,st=%u,p=%u): old: '\n",
                              (unsigned int)size, (unsigned int)width, (unsigned int)height, (unsigned int)stride, (unsigned int)bytesPerPixel);
                    rvxt_md5Dump(stdout, p_virt, size);
                    DEBUG_PRINT("', new: '");
                    rvxt_md5DumpTile(stdout, p_virt, width, height, stride, bytesPerPixel);
                    DEBUG_PRINT("'");
                }
                DEBUG_PRINT("\n");
            }
        }
        else
        {
            if (IS_IMPC(base) || IS_IMPC_SHADOW(base) || IS_IMP(base))
            {
                cinfov("Address resolution failed for '%s' in IMPC (mem->destination = 0x%08x), may be okay for DUMMY regions!\n", name, (const unsigned int)base);
            }
            else
            {
                cerrorv("Address resolution failed for '%s' mem->destination = 0x%08x!\n", name, (const unsigned int)base);
                return false;
            }
        }
    }
    return result;
}

static inline bool rvxt_bcl_checkHeader(bcl_header_t *header)
{
    bool result = true;
    if (header->magic != BCL_MAGIC)
    {
        cwarning("BCL magic mismatch!\n");
        result = false;
    }
    if (header->count.version != BCL_VERSION)
    {
        cwarning("BCL file header version mismatch!\n");
        result = false;
    }
    return result;
}

bool rvxt_bcl_fixMemoryAddresses(void *data, const size_t UNUSED(size), const uintptr_t base_old, const uintptr_t base_new, const size_t base_size)
{
    bcl_header_t *header = (bcl_header_t *)data;

    if (!rvxt_bcl_checkHeader(header))
    {
        return NULL;
    }

    const unsigned int memres_count = header->count.memres;
    const unsigned int memory_entry_count = header->count.mem_entry;
    const unsigned int memory_exit_count = header->count.mem_exit;

    bcl_mem_entry_t *entry = (bcl_mem_entry_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count);
    bcl_mem_exit_t *exit = (bcl_mem_exit_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count + sizeof(bcl_mem_entry_t) * memory_entry_count);

    for (size_t j = 0; j < memory_entry_count; j++)
    {
        const uintptr_t address_old = entry[j].destination;
        if ((address_old >= base_old) && (address_old < (base_old + base_size)))
        {
            const uintptr_t address_new = base_new + address_old - base_old;
            entry[j].destination = (uint32_t)address_new;
        }
    }

    for (size_t j = 0; j < memory_exit_count; j++)
    {
        const uintptr_t address_old = exit[j].base;
        if ((address_old >= base_old) && (address_old < (base_old + base_size)))
        {
            const uintptr_t address_new = base_new + address_old - base_old;
            exit[j].base = (uint32_t)address_new;
        }
    }
    return true;
}

/*!
 * @brief Allocate data for BCL
 * @param data
 * @param size
 * @param index
 * @return
 */
bool rvxt_bcl_alloc(void *data, const size_t size, MemoryList *list, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, const uint32_t memories_alloc_alignment)
{
    if (NULL == data)
    {
        return false;
    }

    e_osal_return_t ret = OSAL_RETURN_FAIL;

    bcl_header_t *header = (bcl_header_t *)data;

    if (!rvxt_bcl_checkHeader(header))
    {
        return false;
    }

    const unsigned int memres_count = header->count.memres;

    bcl_memres_t *memres = (bcl_memres_t *)((uintptr_t)data + sizeof(bcl_header_t));

    for (size_t i = 0; i < memres_count; i++)
    {
        size_t base_size = memres[i].size;
        const uintptr_t base_old = memres[i].base;

        cinfov("Physical address range at 0x%08x, size 0x%08x: ", (unsigned int)base_old, (unsigned int)base_size);
        if (IS_IMPC(base_old))
        {
            DEBUG_PRINT("IMPC [OK].\n");
        }
        else if (IS_IMPC_SHADOW(base_old))
        {
            DEBUG_PRINT("IMPC SHADOW [OK].\n");
        }
        else if (IS_IMP(base_old))
        {
            DEBUG_PRINT("IMP subsystem area [OK].\n");
        }
        else
        {
            void *base_new_phys = NULL;
            osal_memory_buffer_handle_t memres_buffer = OSAL_MEMORY_BUFFER_HANDLE_INVALID;
            ret = OSAL_CHECK(R_OSAL_MmngrAlloc(handle_osalmmngr, base_size + memories_alloc_alignment - base_size % memories_alloc_alignment, memories_alloc_alignment, &memres_buffer));
            //ret = OSAL_CHECK(R_OSAL_MmngrAlloc(osal_mmngr, base_size, 4096, &memres_buffer));
            if (ret != OSAL_RETURN_OK)
            {
                DEBUG_PRINT("rvxt_bcl_alloc: OSAL_CHECK(R_OSAL_MmngrAlloc error code: %d\n", ret);
                return ret;
            }
            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(memres_buffer, &base_new_phys)));
            if (NULL != base_new_phys)
            {
                uintptr_t base_new = 0;
                ret = OSAL_RETURN_FAIL;
                CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetHwAddr(memres_buffer, imp_dev_axi_bus_id, &base_new)));

                MemoryListEntry entry;
                entry.size = base_size;
                entry.addressNew = base_new;
                entry.addressOld = base_old;
                entry.base_new_buffer = memres_buffer;
                memoryListInsertSorted(list, &entry);

                if (base_old == base_new)
                {
                    DEBUG_PRINT("Allocated same range: 0x%08x, size=0x%08x\n", (unsigned int)base_old, (unsigned int)base_size);
                }
                else
                {
                    // r_cl_patch_CNN(data, base_old, base_new, base_size, true);
                    DEBUG_PRINT("Failed to allocate same range: 0x%08x -> 0x%08x, size=0x%08x\n", (unsigned int)base_old, (unsigned int)base_new, (unsigned int)base_size);
                    memres[i].base = (uint32_t)base_new;
                    /* check and fix entries and exit mems */
                    rvxt_bcl_fixMemoryAddresses(data, size, base_old, base_new, base_size);
                }
            }
            else
            {
                cerror("Failed to allocate memory!\n");
                return false;
            }
        }
    }
    return true;
}

// /*!
//  * @brief Flush all memory resources.
//  * @param data Pointer to BCL
//  * @param size Size of BCL.
//  * @return
//  */
// bool rvxt_bcl_flush(void* data, const size_t UNUSED(size))
// {
//     bcl_header_t* header = (bcl_header_t*)data;

//     if (!rvxt_bcl_checkHeader(header))
//     {
//         return NULL;
//     }

//     const unsigned int memres_count = header->count.memres;

//     bcl_memres_t* memres = (bcl_memres_t*)((uintptr_t)data + sizeof(bcl_header_t));

//     for (size_t i = 0; i < memres_count; i++)
//     {
//         /* IMPC and IMPC shadow area do not need cash handling */
//         if (!IS_IMPC(memres[i].base) && !IS_IMPC_SHADOW(memres[i].base) && !IS_IMP(memres[i].base))   //(memres[i].base != IMPC_BASE)
//         {
//             gf_DCacheFlushRange(gf_GetVirtAddr(memres[i].base), (size_t)memres[i].size);
//         }
//     }
//     return true;
// }

// /*!
//  * @brief Invalidate all memory resources.
//  * @param data Pointer to BCL
//  * @param size Size of BCL.
//  * @return
//  */
// bool rvxt_bcl_invalidate(void* data, const size_t UNUSED(size))
// {
//     bcl_header_t* header = (bcl_header_t*)data;

//     if (!rvxt_bcl_checkHeader(header))
//     {
//         return NULL;
//     }

//     const unsigned int memres_count = header->count.memres;

//     bcl_memres_t* memres = (bcl_memres_t*)((uintptr_t)data + sizeof(bcl_header_t));

//     for (size_t i = 0; i < memres_count; i++)
//     {
//         /* IMPC and IMPC shadow area do not need cash handling */
//         if (!IS_IMPC(memres[i].base) && !IS_IMPC_SHADOW(memres[i].base) && !IS_IMP(memres[i].base))
//         {
//             gf_DCacheInvalidateRange(gf_GetVirtAddr(memres[i].base), memres[i].size);
//         }
//     }
//     return true;
// }

/*!
 * @brief Execute BCL on CNNIP.
 * @param bcl
 * @param size
 * @return
 */
bool rvxt_bcl_execute(void *UNUSED(bcl), const size_t UNUSED(size))
{
    bool result = true;
#if 0
	RCvUint core_type[]  = {RCVDRV_CORE_TYPE_CNN};
	RCvUint cl_address[] = {gf_GetPhysAddr(bcl)};

	gf_DCacheFlushRange(bcl, size);

	RCvIMPDRVCTL    rcvdrv_ctl;
	RCvIMPDRVCL     cl_data;
	RCvDrvErrorCode ret;

	cl_data.coretype = core_type;
	cl_data.claddr   = cl_address;
	cl_data.num_core = 1;

	if (!((rcv_impdrv_Init(&rcvdrv_ctl) == RCV_EC_OK_DRV) &&
		(rcv_impdrv_SetConfig(&rcvdrv_ctl, RCVDRV_CORE_CNN0, 2000) == RCV_EC_OK_DRV) &&
		(rcv_impdrv_Start(&rcvdrv_ctl) == RCV_EC_OK_DRV))
		)
	{
		cinfov("Could not open CNNIP\n");
		return false;
	}

	uint64_t start = getSystimerVal_us();
	ret = rcv_impdrv_ExecuteCL(&rcvdrv_ctl, &cl_data);
	uint64_t stop = getSystimerVal_us();

	if ( RCV_EC_OK_DRV != ret)
	{
		cerrorv("rcv_impdrv_ExecuteCL() failed: %u\n", (unsigned int)ret);
		result = false;
	}
	else
	{
		cokv("Executed CL successfully, runtime: %dus.\n", (unsigned int)(stop-start));
	}

	ret = rcv_impdrv_Quit(&rcvdrv_ctl);
	if ( RCV_EC_OK_DRV != ret)
	{
		cerrorv("rcv_impdrv_Quit() failed: %u\n", (unsigned int)ret);
		return false;
	}
#endif
    return result;
}

bool rvxt_bcl_run(void *UNUSED(data), const size_t UNUSED(size))
{
    bool result = false;
#if 0

	result = rvxt_bcl_alloc(data, size);
	rvxt_bcl_print(data, size);
	rvxt_bcl_setup(data, size);
	rvxt_bcl_flush(data, size);

	if (result)
	{
		result = rvxt_bcl_execute(data, size);
	}
	if (!result)
	{
		cinfov("executeCL FAILed\n");
		cnnDbgPrintCurrentCnnState();
	}

	rvxt_bcl_invalidate(data, size);

	if (result)
	{

		result = rvxt_bcl_check(data, size);
		if (!result)
		{
			cinfov("Comparison failed!\n");
		}
	}
#endif
    return result;
}

bcl_mem_exit_t *rvxt_bcl_getExitMemory(void *data, const size_t UNUSED(size), const size_t index)
{
    bcl_mem_exit_t *result = NULL;

    bcl_header_t *header = (bcl_header_t *)data;

    const unsigned int memres_count = header->count.memres;
    const unsigned int memory_entry_count = header->count.mem_entry;
    const unsigned int memory_exit_count = header->count.mem_exit;

    bcl_mem_exit_t *exit = (bcl_mem_exit_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count + sizeof(bcl_mem_entry_t) * memory_entry_count);

    if (index < memory_exit_count)
    {
        result = &exit[index];
    }

    return result;
}

bcl_mem_entry_t *rvxt_bcl_getEntryMemory(void *data, const size_t UNUSED(size), const size_t index)
{
    bcl_mem_entry_t *result = NULL;

    bcl_header_t *header = (bcl_header_t *)data;

    const unsigned int memres_count = header->count.memres;
    const unsigned int memory_entry_count = header->count.mem_entry;

    bcl_mem_entry_t *entry = (bcl_mem_entry_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count);

    if (index < memory_entry_count)
    {
        result = &entry[index];
    }

    return result;
}

/*!
 * @brief Verify BCL file.
 * @param data
 * @param size
 * @return
 */
bool rvxt_bcl_verify(void *data, const size_t UNUSED(size))
{
    bool result = true;

    if (NULL == data)
    {
        result = false;
    }

    if (result)
    {
        bcl_header_t *header = (bcl_header_t *)data;
        result = rvxt_bcl_checkHeader(header);
    }

    return result;
}

bool rvxt_bcl_parseStringList(void *data, const size_t size, StringList *stringList)
{
    (void)size;

    if (NULL == data)
    {
        return false;
    }

    bcl_header_t *header = (bcl_header_t *)data;

    if (!rvxt_bcl_checkHeader(header))
    {
        return NULL;
    }

    const unsigned int memres_count = header->count.memres;
    const unsigned int memory_entry_count = header->count.mem_entry;
    const unsigned int memory_exit_count = header->count.mem_exit;

    uint16_t *sl = (uint16_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count + sizeof(bcl_mem_entry_t) * memory_entry_count + sizeof(bcl_mem_exit_t) * memory_exit_count);

    if (*sl++ != 0x4C53U)
    {
        return false;
    }

    size_t count = *sl++;

    while (count > 0)
    {
        size_t offset = *sl++;
        char *str = (char *)sl;
        stringListAppend(stringList, str);
        sl = (uint16_t *)((uintptr_t)sl + offset);
        count--;
    }

    return true;
}

static char *rvxt_bcl_getMemoryName(void *data, const size_t size, const size_t index)
{
    (void)size;
    char *result = NULL;

    if (NULL == data)
    {
        return result;
    }

    bcl_header_t *header = (bcl_header_t *)data;

    if (!rvxt_bcl_checkHeader(header))
    {
        return result;
    }

    const unsigned int memres_count = header->count.memres;
    const unsigned int memory_entry_count = header->count.mem_entry;
    const unsigned int memory_exit_count = header->count.mem_exit;

    uint16_t *sl = (uint16_t *)((uintptr_t)data + sizeof(bcl_header_t) + sizeof(bcl_memres_t) * memres_count + sizeof(bcl_mem_entry_t) * memory_entry_count + sizeof(bcl_mem_exit_t) * memory_exit_count);

    if (*sl++ != 0x4C53U)
    {
        return result;
    }

    size_t count = *sl++;

    if (count <= index)
    {
        return result;
    }

    count = index + 1;

    while (count > 0)
    {
        size_t offset = *sl++;
        result = (char *)sl;
        sl = (uint16_t *)((uintptr_t)sl + offset);
        count--;
    }

    return result;
}

char *rvxt_bcl_getEntryMemoryName(void *data, const size_t size, const size_t index)
{
    char *result = NULL;

    if (NULL == data)
    {
        return result;
    }

    bcl_header_t *header = (bcl_header_t *)data;

    if (!rvxt_bcl_checkHeader(header))
    {
        return result;
    }

    const unsigned int memory_entry_count = header->count.mem_entry;

    if (index >= memory_entry_count)
    {
        return NULL;
    }

    return rvxt_bcl_getMemoryName(data, size, index);
}

char *rvxt_bcl_getExitMemoryName(void *data, const size_t size, const size_t index)
{
    char *result = NULL;

    if (NULL == data)
    {
        return result;
    }

    bcl_header_t *header = (bcl_header_t *)data;

    if (!rvxt_bcl_checkHeader(header))
    {
        return result;
    }

    const unsigned int memory_entry_count = header->count.mem_entry;
    const unsigned int memory_exit_count = header->count.mem_exit;

    if (index >= memory_exit_count)
    {
        return NULL;
    }

    return rvxt_bcl_getMemoryName(data, size, index + memory_entry_count);
}
