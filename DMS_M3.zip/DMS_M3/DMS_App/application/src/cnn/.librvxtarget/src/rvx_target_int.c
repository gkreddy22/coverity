#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/clofsList.h"
#include "../ince/rvx_target/clofsListCNN.h"
#include "../ince/rvx_target/filesystem.h"
#include "../ince/rvx_target/rvx_target.h"
#include "../ince/rvx_target/rvx_target_int.h"
#include "../ince/rvx_target/stringList.h"
#include "../ince/rvx_target/stringListHelper.h"
#include "../ince/rvx_target/ui.h"

static struct
{
    R_ATMLIB_CLData *cl_current;
    ClofsList *clofsList;
    ClofsListCNN *clofsListCNN;
    StringList *tags;
} state;

static bool checkCL(const R_ATMLIB_CLData *const cl)
{
    if (NULL == state.cl_current)
    {
        cerror("CL was not set!");
        cinfo("Make sure rvxt_int_initCL() was called.");
        return false;
    }

    if (cl != state.cl_current)
    {
        cerror("CLs do not match!");
        return false;
    }

    return true;
}

/*!
 *@brief Init advanced helper functions.
 *@post rvxt_int_closeCL()
 */
bool rvxt_int_initCL(R_ATMLIB_CLData *cl)
{
    if (NULL != state.cl_current)
    {
        cerror("CL already in use! Parallel procassing of CLs is not supported!");
        cerror("Make sure rvxt_int_initCL() and rvxt_int_closeCL() have been called correctly.");
        return false;
    }

    state.cl_current = cl;

    state.clofsListCNN = NULL;
    state.clofsList = NULL;

    if (R_ATMLIB_CLTYPE_CNN == cl->cltype)
    {
        state.clofsListCNN = clofsListCNNCreate();
    }
    else
    {
        state.clofsList = clofsListCreate();
    }

    return true;
}

/*!
 *@brief Init advanced helper functions.
 *@pre rvxt_int_initCL()
 */
bool rvxt_int_closeCL(R_ATMLIB_CLData *const cl)
{
    if (!checkCL(cl))
    {
        return false;
    }

    state.cl_current = NULL;

    if (R_ATMLIB_CLTYPE_CNN == cl->cltype)
    {
        clofsListCNNFree(state.clofsListCNN);
        state.clofsListCNN = NULL;
    }
    else
    {
        clofsListFree(state.clofsList);
        state.clofsList = NULL;
    }

    return true;
}

bool rvxt_int_appendTag(R_ATMLIB_CLData *cl, const char *tag)
{
    if (!checkCL(cl))
    {
        return false;
    }

    if (state.cl_current != cl)
    {
        stringListFree(state.tags);
        state.tags = stringListCreate();
        state.cl_current = cl;
    }

    stringListAppend(state.tags, tag);
    return true;
}

bool rvxt_int_writeTags(const char *filename, const R_ATMLIB_CLData *const cl)
{
    if (!checkCL(cl))
    {
        return false;
    }

    bool result = false;
    FILE *fp = fopen(filename, "wb");
    if (NULL != fp)
    {
        writeStringList(fp, state.tags);
        result = true;
        fclose(fp);
    }
    return result;
}

bool rvxt_int_appendCNNClofs(
    const R_ATMLIB_CLData *const cl,
    const rvxt_info_t *const p_info,
    R_ATMLIB_CNNCLofs_ImageAddr **p_clofs,
    ClofsListCNNEntryMems_t *p_memory_indexes)
{
    (void)p_info;

    if (!checkCL(cl))
    {
        return false;
    }

    ClofsListCNNEntry *p_e = clofsListCNNAppend(state.clofsListCNN, NULL);

    if (NULL == p_e)
    {
        return false;
    }

    if (NULL == p_memory_indexes)
    {
        return false;
    }

    if (NULL != p_clofs)
    {
        *p_clofs = &(p_e->clofs);
    }

    /* add copy of indexes */
    p_e->mems = *p_memory_indexes;

    /* invalidate offsets */
    for (size_t k = 0; k < sizeof(p_e->clofs.clofs_dmai) / sizeof(p_e->clofs.clofs_dmai[0]); k++)
    {
        p_e->clofs.clofs_dmai[k] = 0;
    }
    for (size_t k = 0; k < sizeof(p_e->clofs.clofs_dmac) / sizeof(p_e->clofs.clofs_dmac[0]); k++)
    {
        p_e->clofs.clofs_dmac[k] = 0;
    }
    for (size_t k = 0; k < sizeof(p_e->clofs.clofs_dmao) / sizeof(p_e->clofs.clofs_dmao[0]); k++)
    {
        p_e->clofs.clofs_dmao[k] = 0;
    }

    return true;
}

static bool _appendClof(
    const R_ATMLIB_CLData *const cl,
    const rvxt_info_t *const p_info,
    const size_t idx_memory,
    const uint32_t clof,
    const unsigned int id)
{
    (void)p_info;

    if (!checkCL(cl))
    {
        return false;
    }

    ClofsListEntry *p_e = clofsListAppend(state.clofsList, NULL);

    if (NULL == p_e)
    {
        return false;
    }

    p_e->clof = clof;
    p_e->index = idx_memory;
    p_e->id = id;

    return true;
}

bool rvxt_int_appendDMAClof(
    const R_ATMLIB_CLData *const cl,
    const rvxt_info_t *const p_info,
    const size_t idx_memory,
    const uint32_t clof,
    const unsigned int id)
{
    return _appendClof(cl, p_info, idx_memory, clof, id);
}

bool rvxt_int_appendCVEClof(
    const R_ATMLIB_CLData *const cl,
    const rvxt_info_t *const p_info,
    const size_t idx_memory,
    const uint32_t clof)
{
    return _appendClof(cl, p_info, idx_memory, clof, 0);
}

ClofsList *rvxt_int_getClofsList(
    const R_ATMLIB_CLData *const cl)
{
    if (!checkCL(cl))
    {
        return NULL;
    }

    return state.clofsList;
}

ClofsList *rvxt_int_getClofsListCNN(
    const R_ATMLIB_CLData *const cl)
{
    if (!checkCL(cl))
    {
        return NULL;
    }

    return state.clofsListCNN;
}

uintptr_t rvxt_int_calculateMemoryAddressPhys(const rvxt_info_t *const info, const size_t index)
{
    assert(NULL != info);
    assert(index < info->memories_count);
    uintptr_t memres_base = 0;
    if (NULL != info->memories[index].base)
    {
        memres_base = info->memories[index].base->address.phys;
    }
    else
    {
        const char *name = info->memories[index].name;
        cwarningv("MEMRES of memory '%s' not set. Using offset as absolute address.\n", name);
    }
    uintptr_t memory_offset = info->memories[index].offset;
    return (memres_base + memory_offset);
}

/*
 *@brief 
 *@param p_info in Pointer to info structure.
 *@param caller in Type of calling IP.
 *@param others in Set of other cores.
 *@param p_sync_bits inout Pointer to result.
 */
bool rvxt_int_getSyncBits(const rvxt_info_t *const p_info, rvxt_core_e caller, rvxt_core_e others, uint32_t *p_sync_bits)
{
    if (NULL == p_info)
    {
        return false;
    }

    if (NULL == p_sync_bits)
    {
        return false;
    }

    *p_sync_bits = 0;

    /* find calling core */
    for (size_t i = 0; i < p_info->core_count; i++)
    {
        rvxt_core_info_t *p_cd_c = &(p_info->cores[i]);
        if (p_cd_c->core == caller)
        {
            /* iterate others */
            for (size_t idx_other_core = 0; idx_other_core < p_info->core_count; idx_other_core++)
            {
                rvxt_core_info_t *p_cd_o = &(p_info->cores[idx_other_core]);
                if (0 != (p_cd_o->core & others))
                {
                    uint32_t sync_bit = 0;
                    /* find bit position of other core */
                    for (size_t idx_core_map = 0; idx_core_map < p_info->core_count; idx_core_map++)
                    {
                        size_t index = p_cd_c->core_map[idx_core_map];
                        if (index == idx_other_core)
                        {
                            sync_bit |= (uint32_t)(1 << idx_core_map);
                            break;
                        }
                    }
                    if (0 == sync_bit)
                    {
                        cerror("Core was not found in core map!\n");
                        return false;
                    }
                    *p_sync_bits |= sync_bit;
                }
            }
            /*TODO:FIXME: in case DTA is used, add the next bit */
            if (0 != (others & RVXT_CORE_DTA))
            {
                *p_sync_bits |= (uint32_t)(1 << p_info->core_count);
            }
            break;
        }
    }

    return true;
}

#define ELEMENTS(v) sizeof(v) / sizeof(v[0])

static void _process_dmax(
    FILE *p_file,
    const size_t mems_dma[],
    const uint32_t clofs_dma[],
    const size_t count,
    rvxt_mem_info_t *p_mem,
    const size_t idx_mem,
    uint32_t *const p_cl,
    const uint32_t base_phys,
    size_t *const mems_processed,
    uint32_t *p_MaxPosition,
    uint32_t *p_MinPosition,
    const char type,
    const bool verbose)
{
    for (size_t k = 0; k < count; k++)
    {
        if (mems_dma[k] == idx_mem)
        {
            if ((NULL != mems_processed) && (0 == *mems_processed))
            {
                //cinfov("Processing memory '%s':\n", p_mem->name);
                fprintf(p_file, "  /* memory '%s': */\n", p_mem->name);
            }
            const uint32_t position = clofs_dma[k];

            if (position != 0)
            {
                const uint32_t value = p_cl[position];
                const uintptr_t offset = value - base_phys;

                fprintf(p_file, "  patch(p_commandlist, 0x%08XU, base + 0x%08XU); /* base = 0x%08x, value = 0x%08x */\n", (unsigned int)position, (unsigned int)offset, (unsigned int)base_phys, (unsigned int)value);

                if (verbose)
                {
                    cinfov("base = 0x%08x, position_on_CL = 0x%08x, value = 0x%08x, offset = 0x%08x (DMA%c%u)\n",
                           (unsigned int)base_phys,
                           (unsigned int)position,
                           (unsigned int)value,
                           (unsigned int)offset,
                           type,
                           (unsigned int)k);
                }

                // Update min and max position, that needs to be patched
                if ((p_MaxPosition != NULL) && (p_MinPosition != NULL))
                {
                    if (*p_MinPosition > position)
                    {
                        *p_MinPosition = position;
                    }
                    if (*p_MaxPosition < position)
                    {
                        *p_MaxPosition = position;
                    }
                }
            }
            if (NULL != mems_processed)
            {
                *mems_processed = *mems_processed + 1;
            }
        }
    }
}

char *mystrsep(char **stringp, const char *delim)
{
    char *start = *stringp;
    char *p;

    p = (start != NULL) ? strpbrk(start, delim) : NULL;

    if (p == NULL)
    {
        *stringp = NULL;
    }
    else
    {
        *p = '\0';
        *stringp = p + 1;
    }

    return start;
}

/*!
 *@brief Find last occurence of one of the characrters in key in string.
 */
char *strrpbrk(char *string, const char *key)
{
    char *p, *r = string;
    p = strpbrk(string, key);
    while (p != NULL)
    {
        r = p + 1;
        p = strpbrk(p + 1, key);
    }
    return r;
}

char *extractFunctionName(char *dest, const size_t size, const char *pattern, const char *name)
{
    char buffer[128];
    int ret = snprintf(buffer, ELEMENTS(buffer), pattern, name);
    if ((ret < 0) || (ret >= (int)(ELEMENTS(buffer))))
    {
        return NULL;
    }
    char *function = strrpbrk(buffer, "\\/");
    function = mystrsep(&function, ".");
#ifdef __linux__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wstringop-truncation"
#endif
    strncpy(dest, function, size);
#ifdef __linux__
#pragma GCC diagnostic pop
#endif
    return dest;
}

static bool writeClofsListCNN(
    const rvxt_info_t *const p_info,
    const R_ATMLIB_CLData *const p_cl,
    const char *const filenamePattern,
    const bool do_empty,
    const bool verbose)
{
    (void)do_empty;
    if ((NULL == p_info) || (NULL == p_cl))
    {
        return false;
    }

    ClofsListCNN *p_clofsList = rvxt_int_getClofsListCNN(p_cl);
    if (NULL != p_clofsList)
    {
        cinfov("Number of CLOFS: %u\n", (unsigned int)clofsListCNNSize(p_clofsList));
    }

    /* iterate by ressource */
    for (size_t i = 0; i < p_info->memory_ressources_count; i++)
    {
        const rvxt_memres_info_t *memres = &(p_info->memory_ressources[i]);
        cinfov("Processing memory ressource '%s':\n", memres->name);

        char filename[256];
        const int ret = snprintf(filename, ELEMENTS(filename), filenamePattern, memres->name);
        if (ret < 0)
        {
            cerrorv("Failed to evaluate filename pattern '%s'!\n", filenamePattern);
            return false;
        }
        else if (ret >= (int)(ELEMENTS(filename)))
        {
            cerrorv("Buffer size of filename too small '%s', memres = '%s'!\n", filenamePattern, memres->name);
            return false;
        }

        FILE *p_file = fopen(filename, "w");
        if (NULL == p_file)
        {
            cerrorv("Failed to open '%s'!\n", filename);
            return false;
        }

        /* write file preface */
        fprintf(p_file, "// Patch function for memory resource \"%s\"\n\n", memres->name);
        fprintf(p_file, "#include <stdbool.h>\n");
        fprintf(p_file, "#include <stddef.h>\n\n");
        fprintf(p_file, "#include <stdint.h>\n\n");
        fprintf(p_file, "static bool patch(uint32_t* const p_commandlist, const size_t position, const uint32_t value)\n");
        fprintf(p_file, "{\n");
        fprintf(p_file, "  p_commandlist[position] = value;\n");
        fprintf(p_file, "  return true;\n");
        fprintf(p_file, "}\n\n");
        char function[128];
        fprintf(p_file, "bool %s(uint32_t* const p_commandlist, const uint32_t base)\n",
                extractFunctionName(function, ELEMENTS(function), filenamePattern, memres->name));
        fprintf(p_file, "{\n");

        uint32_t max_position = 0x00000000;
        uint32_t min_position = 0xFFFFFFFF;

        for (size_t j = 0; j < p_info->memories_count; j++)
        {
            const rvxt_mem_info_t *memory = &(p_info->memories[j]);
            if (memory->base == memres)
            {
                size_t count = 0;
                ClofsListCNNIterator *it = clofsListCNNIteratorGet(p_clofsList);
                while (NULL != it)
                {
                    ClofsListCNNEntry *e = clofsListCNNIteratorGetValue(p_clofsList, it);
                    _process_dmax(p_file, e->mems.dmai, e->clofs.clofs_dmai, ELEMENTS(e->mems.dmai), &p_info->memories[j], j, p_cl->top_addr, (uint32_t)p_info->memory_ressources[i].address.phys, &count, &max_position, &min_position, 'I', verbose);
                    _process_dmax(p_file, e->mems.dmao, e->clofs.clofs_dmao, ELEMENTS(e->mems.dmao), &p_info->memories[j], j, p_cl->top_addr, (uint32_t)p_info->memory_ressources[i].address.phys, &count, &max_position, &min_position, 'O', verbose);
                    _process_dmax(p_file, e->mems.dmac, e->clofs.clofs_dmac, ELEMENTS(e->mems.dmac), &p_info->memories[j], j, p_cl->top_addr, (uint32_t)p_info->memory_ressources[i].address.phys, &count, &max_position, &min_position, 'C', verbose);
                    it = clofsListCNNIteratorNext(p_clofsList, it);
                }
            }
        }

        fprintf(p_file, "  return true;\n");
        fprintf(p_file, "}\n\n");

        fprintf(p_file, "// Max position in CL that needs patching\n");
        fprintf(p_file, "uint32_t get_%s_max_position()\n",
                extractFunctionName(function, ELEMENTS(function), filenamePattern, memres->name));
        fprintf(p_file, "{\n");
        fprintf(p_file, "  return 0x%08XU;\n", (unsigned int)max_position);
        fprintf(p_file, "}\n\n");
        fprintf(p_file, "// Min position in CL that needs patching\n");
        fprintf(p_file, "uint32_t get_%s_min_position()\n",
                extractFunctionName(function, ELEMENTS(function), filenamePattern, memres->name));
        fprintf(p_file, "{\n");
        fprintf(p_file, "  return 0x%08XU;\n", (unsigned int)min_position);
        fprintf(p_file, "}\n");
        fclose(p_file);
    }

    return true;
}

static bool writeClofsList(
    const rvxt_info_t *const p_info,
    const R_ATMLIB_CLData *const p_cl,
    const char *const filenamePattern,
    const unsigned int id,
    const bool do_empty,
    const bool verbose)
{
    if ((NULL == p_info) || (NULL == p_cl))
    {
        return false;
    }

    ClofsList *p_clofsList = rvxt_int_getClofsList(p_cl);
    if (NULL != p_clofsList)
    {
        cinfov("Total number of CLOFS: %u\n", (unsigned int)clofsListSize(p_clofsList));
    }

    size_t clofsCount = 0;
    {
        ClofsListIterator *it = clofsListIteratorGet(p_clofsList);

        while (NULL != it)
        {
            ClofsListEntry *e = clofsListIteratorGetValue(p_clofsList, it);
            if (id == e->id)
            {
                clofsCount++;
            }
            it = clofsListIteratorNext(p_clofsList, it);
        }
    }

    if ((0 == clofsCount) && (false == do_empty))
    {
        cinfov("No CLOFS were found for this id (%u), skipping generation of '%s'!\n", (unsigned int)id, filenamePattern);
        return true;
    }

    /* iterate by ressource */
    for (size_t i = 0; i < p_info->memory_ressources_count; i++)
    {
        const rvxt_memres_info_t *memres = &(p_info->memory_ressources[i]);
        cinfov("Processing memory ressource '%s':\n", memres->name);

        {
            size_t count = 0;
            for (size_t j = 0; j < p_info->memories_count; j++)
            {
                const rvxt_mem_info_t *p_mem = &(p_info->memories[j]);
                if (p_mem->base == memres)
                {
                    ClofsListIterator *it = clofsListIteratorGet(p_clofsList);
                    while (NULL != it)
                    {
                        ClofsListEntry *e = clofsListIteratorGetValue(p_clofsList, it);
                        if (id == e->id)
                        {
                            const size_t index = e->index;
                            if (index == j)
                            {
                                count++;
                            }
                        }
                        it = clofsListIteratorNext(p_clofsList, it);
                    }
                }
            }
            if (0 == count)
            {
                cinfov("Skipping '%s', no CLOFS defined.\n", memres->name);
                continue;
            }
        }

        char filename[256];
        const int ret = snprintf(filename, ELEMENTS(filename), filenamePattern, memres->name);
        if (ret < 0)
        {
            cerrorv("Failed to evaluate filename pattern '%s'!\n", filenamePattern);
            return false;
        }
        else if (ret >= (int)(ELEMENTS(filename)))
        {
            cerrorv("Buffer size of filename too small '%s', memres = '%s'!\n", filenamePattern, memres->name);
            return false;
        }

        FILE *p_file = fopen(rvxtfs_convert(filename), "w");
        if (NULL == p_file)
        {
            cerrorv("Failed to open '%s'!\n", filename);
            return false;
        }

        /* write file preface */
        fprintf(p_file, "// Patch function for memory resource \"%s\"\n\n", memres->name);
        fprintf(p_file, "#include <stdbool.h>\n");
        fprintf(p_file, "#include <stddef.h>\n\n");
        fprintf(p_file, "#include <stdint.h>\n\n");
        fprintf(p_file, "static bool patch(uint32_t* const p_commandlist, const size_t position, const uint32_t value)\n");
        fprintf(p_file, "{\n");
        fprintf(p_file, "  p_commandlist[position] = value;\n");
        fprintf(p_file, "  return true;\n");
        fprintf(p_file, "}\n\n");
        char function[128];
        fprintf(p_file, "bool %s(uint32_t* const p_commandlist, const uint32_t base)\n",
                extractFunctionName(function, ELEMENTS(function), filenamePattern, memres->name));
        fprintf(p_file, "{\n");

        uint32_t max_position = 0x00000000;
        uint32_t min_position = 0xFFFFFFFF;

        for (size_t j = 0; j < p_info->memories_count; j++)
        {
            const rvxt_mem_info_t *p_mem = &(p_info->memories[j]);
            if (p_mem->base == memres)
            {
                size_t count = 0;
                ClofsListIterator *it = clofsListIteratorGet(p_clofsList);
                while (NULL != it)
                {
                    ClofsListEntry *e = clofsListIteratorGetValue(p_clofsList, it);
                    if (id == e->id)
                    {
                        const size_t index = e->index;

                        if (index == j)
                        {
                            if (0 == count)
                            {
                                //cinfov("Processing memory '%s':\n", p_mem->name);
                                fprintf(p_file, "  /* memory '%s': */\n", p_mem->name);
                            }
                            const uint32_t position = e->clof;

                            if (position != 0)
                            {
                                const uint32_t value = p_cl->top_addr[position];
                                const uintptr_t base_phys = p_info->memory_ressources[i].address.phys;
                                const uintptr_t offset = value - base_phys;

                                fprintf(p_file, "  patch(p_commandlist, 0x%08XU, base + 0x%08XU); /* base = 0x%08x, value = 0x%08x */\n", (unsigned int)position, (unsigned int)offset, (unsigned int)base_phys, (unsigned int)value);

                                if (verbose)
                                {
                                    cinfov("base = 0x%08x, position_on_CL = 0x%08x, value = 0x%08x, offset = 0x%08x\n",
                                           (unsigned int)base_phys,
                                           (unsigned int)position,
                                           (unsigned int)value,
                                           (unsigned int)offset);
                                }

                                if (min_position > position)
                                {
                                    min_position = position;
                                }
                                if (max_position < position)
                                {
                                    max_position = position;
                                }
                            }
                            count++;
                        }
                    }
                    it = clofsListIteratorNext(p_clofsList, it);
                }
            }
        }

        fprintf(p_file, "  return true;\n");
        fprintf(p_file, "}\n\n");

        fprintf(p_file, "// Max position in CL that needs patching\n");
        fprintf(p_file, "uint32_t get_%s_max_position()\n",
                extractFunctionName(function, ELEMENTS(function), filenamePattern, memres->name));
        fprintf(p_file, "{\n");
        fprintf(p_file, "  return 0x%08XU;\n", (unsigned int)max_position);
        fprintf(p_file, "}\n\n");
        fprintf(p_file, "// Min position in CL that needs patching\n");
        fprintf(p_file, "uint32_t get_%s_min_position()\n",
                extractFunctionName(function, ELEMENTS(function), filenamePattern, memres->name));
        fprintf(p_file, "{\n");
        fprintf(p_file, "  return 0x%08XU;\n", (unsigned int)min_position);
        fprintf(p_file, "}\n");
        fclose(p_file);
    }

    return true;
}

bool rvxt_int_writeClofsList(
    const rvxt_info_t *const p_info,
    const R_ATMLIB_CLData *const p_cl,
    const char *const filenamePattern,
    const unsigned int id,
    const bool do_empty,
    const bool verbose)
{
    if ((NULL == p_info) || (NULL == p_cl))
    {
        return false;
    }

    if (p_cl->cltype == R_ATMLIB_CLTYPE_CNN)
    {
        if (0 == id)
        {
            return writeClofsListCNN(p_info, p_cl, filenamePattern, do_empty, verbose);
        }
    }
    else
    {
        return writeClofsList(p_info, p_cl, filenamePattern, id, do_empty, verbose);
    }
    return false;
}

/* write all clofs */
static bool writeClofsList2(
    const rvxt_info_t *const p_info,
    const R_ATMLIB_CLData *const p_cl,
    char *filename,
    const bool verbose)
{
    if ((NULL == p_info) || (NULL == p_cl))
    {
        return false;
    }

    ClofsList *p_clofsList = rvxt_int_getClofsList(p_cl);
    if (NULL != p_clofsList)
    {
        cinfov("Total number of CLOFS: %u\n", (unsigned int)clofsListSize(p_clofsList));
    }

    /* iterate by memry */
    FILE *p_file = fopen(rvxtfs_convert(filename), "w");
    if (NULL == p_file)
    {
        cerrorv("Failed to open '%s'!\n", filename);
        return false;
    }

    for (size_t j = 0; j < p_info->memories_count; j++)
    {
        const rvxt_mem_info_t *p_mem = &(p_info->memories[j]);
        ClofsListIterator *it = clofsListIteratorGet(p_clofsList);
        while (NULL != it)
        {
            ClofsListEntry *e = clofsListIteratorGetValue(p_clofsList, it);
            //if (0 < e->id)
            {
                const size_t index = e->index;

                if (index == j)
                {
                    const size_t position = e->clof;

                    if (position != 0)
                    {
                        const unsigned int id = e->id;
                        const uint32_t value = p_cl->top_addr[position];
                        const uintptr_t base_phys = p_mem->base->address.phys;
                        const uintptr_t offset = value - base_phys;

                        fprintf(p_file, "%3u, 0x%08X, 0x%08X, 0x%08X, %s, %s\n", (unsigned int)id, (unsigned int)position, (unsigned int)base_phys, (unsigned int)value, p_mem->base->name, p_mem->name);

                        if (verbose)
                        {
                            cinfov("base = 0x%08x, position_on_CL = 0x%08x, value = 0x%08x, offset = 0x%08x\n",
                                   (unsigned int)base_phys,
                                   (unsigned int)position,
                                   (unsigned int)value,
                                   (unsigned int)offset);
                        }
                    }
                }
            }
            it = clofsListIteratorNext(p_clofsList, it);
        }
    }
    fclose(p_file);

    return true;
}

static void _process_dmax2(
    FILE *p_file,
    const size_t mems_dma[],
    const uint32_t clofs_dma[],
    const size_t count,
    rvxt_mem_info_t *p_mem,
    const size_t idx_mem,
    uint32_t *const p_cl,
    const uint32_t base_phys,
    size_t *const mems_processed,
    uint32_t *p_MaxPosition,
    uint32_t *p_MinPosition,
    const char type,
    const bool verbose)
{
    (void)mems_processed;
    (void)p_MaxPosition;
    (void)p_MinPosition;

    for (size_t k = 0; k < count; k++)
    {
        if (mems_dma[k] == idx_mem)
        {
            const size_t position = clofs_dma[k];

            if (position != 0)
            {
                const uint32_t value = p_cl[position];
                const unsigned int id = 0;
                fprintf(p_file, "%3u, 0x%08X, 0x%08X, 0x%08X, %s, %s\n", (unsigned int)id, (unsigned int)position, (unsigned int)base_phys, (unsigned int)value, p_mem->base->name, p_mem->name);

                if (verbose)
                {
                    const uintptr_t offset = value - base_phys;
                    cinfov("base = 0x%08x, position_on_CL = 0x%08x, value = 0x%08x, offset = 0x%08x (DMA%c%u)\n",
                           (unsigned int)base_phys,
                           (unsigned int)position,
                           (unsigned int)value,
                           (unsigned int)offset,
                           type,
                           (unsigned int)k);
                }
            }
        }
    }
}

static bool writeClofsListCNN2(
    const rvxt_info_t *const p_info,
    const R_ATMLIB_CLData *const p_cl,
    const char *const filename,
    const bool verbose)
{
    if ((NULL == p_info) || (NULL == p_cl))
    {
        return false;
    }

    ClofsListCNN *p_clofsList = rvxt_int_getClofsListCNN(p_cl);
    if (NULL != p_clofsList)
    {
        cinfov("Number of CLOFS: %u\n", (unsigned int)clofsListCNNSize(p_clofsList));
    }

    FILE *p_file = fopen(filename, "w");
    if (NULL == p_file)
    {
        cerrorv("Failed to open '%s'!\n", filename);
        return false;
    }

    uint32_t max_position = 0x00000000;
    uint32_t min_position = 0xFFFFFFFF;

    /* iterate by ressource */
    for (size_t i = 0; i < p_info->memory_ressources_count; i++)
    {
        const rvxt_memres_info_t *memres = &(p_info->memory_ressources[i]);
        cinfov("Processing memory ressource '%s':\n", memres->name);

        for (size_t j = 0; j < p_info->memories_count; j++)
        {
            const rvxt_mem_info_t *memory = &(p_info->memories[j]);
            if (memory->base == memres)
            {
                size_t count = 0;
                ClofsListCNNIterator *it = clofsListCNNIteratorGet(p_clofsList);
                while (NULL != it)
                {
                    ClofsListCNNEntry *e = clofsListCNNIteratorGetValue(p_clofsList, it);
                    _process_dmax2(p_file, e->mems.dmai, e->clofs.clofs_dmai, ELEMENTS(e->mems.dmai), &p_info->memories[j], j, p_cl->top_addr, (uint32_t)p_info->memory_ressources[i].address.phys, &count, &max_position, &min_position, 'I', verbose);
                    _process_dmax2(p_file, e->mems.dmao, e->clofs.clofs_dmao, ELEMENTS(e->mems.dmao), &p_info->memories[j], j, p_cl->top_addr, (uint32_t)p_info->memory_ressources[i].address.phys, &count, &max_position, &min_position, 'O', verbose);
                    _process_dmax2(p_file, e->mems.dmac, e->clofs.clofs_dmac, ELEMENTS(e->mems.dmac), &p_info->memories[j], j, p_cl->top_addr, (uint32_t)p_info->memory_ressources[i].address.phys, &count, &max_position, &min_position, 'C', verbose);
                    it = clofsListCNNIteratorNext(p_clofsList, it);
                }
            }
        }
    }
    fclose(p_file);

    return true;
}

bool rvxt_int_writeClofsList2(
    const rvxt_info_t *const p_info,
    const R_ATMLIB_CLData *const p_cl,
    char *filename,
    const bool verbose)
{
    if ((NULL == p_info) || (NULL == p_cl))
    {
        return false;
    }

    if (p_cl->cltype == R_ATMLIB_CLTYPE_CNN)
    {
        return writeClofsListCNN2(p_info, p_cl, filename, verbose);
    }
    else
    {
        return writeClofsList2(p_info, p_cl, filename, verbose);
    }
    return false;
}
