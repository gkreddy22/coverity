#include "../ince/rvx_target/channelSetupList.h"
#include "../ince/rvx_target/list.h"
#include "../ince/rvx_target/ui.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

static size_t _sizeFunction(const void *data)
{
    (void)data;
    return sizeof(ChannelSetupListEntry);
}

ChannelSetupList *channelSetupListCreate()
{
    ChannelSetupList *list = (ChannelSetupList *)malloc(sizeof(ChannelSetupList));
    listCreate(list, _sizeFunction);
    return list;
}

void channelSetupListFree(ChannelSetupList *list)
{
    listDestroy(list);
    free(list);
}

ChannelSetupListEntry *channelSetupListAppend(ChannelSetupList *list, const ChannelSetupListEntry *entry)
{
    ListEntry *p_e = listAppend(list, (void *)entry);
    if (NULL == p_e)
    {
        return NULL;
    }

    return (ChannelSetupListEntry *)p_e->data;
}

size_t channelSetupListSize(ChannelSetupList *list)
{
    return listSize(list);
}

ChannelSetupListIterator *channelSetupListIteratorGet(ChannelSetupList *list)
{
    return listIteratorGet(list);
}

ChannelSetupListIterator *channelSetupListIteratorNext(ChannelSetupList *list, ChannelSetupListIterator *iterator)
{
    return listIteratorNext(list, iterator);
}

ChannelSetupListIterator *channelSetupListIteratorEnd(ChannelSetupList *list)
{
    return listIteratorGetEnd(list);
}

ChannelSetupListEntry *channelSetupListIteratorGetValue(ChannelSetupList *list, ChannelSetupListIterator *iterator)
{
    return (ChannelSetupListEntry *)listIteratorGetValue(list, iterator);
}

bool channelSetupListIteratorInsertAt(ChannelSetupList *list, ChannelSetupListIterator *iterator, const ChannelSetupListEntry *entry)
{
    return listIteratorInsertBefore(list, iterator, (void *)entry);
}

ChannelSetupListEntry *channelSetupListAt(ChannelSetupList *list, size_t index)
{
    return (ChannelSetupListEntry *)listAt(list, index);
}

void channelSetupListPrint(ChannelSetupList *list)
{
    ChannelSetupListIterator *it = channelSetupListIteratorGet(list);
    while (NULL != it)
    {
        ChannelSetupListEntry *e = channelSetupListIteratorGetValue(list, it);
        cinfov(".channelName = '%s'(%i), .src_id_channel = %i\n", e->dst_name_channel, (int)e->dst_id_channel, (int)e->src_id_channel);
        it = channelSetupListIteratorNext(list, it);
    }
}
