/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/r_cl_patch.h"
#include "../ince/rvx_target/r_cl_patch_imp.h"
#include "../ince/rvx_target/ui.h"
#include "common.h"

/*!
 * @brief Test if given address refers to a register containing an address value
 * @param reg
 * @return
 */
static bool isAddressRegisterIMP(const uintptr_t reg, const bool verbose)
{
    bool result;

    switch (reg)
    {
    case IMP_APSASP:
        if (verbose)
            cinfo("     APSASP.\n");
        result = true;
        break;
    case IMP_APSBSP:
        if (verbose)
            cinfo("     APSBSP.\n");
        result = true;
        break;
    case IMP_APDSP:
        if (verbose)
            cinfo("     APDSP.\n");
        result = true;
        break;
    default:
        result = false;
    }
    return result;
}

/*!
 * @brief Patch CL for CNN-IP
 * @details Interprets CL to identify WPR to DMAxSA
 * @details Changes all address in the range [base_old,base_old+size) -> [base_new,base_new+size)
 * @param data Pointer to CL
 * @param base_old Base address of old address base
 * @param base_new Base address of new address base
 * @param size Size of address range to consider.
 * @return
 */
bool r_cl_patch_IMP(void *data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose)
{
    /* based on cl_step of r_CVE_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t *inst = (uint32_t *)data;
    unsigned int wpr_cnt = 0;
    uintptr_t wpr_addr = 0;
    bool okay = true;

    do
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_IMP_CL_CMDID(*inst);

        if (wpr_cnt != 0)
        {
            if (isAddressRegisterIMP(wpr_addr * 4, verbose))
            {
                const uintptr_t address_old = *inst;
                if ((address_old >= base_old) && (address_old < (base_old + size)))
                {
                    const uintptr_t address_new = base_new + address_old - base_old;
                    if (verbose)
                        cinfov("Fixing write to 0x%08x from 0x%08x to 0x%08x.\n", (unsigned int)(uintptr_t)(wpr_addr * 4), (unsigned int)(address_old), (unsigned int)address_new);
                    *inst = (uint32_t)address_new;
                }
                else
                {
                    //if(verbose)cinfo("Address not in range, ignoring\n");
                    const uintptr_t address_new = base_new + address_old - base_old;
                    if (verbose)
                        cinfov("NOT fixing write to 0x%08x from 0x%08x to 0x%08x. (address out of range)\n", (unsigned int)(uintptr_t)(wpr_addr * 4), (unsigned int)(address_old), (unsigned int)address_new);
                }
            }
            ++wpr_addr;
            --wpr_cnt;
            ++inst;
            continue;
        }

        switch (cmd)
        {
        case R_IMP_CL_MOV:
            wpr_addr = R_IMP_CL_WPR_ADDR(*inst);
            wpr_cnt = R_IMP_CL_WPR_N(*inst);
            if (verbose)
                DEBUG_PRINT("   MOV[0x41]: %d  0x%04x .\n", (unsigned int)wpr_cnt, (unsigned int)wpr_addr * 4);
            break;

        case R_IMP_CL_SYNCM:
            break;
        case R_IMP_CL_INT:
            break;

        case R_IMP_CL_TRAP:
            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_IMP_CL_WUP:
            if (verbose)
                DEBUG_PRINT("   WUP[0x48]: %d  0x%04x .\n", (unsigned int)R_IMP_CL_WPR_N(*inst), (unsigned int)R_IMP_CL_WPR_ADDR(*inst));
            break;
        case R_IMP_CL_SLP:
            if (verbose)
                DEBUG_PRINT("   SLP[0x49]: %d  0x%04x .\n", (unsigned int)R_IMP_CL_WPR_N(*inst), (unsigned int)R_IMP_CL_WPR_ADDR(*inst));
            break;

        case R_IMP_CL_GOSUB:
            cerror("GOSUB is not supported!\n");
            return false;
            break;

        case R_IMP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
        ++inst;
    } while (okay);
    return true;
}
