/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
 * No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
 **********************************************************************************************************************/

/**
  *    @file ${file_name}
  *
  *   @brief Function for importing PNM formats.
  * @details Currently PGM and PPM are supported. For reference see:
  *          http://davis.lbl.gov/Manuals/NETPBM/doc/ppm.html
  *          http://davis.lbl.gov/Manuals/NETPBM/doc/pgm.html
  */

/* *****************************************************************************************************************
 * Includes
 *******************************************************************************************************************/
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/pnmHelper.h"
#include "../ince/rvx_target/ui.h"

/* *****************************************************************************************************************
 * Macro definitions
 *******************************************************************************************************************/
#ifndef MIN
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#endif

/* *****************************************************************************************************************
 * Static function declarations
 *******************************************************************************************************************/
const char *getPNMTypeName(const char *pnmData);

/* *****************************************************************************************************************
 * Function definitions
 *******************************************************************************************************************/
bool getPNMImageInfo(const void *pnmBuffer, void **dataBuffer, size_t *width, size_t *height, uint8_t *bpp)
{
    const char *cPtr = (const char *)pnmBuffer;
    char *endPtr = NULL;
    size_t coffset = 0;

    coffset = 2;

    //2. Whitespace (blanks, TABs, CRs, LFs).
    if (cPtr[coffset] != ' ' && cPtr[coffset] != '\t' && cPtr[coffset] != '\n' && cPtr[coffset] != '\r')
    {
        //unexpected character found
        cerror("Invalid PNM header! (missing whitespace)\n");
        return false;
    }
    coffset++;

    //Now expect either Comment or Image size
    if (cPtr[coffset] == '#')
    {
        //it is a comment --> skip until new line;
        while (cPtr[coffset] != '\n' && cPtr[coffset] != '\r')
        {
            coffset++;
        }
        coffset++;
    }
    //A width, formatted as ASCII characters in decimal.

    // decode A width, formatted as ASCII characters in decimal.
    {
        const long ret = strtol(cPtr + coffset, &endPtr, 10);
        if (ret < 0)
        {
            cerror("Invalid PNM header! (width < 0)\n");
            return false;
        }
        *width = (size_t)ret;
    }
    /* decode A height, again in ASCII decimal. */
    {
        const long ret = strtol(endPtr, &endPtr, 10);
        if (ret < 0)
        {
            cerror("Invalid PNM header! (width < 0)\n");
            return false;
        }
        *height = (size_t)ret;
    }

    // decode The maximum color value (Maxval), again in ASCII decimal. Must be less than 65536 and more than zero.
    unsigned int maxVal = (unsigned int)strtol(endPtr, &endPtr, 10);

    coffset = ((uintptr_t)endPtr - (uintptr_t)cPtr);

    //expect a whitespace character now;
    if (cPtr[coffset] != ' ' && cPtr[coffset] != '\t' && cPtr[coffset] != '\n' && cPtr[coffset] != '\r')
    {
        //unexpected character found
        cerror("Invalid PNM header! (missing whitespace)\n");
        return false;
    }

    coffset++;
    *dataBuffer = (void *)(cPtr + coffset);
    *bpp = maxVal < 256 ? 1 : 2;

    return true;
}

void seperatePPMChannel(const void *imageBuffer, size_t width, size_t height, uint8_t *rBuffer, uint8_t *gBuffer, uint8_t *bBuffer)
{
    size_t x, y;

    typedef struct
    {
        uint8_t r, g, b;
    } RGBstruct;

    RGBstruct *rgbPtr = (RGBstruct *)imageBuffer;
    for (y = 0; y < height; y++)
    {
        for (x = 0; x < width; x++)
        {
            if (NULL != rBuffer)
            {
                rBuffer[y * width + x] = (rgbPtr + width * y + x)->r;
            }

            if (NULL != gBuffer)
            {
                gBuffer[y * width + x] = (rgbPtr + width * y + x)->g;
            }

            if (NULL != bBuffer)
            {
                bBuffer[y * width + x] = (rgbPtr + width * y + x)->b;
            }
        }
    }
}

void seperatePPMChannelU16(const void *imageBuffer, size_t width, size_t height, uint16_t *rBuffer, uint16_t *gBuffer, uint16_t *bBuffer)
{
    size_t x, y;

    typedef struct
    {
        uint16_t r, g, b;
    } RGBstruct;

    RGBstruct *rgbPtr = (RGBstruct *)imageBuffer;
    for (y = 0; y < height; y++)
    {
        for (x = 0; x < width; x++)
        {
            if (NULL != rBuffer)
            {
                rBuffer[y * width + x] = (rgbPtr + width * y + x)->r;
            }
            if (NULL != gBuffer)
            {
                gBuffer[y * width + x] = (rgbPtr + width * y + x)->g;
            }
            if (NULL != bBuffer)
            {
                bBuffer[y * width + x] = (rgbPtr + width * y + x)->b;
            }
        }
    }
}

bool testPPMImageFormat(const void *data)
{
    if (NULL == data)
    {
        return false;
    }

    const char *cPtr = (const char *)data;

    // http://davis.lbl.gov/Manuals/NETPBM/doc/ppm.html
    //1. A "magic number" for identifying the file type. A ppm image's magic number is the two strings "P6" or "p6".
    if ((strncmp(cPtr, "P6", 2) == 0) || (strncmp(cPtr, "p6", 2) == 0))
    {
        cinfov("Detected image format: %s\n", getPNMTypeName("P6"));
        return true;
    }
    else
    {
        return false;
    }
}

bool testPGMImageFormat(const void *data)
{
    if (NULL == data)
    {
        return false;
    }

    const char *cPtr = (const char *)data;

    /* 1. A "magic number" for identifying the file type. A ppm image's magic number is the two strings "P5" or "p5". */
    if ((strncmp(cPtr, "P5", 2) == 0) || (strncmp(cPtr, "p5", 2) == 0))
    {
        cinfov("Detected image format: %s\n", getPNMTypeName("P5"));
        return true;
    }
    else
    {
        return false;
    }
}

#define R_IMAGE_PGM_MAGIC_NUMBER "P5"
#define R_IMAGE_HI(num) (int)((num & 0x0000FF00U) >> 8U)
#define R_IMAGE_LO(num) ((num)&0x000000FF)

bool writePGMu8(FILE *fp, const uint8_t *data, const size_t width, const size_t height, const uint8_t mask)
{
    const size_t cols = 1;
    const size_t rows = 1;

    if ((fp == NULL) || (data == NULL))
    {
        return false;
    }

    fprintf(fp, R_IMAGE_PGM_MAGIC_NUMBER);
    fprintf(fp, " %d %d ", (unsigned int)(cols * width), (unsigned int)(rows * height));
    fprintf(fp, "%d ", 255);

    for (size_t r = 0; r < rows; ++r)
    {
        for (size_t i = 0; i < height; ++i)
        {
            for (size_t c = 0; c < cols; ++c)
            {
                for (size_t j = 0; j < width; ++j)
                {
                    uint8_t tmp = data[r * height * cols * width + c * height * width + i * width + j];
                    tmp &= mask;
                    fwrite((void *)&tmp, sizeof(tmp), 1, fp);
                }
            }
        }
    }

    return true;
}

bool writePGMs16(FILE *fp, const int16_t *data, const size_t width, const size_t height, const uint16_t mask)
{
    const size_t cols = 1;
    const size_t rows = 1;

    if ((fp == NULL) || (data == NULL))
    {
        return false;
    }

    int32_t min = INT32_MAX;
    int32_t max = INT32_MIN;

    for (size_t r = 0; r < rows; ++r)
    {
        for (size_t i = 0; i < height; ++i)
        {
            for (size_t c = 0; c < cols; ++c)
            {
                for (size_t j = 0; j < width; ++j)
                {
                    int16_t di = data[r * height * cols * width + c * height * width + i * width + j];
                    uint16_t dm = (*((uint16_t *)&di) & mask);
                    int32_t dx = *((int16_t *)&dm);
                    min = MIN(dx, min);
                    max = MAX(dx, max);
                }
            }
        }
    }

    const unsigned int range = (unsigned int)MAX(max - min, 256);

    fprintf(fp, R_IMAGE_PGM_MAGIC_NUMBER);
    fprintf(fp, " %d %d ", (unsigned int)(cols * width), (unsigned int)(rows * height));
    fprintf(fp, "%d ", range);

    for (size_t r = 0; r < rows; ++r)
    {
        for (size_t i = 0; i < height; ++i)
        {
            for (size_t c = 0; c < cols; ++c)
            {
                for (size_t j = 0; j < width; ++j)
                {
                    int16_t di = data[r * height * cols * width + c * height * width + i * width + j];
                    uint16_t dm = (*((uint16_t *)&di) & mask);
                    int32_t dx = *((int16_t *)&dm);
                    uint16_t val = (uint16_t)(dx - min);

                    int hi = R_IMAGE_HI(val);
                    int lo = R_IMAGE_LO(val);
                    if (range > 255)
                    {
                        fputc(hi, fp);
                    }
                    fputc(lo, fp);
                }
            }
        }
    }

    return true;
}

bool writePGMu16(FILE *fp, const uint16_t *data, const size_t width, const size_t height, const uint16_t mask)
{
    const size_t cols = 1;
    const size_t rows = 1;

    if ((fp == NULL) || (data == NULL))
    {
        return false;
    }

    uint16_t min = UINT16_MAX;
    uint16_t max = 0;

    for (size_t r = 0; r < rows; ++r)
    {
        for (size_t i = 0; i < height; ++i)
        {
            for (size_t c = 0; c < cols; ++c)
            {
                for (size_t j = 0; j < width; ++j)
                {
                    uint16_t di = data[r * height * cols * width + c * height * width + i * width + j];
                    uint16_t dm = di & mask;
                    min = MIN(dm, min);
                    max = MAX(dm, max);
                }
            }
        }
    }

    const unsigned int range = MAX((unsigned int)(max - min), 256);

    fprintf(fp, R_IMAGE_PGM_MAGIC_NUMBER);
    fprintf(fp, " %d %d ", (unsigned int)(cols * width), (unsigned int)(rows * height));
    fprintf(fp, "%d ", range);

    for (size_t r = 0; r < rows; ++r)
    {
        for (size_t i = 0; i < height; ++i)
        {
            for (size_t c = 0; c < cols; ++c)
            {
                for (size_t j = 0; j < width; ++j)
                {
                    uint16_t di = data[r * height * cols * width + c * height * width + i * width + j];
                    uint16_t dm = (di & mask);
                    uint16_t val = (uint16_t)(dm - min);

                    int hi = R_IMAGE_HI(val);
                    int lo = R_IMAGE_LO(val);
                    if (range > 255)
                    {
                        fputc(hi, fp);
                    }
                    fputc(lo, fp);
                }
            }
        }
    }

    return true;
}

/* *****************************************************************************************************************
 * Static function definitions
 *******************************************************************************************************************/
const char *getPNMTypeName(const char *pnmData)
{
    /* LUT for names */
    static const char *typeNames[][2] = {
        {"p1", "PBM ASCII"},
        {"P1", "PBM ASCII"},
        {"p2", "PGM ASCII"},
        {"P2", "PGM ASCII"},
        {"p3", "PPM ASCII"},
        {"P3", "PPM ASCII"},
        {"p4", "PBM binary"},
        {"P4", "PBM binary"},
        {"p5", "PGM binary"},
        {"P5", "PGM binary"},
        {"p6", "PPM binary"},
        {"P6", "PPM binary"},
        {"p7", "PNM binary"},
        {"P7", "PNM binary"},
        {NULL, NULL}};

    /* search the LUT for a matching identifier */
    int idx = 0;
    while (NULL != typeNames[idx])
    {
        if (0 == strncmp(pnmData, typeNames[idx][0], 2))
        {
            return typeNames[idx][1];
        }
        ++idx;
    }

    /* no matching identifier found */
    return "unknown";
}
