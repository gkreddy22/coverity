#include <ctype.h>
#include <inttypes.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/rvxt_string_helper.h"

char *rvxt_strdup(const char *str)
{
    if (NULL == str)
    {
        return NULL;
    }
    size_t n = strlen(str) + 1;
    char *dup = (char *)malloc(n);
    if (dup)
    {
        strcpy(dup, str);
    }
    return dup;
}

char *rvxt_sprintf_dup(char *str, ...)
{
    char *result = NULL;
    va_list arg;
    va_start(arg, str);
    const int bufsz = vsnprintf(NULL, 0, str, arg);
    va_end(arg);

    if (bufsz >= 0)
    {
        const size_t size = (size_t)bufsz + 1;
        char *result = (char *)malloc(size);
        if (NULL != result)
        {
            va_start(arg, str);
            vsnprintf(result, size, str, arg);
            va_end(arg);
        }
    }
    return result;
}

char *rvxt_to_lower(char *str)
{
    if (NULL == str)
    {
        return NULL;
    }

    for (size_t i = 0; i < strlen(str); i++)
    {
        str[i] = (char)tolower((int)str[i]);
    }

    return str;
}
