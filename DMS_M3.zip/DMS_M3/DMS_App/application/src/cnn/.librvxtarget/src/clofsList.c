#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/clofsList.h"
#include "../ince/rvx_target/list.h"

static size_t _sizeFunction(const void *str)
{
    (void)str;
    return sizeof(ClofsListEntry);
}

ClofsList *clofsListCreate()
{
    ClofsList *list = (ClofsList *)malloc(sizeof(ClofsList));
    listCreate(list, _sizeFunction);
    return list;
}

void clofsListFree(ClofsList *list)
{
    listDestroy(list);
    free(list);
}

ClofsListEntry *clofsListAppend(ClofsList *list, const ClofsListEntry *entry)
{
    ListEntry *p_e = listAppend(list, (const void *)entry);
    return (ClofsListEntry *)p_e->data;
}

size_t clofsListSize(ClofsList *list)
{
    return listSize(list);
}

ClofsListIterator *clofsListIteratorGet(ClofsList *list)
{
    return listIteratorGet(list);
}

ClofsListIterator *clofsListIteratorNext(ClofsList *list, ClofsListIterator *iterator)
{
    return listIteratorNext(list, iterator);
}

ClofsListEntry *clofsListIteratorGetValue(ClofsList *list, ClofsListIterator *iterator)
{
    return (ClofsListEntry *)listIteratorGetValue(list, iterator);
}
//#endif
