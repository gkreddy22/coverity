#include <ctype.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../ince/rvx_target/filesystem.h"
#include "../ince/rvx_target/rvxt_string_helper.h"
#include "../ince/rvx_target/ui.h"

/*Global defines */
#define ELEMENTS(array) (sizeof(array) / sizeof(array[0]))

#if !defined(RCAR_XIL_SIL)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wstringop-truncation"
#endif

/* global variables */
static char *directories = NULL; /* Directories for searching csv files. Separated by semicolon. */
static const char *separators = "/\\";

/* private functions */
static char *mystrsep(char **stringp, const char *delim);

// #if !defined(RVXTARGET_HAVE_STRDUP)
// static char* strdup(const char* str)
// {
//     int   n   = strlen(str) + 1;
//     char* dup = (char*)malloc(n);
//     if (dup)
//     {
//         strcpy(dup, str);
//     }
//     return dup;
// }
// #else
// extern char* strdup(const char* str);
// #endif

inline char rvxtfs_getSeperator(void)
{
    char result = '\0';
#if defined(_WIN32)
    result = '\\';
#elif defined(__linux__) || defined(__QNX__)
    result = '/';
#else
//#    error Unsupported Platform
#endif
    return result;
}

bool rvxtfs_isAbsolutePath(const char *const path)
{
    const bool is_absoluteWin = (isalpha((int)path[0]) != 0) && (path[1] == ':') && (path[2] == '\\');
    const bool is_absoluteLin = path[0] == '/';

#if defined(_WIN32)
    if (is_absoluteLin)
    {
        cwarningv("'%s' is an absolute *nix path. May be OK in emulation.\n", path);
    }
#elif defined(__linux__) || defined(__QNX__)
    if (is_absoluteWin)
    {
        cwarningv("'%s' is an absolute Windows path. May be OK in emulation.\n", path);
    }
#endif

    return is_absoluteWin || is_absoluteLin;
}

bool rvxtfs_isRelativePath(const char *const path)
{
    return !rvxtfs_isAbsolutePath(path);
}

char *rvxtfs_convert(char *path)
{
    const char sep = rvxtfs_getSeperator();
    char *ptr = strpbrk(path, separators);
    while (ptr != NULL)
    {
        *ptr = sep;
        ptr = strpbrk(ptr + 1, separators);
    }
    return path;
}

char *rvxtfs_concatPaths(char *destination, size_t num, const char *const source)
{
    if (rvxtfs_isAbsolutePath(source))
    {
        /* cannot concat path with abs path */
        return NULL;
    }

    const size_t dst_len = strlen(destination);
    const size_t src_len = strlen(source);
    size_t add_sep = 0;
    const char sep = rvxtfs_getSeperator();

    if (destination[dst_len - 1] != sep)
    {
        /* additional seperator needed in between */
        add_sep = 1;
    }

    if ((dst_len + add_sep + src_len + 1) > num)
    {
        /* length of string already exceeds maximum size */
        return NULL;
    }

    if (0 < add_sep)
    {
        destination[dst_len + 0] = sep;
        destination[dst_len + 1] = '\0';
    }

    return strncat(destination, source, num - (dst_len + add_sep));
}

FILE *rvxtfs_tryOpenFirst(const char *filename, const char *mode)
{
    FILE *result = NULL;
    char *token, *pos;

    if (rvxtfs_isAbsolutePath(filename))
    {
        char *const p_file = rvxt_strdup(filename);
        if (NULL != p_file)
        {
            result = fopen(rvxtfs_convert(p_file), mode);
            free(p_file);
        }
        return result;
    }

    if (NULL != directories)
    {
        char *dirs = rvxt_strdup(directories);

        if (dirs == NULL)
        {
            return NULL;
        }

        pos = dirs;

        while ((token = mystrsep(&pos, ";")) != NULL)
        {
            /* assemble full path */
            char filepath[1024];
#ifdef __linux__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wstringop-truncation"
#endif
            strncpy(filepath, token, ELEMENTS(filepath));
#ifdef __linux__
#pragma GCC diagnostic pop
#endif
            rvxtfs_concatPaths(filepath, ELEMENTS(filepath), filename);

            /* try to open the file */
            result = fopen(rvxtfs_convert(filepath), mode);

            if (NULL != result)
            {
                break;
            }
        }
        free(dirs);
    }

    if (NULL == result)
    {
        /* just try to open file */
        char *_filename = rvxt_strdup(filename);
        result = fopen(rvxtfs_convert(_filename), mode);
        free(_filename);
    }

    return result;
}

FILE *rvxtfs_openFirst(const char *filename, const char *mode)
{
    FILE *result = rvxtfs_tryOpenFirst(filename, mode);

    if (NULL == result)
    {
        cerrorv("Could not open '%s' in any of '%s'.\n", filename, directories);
    }

    return result;
}

bool rvxtfs_testOpenFirst(const char *filename, const char *mode)
{
    bool result = false;
    FILE *p_file = rvxtfs_tryOpenFirst(filename, mode);

    if (NULL != p_file)
    {
        fclose(p_file);
        result = true;
    }

    return result;
}

bool rvxtfs_setIncludeDirectories(const char *dirs)
{
    if (NULL == dirs)
    {
        return false;
    }

    const size_t len = strlen(dirs);

    if (NULL != directories)
    {
        free(directories);
    }

    directories = (char *)malloc(len + 1);
    if (NULL == directories)
    {
        cerror("Failed to allocate memory!\n");
        return false;
    }
    strcpy(directories, dirs);
    return true;
}

static char *mystrsep(char **stringp, const char *delim)
{
    char *start = *stringp;
    char *p;

    p = (start != NULL) ? strpbrk(start, delim) : NULL;

    if (p == NULL)
    {
        *stringp = NULL;
    }
    else
    {
        *p = '\0';
        *stringp = p + 1;
    }

    return start;
}

#if !defined(RCAR_XIL_SIL)
#pragma GCC diagnostic pop
#endif