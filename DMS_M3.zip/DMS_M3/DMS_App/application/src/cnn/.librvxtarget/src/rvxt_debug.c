#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "../ince/rvx_target/rvxt_debug.h"
#include "../ince/rvx_target/ui.h"

#ifndef MIN
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#endif

#define CNN_BUSPRIO_I0_3 (0x09A8U)
#define CNN_BUSPRIO_O0_3 (0x09B0U)
#define CNN_BUSPRIO_O4_7 (0x09B4U)
#define CNN_BUSPRIO_3DC0_3 (0x09C0U)
#define CNN_BUSPRIO_3DC4_7 (0x09C4U)
#define CNN_BUSPRIO_CL (0x09D0U)

#define CNN_DMAIC0 (0x1000)
#define CNN_DMAIL0 (0x1004)
#define CNN_DMAISA0 (0x1008)
#define CNN_DMAIST0 (0x100C)

#define CNN_DMA3DCC0 (0x1100)
#define CNN_DMA3DCSA0 (0x1108)
#define CNN_DMA3DCL0 (0x1104)
#define CNN_DMA3DCST0 (0x110C)

#define CNN_DMAOSA0 (0x1300)
#define CNN_DMAOL0 (0x1360)
#define CNN_DMAOST0 (0x1340)
#define CNN_DMAOFM (0x1388)

#define CNN_DMAICTRL (0x1040)
#define CNN_DMA3DCCTRL (0x1200)
#define CNN_DMAOCTRL (0x138C)

static uint32_t rcvdrv_reg_read(
    const RCvIMPDRVCTL *const p_rcvdrvctl,
    const RCvIMPDRVCOREINFO *const p_core,
    uintptr_t const offset)
{
    uint32_t index = rcvdrv_CoreToIndex(p_rcvdrvctl, p_core);
    return drvCommon_ReadReg32(p_rcvdrvctl->RegBase[index] + offset);
}

static void dump_cnn_busprio(RCvIMPDRVCTL *p_rcvdrvctl, const RCvIMPDRVCOREINFO *const p_core)
{
    cinfov("CNN%u: "
           "BUSPRIO_I0_3=0x%08x, "
           "BUSPRIO_O0_3=0x%08x, "
           "BUSPRIO_O4_7=0x%08x, "
           "BUSPRIO_3DC0_3=0x%08x, "
           "BUSPRIO_3DC4_7=0x%08x, "
           "BUSPRIO_CL=0x%08x\n",
           p_core->CoreNum,
           (unsigned int)rcvdrv_reg_read(p_rcvdrvctl, p_core, CNN_BUSPRIO_I0_3),
           (unsigned int)rcvdrv_reg_read(p_rcvdrvctl, p_core, CNN_BUSPRIO_O0_3),
           (unsigned int)rcvdrv_reg_read(p_rcvdrvctl, p_core, CNN_BUSPRIO_O4_7),
           (unsigned int)rcvdrv_reg_read(p_rcvdrvctl, p_core, CNN_BUSPRIO_3DC0_3),
           (unsigned int)rcvdrv_reg_read(p_rcvdrvctl, p_core, CNN_BUSPRIO_3DC4_7),
           (unsigned int)rcvdrv_reg_read(p_rcvdrvctl, p_core, CNN_BUSPRIO_CL));
}

static char get_bank(const uint32_t address)
{
    if ((address < 0xED000000U) || (address >= 0xED400000U))
    {
        return '_';
    }

    unsigned int bank = (char)((address - 0xED000000) / 0x20000U);

    return (bank < 10) ? '0' + bank : 'A' + (bank - 10);
}

static unsigned int get_lane(const uint32_t address)
{
    return (address % 128) / 32;
}

void print_DMAI(RCvIMPDRVCTL *p_rcvdrvctl, const RCvIMPDRVCOREINFO *const p_core, unsigned int channel)
{
    const uint32_t dmaictrl = rcvdrv_reg_read(p_rcvdrvctl, p_core, CNN_DMAICTRL);
    const uint16_t dmaisa_reg = CNN_DMAISA0 + channel * 0x10U;
    const uint32_t dmaisa_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dmaisa_reg);
    const bool dmai_ena = ((dmaictrl >> (8 + channel)) & 1) == 1;

    /* DMAILx */
    const uint16_t dmail_reg = CNN_DMAIL0 + channel * 0x10U;
    const uint32_t dmail_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dmail_reg);

    /* DMAISTx */
    const uint16_t dmaist_reg = CNN_DMAIST0 + channel * 0x10U;
    const uint32_t dmaist_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dmaist_reg);

    /* DMA_Cx */
    const uint16_t dma_c_reg = CNN_DMAIC0 + channel * 0x10U;
    const uint32_t dma_c_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dma_c_reg);
    const unsigned int bytesPerPixel = ((dma_c_val >> 25) & 0x1) + 1;

    if (channel < R_ATMLIB_CNN_DMAI_MAX_CH)
    {
        DEBUG_PRINT("[%c] DMAISA%u (0x%04x)=0x%08x(%c.%u) {w=%3up,h=%4up,s=%4up,p=%1uB}",
               dmai_ena ? 'E' : ' ',
               (unsigned int)channel,
               (unsigned int)dmaisa_reg,
               (unsigned int)dmaisa_val,
               get_bank(dmaisa_val),
               get_lane(dmaisa_val),
               dmail_val & 0xFFFU, (dmail_val >> 16) & 0xFFFFU, dmaist_val & 0xFFFFU, bytesPerPixel);
    }
}

void print_DMAC(RCvIMPDRVCTL *p_rcvdrvctl, const RCvIMPDRVCOREINFO *const p_core, unsigned int channel)
{
    const uint32_t dmacctrl = rcvdrv_reg_read(p_rcvdrvctl, p_core, CNN_DMA3DCCTRL);
    const uint16_t dmacsa_reg = CNN_DMA3DCSA0 + channel * 0x10U;
    const uint32_t dmacsa_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dmacsa_reg);
    const bool dmac_ena = ((dmacctrl >> (8 + channel)) & 1) == 1;

    /* DMAILx */
    const uint16_t dma_l_reg = CNN_DMA3DCL0 + channel * 0x10U;
    const uint32_t dma_l_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dma_l_reg);

    /* DMAISTx */
    const uint16_t dma_st_reg = CNN_DMA3DCST0 + channel * 0x10U;
    const uint32_t dma_st_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dma_st_reg);

    /* DMA_Cx */
    const uint16_t dma_c_reg = CNN_DMA3DCC0 + channel * 0x10U;
    const uint32_t dma_c_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dma_c_reg);
    const unsigned int bytesPerPixel = ((dma_c_val >> 25) & 0x1) + 1;

    DEBUG_PRINT("[%c] DMA3DCSA%u (0x%04x)=0x%08x(%c.%u) {w=%3up,h=%4up,s=%4up,p=%1uB}",
           dmac_ena ? 'E' : ' ',
           (unsigned int)channel,
           (unsigned int)dmacsa_reg,
           (unsigned int)dmacsa_val,
           get_bank(dmacsa_val),
           get_lane(dmacsa_val),
           dma_l_val & 0xFFFU, (dma_l_val >> 16) & 0xFFFFU, dma_st_val & 0xFFFFU, bytesPerPixel);
}

void print_DMAO(RCvIMPDRVCTL *p_rcvdrvctl, const RCvIMPDRVCOREINFO *const p_core, unsigned int channel)
{
    const uint32_t dmaoctrl = rcvdrv_reg_read(p_rcvdrvctl, p_core, CNN_DMAOCTRL);
    const uint16_t dmaosa_reg = CNN_DMAOSA0 + channel * 0x04U;
    const uint32_t dmaosa_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dmaosa_reg);
    const bool dmao_ena = ((dmaoctrl >> (8 + channel)) & 1) == 1;

    /* DMA_Lx */
    const uint16_t dma_l_reg = CNN_DMAOL0 + channel * 0x04U;
    const uint32_t dma_l_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dma_l_reg);

    /* DMA_STx */
    const uint16_t dma_st_reg = CNN_DMAOST0 + channel * 0x04U;
    const uint32_t dma_st_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dma_st_reg);

    /* DMA_Cx */
    const uint16_t dma_c_reg = CNN_DMAOFM;
    const uint32_t dma_c_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, dma_c_reg);
    const unsigned int bytesPerPixel = ((dma_c_val >> (4 * channel + 1)) & 0x1) + 1;

    DEBUG_PRINT("[%c] DMAOSA%u(0x%04x)=0x%08x(%c.%u) {w=%3up,h=%4up,s=%4up,p=%1uB}",
           dmao_ena ? 'E' : ' ',
           (unsigned int)channel,
           (unsigned int)dmaosa_reg,
           (unsigned int)dmaosa_val,
           get_bank(dmaosa_val),
           get_lane(dmaosa_val),
           dma_l_val & 0xFFFU, (dma_l_val >> 16) & 0xFFFFU, dma_st_val & 0xFFFFU, bytesPerPixel);
}

static void dump_cnn_DMAxSA(RCvIMPDRVCTL *p_rcvdrvctl, const RCvIMPDRVCOREINFO *const p_core)
{
    for (unsigned int r = 0; r < R_ATMLIB_CNN_DMAO_MAX_CH; r++)
    {
        cinfov("CNN%u: ", p_core->CoreNum);

        if (r < R_ATMLIB_CNN_DMAI_MAX_CH)
        {
            print_DMAI(p_rcvdrvctl, p_core, r);
            DEBUG_PRINT(", ");
        }
        else
        {
            DEBUG_PRINT("                                                                    ");
        }
        print_DMAC(p_rcvdrvctl, p_core, r);
        DEBUG_PRINT(", ");
        print_DMAO(p_rcvdrvctl, p_core, r);
        DEBUG_PRINT("\n");
    }
}

static void dump_dma_SxxAR(RCvIMPDRVCTL *p_rcvdrvctl, const RCvIMPDRVCOREINFO *const p_core)
{
    const uint32_t s0cr = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x50);
    const uint32_t s1cr = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x70);

    const bool s0ren = (s0cr & 0x80000000U) != 0;
    const bool s1ren = (s1cr & 0x80000000U) != 0;

    const uint16_t s0sar_reg = 0x40;
    const uint16_t s1sar_reg = 0x60;
    const uint16_t d0sar_reg = 0x80;

    const uint32_t s0sar_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, s0sar_reg);
    const uint32_t s1sar_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, s1sar_reg);
    const uint32_t d0sar_val = rcvdrv_reg_read(p_rcvdrvctl, p_core, d0sar_reg);

    cinfov("DMA%u: [%c] S0SAR(0x%04x)=0x%08x(%c), [%c] S1SAR(0x%04x)=0x%08x(%c), [%c] D0SAR(0x%04x)=0x%08x(%c)\n",
           p_core->CoreNum,
           s0ren ? 'E' : ' ',
           (unsigned int)s0sar_reg,
           (unsigned int)s0sar_val,
           get_bank(s0sar_val),
           s1ren ? 'E' : ' ',
           (unsigned int)s1sar_reg,
           (unsigned int)s1sar_val,
           get_bank(s1sar_val),
           true ? 'E' : ' ',
           (unsigned int)d0sar_reg,
           (unsigned int)d0sar_val,
           get_bank(d0sar_val));
}

static void dump_cl(const RCvIMPDRVCOREINFO *const p_core,
                    const uint32_t start,
                    const uint32_t current,
                    const unsigned int backtrace,
                    const unsigned int readahead)
{
    char *core_name = "XXX";
    if (p_core->CoreType == RCVDRV_CORE_TYPE_CNN)
    {
        core_name = "CNN";
    }
    else if (p_core->CoreType == RCVDRV_CORE_TYPE_DMAC)
    {
        core_name = "DMA";
    }
    {
        uint32_t *const s = gf_GetVirtAddr(MAX((uintptr_t)start, (uintptr_t)current - backtrace * sizeof(uint32_t)));
        uint32_t *const e = gf_GetVirtAddr((uintptr_t)current);

        for (uint32_t *p = s; p <= e; p++)
        {
            cinfov("%s%u: 0x%08x (0x%08x): 0x%08x\n", core_name, p_core->CoreNum, (unsigned int)gf_GetPhysAddr(p), (unsigned int)(gf_GetPhysAddr(p) - start), *p);
        }
    }
    cinfov("%s%u: -- ^^STOP^^ --\n", core_name, p_core->CoreNum);
    {
        uint32_t *const s = gf_GetVirtAddr((uintptr_t)current + sizeof(uint32_t));
        uint32_t *const e = gf_GetVirtAddr((uintptr_t)current + readahead * sizeof(uint32_t));

        if ((s != NULL) && (e != NULL))
        {
            for (uint32_t *p = s; p <= e; p++)
            {
                cinfov("%s%u: 0x%08x (0x%08x): 0x%08x\n", core_name, p_core->CoreNum, (unsigned int)gf_GetPhysAddr(p), (unsigned int)(gf_GetPhysAddr(p) - start), *p);
            }
        }
        else
        {
            cwarning("Address resolution failed!\n");
        }
    }
}

void rvxt_debug_V3H1(RCvIMPDRVCTL *p_rcvdrvctl, const RCvIMPDRVCOREINFO *const p_core)
{
    size_t backtrace = 16;
    size_t readahead = 4;

    uint32_t index = rcvdrv_CoreToIndex(p_rcvdrvctl, p_core);
    cinfov("State of (%u:%u): %u.\n", (unsigned int)p_core->CoreType, (unsigned int)p_core->CoreNum, (unsigned int)p_rcvdrvctl->State[index]);

    if (p_core->CoreType == RCVDRV_CORE_TYPE_CNN)
    {
        const uint32_t vcr0 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0000U);
        const uint32_t vcr1 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0004U);
        const uint32_t clpc = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0028U);
        const uint32_t sacl = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0080U);

        const uint32_t cleir = *((uint32_t *)gf_GetVirtAddr((uintptr_t)clpc)); /* current instruction */

        const bool is_ImpcBug = (cleir & 0xFF000000U) == 0x8b000000U;

        cinfov("CNN%u: VCR0=0x%08x VCR1=0x%08x SACL=0x%08x CLPC=0x%08x\n", p_core->CoreNum, (unsigned int)vcr0, (unsigned int)vcr1, (unsigned int)sacl, (unsigned int)clpc);

        const uint32_t syncc0_3 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0900U);
        const uint32_t syncc4_7 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0904U);
        const uint32_t syncc8_11 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0908U);
        const uint32_t syncc12_15 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x090CU);

        cinfov("CNN%u: syncc0_3=0x%08x syncc4_7=0x%08x syncc8_11=0x%08x syncc12_15=0x%08x\n", p_core->CoreNum, (unsigned int)syncc0_3, (unsigned int)syncc4_7, (unsigned int)syncc8_11, (unsigned int)syncc12_15);

        dump_cnn_busprio(p_rcvdrvctl, p_core);
        dump_cnn_DMAxSA(p_rcvdrvctl, p_core);

        if (is_ImpcBug)
        {
            /* reduce output */
            //backtrace = 16;
            //readahead = 4;
        }

        dump_cl(p_core, sacl, clpc, backtrace, readahead);
    }
    else if (p_core->CoreType == RCVDRV_CORE_TYPE_OCV)
    {
        const uint32_t vcr = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0000U);
        const uint32_t dlsar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0180U);
        const uint32_t dlfar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0194U);
        const uint32_t dleir = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0198U);

        const uint32_t vpcsar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0320U);
        const uint32_t vibar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0340U);
        const uint32_t vspc = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x11C0U);

        cinfov("CVE%u: VCR=0x%08x DLSAR=0x%08x DLFAR=0x%08x DLEIR=0x%08x\n", p_core->CoreNum, (unsigned int)vcr, (unsigned int)dlsar, (unsigned int)dlfar, (unsigned int)dleir);

        const uint32_t SYNCCNFR03 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x04C0U);
        const uint32_t SYNCCNFR47 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x04C4U);
        const uint32_t SYNCCNFR811 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x04C8U);
        const uint32_t SYNCCNFR1215 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x04CCU);

        cinfov("CVE%u: SYNCCNFR03=0x%08x SYNCCNFR47=0x%08x SYNCCNFR811=0x%08x SYNCCNFR1215=0x%08x\n", p_core->CoreNum, (unsigned int)SYNCCNFR03, (unsigned int)SYNCCNFR47, (unsigned int)SYNCCNFR811, (unsigned int)SYNCCNFR1215);

        cinfov("CVE%u: VPCSAR=0x%08x VIBAR=0x%08x (0x%08x) VSPC=0x%08x (0x%08x)\n",
               p_core->CoreNum,
               (unsigned int)vpcsar,
               (unsigned int)vibar,
               (unsigned int)*((uint32_t *)gf_GetVirtAddr(vibar)),
               (unsigned int)vspc,
               (unsigned int)*((uint32_t *)gf_GetVirtAddr(vibar + vspc)));

        dump_cl(p_core, dlsar, dlfar, backtrace, readahead);
    }
    else if (p_core->CoreType == RCVDRV_CORE_TYPE_DMAC)
    {
        const uint32_t vcr = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0000U);
        const uint32_t prir = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0024U);
        const uint32_t clsar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0028U);
        const uint32_t clfar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00C8U);
        const uint32_t cleir = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00CCU);

        cinfov("DMA%u: VCR=0x%08x CLSAR=0x%08x CLFAR=0x%08x CLEIR=0x%08x PRIR=0x%08x\n", p_core->CoreNum, (unsigned int)vcr, (unsigned int)clsar, (unsigned int)clfar, (unsigned int)cleir, (unsigned int)prir);

        const uint32_t SYNCCR0 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00E8);
        const uint32_t SYNCCR1 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00EC);
        const uint32_t SYNCCR2 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00F0);
        const uint32_t SYNCCR3 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00F4);

        cinfov("DMA%u: SYNCCR0=0x%08x SYNCCR1=0x%08x SYNCCR2=0x%08x SYNCCR3=0x%08x\n", p_core->CoreNum, (unsigned int)SYNCCR0, (unsigned int)SYNCCR1, (unsigned int)SYNCCR2, (unsigned int)SYNCCR3);

        dump_dma_SxxAR(p_rcvdrvctl, p_core);
        dump_cl(p_core, clsar, clfar, backtrace, readahead);
    }
}

void rvxt_debug_V3U1(RCvIMPDRVCTL *p_rcvdrvctl, const RCvIMPDRVCOREINFO *const p_core)
{
    size_t backtrace = 16;
    size_t readahead = 4;

    uint32_t index = rcvdrv_CoreToIndex(p_rcvdrvctl, p_core);
    cinfov("State of (%u:%u): %u.\n", (unsigned int)p_core->CoreType, (unsigned int)p_core->CoreNum, (unsigned int)p_rcvdrvctl->State[index]);

    if (p_core->CoreType == RCVDRV_CORE_TYPE_CNN)
    {
        const uint32_t vcr0 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0000U);
        const uint32_t vcr1 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0004U);
        const uint32_t clpc = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0100U);
        const uint32_t sacl = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0104U);
        const uint32_t cleir = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x010CU);

        cinfov("CNN%u: VCR0=0x%08x VCR1=0x%08x SACL=0x%08x CLPC=0x%08x CLEIR=0x%08x\n",
               p_core->CoreNum, (unsigned int)vcr0, (unsigned int)vcr1, (unsigned int)sacl, (unsigned int)clpc, (unsigned int)cleir);

        const uint32_t syncc0_3 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0900U);
        const uint32_t syncc4_7 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0904U);
        const uint32_t syncc8_11 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0908U);
        const uint32_t syncc12_15 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x090CU);

        cinfov("CNN%u: syncc0_3=0x%08x syncc4_7=0x%08x syncc8_11=0x%08x syncc12_15=0x%08x\n", p_core->CoreNum, (unsigned int)syncc0_3, (unsigned int)syncc4_7, (unsigned int)syncc8_11, (unsigned int)syncc12_15);

        //dump_cnn_busprio(p_rcvdrvctl, p_core);
        //dump_cnn_DMAxSA(p_rcvdrvctl, p_core);

        const uint32_t dmaisa = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x4000U);
        const uint32_t dmaico = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x4004U);
        const uint32_t dmaisa00 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x4100U);
        const uint32_t dmaie = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x401CU);
        const uint32_t dmais = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x4020U);

        const uint32_t dma3dcsa = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x5000U);
        const uint32_t dma3dcco = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x5004U);
        const uint32_t dma3dcsa00 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x5100U);
        const uint32_t dma3dce = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x501CU);
        const uint32_t dma3dcs = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x5020U);

        const uint32_t dmaosa = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x6000U);
        const uint32_t dmaoco = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x6004U);
        const uint32_t dmaosa00 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x6100U);
        const uint32_t dmaoe = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x6018U);
        const uint32_t dmaos = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x601CU);
        const uint32_t dmaol = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x6008U);

        const uint32_t aricsr = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x1000U);
        const uint32_t arie = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x1004U);
        const uint32_t ari_len = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x1010U);

        const uint32_t sr = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0010U);
        cinfov("CNN%u: DMAISA=0x%08x, DMAICO=0x%08x,  DMAISA00=0x%08x,  DMAIE=0x%08x, DMAIS=0x%08x\n",
               p_core->CoreNum,
               (unsigned int)dmaisa, (unsigned int)dmaico, (unsigned int)dmaisa00, (unsigned int)dmaie, (unsigned int)dmais);

        cinfov("CNN%u: DMA3DSA=0x%08x, DMA3DCO=0x%08x, DMA3DSA00=0x%08x, DMA3DE=0x%08x, DMA3DS=0x%08x\n",
               p_core->CoreNum,
               (unsigned int)dma3dcsa, (unsigned int)dma3dcco, (unsigned int)dma3dcsa00, (unsigned int)dma3dce, (unsigned int)dma3dcs);

        cinfov("CNN%u: DMAOSA=0x%08x,  DMA3DCO=0x%08x, DMAOSA00=0x%08x,  DMAOE=0x%08x,  DMAOS=0x%08x,  DMAOL=0x%08x\n",
               p_core->CoreNum,
               (unsigned int)dmaosa, (unsigned int)dmaoco, (unsigned int)dmaosa00, (unsigned int)dmaoe, (unsigned int)dmaos, (unsigned int)dmaol);

        cinfov("CNN%u: ARICSR=0x%08x,  ARIE=0x%08x, ARI_LEN=0x%08x\n",
               p_core->CoreNum,
               (unsigned int)aricsr, (unsigned int)arie, (unsigned int)ari_len);

        cinfov("CNN%u: SR=0x%08x: ", p_core->CoreNum, (unsigned int)sr);
        if (sr & 0x8000)
            DEBUG_PRINT("R");
        if (sr & 0x4000)
            DEBUG_PRINT("C");
        if (sr & 0x2000)
            DEBUG_PRINT("I");
        if (sr & 0x1000)
            DEBUG_PRINT("3");
        if (sr & 0x0800)
            DEBUG_PRINT("O");
        if (sr & 0x0400)
            DEBUG_PRINT("A");
        if (sr & 0x0200)
            DEBUG_PRINT("S");
        DEBUG_PRINT("\n");

        dump_cl(p_core, sacl, clpc, backtrace, readahead);
    }
    else if (p_core->CoreType == RCVDRV_CORE_TYPE_OCV)
    {
        const uint32_t vcr = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0000U);
        const uint32_t dlsar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0180U);
        const uint32_t dlfar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0194U);
        const uint32_t dleir = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0198U);

        const uint32_t vpcsar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0320U);
        const uint32_t vibar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0340U);
        const uint32_t vspc = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x11C0U);

        cinfov("CVE%u: VCR=0x%08x DLSAR=0x%08x DLFAR=0x%08x DLEIR=0x%08x\n", p_core->CoreNum, (unsigned int)vcr, (unsigned int)dlsar, (unsigned int)dlfar, (unsigned int)dleir);

        const uint32_t SYNCCNFR03 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x04C0U);
        const uint32_t SYNCCNFR47 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x04C4U);
        const uint32_t SYNCCNFR811 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x04C8U);
        const uint32_t SYNCCNFR1215 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x04CCU);

        cinfov("CVE%u: SYNCCNFR03=0x%08x SYNCCNFR47=0x%08x SYNCCNFR811=0x%08x SYNCCNFR1215=0x%08x\n", p_core->CoreNum, (unsigned int)SYNCCNFR03, (unsigned int)SYNCCNFR47, (unsigned int)SYNCCNFR811, (unsigned int)SYNCCNFR1215);

        cinfov("CVE%u: VPCSAR=0x%08x VIBAR=0x%08x (0x%08x) VSPC=0x%08x (0x%08x)\n",
               p_core->CoreNum,
               (unsigned int)vpcsar,
               (unsigned int)vibar,
               (unsigned int)*((uint32_t *)gf_GetVirtAddr(vibar)),
               (unsigned int)vspc,
               (unsigned int)*((uint32_t *)gf_GetVirtAddr(vibar + vspc)));

        dump_cl(p_core, dlsar, dlfar, backtrace, readahead);
    }
    else if (p_core->CoreType == RCVDRV_CORE_TYPE_DMAC)
    {
        const uint32_t vcr = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0000U);
        const uint32_t prir = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0024U);
        const uint32_t clsar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x0028U);
        const uint32_t clfar = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00C8U);
        const uint32_t cleir = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00CCU);

        cinfov("DMA%u: VCR=0x%08x CLSAR=0x%08x CLFAR=0x%08x CLEIR=0x%08x PRIR=0x%08x\n", p_core->CoreNum, (unsigned int)vcr, (unsigned int)clsar, (unsigned int)clfar, (unsigned int)cleir, (unsigned int)prir);

        const uint32_t SYNCCR0 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00E8);
        const uint32_t SYNCCR1 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00EC);
        const uint32_t SYNCCR2 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00F0);
        const uint32_t SYNCCR3 = rcvdrv_reg_read(p_rcvdrvctl, p_core, 0x00F4);

        cinfov("DMA%u: SYNCCR0=0x%08x SYNCCR1=0x%08x SYNCCR2=0x%08x SYNCCR3=0x%08x\n", p_core->CoreNum, (unsigned int)SYNCCR0, (unsigned int)SYNCCR1, (unsigned int)SYNCCR2, (unsigned int)SYNCCR3);

        dump_dma_SxxAR(p_rcvdrvctl, p_core);
        dump_cl(p_core, clsar, clfar, backtrace, readahead);
    }
}

void rvxt_debug(RCvIMPDRVCTL *p_rcvdrvctl, const RCvIMPDRVCOREINFO *const p_core)
{
#if defined(RCAR_SOC_V3U)
    rvxt_debug_V3U1(p_rcvdrvctl, p_core);
#else
    rvxt_debug_V3H1(p_rcvdrvctl, p_core);
#endif
}