#ifndef PGM_HELPER_H
#define PGM_HELPER_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

bool getPNMImageInfo(const void* ppmBuffer, void** dataBuffer, size_t* width, size_t* height, uint8_t* bpp);

//bool getPGMImageInfo(const void* ppmBuffer, void** dataBuffer, size_t* width, size_t* height, uint8_t* bpp);

void seperatePPMChannel(const void* imageBuffer, size_t width, size_t height, uint8_t* rBuffer, uint8_t* gBuffer, uint8_t* bBuffer);
void seperatePPMChannelU16(const void* imageBuffer, size_t width, size_t height, uint16_t* rBuffer, uint16_t* gBuffer, uint16_t* bBuffer);

bool testPPMImageFormat(const void* data);
bool testPGMImageFormat(const void* data);

bool writePGMu8(FILE* fp, const uint8_t* data, const size_t width, const size_t height, const uint8_t mask);
bool writePGMs16(FILE* fp, const int16_t* data, const size_t width, const size_t height, const uint16_t mask);
bool writePGMu16(FILE* fp, const uint16_t* data, const size_t width, const size_t height, const uint16_t mask);

#ifdef __cplusplus
}
#endif

#endif   //PGM_HELPER_H
