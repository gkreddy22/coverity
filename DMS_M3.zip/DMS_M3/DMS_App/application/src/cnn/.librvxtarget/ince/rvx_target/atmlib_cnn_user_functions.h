
/******************************************************************************
 [ FuncName ] CNN_UserShiftFunc
 [ params]
   cldata           Pointer to the CL data
   ch_fp_handles	List of fp handles corresponding to the channel
   weight_frac      The current weight fraction size
   bias_frac        The current bias fraction size
 [ Return ]
   R_ATMLIB_E_OK        on success
   R_ATMLIB_E_NG_ARG1   argument cldata NULL address
   R_ATMLIB_E_NG_CLTYPE cldata type is not UNSET and CNN
   R_ATMLIB_E_NG_ARG3   argument layer is out of range
   R_ATMLIB_E_NG_ARG4   argument ch_layers NULL address
   R_ATMLIB_E_NG_CLSIZE lack of CL area
 [ Function ] Set the shift value.
 [ Note ] none
******************************************************************************/

#ifndef __ATMLIB_CNN_USER_FUNCTIONS_H__
#define __ATMLIB_CNN_USER_FUNCTIONS_H__

#include "rcar-xos/atmlib/r_atmlib_types.h"

#define RVXT_ATMLIB_CNN_USER_SHIFT_FUNC CNN_UserShiftFunc
#define RVXT_ATMLIB_CNN_USER_FRAC_ADJ_FUNC CNN_UserFracAdjFunc

#ifdef __cplusplus
extern "C" {
#endif

#if defined(HAVE_ATMLIB_CNNIPv1)

R_ATMLIB_RETURN_VALUE CNN_UserShiftFunc(R_ATMLIB_CLData* const cldata, const uint32_t* const ch_fp_handles, const int8_t weight_frac, const int8_t bias_frac);
R_ATMLIB_RETURN_VALUE CNN_UserFracAdjFunc(R_ATMLIB_CLData* const cldata, uint8_t layer_count);

#elif defined(HAVE_ATMLIB_CNNIPv2)

R_ATMLIB_CNN_RETURN_VALUE CNN_UserShiftFunc(R_ATMLIB_CLData* cldata, const R_ATMLIB_CNNShiftConfig* shift_cfg);
// R_ATMLIB_RETURN_VALUE CNN_UserFracAdjFunc(R_ATMLIB_CLData* const cldata, uint8_t layer_count);
#endif

#ifdef __cplusplus
}
#endif
#endif