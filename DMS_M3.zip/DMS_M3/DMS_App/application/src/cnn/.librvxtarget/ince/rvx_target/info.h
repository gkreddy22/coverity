#ifndef __INFO_H__
#define __INFO_H__

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

//#include "rcar-xos/atmlib/r_atmlib_def.h" /* required by r_atmlib_types.h */
//#include "rcar-xos/atmlib/r_atmlib_types.h"

#define RVX_MAX_CORE_MAP_SIZE (16)
#define RVX_FP_FIXED_START (4096)
#define RVX_FP_FIXED_MAX_NEGATIVE (32)

//struct _rvxt_info_t;
//typedef struct _rvxt_info_t rvxt_info_t;

typedef enum
{
    U8 = 1,
    S8,
    U16,
    S16,
    U32,
    S32,
} rvxt_data_format_e;

typedef enum
{
    RVXT_CORE_NONE = 0,
    RVXT_CORE_IMP0 = 1 << 0,
    RVXT_CORE_IMP1 = 1 << 1,
    RVXT_CORE_IMP2 = 1 << 2,
    RVXT_CORE_IMP3 = 1 << 3,
    RVXT_CORE_IMP4 = 1 << 4,
    RVXT_CORE_IMP5 = 1 << 5,
    RVXT_CORE_IMP6 = 1 << 6,
    RVXT_CORE_IMP7 = 1 << 7,
    RVXT_CORE_CVE0 = 1 << 8,
    RVXT_CORE_CVE1 = 1 << 9,
    RVXT_CORE_CVE2 = 1 << 10,
    RVXT_CORE_CVE3 = 1 << 11,
    RVXT_CORE_CVE4 = 1 << 12,
    RVXT_CORE_CVE5 = 1 << 13,
    RVXT_CORE_CVE6 = 1 << 14,
    RVXT_CORE_CVE7 = 1 << 15,
    RVXT_CORE_DMA0 = 1 << 16,
    RVXT_CORE_DMA1 = 1 << 17,
    RVXT_CORE_DMA2 = 1 << 18,
    RVXT_CORE_DMA3 = 1 << 19,
    RVXT_CORE_PSC0 = 1 << 20,
    RVXT_CORE_PSC1 = 1 << 21,
    RVXT_CORE_PSC2 = 1 << 22,
    RVXT_CORE_PSC3 = 1 << 23,
    RVXT_CORE_CNN0 = 1 << 24,
    RVXT_CORE_CNN1 = 1 << 25,
    RVXT_CORE_CNN2 = 1 << 26,
    RVXT_CORE_CNN3 = 1 << 27,
    RVXT_CORE_DTA  = 1 << 28,
} rvxt_core_e;

typedef enum
{
    RVXT_CORE_GROUP_NONE = 0,
    RVXT_CORE_GROUP_IMP  = 1 << 0,
    RVXT_CORE_GROUP_CVE  = 1 << 1,
    RVXT_CORE_GROUP_DMA  = 1 << 2,
    RVXT_CORE_GROUP_PSC  = 1 << 3,
    RVXT_CORE_GROUP_CNN  = 1 << 4,
    RVXT_CORE_GROUP_DTA  = 1 << 5,
} rvxt_core_group_e;

typedef enum
{
    RVX_UNSIGNED = 0,   //!< unsigned fixed point
    RVX_SIGNED,         //!< signed fixed point
    RVX_FLOAT,          //!< floating point
} rvx_format_type_e;

//typedef  (*rvxt_cl_gen_f)(R_ATMLIB_CLData* cl, const rvxt_info_t* const p_info);

typedef unsigned int rvxt_core_map_t[RVX_MAX_CORE_MAP_SIZE];

typedef struct
{
    rvxt_core_e     core;
    rvxt_core_map_t core_map;
    //    rvxt_cl_gen_f   cl_gen;
} rvxt_core_info_t;

typedef struct
{
    size_t x, y;
} rvxt_coord_t;

struct rvxt_memres_info;
typedef struct rvxt_memres_info rvxt_memres_info_t;

/**
 * @brief Structure to store tile information
 */
typedef struct
{
    rvx_format_type_e format_type;   //! Sign
    int16_t           frac_pos;      //! Number of fractional bits
    uint8_t           bitpp;         //! Bits per pixel, typically 8 or 16.
} rvxt_data_format_t;

typedef struct
{
    uintptr_t          offset;      //! Offset to base of underlying memory resource in bytes.
    uint8_t            dim_count;   //! Number of dimensions.
    uint16_t*          size;        //! Size of dimension.
    char*              layout;      //! Layout definition. Typically "WHC", "CWH", or "WCH". Fastest changing axis in memory first.
    rvxt_data_format_t format;      //! Data format of tensor.
} rvxt_tensor_info_t;

/**
 * @brief Structure to store memory information
 */
typedef struct
{
    char*               name;     //! name of the memory
    rvxt_memres_info_t* base;     //! pointer to underlying memory resource
    uintptr_t           offset;   //! offset within memory resource
    size_t              size;     //! size in byte
    rvxt_tensor_info_t  tensor;   //! tensor format, first tensor in memory definition.
    uint8_t*            data;     //! data used for initialization or comparison
} rvxt_mem_info_t;

/**
 * @brief Structure to store memory initialization values
 */
typedef struct
{
    size_t    idx_mem;    //! index of the memory info structure
    void*     p_data;     //! pointer to the data array
    size_t    size;       //! size of the data array
    uintptr_t offset;     //! offset within data
    char*     filename;   //! filename
} rvxt_mem_init_t;

typedef struct
{
    uintptr_t phys;   //! physical address
    void*     virt;   //! virtual address
} rvxt_address_t;

struct rvxt_memres_info
{
    char*          name;         //! name of the memory ressource
    rvxt_address_t address;      //! the memory address
    size_t         size;         //! size in bytes
    size_t         peak_usage;   //! peak usage of ressource in bytes.
    bool           dynamic;      //! indicate if memory manager shall allocate address
};

/**
  * @brief Structure to store all RVX output information.
  */
typedef struct _rvxt_info_t
{
    size_t              memory_ressources_count;
    rvxt_memres_info_t* memory_ressources;
    size_t              memories_count;
    rvxt_mem_info_t*    memories;
    size_t              entry_memories_count;
    rvxt_mem_info_t**   entry_memories;
    size_t              exit_memories_count;
    rvxt_mem_info_t**   exit_memories;
    size_t              init_memories_count;
    rvxt_mem_init_t*    init_memories;
    size_t              core_count;
    rvxt_core_info_t*   cores;
} rvxt_info_t;

#endif
