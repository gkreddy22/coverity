/**
 * @brief RVX header file for target project, internal functions
 * @details
 */

#ifndef __RVX_TARGET_INT_H__
#define __RVX_TARGET_INT_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "rcar-xos/atmlib/r_atmlib_types.h"

#include "clofsList.h"
#include "clofsListCNN.h"
#include "info.h"
#include "ui.h"

#define RVXT_ATMLIB_CNN_BRELU_INVALID (0xffffu)

#define RVXT_ATMLIB_ASSERT_OK(func)                                                                             \
    {                                                                                                           \
        R_ATMLIB_RETURN_VALUE ret = func;                                                                       \
        if (R_ATMLIB_E_OK != ret)                                                                               \
        {                                                                                                       \
            cerrorv("%s \"RVX_RESULT_SUCCESS == %s\" failed with %i!", __RVX_CODE_POSITION__, #func, (int)ret); \
            return ret;                                                                                         \
        }                                                                                                       \
    }

#define RVXT_RETURN_VALUE_IF_FALSE(condition, value)                                  \
    {                                                                                 \
        if (false == condition)                                                       \
        {                                                                             \
            cerrorv("%s \"false != %s\" failed!", __RVX_CODE_POSITION__, #condition); \
            return ret;                                                               \
        }                                                                             \
    }

#ifdef __cplusplus
extern "C"
{
#endif

    bool rvxt_int_initCL(R_ATMLIB_CLData *cl);
    bool rvxt_int_closeCL(R_ATMLIB_CLData *const cl);

    bool rvxt_int_appendTag(R_ATMLIB_CLData *cl, const char *tag);
    bool rvxt_int_writeTags(const char *filename, const R_ATMLIB_CLData *const cl);

    size_t rvxt_fileSize(FILE *p_file);
    uintptr_t rvxt_int_calculateMemoryAddressPhys(const rvxt_info_t *const info, const size_t index);

    bool rvxt_int_getSyncBits(const rvxt_info_t *const p_info, rvxt_core_e caller, rvxt_core_e others, uint32_t *sync_bits);

    bool rvxt_int_appendCNNClofs(
        const R_ATMLIB_CLData *const cl,
        const rvxt_info_t *const p_info,
        R_ATMLIB_CNNCLofs_ImageAddr **p_clofs,
        ClofsListCNNEntryMems_t *p_memory_indexes);

    bool rvxt_int_appendDMAClof(
        const R_ATMLIB_CLData *const cl,
        const rvxt_info_t *const p_info,
        const size_t idx_memory,
        const uint32_t clof,
        const unsigned int id);

    bool rvxt_int_appendCVEClof(
        const R_ATMLIB_CLData *const cl,
        const rvxt_info_t *const p_info,
        const size_t idx_memory,
        const uint32_t clof);

    ClofsList *rvxt_int_getClofsList(
        const R_ATMLIB_CLData *const cl);

    ClofsList *rvxt_int_getClofsListCNN(
        const R_ATMLIB_CLData *const cl);

    bool rvxt_int_writeClofsList(
        const rvxt_info_t *const p_info,
        const R_ATMLIB_CLData *const p_cl,
        const char *const filenamePattern,
        const unsigned int id,
        const bool do_empty,
        const bool verbose);

    bool rvxt_int_writeClofsList2(
        const rvxt_info_t *const p_info,
        const R_ATMLIB_CLData *const p_cl,
        char *filenamePattern,
        const bool verbose);

#ifdef __cplusplus
}
#endif

#endif
