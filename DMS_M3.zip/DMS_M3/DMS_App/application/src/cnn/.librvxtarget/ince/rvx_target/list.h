#ifndef __LIST__
#define __LIST__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

struct _List;
struct _ListEntry;

typedef struct _ListEntry
{
    void*              data;
    struct _ListEntry* prev;
    struct _ListEntry* next;
} ListEntry;

typedef struct _List
{
    size_t (*sizeFunction)(const void*);
    size_t     elementCount;
    ListEntry* head;
    ListEntry* tail;
} List;

typedef ListEntry ListIterator;

/*!
 * @brief Create list.
 */
bool listCreate(List* list, size_t (*sizeFunction)(const void*));

/*!
 * @brief Destroy all elements of list.
 */
void listDestroy(List* list);

/*!
 * @brief Append an entry to list.
 */
ListEntry* listAppend(List* list, const void* data);

/*!
 * @brief Get size of list
 */
size_t listSize(const List* list);

/*!
 * @brief Get element at position index.
 */
ListEntry* listAt(List* list, size_t index);

/*!
 * @brief Insert new element at position pos. Move pos at the end of new.
 * @param list
 * @param pos
 * @param new
 * @return
 */
bool listInsertBefore(List* list, ListEntry* pos, ListEntry* entry);

/*!
 * @brief Insert new element after element pos.
 * @param list
 * @param pos
 * @param new
 * @return
 */
bool listInsertBefore(List* list, ListEntry* pos, ListEntry* entry);

/*!
 * @brief Get iterator to list.
 */
ListIterator* listIteratorGet(List* list);

/*!
 * @brief Get iterator to list, set to last element.
 */
ListIterator* listIteratorGetLast(List* list);

/*!
 * @brief Get iterator to list, set to element after last.
 */
ListIterator* listIteratorGetEnd(List* list);

/*!
 * @brief Increment iterator.
 */
ListIterator* listIteratorNext(List* list, ListIterator* iterator);

/*!
 * @brief
 */
bool listIteratorInsertBefore(List* list, ListIterator* iterator, const void* data);
bool listIteratorInsertAfter(List* list, ListIterator* iterator, const void* data);

void* listIteratorGetValue(List* list, ListIterator* iterator);

#ifdef __cplusplus
}
#endif

#endif
