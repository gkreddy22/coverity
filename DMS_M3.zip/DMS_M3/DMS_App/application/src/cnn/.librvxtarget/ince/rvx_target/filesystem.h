#ifndef __FILESYSTEM_H__
#define __FILESYSTEM_H__

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif


char  rvxtfs_getSeperator(void);
bool  rvxtfs_isRelativePath(const char* const path);
char* rvxtfs_convert(char* path);
char* rvxtfs_concatPaths(char* destination, size_t length, const char* const other);

/*!
 *@brief Open file relative to the directories provided by rvxtfs_setIncludeDirectories().
 */
FILE* rvxtfs_openFirst(const char* filename, const char* mode);

/*!
 *@brief Set list of include directories for searchinf for csv files (semeicolon separated).
 */
bool rvxtfs_setIncludeDirectories(const char* dirs);

/*!
 *@brief Test if rvxtfs_openFirst() will succeed. 
 *@details May be used to check if file is preswent and accessiable.
 */
bool rvxtfs_testOpenFirst(const char* filename, const char* mode);

#ifdef __cplusplus
}
#endif


#endif
