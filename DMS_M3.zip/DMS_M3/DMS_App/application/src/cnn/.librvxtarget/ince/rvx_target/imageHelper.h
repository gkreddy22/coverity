#ifndef __IMAGEHELPER_H__
#define __IMAGEHELPER_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*!
 * @brief Setup channel from data provided as data.
 * @details Tries to automatically detect data format.
 * @param destination Destination to write channel data to.
 * @param width Width of channel.
 * @param height Height of channel.
 * @param bytesPerPixel Destination format.
 * @param channel Channel If data supports multiple channel, this can be specified here.
 * @param data Image data used as source.
 * @return
 */
bool setupChannelFromData(
    void*              p_destination,
    const size_t       width,
    const size_t       height,
    const unsigned int bytesPerPixel,
    const unsigned int channel,
    const void*        data);

#ifdef __cplusplus
}
#endif

#endif
