#ifndef _BCL_H_
#define _BCL_H_

#include <stdint.h>

/*!
 * \brief Definitions for binary command lists (BCL).
 */

#define BCL_VERSION (4)         /** current version, must be incremented with every change! */
#define BCL_MAGIC (0x324D3356U) /** magic dword in header */

#ifdef __cplusplus
extern "C" {
#endif

typedef struct bcl_header_count
{
    uint16_t memres;    /** number of memres definitions */
    uint16_t mem_entry; /** number of entry memory definitions */
    uint16_t mem_exit;  /** number of exit memory definitions */
    uint16_t version;   /** additional version tag, must be set to BCL_VERSION */
} __attribute__((packed)) bcl_header_count_t;

typedef struct bcl_header
{
    uint32_t           brc;   /** branch instruction */
    uint32_t           magic; /** magic */
    bcl_header_count_t count; /** stride in pixels */
} bcl_header_t;

typedef struct bcl_tile_fmt
{
    uint16_t width;       /** width of tile in pixels */
    uint16_t height;      /** height of tile in pixels */
    uint16_t stride;      /** stride in pixels */
    uint8_t  bitpp;       /** pixel bitpp format */
    uint8_t  format_type; /** pixel format type 0 = unsigned int, 1 = signed int, 2 = float*/
} __attribute__((packed)) bcl_tile_fmt_t;

typedef struct bcl_memres
{
    uint32_t base; /** base address in physical memory */
    uint32_t size; /** size of resource */
} bcl_memres_t;

typedef struct bcl_mem_entry
{
    uint32_t       destination; /** destination address in physical memory */
    uint32_t       position;    /** position of data payload in current CL */
    uint32_t       size;        /** size of payload in bytes */
    bcl_tile_fmt_t tile;        /** tile definition */
} bcl_mem_entry_t;

typedef struct bcl_mem_exit
{
    uint32_t       base;     /** base address in physical memory */
    uint32_t       position; /** position of data payload in current CL */
    uint32_t       size;     /** size of memory block in bytes */
    bcl_tile_fmt_t tile;     /** tile definition */
    uint32_t       mask;     /** mask used for displaying, ie. LSB only */
} bcl_mem_exit_t;

#ifdef __cplusplus
}
#endif

#endif
