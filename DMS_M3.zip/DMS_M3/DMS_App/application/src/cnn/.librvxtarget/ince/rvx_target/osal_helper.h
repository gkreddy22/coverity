
/******************************************************************************
 [ FuncName ] CNN_UserShiftFunc
 [ params]
   cldata           Pointer to the CL data
   ch_fp_handles	List of fp handles corresponding to the channel
   weight_frac      The current weight fraction size
   bias_frac        The current bias fraction size
 [ Return ]
   R_ATMLIB_E_OK        on success
   R_ATMLIB_E_NG_ARG1   argument cldata NULL address
   R_ATMLIB_E_NG_CLTYPE cldata type is not UNSET and CNN
   R_ATMLIB_E_NG_ARG3   argument layer is out of range
   R_ATMLIB_E_NG_ARG4   argument ch_layers NULL address
   R_ATMLIB_E_NG_CLSIZE lack of CL area
 [ Function ] Set the shift value.
 [ Note ] none
******************************************************************************/

#ifndef __OSAL_HELPER__
#define __OSAL_HELPER__

#include "rcar-xos/osal/r_osal.h"

#include "ui.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define CHECK_OK(val)                       \
    {                                       \
        if (OSAL_RETURN_OK != val)          \
        {                                   \
            cerror("'" #val "' failed!\n"); \
        }                                   \
    }

    static inline e_osal_return_t _osal_check(e_osal_return_t const val, const char *pos, const char *exp)
    {
        if (OSAL_RETURN_OK != val)
        {
            fprintf(rvxtui_get_stderr(), __ERROR_PREFIX "%s '%s' failed with %i\n", pos, exp, val);
        }
        else
        {
            /*Do nothing*/
        }
        return val;
    }

#define OSAL_CHECK(EXPR) _osal_check(EXPR, __RVX_CODE_POSITION__, #EXPR)

#ifdef __cplusplus
}
#endif

#endif