#ifndef _R_CL_PATCH_H_
#define _R_CL_PATCH_H_

#define R_CL_SYNC_BITS(cmd) (((cmd) >> 0) & 0xffff)

typedef enum
{
    CORE_TYPE_UNUSED = 0,
    CORE_TYPE_IMP = 1,
    CORE_TYPE_OCV,
    CORE_TYPE_DMA,
    CORE_TYPE_PSC,
    CORE_TYPE_CNN, // = 6,
    CORE_TYPE_SIMP
} r_cl_patch_core_t;

typedef struct
{
    r_cl_patch_core_t type;
    unsigned int index;
} r_cl_patch_core_map_entry_t;

typedef struct
{
    r_cl_patch_core_map_entry_t entry[16];
} cl_patch_core_map_t;

uint32_t r_cl_patch_remapSync(uint32_t inst, const cl_patch_core_map_t *map_in, const cl_patch_core_map_t *map_out, const bool verbose);

#endif
