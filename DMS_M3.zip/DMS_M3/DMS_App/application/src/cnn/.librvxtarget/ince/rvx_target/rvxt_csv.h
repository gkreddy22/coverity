#ifndef __RVXT_CSV_H__
#define __RVXT_CSV_H__

#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Atomic library */
#include "rcar-xos/atmlib/r_atmlib_prot.h"
#include "rcar-xos/atmlib/r_atmlib_types.h"

/* RVX Target interface */
#include "atmlib_cnn_user_functions.h"
#include "info.h"
#include "rvx_target_int.h"
#include "rvxt_csv_helper.h"

#ifdef __cplusplus
extern "C" {
#endif
R_ATMLIB_RETURN_VALUE rvxt_csv_cl_gen_by_corename(R_ATMLIB_CLData* cl, const char* const corename, const rvxt_info_t* const p_info, const rvxt_core_group_e coretype, const bool noWeights, const bool noSync);
R_ATMLIB_RETURN_VALUE rvxt_cl_from_csv(R_ATMLIB_CLData* cl, char* csv_filepath, const rvxt_info_t* const p_info, const rvxt_core_group_e coretype, const bool noWeights, const bool noSync);

// DUMMY - For compatibility only
const void *_unused_csv_var(const void *const var);
R_ATMLIB_RETURN_VALUE rvxt_csv_DMA_cl_from_csv(R_ATMLIB_CLData *cl, char *corename, const rvxt_info_t *const p_info);
R_ATMLIB_RETURN_VALUE rvxt_csv_CNN_cl_from_csv(R_ATMLIB_CLData *cl, char *corename, const rvxt_info_t *const p_info);
R_ATMLIB_RETURN_VALUE rvxt_csv_CVE_cl_from_csv(R_ATMLIB_CLData *cl, char *corename, const rvxt_info_t *const p_info);
R_ATMLIB_RETURN_VALUE rvxt_csv_IMP_cl_from_csv(R_ATMLIB_CLData *cl, char *corename, const rvxt_info_t *const p_info);
// DUMMY - For compatibility only

#ifdef __cplusplus
}
#endif

#endif
