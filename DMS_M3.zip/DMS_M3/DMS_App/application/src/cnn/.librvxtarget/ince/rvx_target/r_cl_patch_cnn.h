#ifndef __R_CL_PATCH_CNN_H__
#define __R_CL_PATCH_CNN_H__

#include "r_cl_patch.h"
#include "r_cl_patch_helper.h"

#define SIGN_EXT16(v, w) (unsigned int)((int16_t)((int16_t)(v) << (16 - (w))) >> (16 - (w)))

#define R_CNNIP_CL_CMDID(cmd) (uint8_t)(((cmd) >> 24) & 0xff)
#define R_CNNIP_CL_BRC_COND(cmd) (uint8_t)(((cmd) >> 22) & 0x3)
#define R_CNNIP_CL_BRC_DIST(cmd) (uint16_t)(((cmd) >> 9) & 0x1fff)
#define R_CNNIP_CL_WPR_ADDR(cmd) (uint16_t)(((cmd) >> 8) & 0xffff)
#define R_CNNIP_CL_WPR_N(cmd) (uint8_t)((cmd)&0xff)
#define R_CNNIP_BRC_ALWAYS (0x3)

#define R_CNNIP_CL_WPR (0x55U)
#define R_CNNIP_CL_WPRNBSY (0x56U)
#define R_CNNIP_CL_NOP (0x80U)
#define R_CNNIP_CL_SYNCS (0x8BU)
#define R_CNNIP_CL_WUP (0xA0U)
#define R_CNNIP_CL_SLP (0xA1U)
#define R_CNNIP_CL_INT (0x81U)
#define R_CNNIP_CL_TRAP (0x88U)
#define R_CNNIP_CL_JUMP (0x90U)
#define R_CNNIP_CL_GOSUB (0x91U)
#define R_CNNIP_CL_RET (0x99U)
#define R_CNNIP_CL_CLUVT (0x48U)
#define R_CNNIP_CL_SCRES (0x49U)
#define R_CNNIP_CL_SCCHK (0x4AU)
#define R_CNNIP_CL_TUV2UVT (0x4BU)
#define R_CNNIP_CL_CLW (0x4CU)
#define R_CNNIP_CL_ADD (0x40U)
#define R_CNNIP_CL_SUB (0x41U)
#define R_CNNIP_CL_WR (0x42U)
#define R_CNNIP_CL_WRI (0x43U)
#define R_CNNIP_CL_BRC (0x44U)

#if defined(RCAR_SOC_V3U) || defined(RCAR_SOC_V3H2)
#define CNNIP_VCR0 (0x0000)
#define CNNIP_VCR1 (0x0004)

#define CNNIP_CLPC (0x0100)
#define CNNIP_SACL (0x0104)

#define CNNIP_DMAISA (0x4000)
#define CNNIP_DMAISA0 (0x4100)
#define CNNIP_DMAISA1 (0x4104)
#define CNNIP_DMAISA2 (0x4108)
#define CNNIP_DMAISA3 (0x410C)

#define CNNIP_DMAISA4 (0x4110)
#define CNNIP_DMAISA5 (0x4114)
#define CNNIP_DMAISA6 (0x4118)
#define CNNIP_DMAISA7 (0x411c)
#define CNNIP_DMAISA8 (0x4120)
#define CNNIP_DMAISA9 (0x4124)
#define CNNIP_DMAISA10 (0x4128)
#define CNNIP_DMAISA11 (0x412c)
#define CNNIP_DMAISA12 (0x4130)
#define CNNIP_DMAISA13 (0x4134)
#define CNNIP_DMAISA14 (0x4138)
#define CNNIP_DMAISA15 (0x413c)

#define CNNIP_DMAIST0 (0x4180)
#define CNNIP_DMAIST1 (0x4184)
#define CNNIP_DMAIST2 (0x4188)
#define CNNIP_DMAIST3 (0x418C)

#define CNNIP_DMAIL0 (0x4140)
#define CNNIP_DMAIL1 (0x4144)
#define CNNIP_DMAIL2 (0x4148)
#define CNNIP_DMAIL3 (0x414C)

#define CNNIP_PADD00_01 (0x1100)
#define CNNIP_PADD02_03 (0x1104)

#define CNNIP_STRIDE00_03 (0x1120)
#define CNNIP_STRIDE04_07 (0x1124)

#define CNNIP_DMAIMAG (0x4010)
#define CNNIP_DMAIMAG00_03 (0x41C0)
#define CNNIP_DMAIMAG04_07 (0x41C4)
#define CNNIP_DMAIMAG08_11 (0x41C8)
#define CNNIP_DMAIMAG12_15 (0x41CC)

#define CNNIP_DMAIFM00_07 (0x41D0)
#define CNNIP_DMAIFM08_15 (0x41D4)

#define CNNIP_DMA3DCFM00_07 (0x52A0)
#define CNNIP_DMA3DCFM08_15 (0x52A4)

#define R_CNNIP_MAX_INPUTS 16
#define R_CNNIP_MAX_OUTPUTS 32
#define R_CNNIP_INREG_MAX_COLS 128
#define R_CNNIP_INREG_MAX_ROWS 4096

#define CNNIP_DMA3DCST0 (0x5200)
#define CNNIP_DMA3DCST1 (0x5204)
#define CNNIP_DMA3DCST2 (0x5208)
#define CNNIP_DMA3DCST3 (0x520C)
#define CNNIP_DMA3DCST4 (0x5210)
#define CNNIP_DMA3DCST5 (0x5214)
#define CNNIP_DMA3DCST6 (0x5218)
#define CNNIP_DMA3DCST7 (0x521C)

#define CNNIP_DMA3DCL0 (0x5180)
#define CNNIP_DMA3DCL1 (0x5184)
#define CNNIP_DMA3DCL2 (0x5188)
#define CNNIP_DMA3DCL3 (0x518C)
#define CNNIP_DMA3DCL4 (0x5190)
#define CNNIP_DMA3DCL5 (0x5194)
#define CNNIP_DMA3DCL6 (0x5198)
#define CNNIP_DMA3DCL7 (0x519C)

#define CNNIP_DMAOST (0x600C)

#define CNNIP_DMAOL (0x6008)

#define CNNIP_DMAOFM (0x6010)

#define CNNIP_DMA3DCMAG00_03 (0x5280)

#define CNNIP_DMAIE (0x401C)
#define CNNIP_DMA3DCE (0x501C)
#define CNNIP_DMAOE (0x6018)

#define CNNIP_DMA3DCSA (0x5000)
#define CNNIP_DMA3DCSA0 (0x5100)
#define CNNIP_DMA3DCSA1 (0x5104)
#define CNNIP_DMA3DCSA2 (0x5108)
#define CNNIP_DMA3DCSA3 (0x510C)
#define CNNIP_DMA3DCSA4 (0x5110)
#define CNNIP_DMA3DCSA5 (0x5114)
#define CNNIP_DMA3DCSA6 (0x5118)
#define CNNIP_DMA3DCSA7 (0x511C)
#define CNNIP_DMA3DCSA8 (0x5120)
#define CNNIP_DMA3DCSA9 (0x5124)
#define CNNIP_DMA3DCSA10 (0x5128)
#define CNNIP_DMA3DCSA11 (0x512C)
#define CNNIP_DMA3DCSA12 (0x5130)
#define CNNIP_DMA3DCSA13 (0x5134)
#define CNNIP_DMA3DCSA14 (0x5138)
#define CNNIP_DMA3DCSA15 (0x513c)
#define CNNIP_DMA3DCSA16 (0x5140)
#define CNNIP_DMA3DCSA17 (0x5144)
#define CNNIP_DMA3DCSA18 (0x5148)
#define CNNIP_DMA3DCSA19 (0x514c)
#define CNNIP_DMA3DCSA20 (0x5150)
#define CNNIP_DMA3DCSA21 (0x5154)
#define CNNIP_DMA3DCSA22 (0x5158)
#define CNNIP_DMA3DCSA23 (0x515c)
#define CNNIP_DMA3DCSA24 (0x5160)
#define CNNIP_DMA3DCSA25 (0x5164)
#define CNNIP_DMA3DCSA26 (0x5168)
#define CNNIP_DMA3DCSA27 (0x516c)
#define CNNIP_DMA3DCSA28 (0x5170)
#define CNNIP_DMA3DCSA29 (0x5174)
#define CNNIP_DMA3DCSA30 (0x5178)
#define CNNIP_DMA3DCSA31 (0x517c)

#define CNNIP_DMAOSA (0x6000)
#define CNNIP_DMAOSA0 (0x6100)
#define CNNIP_DMAOSA1 (0x6104)
#define CNNIP_DMAOSA2 (0x6108)
#define CNNIP_DMAOSA3 (0x610C)
#define CNNIP_DMAOSA4 (0x6110)
#define CNNIP_DMAOSA5 (0x6114)
#define CNNIP_DMAOSA6 (0x6118)
#define CNNIP_DMAOSA7 (0x611C)

#define CNNIP_DMAOSA8 (0x6120)
#define CNNIP_DMAOSA9 (0x6124)
#define CNNIP_DMAOSA10 (0x6128)
#define CNNIP_DMAOSA11 (0x612c)
#define CNNIP_DMAOSA12 (0x6130)
#define CNNIP_DMAOSA13 (0x6134)
#define CNNIP_DMAOSA14 (0x6138)
#define CNNIP_DMAOSA15 (0x613c)
#define CNNIP_DMAOSA16 (0x6140)
#define CNNIP_DMAOSA17 (0x6144)
#define CNNIP_DMAOSA18 (0x6148)
#define CNNIP_DMAOSA19 (0x614c)
#define CNNIP_DMAOSA20 (0x6150)
#define CNNIP_DMAOSA21 (0x6154)
#define CNNIP_DMAOSA22 (0x6158)
#define CNNIP_DMAOSA23 (0x615c)
#define CNNIP_DMAOSA24 (0x6160)
#define CNNIP_DMAOSA25 (0x6164)
#define CNNIP_DMAOSA26 (0x6168)
#define CNNIP_DMAOSA27 (0x616c)
#define CNNIP_DMAOSA28 (0x6170)
#define CNNIP_DMAOSA29 (0x6174)
#define CNNIP_DMAOSA30 (0x6178)
#define CNNIP_DMAOSA31 (0x617c)

#define CNNIP_BIAS00_01 (0x1138)
#define CNNIP_BIAS02_03 (0x113C)
#define CNNIP_BIAS04_05 (0x1140)
#define CNNIP_BIAS06_07 (0x1144)
#define CNNIP_BIAS08_09 (0x1148)
#define CNNIP_BIAS10_11 (0x114C)
#define CNNIP_BIAS12_13 (0x1150)
#define CNNIP_BIAS14_15 (0x1154)

#define CNNIP_SLSP (0x0110)

#define CNNIP_SACL (0x0104)

#define CNNIP_SWAPBYTE_RFCL (0x3064)
#define CNNIP_SWAPBYTE_I3DCO (0x3060)
#define CNNIP_SWAPBYTE_I00_03 (0x3070)
#define CNNIP_SWAPBYTE_I04_07 (0x3074)
#define CNNIP_SWAPBYTE_3DC00_03 (0x3080)
#define CNNIP_SWAPBYTE_O00_03 (0x30A0)

#define CNNIP_ARICSR (0x1000)
#define CNNIP_ARIE (0x1004)
#define CNNIP_ARI_BND (0x20DC)
#define CNNIP_ARI_LEN (0x1010)

#define CNNIP_DMARFESA (0x7000)

#define CNNIP_SFTB (0x2008)
#define CNNIP_SFTM (0x200C)
#define CNNIP_SFTI0 (0x2010)
#define CNNIP_SFTC (0x2004)
#define CNNIP_SFTC0 (0x2050)

#define CNNIP_MAX_VAL_THRES (0x0228)
#define CNNIP_MIN_VAL_THRES (0x022C)
#define CNNIP_MAXSUM_CNT_THRES (0x0230)
#define CNNIP_MINSUM_CNT_THRES (0x0234)
#else
#define CNNIP_DMAISA0 (0x1008)
#define CNNIP_DMAISA1 (0x1018)
#define CNNIP_DMAISA2 (0x1028)
#define CNNIP_DMAISA3 (0x1038)

#define CNNIP_DMA3DCSA0 (0x1108)
#define CNNIP_DMA3DCSA1 (0x1118)
#define CNNIP_DMA3DCSA2 (0x1128)
#define CNNIP_DMA3DCSA3 (0x1138)
#define CNNIP_DMA3DCSA4 (0x1148)
#define CNNIP_DMA3DCSA5 (0x1158)
#define CNNIP_DMA3DCSA6 (0x1168)
#define CNNIP_DMA3DCSA7 (0x1178)

#define CNNIP_DMAOSA0 (0x1300)
#define CNNIP_DMAOSA1 (0x1304)
#define CNNIP_DMAOSA2 (0x1308)
#define CNNIP_DMAOSA3 (0x130C)
#define CNNIP_DMAOSA4 (0x1310)
#define CNNIP_DMAOSA5 (0x1314)
#define CNNIP_DMAOSA6 (0x1318)
#define CNNIP_DMAOSA7 (0x131C)

#define CNNIP_SLSP (0x0108)
#endif

#if defined(RCAR_SOC_V3U) || defined(RCAR_SOC_V3H2)
#define CNNIP_DMAIE_EN(r) ((r)&0xFFFFU)
#define CNNIP_DMA3D_EN(r) ((r)&0xFFFFFFFFU)
#define CNNIP_DMAOE_EN(r) ((r)&0xFFFFFFFFU)
#define CNNIP_DMAIE_CH_16B_EN(r, ch) ((r)&(0x1U <<(ch))
#define CNNIP_DMA3D_CH_16B_EN(r, ch) ((r)&(0x1U <<(ch))
#define CNNIP_DMAOE_CH_16B_EN(r, ch) ((r)&(0x1U <<(ch))

#define CNNIP_DMAIL_X(r) ((r)&0x3FFU)
#define CNNIP_DMAIL_Y(r) (((r) >> 16) & 0x7FFFU)

#define CNNIP_DMAIMAG_PMV_00_04_08_12(r) ((r)&0x7U)
#define CNNIP_DMAIMAG_PMV_01_05_09_13(r) (((r) >> 8) & 0x7U)
#define CNNIP_DMAIMAG_PMV_02_06_10_14(r) (((r) >> 16) & 0x7U)
#define CNNIP_DMAIMAG_PMV_03_07_11_15(r) (((r) >> 24) & 0x7U)

#define CNNIP_DMAIMAG_RMV_00_04_08_12(r) (((r) >> 3) & 0x7U)
#define CNNIP_DMAIMAG_RMV_01_05_09_13(r) (((r) >> 11) & 0x7U)
#define CNNIP_DMAIMAG_RMV_02_06_10_14(r) (((r) >> 19) & 0x7U)
#define CNNIP_DMAIMAG_RMV_03_07_11_15(r) (((r) >> 27) & 0x7U)

#define CNNIP_DMAIMAG_MM_00_04_08_12(r) (((r) >> 6) & 0x3U)
#define CNNIP_DMAIMAG_MM_01_05_09_13(r) (((r) >> 14) & 0x3U)
#define CNNIP_DMAIMAG_MM_02_06_10_14(r) (((r) >> 22) & 0x3U)
#define CNNIP_DMAIMAG_MM_03_07_11_15(r) (((r) >> 30) & 0x3U)

#define CNNIP_DMA3DCL_X(r) ((r)&0x3FFU)
#define CNNIP_DMA3DCL_Y(r) (((r) >> 16) & 0x7FFFU)

#define CNNIP_DMAOL_X(r) ((r)&0xFFU)
#define CNNIP_DMAOL_Y(r) (((r) >> 16) & 0xFFFU)

#define CNNIP_BIAS_16B_LO(r) ((r)&0xFFFFU)
#define CNNIP_BIAS_16B_HI(r) (((r) >> 16) & 0xFFFFU)

#define CNNIP_PADD_N0(r) ((r)&0x7U)
#define CNNIP_PADD_S0(r) (((r) >> 3) & 0x7U)
#define CNNIP_PADD_E0(r) (((r) >> 11) & 0x1FU)
#define CNNIP_PADD_W0(r) (((r) >> 6) & 0x1FU)
#define CNNIP_PADD_N1(r) (((r) >> 16) & 0x7U)
#define CNNIP_PADD_S1(r) (((r) >> 19) & 0x7U)
#define CNNIP_PADD_E1(r) (((r) >> 27) & 0x1FU)
#define CNNIP_PADD_W1(r) (((r) >> 22) & 0x1FU)

#define CNNIP_STRIDE_X(r, ch) (((r) >> ((ch)*8)) & 0x7)
#define CNNIP_STRIDE_Y(r, ch) (((r) >> (4 + (ch)*8)) & 0x7U)

#define CNNIP_SWAPBYTE_CL_VAL(v) ((v)&0x3C00U)
#define CNNIP_SWAPBYTE_IOC(r, ch) (((r) >> ((ch)*8)) & 0x3FU)

#define CNNIP_ARICSR_BIAS(r) (((r) >> 1) & 0x1U)
#define CNNIP_ARICSR_ACT_FUNC(r) (((r) >> 2) & 0x7U)
#define CNNIP_ARICSR_XPOOL(r) (((r) >> 12) & 0x3U)
#define CNNIP_ARICSR_YPOOL(r) (((r) >> 14) & 0x3U)
#define CNNIP_ARICSR_XPOOL_MODE(r) (((r) >> 10) & 0x3U)
#define CNNIP_ARICSR_CPOOL_MODE(r) (int)(((r) >> 5) & 0x3U)
#define CNNIP_ARICSR_CPOOL_INFO(r) (int)(((r) >> 7) & 0x7U)
#define CNNIP_ARI_LEN_XLEN(r) ((r)&0xFFU)
#define CNNIP_ARI_LEN_YLEN(r) (((r) >> 16) & 0xFFFU)

#define CNNIP_MAX_VAL_THRES_MASK(v) ((v)&0xFFFFU)
/* DMAIPMVxx */
#define CNNIP_DMAXC_PRV_VAL(r, ch) (((r) >> ((ch)*8)) & 0x7U)
/* DMAIMMxx */
#define CNNIP_DMAXC_PRR_VAL(r, ch) (((r) >> (((ch)*8) + 6)) & 0x3U)
/* DMAIRMVxx */
#define CNNIP_DMAXC_RRV_VAL(r, ch) (((r) >> (((ch)*8) + 3)) & 0x7U)

#define CNNIP_DMAIFM_VAL(r, ch) (((r) >> ((ch)*4)) & 0x7U)

#define CNNIP_DMA3DCFM_VAL(r, ch) (((r) >> ((ch)*4)) & 0x7U)

#define CNNIP_SFTI_VAL(r) ((r)&0x1FU)
#define CNNIP_SFTC_VAL(r) ((r)&0x3FU)

#define TEST_BIT(b, pos) (((b) >> pos) & 0x1U)
#define R_ARR_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#endif

#ifdef RCAR_SOC_V3U
/* Input pixel format */
typedef enum
{
    R_CNNIP_PIXFMT_INT4 = 0x00,
    R_CNNIP_PIXFMT_UINT4 = 0x01,
    R_CNNIP_PIXFMT_INT8 = 0x02,
    R_CNNIP_PIXFMT_UINT8 = 0x03,
    R_CNNIP_PIXFMT_INT16 = 0x04,
    R_CNNIP_PIXFMT_UINT16 = 0x05
} r_cnnip_pixfmt_v3u_t;
#endif

#ifdef __cplusplus
extern "C"
{
#endif

    bool r_cl_patch_CNN(void *data, const size_t size, const uintptr_t base_old, const uintptr_t base_new, bool verbose);
    bool r_cl_patch_CNN_sync(void *data, const cl_patch_core_map_t *map_in, const cl_patch_core_map_t *map_out, const bool verbose);
    bool r_cl_patch_CNN_removeGOSUB(void *data, const bool verbose);
    bool r_cl_patch_CNN_patchGOSUB(void *data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose);
    bool r_cl_patch_CNN_removeStart(void *data, const bool verbose);
    bool r_cl_patch_CNN_patchGOSUB2JUMP(void *data, const bool verbose);
    bool r_cl_patch_CNN_findSYNCS(void *data, MemoryList *list, const bool verbose);
    bool r_cl_CNN_FindRangesUsed(void *data, MemoryList *list, const size_t granularity, const bool verbose);
    bool r_cl_patch_CNN_patchNOP2INT(void *data, const bool verbose);

#ifdef __cplusplus
}
#endif

#endif
