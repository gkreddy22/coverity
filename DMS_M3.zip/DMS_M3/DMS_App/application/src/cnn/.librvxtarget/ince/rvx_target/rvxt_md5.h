#ifndef _RVXT_MD5_H_
#define _RVXT_MD5_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../md5.h"
#include "rvxt_md5.h"
#include "ui.h"

typedef struct md5_t
{
    unsigned char hash[16];
} md5_t;

#ifdef __cplusplus
extern "C"
{
#endif

    void rvxt_md5Calculate(md5_t *p_md5, const void *base, const size_t size);
    bool rvxt_md5CalculateTile(md5_t *p_md5, const void *data, const size_t width, const size_t height, const size_t stride, const unsigned int bytesPerPixel);
    void rvxt_md5Print(FILE *fp, md5_t *p_md5);
    bool rvxt_md5Compare(md5_t *p_md5a, md5_t *p_md5b);
    void rvxt_md5Dump(FILE *fp, const void *base, const size_t size);
    void rvxt_md5DumpTile(FILE *fp, const void *p_data, const size_t width, const size_t height, const size_t stride, const unsigned int bytesPerPixel);
    bool rvxt_md5DumpTileCheck(FILE *fp, const void *p_data, const size_t size, const size_t width, const size_t height, const size_t stride, const unsigned int bytesPerPixel);

#ifdef __cplusplus
}
#endif

#endif
