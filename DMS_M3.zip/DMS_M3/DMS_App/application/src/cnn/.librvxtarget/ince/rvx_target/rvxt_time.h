#ifndef __RVXT_TIME_H__
#define __RVXT_TIME_H__

#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(__linux__) || defined(__QNX__) || defined(_WIN64)
#    define RVXT_TIME_USE_TIMESPEC (1)
#endif

#if defined(RVXT_TIME_USE_TIMESPEC)
#    include <time.h>
typedef struct timespec rvx_time_t;
#else
typedef uint64_t rvx_time_t;
#endif

/*!
 *@brief Returns delat time in us.
 */
unsigned int rvxt_time_getTimeDelta(rvx_time_t start, rvx_time_t stop);

/*!
 *@brief Get current time.
 */
bool rvxt_time_getCurrentTime(rvx_time_t* p_time);

/*!
 *@brief Return max value
 */
rvx_time_t rvxt_time_max(const rvx_time_t lhs, const rvx_time_t rhs);

/*!
 *@brief Return min value
 */
rvx_time_t rvxt_time_min(const rvx_time_t lhs, const rvx_time_t rhs);

#endif
