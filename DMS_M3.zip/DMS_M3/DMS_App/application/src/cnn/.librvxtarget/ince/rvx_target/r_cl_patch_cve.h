#ifndef __R_CL_PATCH_CVE_H__
#define __R_CL_PATCH_CVE_H__

#include <stdbool.h>

#include "r_cl_patch.h"

#define R_CVE_CL_CMDID(cmd) (uint8_t)(((cmd) >> 24) & 0xff)
#define R_CVE_CL_WPR_ADDR(cmd) (uint16_t)(((cmd) >> 8) & 0xffff)
#define R_CVE_CL_WPR_N(cmd) (uint8_t)((cmd)&0xff)

#define R_CVE_CL_WPR (0x55U)
#define R_CVE_CL_NOP (0x80U)
#define R_CVE_CL_WUP (0xA0U)
#define R_CVE_CL_SLP (0xA1U)
#define R_CVE_CL_INT (0x81U)
#define R_CVE_CL_TRAP (0x88U)
#define R_CVE_CL_SYNCM (0x8AU)
#define R_CVE_CL_SYNCS (0x8BU)
#define R_CVE_CL_JUMP (0x90U)
#define R_CVE_CL_GOSUB (0x91U)
#define R_CVE_CL_RET (0x99U)
#define R_CVE_CL_RECT (0x22U)

#define CVE_DLSAR (0x0180)
#define CVE_VIBAR (0x0340)
#define CVE_PIBAR (0x0344)
#define CVE_IMGBAR0 (0x0400)
#define CVE_IMGBAR1 (0x040C)
#define CVE_IMGBAR2 (0x0418)
#define CVE_IMGBAR3 (0x0424)
#define CVE_IMGBAR4 (0x0430)
#define CVE_IMGBAR5 (0x043C)
#define CVE_IMGBAR6 (0x0448)
#define CVE_IMGBAR7 (0x0454)

#ifdef __cplusplus
extern "C" {
#endif

bool r_cl_patch_CVE(void* data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose);

#ifdef __cplusplus
}
#endif

#endif
