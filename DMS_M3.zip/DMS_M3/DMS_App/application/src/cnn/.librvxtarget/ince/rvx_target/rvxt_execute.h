#ifndef __RVXT_EXECUTE_H__
#define __RVXT_EXECUTE_H__

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

//#include "rcar-xos/atmlib/r_atmlib_def.h" /* required by r_atmlib_types.h */
//#include "rcar-xos/atmlib/r_atmlib_types.h"
//#include "rcv_impdrv.h"

#include "info.h"
#include "r_cl_patch.h"
#include "rvx_target.h"

/* OSAL API*/
#include "config.h"

#if defined(HAS_RCV_IMPDRV_H)
#include "rcar-xos/imp/rcv_impdrv.h"
#else
#include "rcar-xos/imp/r_impdrv.h"
#endif
#include "rcar-xos/osal/r_osal.h"

typedef struct
{
    osal_memory_buffer_handle_t cmd_buffer;
    void *virt;
    uintptr_t phys;
    size_t size;
    r_cl_patch_core_t core;
    unsigned int syncid;
} Commandlist;

#if defined(RCAR_SOC_V3U)
#define RVXT_CORE_IMP_NUM (4)
#define RVXT_CORE_CVE_NUM (8)
#define RVXT_CORE_DMA_NUM (4)
#define RVXT_CORE_CNN_NUM (3)
#elif defined(RCAR_SOC_V3H1) || defined(RCAR_SOC_V3H2)
#define RVXT_CORE_IMP_NUM (5)
#define RVXT_CORE_CVE_NUM (5)
#define RVXT_CORE_DMA_NUM (4)
#define RVXT_CORE_CNN_NUM (1)
#elif defined(RCAR_SOC_V3M2)
#define RVXT_CORE_IMP_NUM (4)
#define RVXT_CORE_CVE_NUM (2)
#define RVXT_CORE_DMA_NUM (2)
#define RVXT_CORE_CNN_NUM (1)
#else
#error "Unknown architecture!"
#endif

#define RVXT_CORE_NUM (RVXT_CORE_CNN_NUM + RVXT_CORE_DMA_NUM + RVXT_CORE_CVE_NUM + RVXT_CORE_IMP_NUM)

#ifdef __cplusplus
extern "C" {
#endif

bool executeCommandlists(Commandlist *commandlists, size_t const count, rvxt_cb_mem_t *p_cb_mem, size_t clxX, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, int timeout_ms, const uint32_t cl_alloc_alignment, bool DTAenabled);
bool impdrv_start(size_t const count,bool DTAenabled,Commandlist *commandlists, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id);
bool imp_stop(size_t const count);
#ifdef __cplusplus
}
#endif

#endif
