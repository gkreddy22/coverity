#ifndef __CLOFSLIST_H__
#define __CLOFSLIST_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "list.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    uint32_t     clof;
    size_t       index;
    unsigned int id;
} ClofsListEntry_t;

typedef List             ClofsList;
typedef ListIterator     ClofsListIterator;
typedef ClofsListEntry_t ClofsListEntry;

/*!
 * @brief Append an entry to list.
 */
ClofsListEntry* clofsListAppend(ClofsList* list, const ClofsListEntry* entry);

/*!
 * @brief Create list.
 */
ClofsList* clofsListCreate(void);

/*!
 * @brief Destroy list.
 */
void clofsListFree(ClofsList* list);

ClofsListIterator* clofsListIteratorGet(ClofsList* list);
ClofsListIterator* clofsListIteratorNext(ClofsList* list, ClofsListIterator* iterator);
ClofsListEntry*    clofsListIteratorGetValue(ClofsList* list, ClofsListIterator* iterator);
size_t             clofsListSize(ClofsList* list);

#ifdef __cplusplus
}
#endif

//#endif
#endif
