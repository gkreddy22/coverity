#ifndef __AIFHELPER_H__
#define __AIFHELPER_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

bool getAIFImageInfo(const void* aifBuffer, void** dataBuffer, size_t* width, size_t* height, uint32_t* maxval);
bool testAIFImageFormat(const void* data);

#ifdef __cplusplus
}
#endif

#endif
