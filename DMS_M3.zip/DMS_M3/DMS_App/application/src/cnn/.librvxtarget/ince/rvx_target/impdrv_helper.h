
/******************************************************************************
 [ FuncName ] CNN_UserShiftFunc
 [ params]
   cldata           Pointer to the CL data
   ch_fp_handles	List of fp handles corresponding to the channel
   weight_frac      The current weight fraction size
   bias_frac        The current bias fraction size
 [ Return ]
   R_ATMLIB_E_OK        on success
   R_ATMLIB_E_NG_ARG1   argument cldata NULL address
   R_ATMLIB_E_NG_CLTYPE cldata type is not UNSET and CNN
   R_ATMLIB_E_NG_ARG3   argument layer is out of range
   R_ATMLIB_E_NG_ARG4   argument ch_layers NULL address
   R_ATMLIB_E_NG_CLSIZE lack of CL area
 [ Function ] Set the shift value.
 [ Note ] none
******************************************************************************/

#ifndef __IMPDRV_HELPER__
#define __IMPDRV_HELPER__

#include "ui.h"

#include "config.h"

#if defined(HAS_R_IMPDRV_H)
#include "rcar-xos/imp/r_impdrv.h"
#elif defined(HAS_RCV_IMPDRV_H)
#include "rcar-xos/imp/rcv_impdrv.h"
#if !defined(e_impdrv_errorcode_t)
#define e_impdrv_errorcode_t RCvDrvErrorCode
#endif
#if !defined(IMPDRV_EC_OK)
#define IMPDRV_EC_OK RCV_EC_OK_DRV
#endif

#endif

static inline e_impdrv_errorcode_t _impdrv_check(e_impdrv_errorcode_t const val, char *const pos, char *const exp)
{
  if (IMPDRV_EC_OK != val)
  {
    fprintf(rvxtui_get_stderr(), "%s '%s' failed with %i\n", pos, exp, val);
  }
  return val;
}

#define IMPDRV_CHECK(EXPR) _impdrv_check(EXPR, __ERROR_PREFIX __RVX_CODE_POSITION__, #EXPR)

#endif