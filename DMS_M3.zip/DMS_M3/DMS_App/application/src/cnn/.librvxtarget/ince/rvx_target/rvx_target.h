/**
 * @brief RVX header file for target project
 * @details
 */

#ifndef __RVX_TARGET_H__
#define __RVX_TARGET_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#include "info.h"
#include "stringList.h"

typedef void* (*rvxt_cb_malloc_f)(size_t size);
typedef void (*rvxt_cb_free_f)(void* ptr);
typedef void* (*rvxt_cb_getVirt_f)(const uintptr_t phys);
typedef uintptr_t (*rvxt_cb_getPhys_f)(const void* virt);
typedef void (*rvxt_cb_flush_f)(void* addr, size_t len);
typedef void (*rvxt_cb_invalidate_f)(void* addr, size_t len);

typedef struct
{
    rvxt_cb_malloc_f     malloc;
    rvxt_cb_free_f       free;
    rvxt_cb_getVirt_f    getVirt;
    rvxt_cb_getPhys_f    getPhys;
    rvxt_cb_flush_f      flush;
    rvxt_cb_invalidate_f invalidate;
} rvxt_cb_mem_t;

#ifdef __cplusplus
extern "C" {
#endif

#define RVX_TARGET_VERSION_MAJOR (0x0001U)
#define RVX_TARGET_VERSION_MINOR (0x0000U)

#define RVXT_PATH_MAX (4096)

void         rvx_target_summary(const rvxt_info_t* const info);
void         rvx_target_linearizeMemoryAllocation(rvxt_info_t* const info, const size_t index_memres);
size_t       rvx_target_getMemresPeakUsage(const rvxt_info_t* const info, const size_t index_memres);
const char*  rvxt_getMemoryName(const rvxt_info_t* const info, const size_t index);
uintptr_t    rvxt_getMemoryAddressPhys(const rvxt_info_t* const info, const size_t index);
void*        rvxt_getMemoryAddressVirt(const rvxt_info_t* const info, const size_t index);
size_t       rvxt_getMemorySize(const rvxt_info_t* const info, const size_t index);
bool         rvxt_getMemoryTileWidth(const rvxt_info_t* const info, const size_t index, size_t* p_width);
bool         rvxt_getMemoryTileHeight(const rvxt_info_t* const info, const size_t index, size_t* p_height);
bool         rvxt_getMemoryTileStride(const rvxt_info_t* const info, const size_t index, size_t* p_stride);
unsigned int rvxt_getMemoryTileFormatBitpp(const rvxt_info_t* const info, const size_t index);
unsigned int rvxt_getMemoryTileFormatType(const rvxt_info_t* const info, const size_t index);
size_t       rvxt_getEntryMemoryIndex(const rvxt_info_t* const info, const size_t index);
size_t       rvxt_getExitMemoryIndex(const rvxt_info_t* const info, const size_t index);
size_t       rvxt_getEntryMemoryMemresIndex(const rvxt_info_t* const info, const size_t index);
size_t       rvxt_getExitMemoryMemresIndex(const rvxt_info_t* const info, const size_t index);
void         rvxt_setMemresAddressVirt(const rvxt_info_t* const info, const size_t index, void* address);
void         rvxt_setMemresAddressPhys(const rvxt_info_t* const info, const size_t index, uintptr_t phys);
uintptr_t    rvxt_getMemresAddressPhys(const rvxt_info_t* const info, const size_t index);
bool         rvxt_getMemresByName(const rvxt_info_t* const info, const char* const name, size_t* index);
bool         rvxt_getMemoryByName(const rvxt_info_t* const info, const char* const name, size_t* index);

bool rvxt_allocateMemresByIndex(const rvxt_info_t* const info, const size_t index_memres, rvxt_cb_mem_t* p_cb_mem, bool setPhysAddress);
bool rvxt_allocateMemres(const rvxt_info_t* const info, rvxt_cb_mem_t* p_cb_mem, bool setPhysAddress);
bool rvxt_getCoreNumberInGroup(const rvxt_info_t* const p_info, const size_t index, size_t* number);
bool rvxt_printCoreMaps(const rvxt_info_t* const p_info);
/*
 * @brief Appends all memories within a memres to a StringList.
 */
bool rvx_target_appendMemoriesFromMemres(
    rvxt_info_t* const p_info,
    const size_t       index_memres,
    StringList*        p_list);

const char*       rvxt_getCoreName(rvxt_core_e core);
const char*       rvxt_getCoreGroupName(rvxt_core_group_e core);
unsigned int      rvxt_getCoreGroupNumber(rvxt_core_group_e core);
rvxt_core_group_e rvxt_getCoreGroup(rvxt_core_e core);
unsigned int      rvxt_getCoreCount(const rvxt_info_t* const p_info, const rvxt_core_group_e group);
bool              rvxt_getCoreIndex(const rvxt_info_t* const p_info, const rvxt_core_group_e group, unsigned int number, size_t* index);
bool              rvxt_setGlobalCoreMap(rvxt_info_t* const p_info, rvxt_core_map_t p_core_map);
bool              rvxt_printEntryMemoryHashes(rvxt_info_t* const p_info);
bool              rvxt_printExitMemoryHashes(rvxt_info_t* const p_info);
uint8_t*          rvxt_loadFile(const char* filename);

/*!
 *@brief Parse channel string as used by eg. --setMemory.
 *@details Format is <channel_name>(<channel_id>).
 */
bool rvxt_parseChannel(char* const str, int* const p_channel);

#ifdef __cplusplus
}
#endif
#endif
