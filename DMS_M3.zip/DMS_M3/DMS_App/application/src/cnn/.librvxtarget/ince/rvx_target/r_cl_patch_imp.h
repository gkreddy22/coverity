#ifndef __R_CL_PATCH_IMP_H__
#define __R_CL_PATCH_IMP_H__

#include <stdbool.h>
//
#include "r_cl_patch.h"
#define R_IMP_CL_CMDID(cmd) (uint8_t)(((cmd) >> 24) & 0xff)
#define R_IMP_CL_WPR_ADDR(cmd) (uint16_t)((cmd)&0xffff)
#define R_IMP_CL_WPR_N(cmd) (uint8_t)((cmd >> 16) & 0xff)

#define R_IMP_CL_MOV (0x41U)
#define R_IMP_CL_INT (0x42U)
#define R_IMP_CL_NOP (0x40U)
#define R_IMP_CL_SYNCM (0x43U)
#define R_IMP_CL_WUP (0x48U)
#define R_IMP_CL_SLP (0x49U)
#define R_IMP_CL_TRAP (0x4FU)
#define R_IMP_CL_GOSUB (0x46U)
#define R_IMP_CL_RET (0x47U)

#define IMP_APSASP (0x0100)
#define IMP_APSBSP (0x0104)
#define IMP_APDSP (0x0108)

#ifdef __cplusplus
extern "C"
{
#endif
    bool r_cl_patch_IMP(void *data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose);

#ifdef __cplusplus
}
#endif

#endif
