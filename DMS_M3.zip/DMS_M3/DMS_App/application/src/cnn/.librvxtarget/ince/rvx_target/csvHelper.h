#ifndef __CSVHELPER_H__
#define __CSVHELPER_H__

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

bool writeCSVu16(FILE* fp, const uint16_t* data, const size_t width, const size_t height);
bool writeCSVu8(FILE* fp, const uint8_t* data, const size_t width, const size_t height);
bool writeCSVf32(FILE* fp, const float* data, const size_t width, const size_t height);

#ifdef __cplusplus
}
#endif


#endif
