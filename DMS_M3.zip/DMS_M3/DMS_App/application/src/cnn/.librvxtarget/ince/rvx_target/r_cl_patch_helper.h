#ifndef __R_CL_PATCH_HELPER__
#define __R_CL_PATCH_HELPER__

#include "list.h"
#include <stddef.h>
#include <stdint.h>

#include "rcar-xos/osal/r_osal.h"

#ifdef __cplusplus
extern "C"
{
#endif

   typedef struct _MemoryListEntry
   {
      osal_memory_buffer_handle_t base_new_buffer;
      uintptr_t addressOld;
      uintptr_t addressNew;
      size_t size;
      uint32_t memres_index;
   } MemoryListEntry;

   typedef List MemoryList;
   typedef ListIterator MemoryListIterator;

   /*!
 * @brief Append an entry to list.
 */
   bool memoryListAppend(MemoryList *list, const MemoryListEntry *entry);

   /*!
 * @brief Create list.
 */
   MemoryList *memoryListCreate(void);

   /*!
 * @brief Destroy list.
 */
   void memoryListFree(MemoryList *list);

   MemoryListEntry *memoryListNext(MemoryListEntry *entry);

   /*!
 * @brief Get size of list
 */
   size_t memoryListSize(MemoryList *list);

   /*!
 * @brief Get element at position index.
 */
   MemoryListEntry *memoryListAt(MemoryList *list, size_t index);

   MemoryListIterator *memoryListIteratorGet(MemoryList *list);
   MemoryListIterator *memoryListIteratorNext(MemoryList *list, MemoryListIterator *iterator);
   MemoryListEntry *memoryListIteratorGetValue(MemoryList *list, MemoryListIterator *ietartor);
   bool memoryListIteratorInsertAt(MemoryList *list, MemoryListIterator *iterator, const MemoryListEntry *entry);

   bool memoryListInsertSorted(MemoryList *list, const MemoryListEntry *entry);
   bool memoryListMergeSorted(MemoryList *list, const MemoryListEntry entry);

   void memoryListPrint(MemoryList *list);

#ifdef __cplusplus
}
#endif

#endif
