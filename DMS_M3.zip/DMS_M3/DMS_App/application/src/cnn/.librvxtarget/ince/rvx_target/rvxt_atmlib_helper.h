#ifndef __RVXT_ATMLIB_HELPER_H__
#define __RVXT_ATMLIB_HELPER_H__

#include "rcar-xos/atmlib/r_atmlib_types.h"

#ifdef __cplusplus
extern "C"
{
#endif

#if defined(RCAR_SOC_V3H1) || defined(RCAR_SOC_V3M2) || defined(RCAR_SOC_V3U)

    char *rvxt_atmlib_getErrorString(R_ATMLIB_RETURN_VALUE value);

#elif defined(RCAR_SOC_V3H2)
#endif

#ifdef __cplusplus
}
#endif

#endif
