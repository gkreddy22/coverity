/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

/**
 *    @file device_info.h
 * @version 1.00
 *    @date 06.09.2018
 *  @author Marius Dahlmanns
 *
 *   @brief Device specific information
 */

#ifndef APPLICATION_INC_DEVICE_INFO_H_
#define APPLICATION_INC_DEVICE_INFO_H_

/* HW specific settings */
#if defined(RCAR_SOC_V3U)
// #    pragma message("Stub! Using same value as for V3H!")
#define SPMC0_BASE (0xED600000)
#define SPMC0_SIZE (2 * 1024 * 1024)
#define SPMC1_BASE (0xED800000)
#define SPMC1_SIZE (2 * 1024 * 1024)
#define SPMC2_BASE (0xED400000)
#define SPMC2_SIZE (2 * 1024 * 1024)
#define SPMI0_BASE (0xED300000)
#define SPMI0_SIZE (1 * 1024 * 1024)
#define SPMI1_BASE (0xEDA00000)
#define SPMI1_SIZE (1 * 1024 * 1024)

#define IMPC_BASE (SPMC0_BASE)
#define IMPC_SIZE (SPMC0_SIZE)

#define IS_SPMC0(base) ((SPMC0_BASE <= base) && (base < SPMC0_BASE + SPMC0_SIZE))
#define IS_SPMC1(base) ((SPMC1_BASE <= base) && (base < SPMC1_BASE + SPMC1_SIZE))
#define IS_SPMC2(base) ((SPMC2_BASE <= base) && (base < SPMC2_BASE + SPMC2_SIZE))
#define IS_SPMI0(base) ((SPMI0_BASE <= base) && (base < SPMI0_BASE + SPMI0_SIZE))
#define IS_SPMI1(base) ((SPMI1_BASE <= base) && (base < SPMI1_BASE + SPMI1_SIZE))
#define IS_IMPC(base) (IS_SPMC0(base) || IS_SPMC1(base) || IS_SPMC2(base) || IS_SPMI0(base) || IS_SPMI1(base))
#define IS_IMPC_SHADOW(base) (IS_IMPC(base))
#elif defined(RCAR_SOC_V3M2)
#define IMPC_BASE (0xED000000U)
#define IMPC_SHADOW_BASE (0xED200000U)

#define IMPC_SIZE (896 * 1024)

#define CORE_CNN RCVDRV_CORE_CNN0
#define CORE_CNN_CH (RCVDRV_CNN_START_CORE + 0)
#define CORE_CNN_NAME "CNN0"

#define CORE_DMA RCVDRV_CORE_DMAC0
#define CORE_DMA_CH (RCVDRV_DMAC_START_CORE + 0)
#define CORE_DMA_NAME "DMA0"

#define CORE_CVE RCVDRV_CORE_OCV0
#define CORE_CVE_NAME "CVE0"
#define CORE_CVE_CH (RCVDRV_OCV_START_CORE + 0)
#define IS_IMPC(base) ((IMPC_BASE <= base) && (base < IMPC_BASE + IMPC_SIZE))
#define IS_IMPC_SHADOW(base) ((IMPC_SHADOW_BASE <= base) && (base < IMPC_SHADOW_BASE + IMPC_SIZE))

#elif defined(RCAR_SOC_V3H1) || defined(RCAR_SOC_V3H2)
#define IMPC_BASE (0xED000000U)
#define IMPC_SHADOW_BASE (0xED200000U)

#define IMPC_SIZE (2 * 1024 * 1024)

#define IS_IMPC(base) ((IMPC_BASE <= base) && (base < IMPC_BASE + IMPC_SIZE))
#define IS_IMPC_SHADOW(base) ((IMPC_SHADOW_BASE <= base) && (base < IMPC_SHADOW_BASE + IMPC_SIZE))

#else
#error "Driver architecture not set!"
#endif

#define IMP_BASE (0xFF900000U)
#define IMP_SIZE (0x00700000U)

#define DDR0_SIZE (0x2000000) /* default size of DDR memory, adapt to output of cnnip_xml_reader */

/*
 * Helper macros
 */

#define IS_IMP(base) ((base >= IMP_BASE) && ((uintptr_t)base < ((uintptr_t)IMP_BASE + (uintptr_t)IMP_SIZE)))

#endif /* APPLICATION_INC_DEVICE_INFO_H_ */
