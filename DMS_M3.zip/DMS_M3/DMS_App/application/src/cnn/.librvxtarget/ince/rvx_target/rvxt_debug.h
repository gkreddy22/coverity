#ifndef __RVXT_DEBUG_H__
#define __RVXT_DEBUG_H__

//#include "rcv_impdrv.h"
#include "rcar-xos/imp/r_impdrv.h"
#include "rcar-xos/osal/r_osal.h"

/*!
 * Shows a traceback of all IPs set in core_info.
 * @param rcvdrv_ctl
 * @param core_info
 */
void rvxt_debug(RCvIMPDRVCTL* rcvdrv_ctl, const RCvIMPDRVCOREINFO* const core_info);

#endif
