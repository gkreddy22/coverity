/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

/**
 *    @file ui.h
 * @version 1.00
 *    @date 05.09.2018
 *  @author Marius Dahlmanns
 *
 *   @brief Macros for unified UI output
 *
 */

#ifndef RVX_TARGET_INC_UI_H_
#define RVX_TARGET_INC_UI_H_

#include <stdio.h>

#ifndef __FILE__
#define __RVXTUI_FILE "<N/A>"
#else
#define __RVXTUI_FILE __FILE__
#endif

#ifndef __FUNCTION__
#if defined __func__
#define __RVXTUI__FUNCTION__ __func__
#elif defined __PRETTY_FUNCTION__
#define __RVXTUI__FUNCTION__ __PRETTY_FUNCTION__
#else
#define __RVXTUI__FUNCTION__ ""
#endif
#else
#define define __RVXTUI__FUNCTION__ __FUNCTION__
#endif

#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)

#define __RVX_CODE_POSITION__ __RVXTUI_FILE ":" __RVXTUI__FUNCTION__ "@" TOSTRING(__LINE__)

#define __OK_PREFIX "[OK] "

#define cok(msg) fprintf(stdout, __OK_PREFIX msg)
//#define cinfo(msg) fprintf(stdout, "[II] " msg)
#define cinfo(msg)
#define cline(msg) fprintf(stdout, "     " msg)
#define cerror(msg) fprintf(rvxtui_get_stderr(), "[!!] %s %s", __RVX_CODE_POSITION__, msg)
#define cwarning(msg) fprintf(stdout, "[WW] " msg)

#define cokv(msg, ...) fprintf(stdout, "[OK] " msg, __VA_ARGS__)
//#define cinfov(msg, ...) fprintf(stdout, "[II] " msg, __VA_ARGS__)
#define cinfov(msg, ...)
#define clinev(msg, ...) fprintf(stdout, "     " msg, __VA_ARGS__)

#define __ERROR_PREFIX "[!!] "
#define __SPACE " "
#define __NEWLINE "\n"
#define cerrorv(msg, ...) fprintf(rvxtui_get_stderr(), __ERROR_PREFIX __RVX_CODE_POSITION__ __SPACE #msg __NEWLINE, __VA_ARGS__)

#define cwarningv(msg, ...) fprintf(stdout, "[WW] " msg, __VA_ARGS__)

#ifdef __cplusplus
extern "C"
{
#endif

    /*!
 *@brief Set file descriptor for error output.
 */
    void rvxtui_set_stderr(FILE *const p_file);

    /*!
 *@brief Get file descriptor for error output.
 *@details Defaults to stdout, may be set to stderr or different.
 */
    FILE *rvxtui_get_stderr(void);

#ifdef __cplusplus
}
#endif

#endif /* RVX_TARGET_INC_UI_H_ */
