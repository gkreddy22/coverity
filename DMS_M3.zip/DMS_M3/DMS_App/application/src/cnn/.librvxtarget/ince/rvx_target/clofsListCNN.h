#ifndef __CLOFSLISTCNN_H__
#define __CLOFSLISTCNN_H__

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "list.h"

#include "rcar-xos/atmlib/r_atmlib_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    size_t dmai[R_ATMLIB_CNN_DMAI_MAX_CH];
    size_t dmao[R_ATMLIB_CNN_DMAO_MAX_CH];
    size_t dmac[R_ATMLIB_CNN_DMAC_MAX_CH];
} ClofsListCNNEntryMems_t;

typedef struct
{
    R_ATMLIB_CNNCLofs_ImageAddr clofs;
    ClofsListCNNEntryMems_t     mems;
} ClofsListCNNEntry_t;

typedef List                ClofsListCNN;
typedef ListIterator        ClofsListCNNIterator;
typedef ClofsListCNNEntry_t ClofsListCNNEntry;

/*!
 * @brief Append an entry to list.
 */
ClofsListCNNEntry* clofsListCNNAppend(ClofsListCNN* list, const ClofsListCNNEntry* entry);

/*!
 * @brief Create list.
 */
ClofsListCNN* clofsListCNNCreate(void);

/*!
 * @brief Destroy list.
 */
void clofsListCNNFree(ClofsListCNN* list);

ClofsListCNNIterator* clofsListCNNIteratorGet(ClofsListCNN* list);
ClofsListCNNIterator* clofsListCNNIteratorNext(ClofsListCNN* list, ClofsListCNNIterator* iterator);
ClofsListCNNEntry*    clofsListCNNIteratorGetValue(ClofsListCNN* list, ClofsListCNNIterator* iterator);
size_t                clofsListCNNSize(ClofsListCNN* list);
#ifdef __cplusplus
}
#endif

//#endif
#endif
