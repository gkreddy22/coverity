#ifndef _RVXT_BCL_H_
#define _RVXT_BCL_H_

#include "bcl.h"
#include "r_cl_patch_helper.h"
#include "stringList.h"

/* OSAL API*/
#include "rcar-xos/osal/r_osal.h"

#ifdef __cplusplus
extern "C" {
#endif

/*!
 * @brief Print some details about BCL file.
 * @param data Pointer to BCL.
 * @param size Size of BCL.
 * @return true on success.
 */
bool rvxt_bcl_print(void* data, const size_t size, unsigned int verbosity);

/*!
 * @brief Run a BCL on CNNIP.
 * @details Runs a given BCL file on the CNNIP using rcv_impdrv.
 * @details This function also does all memory allocation, CL patching and result checking.
 * @param data Pointer to BCL.
 * @param size Size of BCL.
 * @return True on success.
 */
bool rvxt_bcl_run(void* data, const size_t size);
bool rvxt_bcl_alloc(void* data, const size_t size, MemoryList* list, osal_memory_manager_handle_t handle_osalmmngr, osal_axi_bus_id_t imp_dev_axi_bus_id, const uint32_t cl_alloc_alignment);

bcl_mem_exit_t*  rvxt_bcl_getExitMemory(void* data, const size_t size, const size_t index);
bcl_mem_entry_t* rvxt_bcl_getEntryMemory(void* data, const size_t size, const size_t index);

bool rvxt_bcl_setupInputMemories(void* data, const size_t size, const bool verbose, MemoryList* list, const uint32_t memories_alloc_alignment);
bool rvxt_bcl_check_entry(void* data, const size_t data_size, const bool verbose, osal_memory_manager_handle_t img_buffer, MemoryList* list);
bool rvxt_bcl_check_exit(void* data, const size_t size, const bool verbose, osal_memory_manager_handle_t handle_osalmmngr, MemoryList* list);

bool rvxt_bcl_fixMemoryAddresses(void* data, const size_t size, const uintptr_t base_old, const uintptr_t base_new, const size_t base_size);

/*!
 * @brief Read string list from BCL file.
 */
bool  rvxt_bcl_parseStringList(void* data, const size_t size, StringList* stringList);
char* rvxt_bcl_getEntryMemoryName(void* data, const size_t size, const size_t index);
char* rvxt_bcl_getExitMemoryName(void* data, const size_t size, const size_t index);

#ifdef __cplusplus
}
#endif

#endif
