#ifndef __RVXT_STRING_HELPER_H__
#define __RVXT_STRING_HELPER_H__

char* rvxt_strdup(const char* str);
char* rvxt_sprintf_dup(char* str, ...);
char* rvxt_to_lower(char* str);

#endif
