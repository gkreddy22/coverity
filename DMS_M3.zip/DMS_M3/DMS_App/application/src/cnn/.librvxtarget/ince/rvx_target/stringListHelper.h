#ifndef __STRINGLISTHELPER_H__
#define __STRINGLISTHELPER_H__

#include "stringList.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/*!
 * @brief Dump StringList to file
 * @param fp
 * @param stringList
 * @return
 */
size_t writeStringList(FILE* fp, StringList* stringList);

/*!
 * @brief Calculate size of StringList if dumped to file.
 * @param stringList
 * @return
 */
size_t calculateStringListFileSize(StringList* stringList);

#endif
