#ifndef __STRINGLIST_H__
#define __STRINGLIST_H__

#include "list.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef List         StringList;
typedef ListIterator StringListIterator;
typedef char         StringListEntry;

/*!
 * @brief Append an entry to list.
 */
StringListEntry* stringListAppend(StringList* list, const char* string);

/*!
 * @brief Create list.
 */
StringList* stringListCreate(void);

/*!
 * @brief Create list and fill it.
 */
StringList* stringListCreateFromString(const char* const p_string, const char* separators);

/*!
 * @brief Destroy list.
 */
void stringListFree(StringList* list);

/*!
 * @brief Get size of list
 */
size_t stringListSize(StringList* list);

/*!
 * @brief Get element at position index.
 */
char* stringListAt(StringList* list, size_t index);

StringListIterator* stringListIteratorGet(StringList* list);
StringListIterator* stringListIteratorGetLast(StringList* list);
StringListIterator* stringListIteratorGetEnd(StringList* list);
StringListIterator* stringListIteratorNext(StringList* list, StringListIterator* iterator);
char*               stringListIteratorGetValue(StringList* list, StringListIterator* iterator);
bool                stringListIteratorInsertBefore(StringList* list, StringListIterator* iterator, const char* str);
bool                stringListIteratorInsertAfter(StringList* list, StringListIterator* iterator, const char* str);
void                stringListPrint(StringList* list);
bool                stringListAppendUnique(StringList* list, const char* str);
bool                stringListAppendList(StringList* list, StringList* appendList);

#ifdef __cplusplus
}
#endif

#endif
