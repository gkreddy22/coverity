#ifndef __CHANNELSETUPLIST__
#define __CHANNELSETUPLIST__

#include "list.h"
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _ChannelSetupListEntry
{
    char* dst_name_channel;
    //char* src_name_file;
    char* src_name_file;
    int   src_id_channel;
    int   dst_id_channel;
} ChannelSetupListEntry;

typedef List         ChannelSetupList;
typedef ListIterator ChannelSetupListIterator;

/*!
 * @brief Append an entry to list.
 */
ChannelSetupListEntry* channelSetupListAppend(ChannelSetupList* list, const ChannelSetupListEntry* entry);

/*!
 * @brief Create list.
 */
ChannelSetupList* channelSetupListCreate(void);

/*!
 * @brief Destroy list.
 */
void channelSetupListFree(ChannelSetupList* list);

ChannelSetupListEntry* channelSetupListNext(ChannelSetupListEntry* entry);

/*!
 * @brief Get size of list
 */
size_t channelSetupListSize(ChannelSetupList* list);

/*!
 * @brief Get element at position index.
 */
ChannelSetupListEntry* channelSetupListAt(ChannelSetupList* list, size_t index);

ChannelSetupListIterator* channelSetupListIteratorGet(ChannelSetupList* list);
ChannelSetupListIterator* channelSetupListIteratorNext(ChannelSetupList* list, ChannelSetupListIterator* iterator);
ChannelSetupListIterator* channelSetupListIteratorEnd(ChannelSetupList* list);
ChannelSetupListEntry*    channelSetupListIteratorGetValue(ChannelSetupList* list, ChannelSetupListIterator* ietartor);
bool                      channelSetupListIteratorInsertAt(ChannelSetupList* list, ChannelSetupListIterator* iterator, const ChannelSetupListEntry* entry);
void                      channelSetupListPrint(ChannelSetupList* list);

#ifdef __cplusplus
}
#endif

#endif
