#if defined(__STDC_LIB_EXT1__)
#if (__STDC_LIB_EXT1__ >= 201112L)
#define USE_EXT1 1
#define __STDC_WANT_LIB_EXT1__ 1 /* Want the ext1 functions */
#endif
#endif

#include <getopt.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "include/helper.h"
#include ".librvxtarget/ince/rvx_target/channelSetupList.h"
#include ".librvxtarget/ince/rvx_target/imageHelper.h"
#include ".librvxtarget/ince/rvx_target/osal_helper.h"
#include ".librvxtarget/ince/rvx_target/rvx_target.h"
#include ".librvxtarget/ince/rvx_target/rvxt_bcl.h"
#include ".librvxtarget/ince/rvx_target/stringList.h"
#include ".librvxtarget/ince/rvx_target/ui.h"

#include "include/osal_debug.h"
#include "common.h"

#define DST_ID_CL -1
#define SRC_ID_CL 0

typedef struct __dst_chnl
{
    char name[50];

} _dst_chnl;

/*Channel name helper table*/
static _dst_chnl dst_chnl[NUM_CNN_CHANNELS] = {0};

static osal_memory_buffer_handle_t getbufobj_listentry (uint32_t physaddr, MemoryList * list, uint32_t * offset);

static osal_memory_buffer_handle_t getbufobj_listentry(uint32_t physaddr, MemoryList * list, uint32_t * offset)
{
    //uint32_t listSize = memoryListSize(list);
    MemoryListIterator * it = memoryListIteratorGet(list);

    while (NULL != it)
    {
        MemoryListEntry * e = memoryListIteratorGetValue(list, it);
        //cinfov("addressNew: %p, size: %08x, physaddr: %08x\n", (void *)e->addressNew, e->size, physaddr);

        if (e->addressNew <= physaddr && physaddr < e->addressNew + e->size)
        {
            *offset = (uint32_t)(physaddr - e->addressNew);

            //cinfov("offset: %08x\n", *offset);
            return e->base_new_buffer;
        }

        it = it->next;
    }

    return NULL;
}

bool R_CNN_entrychannels_set(_CnnChannelDetails *CnnChannelDetails, int CnnChannelCount)
{
    bool result = true;
    do
    {
        if (NULL == CnnChannelDetails)
        {
            result = false;
            break;
        }
        for (size_t i = 0; i < CnnChannelCount; i++)
        {

            result &= setupChannelFromData(
                CnnChannelDetails[i].p_virt,
             (const size_t)CnnChannelDetails[i].width,
            (const size_t)CnnChannelDetails[i].height,
            (const unsigned int)CnnChannelDetails[i].bytesPerPixel,
            (const unsigned int)CnnChannelDetails[i].channel, 
            (void*)cnn_in
            );
        }      
    }while(0);
   
    return result;
}

bool setupChannels(rvxt_info_pb_t *pbinfo, ChannelSetupList *p_channelSetupList, MemoryList *p_memoryList,
                                                                 _CnnChannelDetails *CnnChannelDetails, int CnnChannelCount)
{
    size_t count = channelSetupListSize(p_channelSetupList);
    bool result  = true;
    uint8_t channelCount = 0;
    for (size_t i = 0; i < pbinfo->entry_memories_count; i++)
    {
        const char * entryName = pbinfo->entry_memories[i].name;
        ChannelSetupListIterator * it = channelSetupListIteratorGet(p_channelSetupList);

        while (NULL != it)
        {
            ChannelSetupListEntry * e = channelSetupListIteratorGetValue(p_channelSetupList, it);
            char _name[256];

            if (-1 == e->dst_id_channel)
            {
                snprintf(_name, 256, "%s", e->dst_name_channel);
            }
            else
            {
                snprintf(_name, 256, "%s(%i)", e->dst_name_channel, e->dst_id_channel);
            }

            if (0 == strcmp(entryName, _name))
            {
                const char * channelName = _name;
                //void *p_virt = NULL;
                uint32_t offset;

                osal_memory_buffer_handle_t bufobj = getbufobj_listentry(pbinfo->entry_memories[i].base, p_memoryList, &offset);

                if (bufobj != OSAL_MEMORY_BUFFER_HANDLE_INVALID)
                {
                    //CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufobj, &p_virt)));
                    CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr(bufobj, &CnnChannelDetails[channelCount].p_virt)));

                   // p_virt = ((char *)p_virt + offset);
                    CnnChannelDetails[channelCount].p_virt = ((char *)CnnChannelDetails[channelCount].p_virt + offset);

                }
                
                //const size_t width = pbinfo->entry_memories[i].tile.width;
                CnnChannelDetails[channelCount].width = pbinfo->entry_memories[i].tile.width;
                //convert to 2D
                //const size_t height = pbinfo->entry_memories[i].tile.height * pbinfo->entry_memories[i].channelCnt;
                CnnChannelDetails[channelCount].height = pbinfo->entry_memories[i].tile.height * pbinfo->entry_memories[i].channelCnt;
                
                //const unsigned int bytesPerPixel = pbinfo->entry_memories[i].tile.bitpp / 8;
                 CnnChannelDetails[channelCount].bytesPerPixel = pbinfo->entry_memories[i].tile.bitpp / 8;
                 CnnChannelDetails[channelCount].channel = channelCount;
                count--;
                channelCount++;
                
                if (CnnChannelCount < channelCount)
                {
                    break;
                }
            }
            it = channelSetupListIteratorNext(p_channelSetupList, it);
        }
    }

    if (0 != count)
    {
        cerrorv("Not all memories were set up as requested (missing: %u)! Mismatch in channel name?\n", (unsigned int)count);
        return false;
    }

    return result;
}

/*!
 * @brief Fill channelSetupList based on entries in list.
 * @param p_channelSetupList
 * @param list
 * @return
 */
bool fillChannelSetupList(ChannelSetupList * p_channelSetupList)
{
    bool retVal = true;
    uint8_t count = 0;
    
    do
    {
        if (NULL == p_channelSetupList)
        {
            retVal = false;
            break;
        }
        while (count < g_customize.CNN_NumberOfChannels) /*3 channels*/
        {
            ChannelSetupListEntry entry;
            sprintf(dst_chnl[count].name, "%s(%d)", g_customize.CNN_ChannelName, count);
            entry.dst_name_channel = dst_chnl[count].name;
            entry.dst_id_channel = DST_ID_CL;
            entry.src_id_channel = SRC_ID_CL;
            channelSetupListAppend(p_channelSetupList, &entry);
            count++;
        }
    } while(0);

    return retVal;
}

static e_osal_return_t configureIODevice(char * p_reg_dev_name, osal_device_handle_t * p_spmDevice)
{
    e_osal_return_t ret_osal = OSAL_CHECK(R_OSAL_IoDeviceOpen(p_reg_dev_name, p_spmDevice));

    if (OSAL_RETURN_OK != ret_osal)
    {
        return ret_osal;
    }

    ret_osal = OSAL_CHECK(R_OSAL_PmSetPolicy(* p_spmDevice, OSAL_PM_POLICY_HP, true));
    //if (R_OSAL_PmSetPolicy(* p_spmDevice, OSAL_PM_POLICY_HP, true) != ret_osal)

    if (OSAL_RETURN_OK != ret_osal)
    {
        (void)OSAL_CHECK(R_OSAL_IoDeviceClose(* p_spmDevice));
        * p_spmDevice = OSAL_DEVICE_HANDLE_INVALID;
        return ret_osal;
    }

    ret_osal = OSAL_CHECK(R_OSAL_PmSetRequiredState(* p_spmDevice, OSAL_PM_REQUIRED_STATE_REQUIRED, true));

    if (OSAL_RETURN_OK != ret_osal)
    {
        (void)OSAL_CHECK(R_OSAL_IoDeviceClose(* p_spmDevice));
        * p_spmDevice = OSAL_DEVICE_HANDLE_INVALID;
        return ret_osal;
    }

    ret_osal = OSAL_CHECK(R_OSAL_PmSetResetState(* p_spmDevice, OSAL_PM_RESET_STATE_RELEASED));

    if (OSAL_RETURN_OK != ret_osal)
    {
        (void)OSAL_CHECK(R_OSAL_IoDeviceClose(* p_spmDevice));
        * p_spmDevice = OSAL_DEVICE_HANDLE_INVALID;
        return ret_osal;
    }
         
    CHECK_OK(OSAL_CHECK(R_OSAL_ThreadSleepForTimePeriod(10)));
    return ret_osal;
}
/*!
 * @brief Patch CL for CNN-IP
 * @details Interprets CL to identify WPR to DMAxSA
 * @details Changes all address in the range [base_old,base_old+size) -> [base_new,base_new+size)
 * @param p_data Pointer to CL
 * @param base_old Base address of old address base
 * @param base_new Base address of new address base
 * @param size Size of address range to consider.
 * @return
 */
bool pb_cl_patch_DMA(const pb_cmdl_info_t cml_info, void * p_data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose)
{
    /* based on cl_step of r_IDMA_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */
    uint32_t * inst = (uint32_t *)p_data;

    for (unsigned int k = 0; k < cml_info.clofs_size; k++)
    {
        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_IDMA_CL_CMDID(* inst);

        if (cml_info.clofs[k].cl_offset > cml_info.cl_data_size)
        {
            cerrorv("cl_offset(0x%08x) is higher than cl_data_size(0x%08x) !\n", (unsigned int)cml_info.clofs[k].cl_offset, (unsigned int)cml_info.cl_data_size);
            return false;
        }

        uint32_t * inst = (uint32_t *)p_data + cml_info.clofs[k].cl_offset;
        const uintptr_t address_old = *inst;

        if ((address_old >= base_old) && (address_old < (base_old + size)))
        {
            const uintptr_t address_new = base_new + address_old - base_old;

            if (verbose)
                cinfov("Fixing write from 0x%08x to 0x%08x.\n", (unsigned int)(address_old), (unsigned int)address_new);
            *inst = (uint32_t)address_new;
        }
        else
        {
            if (verbose)
                cinfo("Address not in range, ignoring\n");
        }
        // }

        switch (cmd)
        {
        case R_IDMA_CL_WPR:
            break;

        case R_IDMA_CL_SYNCS:
            break;

        case R_IDMA_CL_SYNCCC:
            break;

        case R_IDMA_CL_SYNCCF:
            break;

        case R_IDMA_CL_INT:
            break;

        case R_IDMA_CL_TRAP:

            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_IDMA_CL_WUP:

            if (verbose)
                DEBUG_PRINT("   WUP[0xA0]: %d  0x%04x .\n", (unsigned int)R_IDMA_CL_WPR_N(*inst), (unsigned int)R_IDMA_CL_WPR_ADDR(*inst));

            break;
        case R_IDMA_CL_SLP:

            if (verbose)
                DEBUG_PRINT("   SLP[0xA1]: %d  0x%04x .\n", (unsigned int)R_IDMA_CL_WPR_N(*inst), (unsigned int)R_IDMA_CL_WPR_ADDR(*inst));
            break;

        case R_IDMA_CL_JUMP:
            cerror("JUMP is not supported!.\n");
            return false;
            break;

        case R_IDMA_CL_GOSUB:
            cerror("GOSUB is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_RET:
            cerror("RET is not supported!\n");
            return false;
            break;

        case R_IDMA_CL_NOP:
            break;

        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
    }
    return true;
}

bool pb_cl_patch_CNN_patchGOSUB(const pb_cmdl_info_t cml_info, void * p_data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    //uint32_t *    inst     = (uint32_t*)p_data;

    for (unsigned int k = 0; k < cml_info.clofs_size; k++)
    {
        uint32_t * inst = (uint32_t *)p_data + cml_info.clofs[k].cl_offset;

        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_BRC:
        {
            uint8_t cond = R_CNNIP_CL_BRC_COND(*inst);

            if (R_CNNIP_BRC_ALWAYS == cond)
            {
                uint32_t offset = SIGN_EXT16(R_CNNIP_CL_BRC_DIST(*inst), 13);
                inst += offset;
                continue;
            }
            else
            {
                cwarning("BRC ignored, stepping over.\n");
            }

            break;
        }

        case R_CNNIP_CL_WPR:
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
            break;
        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:

            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
            break;
        case R_CNNIP_CL_SLP:
            break;
        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:
            cerror("JUMP is not supported!.\n");
            return false;
            break;

        case R_CNNIP_CL_GOSUB:
            cinfo("Patching GOSUB!\n");
            const uintptr_t address_old = inst[1];

            if ((address_old >= base_old) && (address_old < (base_old + size)))
            {
                const uintptr_t address_new = base_new + address_old - base_old;

                if (verbose)
                    cinfov("Fixing write from 0x%08x to 0x%08x.\n", (unsigned int)(address_old), (unsigned int)address_new);
                inst[1] = (uint32_t)address_new;
            }

            break;

        case R_CNNIP_CL_RET:
            cerror("RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)! \n", (unsigned int)*inst);
            return false;
        }
    }
    return true;
}

/*!
 * @brief Patch CL for CNN-IP
 * @details Interprets CL to identify WPR to DMAxSA
 * @details Changes all address in the range [base_old,base_old+size) -> [base_new,base_new+size)
 * @param p_data Pointer to CL
 * @param base_old Base address of old address base
 * @param base_new Base address of new address base
 * @param size Size of address range to consider.
 * @return
 */
bool pb_cl_patch_CNN(const pb_cmdl_info_t cml_info, void * p_data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose)
{
    /* based on cl_step of r_cnnip_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t * inst = (uint32_t *)p_data;

    unsigned int error_cnt_jump  = 0;
    unsigned int error_cnt_gosub = 0;

    for (unsigned int k = 0; k < cml_info.clofs_size; k++)
    {
        uint8_t cmd = R_CNNIP_CL_CMDID(*inst);

        if (cml_info.clofs[k].cl_offset > cml_info.cl_data_size)
        {
            cerrorv("cl_offset(0x%08x) is higher than cl_data_size(0x%08x) !\n", (unsigned int)cml_info.clofs[k].cl_offset, (unsigned int)cml_info.cl_data_size);
            return false;
        }

        uint32_t * inst = (uint32_t *)p_data + cml_info.clofs[k].cl_offset;
        const uintptr_t address_old = *inst;

        if ((address_old >= base_old) && (address_old < (base_old + size)))
        {
            const uintptr_t address_new = base_new + address_old - base_old;

            if (verbose)
                cinfov("Fixing write from 0x%08x to 0x%08x.\n", (unsigned int)(address_old), (unsigned int)address_new);
            * inst = (uint32_t)address_new;
        }
        else
        {
            if (verbose)
                cinfo("Address not in range, ignoring\n");
        }

        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        switch (cmd)
        {
        case R_CNNIP_CL_ADD:
            break;
        case R_CNNIP_CL_SUB:
            break;
        case R_CNNIP_CL_WR:
            break;
        case R_CNNIP_CL_WRI:
            break;

        case R_CNNIP_CL_WPR:
            break;

        case R_CNNIP_CL_CLW:
            break;
        case R_CNNIP_CL_CLUVT:
            break;
        case R_CNNIP_CL_SYNCS:
            break;
        case R_CNNIP_CL_INT:
            break;

        case R_CNNIP_CL_TRAP:

            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CNNIP_CL_WUP:
            break;
        case R_CNNIP_CL_SLP:
            break;
        case R_CNNIP_CL_SCRES:
            break;
        case R_CNNIP_CL_SCCHK:
            break;

        case R_CNNIP_CL_JUMP:

            if (error_cnt_jump == 0)
                cerror("JUMP is not supported! Stepping over, you have been warned!\n");
            error_cnt_jump++;
            break;

        case R_CNNIP_CL_GOSUB:

            if (error_cnt_gosub == 0)
                cerror("GOSUB is not supported! Stepping over, you have been warned!\n");
            error_cnt_gosub++;
            break;

        case R_CNNIP_CL_RET:
            cerror("RET is not supported!\n");
            return false;
            break;

        case R_CNNIP_CL_TUV2UVT:
            break;
        case R_CNNIP_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
    }
    return true;
}

/*!
 * @brief Patch CL for CNN-IP
 * @details Interprets CL to identify WPR to DMAxSA
 * @details Changes all address in the range [base_old,base_old+size) -> [base_new,base_new+size)
 * @param p_data Pointer to CL
 * @param base_old Base address of old address base
 * @param base_new Base address of new address base
 * @param size Size of address range to consider.
 * @return
 */
bool pb_cl_patch_CVE(const pb_cmdl_info_t cml_info, void * p_data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose)
{
    /* based on cl_step of r_CVE_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t * inst = (uint32_t *)p_data;

    for (unsigned int k = 0; k < cml_info.clofs_size; k++)
    {

        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd = R_CVE_CL_CMDID(*inst);

        uint32_t * inst = (uint32_t *)p_data + cml_info.clofs[k].cl_offset;
        const uintptr_t address_old = * inst;

        if ((address_old >= base_old) && (address_old < (base_old + size)))
        {
            const uintptr_t address_new = base_new + address_old - base_old;

            if (verbose)
                cinfov("Fixing write from 0x%08x to 0x%08x.\n", (unsigned int)(address_old), (unsigned int)address_new);
            * inst = (uint32_t)address_new;
        }
        else
        {
            // if (verbose)
            //     cinfo("Address not in range, ignoring\n");
            const uintptr_t address_new = base_new + address_old - base_old;

            if (verbose)
                cinfov("NOT fixing write from 0x%08x to 0x%08x. (address out of range)\n", (unsigned int)(address_old), (unsigned int)address_new);
        }

        switch (cmd)
        {
        case R_CVE_CL_WPR:
            break;

        case R_CVE_CL_RECT:
            inst += 4;
            break;

        case R_CVE_CL_SYNCM:
            break;
        case R_CVE_CL_SYNCS:
            break;
        case R_CVE_CL_INT:
            break;

        case R_CVE_CL_TRAP:

            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_CVE_CL_WUP:
            break;
        case R_CVE_CL_SLP:
            break;

        case R_CVE_CL_JUMP:
            cerror("JUMP is not supported!\n");
            return false;
            break;

        case R_CVE_CL_GOSUB:
            cerror("GOSUB is not supported!\n");
            return false;
            break;

        case R_CVE_CL_RET:
            cerror("RET is not supported!\n");
            return false;
            break;

        case R_CVE_CL_NOP:
            break;
        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
    }
    return true;
}

/*!
 * @brief Patch CL for CNN-IP
 * @details Interprets CL to identify WPR to DMAxSA
 * @details Changes all address in the range [base_old,base_old+size) -> [base_new,base_new+size)
 * @param p_data Pointer to CL
 * @param base_old Base address of old address base
 * @param base_new Base address of new address base
 * @param size Size of address range to consider.
 * @return
 */
bool pb_cl_patch_IMP(const pb_cmdl_info_t cml_info, void * p_data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose)
{
    /* based on cl_step of r_CVE_drv */
    /* GOSUB, RET, JUMP are not supported */
    /* BRC is ignored */

    uint32_t * inst = (uint32_t *)p_data;

    for (unsigned int k = 0; k < cml_info.clofs_size; k++)
    {

        if (verbose)
            DEBUG_PRINT("[0x%16p] 0x%08x\n", (void *)inst, (unsigned int)*inst);

        uint8_t cmd     = (unsigned char)R_IMP_CL_CMDID(*inst);

        uint32_t * inst = (uint32_t *)p_data + cml_info.clofs[k].cl_offset;
        const uintptr_t address_old = *inst;

        if ((address_old >= base_old) && (address_old < (base_old + size)))
        {
            const uintptr_t address_new = base_new + address_old - base_old;

            if (verbose)
                cinfov("Fixing write from 0x%08x to 0x%08x.\n", (unsigned int)(address_old), (unsigned int)address_new);
            *inst = (uint32_t)address_new;
        }
        else
        {

            if (verbose)
                cinfo("Address not in range, ignoring\n");
            const uintptr_t address_new = base_new + address_old - base_old;

            if (verbose)
                cinfov("NOT fixing write from 0x%08x to 0x%08x. (address out of range)\n", (unsigned int)(address_old), (unsigned int)address_new);
        }

        switch (cmd)
        {
        case R_IMP_CL_MOV:
            break;

        case R_IMP_CL_SYNCM:
            break;

        case R_IMP_CL_INT:
            break;

        case R_IMP_CL_TRAP:

            if (verbose)
                cinfo("TRAP reached, done with patching.\n");
            return true;

        case R_IMP_CL_WUP:

            if (verbose)
                DEBUG_PRINT("   WUP[0x48]: %d  0x%04x .\n", (unsigned int)R_IMP_CL_WPR_N(*inst), (unsigned int)R_IMP_CL_WPR_ADDR(*inst));

            break;

        case R_IMP_CL_SLP:

            if (verbose)
                DEBUG_PRINT("   SLP[0x49]: %d  0x%04x .\n", (unsigned int)R_IMP_CL_WPR_N(*inst), (unsigned int)R_IMP_CL_WPR_ADDR(*inst));
            break;

        case R_IMP_CL_GOSUB:
            cerror("GOSUB is not supported!\n");
            return false;
            break;

        case R_IMP_CL_NOP:
            break;

        default:
            cerrorv("Invalid instruction (0x%08x)!\n", (unsigned int)*inst);
            return false;
        }
    }
    return true;
}
