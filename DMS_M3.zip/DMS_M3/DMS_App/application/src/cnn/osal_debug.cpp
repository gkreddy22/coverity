#include <map>

#include "rcar-xos/osal/r_osal.h"

#include "include/osal_debug.h"

#undef R_OSAL_MmngrAlloc
#undef R_OSAL_MmngrDealloc

static std :: map<osal_memory_buffer_handle_t, size_t const> memory_buffer_handles;

e_osal_return_t __OSAL_MmngrAlloc(osal_memory_manager_handle_t const hndl_mmngr,
                                  size_t const size,
                                  size_t const alignment,
                                  osal_memory_buffer_handle_t * const p_buffer_obj)
{
    e_osal_return_t result = OSAL_RETURN_OK;

    result = R_OSAL_MmngrAlloc(hndl_mmngr, size, alignment, p_buffer_obj);

    if (OSAL_RETURN_OK == result)
    {
        memory_buffer_handles.insert(std :: make_pair(* p_buffer_obj, size));
    }

    return result;
}

e_osal_return_t __OSAL_MmngrDealloc(osal_memory_manager_handle_t hndl_mmngr,
                                    osal_memory_buffer_handle_t buffer_obj)
{
    e_osal_return_t result = OSAL_RETURN_OK;

    result = R_OSAL_MmngrDealloc(hndl_mmngr, buffer_obj);

    if (OSAL_RETURN_OK == result)
    {
        memory_buffer_handles.erase(buffer_obj);
    }

    return result;
}

bool findCpuPtrFromHwPtr(uintptr_t hwAddress, osal_axi_bus_id_t imp_dev_axi_bus_id, void ** p_cpu_ptr)
{
    for (auto const &[handle, size] : memory_buffer_handles)
    {
        void * p_virt = nullptr;

        R_OSAL_MmngrGetCpuPtr(handle, &p_virt);
        uintptr_t hw_ptr = 0;
        R_OSAL_MmngrGetHwAddr(handle, imp_dev_axi_bus_id, &hw_ptr);

        if ((hw_ptr <= hwAddress) && (hwAddress < (hw_ptr + size)))
        {
            *p_cpu_ptr = (void *)((uintptr_t)p_virt + (hwAddress - hw_ptr));
            return true;
        }

    }
    return false;
}
