#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include <fcntl.h>
#include <sys/mman.h>  /* for mmap */
#include <sys/stat.h>  /* for open */
#include <sys/types.h> /* for open */
#include <unistd.h>    /* for close */

#include "rcar-xos/osal/r_osal.h"

#define DEVNAME_MEM "/dev/mem"

#define IOAREA_SIZE (0x20000000U)
#define IOAREA_BASE (0xE0000000U)

static int      mem_fd     = -1;
static uint64_t ioAreaBase = 0;

#define WRITE_REG32(addr, value) \
    *((volatile uint32_t*)((uint64_t)(ioAreaBase + addr - IOAREA_BASE))) = value

#define WRITE_REG64(addr, value) \
    *((volatile uint64_t*)((uint64_t)(ioAreaBase + addr - IOAREA_BASE))) = value

#define READ_REG32(addr) \
    *((volatile uint32_t*)((uint64_t)(ioAreaBase + addr - IOAREA_BASE)))

#define READ_REG64(addr) \
    *((volatile uint64_t*)((uint64_t)(ioAreaBase + addr - IOAREA_BASE)))

static bool _open()
{
    /* open /dev/mem */
    mem_fd = open(DEVNAME_MEM, O_RDWR);
		
    if (mem_fd < 0)
    {
        return false;
    }

    /* get device infomation */
    ioAreaBase = (uint64_t)mmap(NULL, IOAREA_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd, IOAREA_BASE);

    return true;
}

static bool _close()
{
    munmap((void *)ioAreaBase, IOAREA_SIZE);
    close(mem_fd);
    mem_fd = -1;

    return true;
}

bool fix_V3U1()
{
    bool result = _open();

    if (result)
    {
        WRITE_REG32(0xff902000U, 0x0000000aU);
        WRITE_REG32(0xffa8e000U, 0x0000000aU);
        WRITE_REG32(0xffb8e000U, 0x0000000cU);
        WRITE_REG32(0xffab2000U, 0x00000009U);
        WRITE_REG32(0xffad2000U, 0x0000000aU);
        WRITE_REG32(0xffbd2000U, 0x0000000cU);
        /*
    WRITE_REG32(0xffbd21a0U, 0x00000044U);
    WRITE_REG32(0xffbd21a4U, 0x00000044U);
    WRITE_REG32(0xffbd21a8U, 0x00000044U);
    WRITE_REG32(0xffbd21acU, 0x00000044U);
    */
        result = result && _close();
    }

    return result;
}