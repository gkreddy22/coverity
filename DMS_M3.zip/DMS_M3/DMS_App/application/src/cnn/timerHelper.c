#include <stddef.h>
#include <stdint.h>

#include "include/timerHelper.h"

uint64_t getSystimerValTick(void)
{
    uint64_t curr = 0;
#if !defined(__x86_64__)
    __asm__ volatile("isb;mrs %0, cntpct_el0"
                     : "=r"(curr));
#endif
    return curr;
}

uint32_t getSystimerFreqHz(void)
{
    uint32_t curr = 0;
#if !defined(__x86_64__)
    __asm__ volatile("isb;mrs %0, cntfrq_el0"
                     : "=r"(curr));
#endif
    return curr;
}

uint64_t getSystimerVal_s(void)
{
    uint64_t freq     = getSystimerFreqHz();
    uint64_t currTick = getSystimerValTick();
    return currTick / freq;
}

uint64_t getSystimerVal_ms(void)
{
    uint64_t freq     = getSystimerFreqHz();
    uint64_t currTick = getSystimerValTick();
    return 1000 * currTick / freq;
}

uint64_t getSystimerVal_us(void)
{
    uint64_t freq     = getSystimerFreqHz();
    uint64_t currTick = getSystimerValTick();
    return (1000 * 1000) * currTick / freq;
}

uint64_t getSystimerVal_ns(void)
{
    uint64_t freq     = getSystimerFreqHz();
    uint64_t currTick = getSystimerValTick();
    return (1000 * 1000 * 1000) * currTick / freq;
}
