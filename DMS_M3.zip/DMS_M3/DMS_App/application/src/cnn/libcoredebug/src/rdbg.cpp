#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>     // printf
#include <sys/mman.h>  /* for mmap */
#include <sys/stat.h>  /* for open */
#include <sys/types.h> /* for open */
#include <unistd.h>    /* for close */

#include <map>
#include <utility>

#include "include/rdbg.hpp"
#include "include/rdbg_ext.h"

uint32_t
ImpSubSystem_V3U::getIpBaseAddress(const CoreID coreid)
{
    return m_base + m_ips[coreid];
}

ImpSubSystem *ImpSubSystemFactory::create(int pid)
{
    ImpSubSystem *result = nullptr;
    switch (pid)
    {
    case PRODUCT_ID_V3U:
    {
        result = new ImpSubSystem_V3U();
        break;
    }
    default:
        result = new ImpSubSystem();
    }
    return result;
}

#define DEVNAME_MEM "/dev/mem"

//#define IOAREA_SIZE (0x20000000U)
//#define IOAREA_BASE (0xE0000000U)

#define IOAREA_SIZE (0x40000000U)
#define IOAREA_BASE (0xC0000000U)

int mem_fd = -1;
uint64_t ioAreaBase = 0;

#define WRITE_REG32(addr, value) \
    *((volatile uint32_t *)((uint64_t)(ioAreaBase + addr - IOAREA_BASE))) = value

#define WRITE_REG64(addr, value) \
    *((volatile uint64_t *)((uint64_t)(ioAreaBase + addr - IOAREA_BASE))) = value

#define READ_REG32(addr) \
    *((volatile uint32_t *)((uint64_t)(ioAreaBase + addr - IOAREA_BASE)))

#define READ_REG64(addr) \
    *((volatile uint64_t *)((uint64_t)(ioAreaBase + addr - IOAREA_BASE)))

void rdbg_open()
{
    /* open /dev/mem */
    mem_fd = open(DEVNAME_MEM, O_RDWR);

    /* get device infomation */
    ioAreaBase = (uint64_t)mmap(NULL,
                                IOAREA_SIZE,
                                PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd,
                                IOAREA_BASE);
}

static int getProductID()
{
    uint32_t val = 0;
    rdbg_readReg(0xFFF00044U, &val);
    int pid = (val & 0xff00) >> 8;
    return pid;
}

bool rdbg_readReg(uint32_t const addr, uint32_t *const p_value)
{
    if (NULL == p_value)
    {
        DEBUG_PRINT("Invalid pointer to return value.\n");
        return false;
    }

    if ((0 > mem_fd) || (0 == ioAreaBase))
    {
        DEBUG_PRINT("Invalid memory mapping (%i, 0x%08x).\n", (int)mem_fd, (unsigned int)ioAreaBase);
        return false;
    }

    if (((int64_t)addr < IOAREA_BASE) || ((int64_t)addr > ((int64_t)IOAREA_BASE + IOAREA_SIZE - 1)))
    {
        DEBUG_PRINT("Address out of range (0x%08x, 0x%08x, 0x%08lx).\n", (unsigned int)addr, (unsigned int)IOAREA_BASE, (unsigned long int)((uint64_t)IOAREA_BASE + IOAREA_SIZE - 1));
        return false;
    }

    *p_value = READ_REG32(addr);

    return true;
}

bool rdbg_readCoreReg(int const core, int const id, uint16_t reg, uint32_t *const p_value)
{
    int pid = getProductID();
    ImpSubSystem *p_iss = ImpSubSystemFactory::create(pid);
    ImpSubSystem::CoreID coreid = {(ImpSubSystem::Core)core, id};

    uint32_t base = p_iss->getIpBaseAddress(coreid);
    const bool ret = rdbg_readReg(base + reg, p_value);
    delete p_iss;
    return ret;
}

uint32_t rdbg_readCoreRegi(int core, int id, uint16_t reg)
{
    uint32_t result = 0;
    rdbg_readCoreReg(core, id, reg, &result);
    return result;
}

uint32_t rdbg_readRegi(uint32_t address)
{
    uint32_t result = 0;
    rdbg_readReg(address, &result);
    return result;
}

void rdbg_close()
{
    munmap((void *)ioAreaBase, IOAREA_SIZE);
    close(mem_fd);
    mem_fd = -1;
}
