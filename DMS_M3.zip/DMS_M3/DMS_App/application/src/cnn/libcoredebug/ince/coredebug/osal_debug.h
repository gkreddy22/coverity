#ifndef _OSAL_DEBUG_HPP_
#define _OSAL_DEBUG_HPP_

#include "rcar-xos/osal/r_osal.h"

#ifdef __cplusplus
extern "C"
{
#endif

    e_osal_return_t __OSAL_MmngrAlloc(osal_memory_manager_handle_t const hndl_mmngr,
                                      size_t const size,
                                      size_t const alignment,
                                      osal_memory_buffer_handle_t *const p_buffer_obj);

    e_osal_return_t __OSAL_MmngrDealloc(osal_memory_manager_handle_t hndl_mmngr,
                                        osal_memory_buffer_handle_t buffer_obj);

    bool findCpuPtrFromHwPtr(uintptr_t hwAddress, osal_axi_bus_id_t imp_dev_axi_bus_id, void **p_cpu_ptr);

#if defined(RCAR_XIL_HIL)
#define R_OSAL_MmngrAlloc __OSAL_MmngrAlloc
#define R_OSAL_MmngrDealloc __OSAL_MmngrDealloc
#endif

#ifdef __cplusplus
}
#endif

#endif