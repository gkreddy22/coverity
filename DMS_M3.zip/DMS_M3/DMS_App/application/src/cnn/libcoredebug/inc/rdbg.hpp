#ifndef __RDBG_HPP__
#define __RDBG_HPP__

#define PRODUCT_ID_V3U (0x59)

class ImpSubSystem {
public:
    typedef enum
    {
        undefined = 0,
        IMP,
        CVE,
        DMAC,
        PSCEXE,
        CNN = 6,
        SIMP
    } Core;
    typedef std::pair<Core, int> CoreID;

public:
    ImpSubSystem() = default;
    virtual uint32_t getIpBaseAddress(const CoreID coreid)
    {
        (void)coreid;
        return 0x0;
    }
    virtual ~ImpSubSystem() = default;
};

class ImpSubSystem_V3U : public ImpSubSystem {
private:
    constexpr static uint32_t m_base = 0xFF900000U;

    std::map<ImpSubSystem::CoreID, uint32_t> m_ips = {
        {{ImpSubSystem::Core::IMP, 0}, 0x00100000U},   // IMP
        {{ImpSubSystem::Core::IMP, 1}, 0x00120000U},
        {{ImpSubSystem::Core::IMP, 2}, 0x00200000U},
        {{ImpSubSystem::Core::IMP, 3}, 0x00220000U},
        {{ImpSubSystem::Core::CVE, 0}, 0x00140000U},   // CVE
        {{ImpSubSystem::Core::CVE, 1}, 0x00150000U},
        {{ImpSubSystem::Core::CVE, 2}, 0x00240000U},
        {{ImpSubSystem::Core::CVE, 3}, 0x00250000U},
        {{ImpSubSystem::Core::CVE, 4}, 0x00160000U},
        {{ImpSubSystem::Core::CVE, 5}, 0x00260000U},
        {{ImpSubSystem::Core::CVE, 6}, 0x00170000U},
        {{ImpSubSystem::Core::CVE, 7}, 0x00270000U},
        {{ImpSubSystem::Core::DMAC, 0}, 0x00180000U},   // DMAC
        {{ImpSubSystem::Core::DMAC, 1}, 0x00181000U},
        {{ImpSubSystem::Core::DMAC, 2}, 0x00280000U},
        {{ImpSubSystem::Core::DMAC, 3}, 0x00281000U},
        {{ImpSubSystem::Core::PSCEXE, 0}, 0x00184000U},   // PSCEXE
        {{ImpSubSystem::Core::PSCEXE, 1}, 0x00284000U},
        {{ImpSubSystem::Core::CNN, 0}, 0x001A0000U},   // CNN
        {{ImpSubSystem::Core::CNN, 1}, 0x002C0000U},
        {{ImpSubSystem::Core::CNN, 2}, 0x001C0000U}};

public:
    ImpSubSystem_V3U() = default;

    uint32_t getIpBaseAddress(const CoreID coreid);
};

class ImpSubSystemFactory {
public:
    static ImpSubSystem* create(int pid);
};

#endif