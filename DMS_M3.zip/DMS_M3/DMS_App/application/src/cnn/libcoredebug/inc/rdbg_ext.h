#ifndef __RDBG_EXT_HPP__
#define __RDBG_EXT_HPP__

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

void rdbg_open(void);
bool rdbg_readReg(uint32_t const addr, uint32_t* p_value);
bool rdbg_readCoreReg(int core, int id, uint16_t reg, uint32_t* p_value);
void rdbg_close(void);

uint32_t rdbg_readCoreRegi(int core, int id, uint16_t reg);
uint32_t rdbg_readRegi(uint32_t address);

#ifdef __cplusplus
}
#endif

#endif