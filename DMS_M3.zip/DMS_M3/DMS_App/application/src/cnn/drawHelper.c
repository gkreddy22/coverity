#include "drawHelper.h"
#include <stdint.h>
#include <stdio.h>

//#include "generic_api_memory.h"
#include "rcar-xos/osal/r_osal.h"
#include ".librvxtarget/ince/rvx_target/ui.h"

#define FRAME_WIDTH  1920
#define FRAME_HEIGHT 1080
extern uint8_t * g_framebuffer;

typedef struct
{
    uint8_t b;
    uint8_t g;
    uint8_t r;
    uint8_t a;
} FrameBufferColor;

void drawPPMImageToFrameBuffer(const void * imageBuffer, size_t width, size_t height, size_t posX, size_t posY)
{
    size_t x, y;
    typedef struct
    {
        uint8_t r, g, b;
    } RGBstruct;

    FrameBufferColor * argbPtr = (FrameBufferColor *)g_framebuffer;
    RGBstruct *        rgbPtr  = (RGBstruct *)imageBuffer;
    for (y = 0; y < height; y++)
    {
        for (x = 0; x < width; x++)
        {
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->a = 0;
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->r = (rgbPtr + width * y + x)->r;
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->g = (rgbPtr + width * y + x)->g;
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->b = (rgbPtr + width * y + x)->b;
        }
    }
#if !defined(__linux__) && !defined(__QNX__)
    //gf_DCacheFlushRange((uintptr_t)(argbPtr + (posY)*FRAME_WIDTH + (posX)), height * FRAME_WIDTH * 4);
    osal_memory_buffer_handle_t handle = (uintptr_t)(argbPtr + (posY) * FRAME_WIDTH + (posX));
    OSAL_CHECK(R_OSAL_MmngrFlush(handle, 0, height * FRAME_WIDTH * 4));

#endif
}

void draw8GreyScaleImageToFrameBuffer(const void * imageBuffer, size_t width, size_t height, size_t posX, size_t posY)
{
    size_t   x, y;
    uint8_t * cptr = (uint8_t *)imageBuffer;

    FrameBufferColor * argbPtr = (FrameBufferColor *)g_framebuffer;

    for (y = 0; y < height; y++)
    {
        for (x = 0; x < width; x++)
        {
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->a = 0;
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->r = cptr[y * width + x];
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->g = cptr[y * width + x];
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->b = cptr[y * width + x];
        }
    }

#if !defined(__linux__) && !defined(__QNX__)
    //gf_DCacheFlushRange((uintptr_t)(argbPtr + (posY)*FRAME_WIDTH + (posX)), height * FRAME_WIDTH * 4);
    osal_memory_buffer_handle_t handle = (uintptr_t)(argbPtr + (posY)*FRAME_WIDTH + (posX));
    OSAL_CHECK(R_OSAL_MmngrFlush(handle, 0, height * FRAME_WIDTH * 4));
#endif
}

void draw16GreyScaleImageToFrameBuffer(const void * imageBuffer, size_t width, size_t height, size_t posX, size_t posY, bool normalize)
{
    size_t     x, y;
    uint16_t * cptr   = (uint16_t *)imageBuffer;
    uint16_t   maxVal = 0;

    FrameBufferColor * argbPtr = (FrameBufferColor *)g_framebuffer;

    if (normalize)
    {
        for (y = 0; y < height; y++)
        {
            for (x = 0; x < width; x++)
            {
                maxVal = (cptr[y * width + x] > maxVal) ? cptr[y * width + x] : maxVal;
            }
        }
    }

    cinfov("MaxVal = %u\n", maxVal);

    for (y = 0; y < height; y++)
    {
        for (x = 0; x < width; x++)
        {
            uint8_t val = (cptr[y * width + x] >> 8) & 0xFF;

            if (normalize)
            {
                val = (uint8_t)(((float)cptr[y * width + x]) * 255.0f / (float)maxVal + 0.5f);
            }
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->a = 0;
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->r = val;
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->g = val;
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->b = val;
        }
    }

#if !defined(__linux__) && !defined(__QNX__)
    //gf_DCacheFlushRange((uintptr_t)(argbPtr + (posY)*FRAME_WIDTH + (posX)), height * FRAME_WIDTH * 4);
    osal_memory_buffer_handle_t handle = (uintptr_t)(argbPtr + (posY)*FRAME_WIDTH + (posX));
    OSAL_CHECK(R_OSAL_MmngrFlush(handle, 0, height * FRAME_WIDTH * 4));
#endif
}

void drawRGB16ChannelToFrameBuffer(const uint16_t * rBuf, const uint16_t * gBuf, const uint16_t * bBuf, size_t width, size_t height, size_t posX, size_t posY, uint16_t bitmask, bool normalize)
{
    size_t x, y, endX, endY;
    typedef struct
    {
        uint8_t b, g, r, a;
    } ARGBstruct;

    ARGBstruct * argbPtr = (ARGBstruct *)g_framebuffer;

    uint16_t max_r = 0;
    uint16_t max_g = 0;
    uint16_t max_b = 0;

    uint16_t min_r = 0xFFFF;
    uint16_t min_g = 0xFFFF;
    uint16_t min_b = 0xFFFF;

    if (normalize)
    {
        for (y = 0; y < height; y++)
        {
            for (x = 0; x < width; x++)
            {
                if (rBuf)
                {
                    uint16_t val = rBuf[y * width + x] & bitmask;
                    max_r        = (val > max_r) ? val : max_r;
                    min_r        = (val < min_r) ? val : min_r;
                }

                if (gBuf)
                {
                    uint16_t val = gBuf[y * width + x] & bitmask;
                    max_g        = (val > max_g) ? val : max_g;
                    min_g        = (val < min_g) ? val : min_g;
                }

                if (bBuf)
                {
                    uint16_t val = bBuf[y * width + x] & bitmask;
                    max_b        = (val > max_b) ? val : max_b;
                    min_b        = (val < min_b) ? val : min_b;
                }
            }
        }
    }

    if (rBuf)
    {
        cinfov("min_r=%u\n", (unsigned int)min_r);
        cinfov("max_r=%u\n", (unsigned int)max_r);
    }

    if (gBuf)
    {
        cinfov("min_g=%u\n", (unsigned int)min_g);
        cinfov("max_g=%u\n", (unsigned int)max_g);
    }

    if (bBuf)
    {
        cinfov("min_b=%u\n", (unsigned int)min_b);
        cinfov("max_b=%u\n", (unsigned int)max_b);
    }

    for (y = 0; y < height; y++)
    {
        for (x = 0; x < width; x++)
        {
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->a = 0;

            if (rBuf)
            {
                uint32_t val = (*(rBuf + width * y + x)) & bitmask;

                if (normalize)
                {
                    val -= min_r;
                    val *= 255;
                    val /= max_r;
                }
                else
                {
                    val >>= 8;
                }
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->r = val & 0xFF;
            }
            else
            {
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->r = 0;
            }

            if (gBuf)
            {
                uint32_t val = (* (gBuf + width * y + x)) & bitmask;

                if (normalize)
                {
                    val -= min_g;
                    val *= 255;
                    val /= max_g;
                }
                else
                {
                    val >>= 8;
                }
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->g = val & 0xFF;
            }
            else
            {
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->g = 0;
            }

            if (bBuf)
            {
                uint32_t val = (* (bBuf + width * y + x)) & bitmask;

                if (normalize)
                {
                    val -= min_b;
                    val *= 255;
                    val /= max_b;
                }
                else
                {
                    val >>= 8;
                }
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->b = val & 0xFF;
            }
            else
            {
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->b = 0;
            }
        }
    }
#if !defined(__linux__) && !defined(__QNX__)
    //gf_DCacheFlushRange((uintptr_t)(argbPtr + (posY)*FRAME_WIDTH + (posX)), height * FRAME_WIDTH * 4);
    osal_memory_buffer_handle_t handle = (uintptr_t)(argbPtr + (posY) * FRAME_WIDTH + (posX));
    OSAL_CHECK(R_OSAL_MmngrFlush(handle, 0, height * FRAME_WIDTH * 4));
#endif
}

void drawRGB8ChannelToFrameBuffer(const uint8_t * rBuf, const uint8_t * gBuf, const uint8_t * bBuf, size_t width, size_t height, size_t posX, size_t posY, uint8_t bitmask, bool normalize)
{
    size_t x, y;

    FrameBufferColor * argbPtr = (FrameBufferColor *)g_framebuffer;

    uint8_t max_r = 0;
    uint8_t max_g = 0;
    uint8_t max_b = 0;

    uint8_t min_r = 0xFF;
    uint8_t min_g = 0xFF;
    uint8_t min_b = 0xFF;

    if (normalize)
    {
        for (y = 0; y < height; y++)
        {
            for (x = 0; x < width; x++)
            {
                if (rBuf)
                {
                    uint8_t val = rBuf[y * width + x] & bitmask;
                    max_r       = (val > max_r) ? val : max_r;
                    min_r       = (val < min_r) ? val : min_r;
                }

                if (gBuf)
                {
                    uint8_t val = gBuf[y * width + x] & bitmask;
                    max_g       = (val > max_g) ? val : max_g;
                    min_g       = (val < min_g) ? val : min_g;
                }

                if (bBuf)
                {
                    uint8_t val = bBuf[y * width + x] & bitmask;
                    max_b       = (val > max_b) ? val : max_b;
                    min_b       = (val < min_b) ? val : min_b;
                }
            }
        }
    }

    if (rBuf)
    {
        cinfov("min_r=%u\n", (unsigned int)min_r);
        cinfov("max_r=%u\n", (unsigned int)max_r);
    }

    if (gBuf)
    {
        cinfov("min_g=%u\n", (unsigned int)min_g);
        cinfov("max_g=%u\n", (unsigned int)max_g);
    }

    if (bBuf)
    {
        cinfov("min_b=%u\n", (unsigned int)min_b);
        cinfov("max_b=%u\n", (unsigned int)max_b);
    }

    for (y = 0; y < height; y++)
    {
        for (x = 0; x < width; x++)
        {
            (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->a = 0;
            if (rBuf)
            {
                uint32_t val = (* (rBuf + width * y + x)) & bitmask;

                if (normalize)
                {
                    val -= min_r;
                    val *= 255;
                    val /= max_r;
                }
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->r = val & 0xFF;
            }
            else
            {
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->r = 0;
            }

            if (gBuf)
            {
                uint32_t val = (* (gBuf + width * y + x)) & bitmask;

                if (normalize)
                {
                    val -= min_g;
                    val *= 255;
                    val /= max_g;
                }
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->g = val & 0xFF;
            }
            else
            {
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->g = 0;
            }

            if (bBuf)
            {
                uint32_t val = (* (bBuf + width * y + x)) & bitmask;

                if (normalize)
                {
                    val -= min_b;
                    val *= 255;
                    val /= max_b;
                }
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->b = val & 0xFF;
            }
            else
            {
                (argbPtr + (posY + y) * FRAME_WIDTH + (posX + x))->b = 0;
            }
        }
    }
#if !defined(__linux__) && !defined(__QNX__)
    //gf_DCacheFlushRange((uintptr_t)(argbPtr + (posY)*FRAME_WIDTH + (posX)), height * FRAME_WIDTH * 4);
    osal_memory_buffer_handle_t handle = (uintptr_t)(argbPtr + (posY) * FRAME_WIDTH + (posX));
    OSAL_CHECK(R_OSAL_MmngrFlush(handle, 0, height * FRAME_WIDTH * 4));
#endif
}

void maskBit16(const void * imageBuffer, size_t width, size_t height)
{
    uint16_t * ptr = imageBuffer;
    size_t    x, y;

    for (y = 0; y < height; y++)
    {
        for (x = 0; x < width; x++)
        {
            *ptr = (*ptr) & 0x1;
            ptr++;
        }
    }
}
