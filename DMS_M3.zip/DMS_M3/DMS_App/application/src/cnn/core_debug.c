#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "rcar-xos/osal/r_osal.h"

#include "include/osal_debug.h"

#include "include/rdbg_ext.h"
#include "common.h"

#ifndef MIN
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#endif

#define CNN_BUSPRIO_I0_3         ((uint16_t)0x09A8U)
#define CNN_BUSPRIO_O0_3         (uint16_t)(0x09B0U)
#define CNN_BUSPRIO_O4_7         (uint16_t)(0x09B4U)
#define CNN_BUSPRIO_3DC0_3       (uint16_t)(0x09C0U)
#define CNN_BUSPRIO_3DC4_7       (uint16_t)(0x09C4U)
#define CNN_BUSPRIO_CL           (uint16_t)(0x09D0U)

#define CNN_DMAIC0               (uint16_t)(0x1000U)
#define CNN_DMAIL0               (uint16_t)(0x1004U)
#define CNN_DMAISA0              (uint16_t)(0x1008U)
#define CNN_DMAIST0              (uint16_t)(0x100CU)

#define CNN_DMA3DCC0             (uint16_t)(0x1100U)
#define CNN_DMA3DCSA0            (uint16_t)(0x1108U)
#define CNN_DMA3DCL0             (uint16_t)(0x1104U)
#define CNN_DMA3DCST0            (uint16_t)(0x110CU)

#define CNN_DMAOSA0              (uint16_t)(0x1300U)
#define CNN_DMAOL0               (uint16_t)(0x1360U)
#define CNN_DMAOST0              ((uint16_t)0x1340U)
#define CNN_DMAOFM               (uint16_t)(0x1388U)

#define CNN_DMAICTRL             (uint16_t)(0x1040U)
#define CNN_DMA3DCCTRL           (uint16_t)(0x1200U)
#define CNN_DMAOCTRL             (uint16_t)(0x138CU)

#define cok(msg)                 fprintf(stdout, "[OK] " msg)
#define cinfo(msg)               fprintf(stdout, "[II] " msg)
#define cwarning(msg)            fprintf(stdout, "[WW] " msg)

#define cokv(msg, ...)           fprintf(stdout, "[OK] " msg, __VA_ARGS__)
#define cinfov(msg, ...)         fprintf(stdout, "[II] " msg, __VA_ARGS__)
#define cwarningv(msg, ...)      fprintf(stdout, "[WW] " msg, __VA_ARGS__)

#define R_ATMLIB_CNN_DMAI_MAX_CH (4)
#define R_ATMLIB_CNN_DMAO_MAX_CH (8)

typedef struct
{
    enum
    {
        UNUSED = 0,
        IMP    = 1,
        CVE,
        DMAC,
        PSC, //PSCEXE,
        //PSCOUT,
        CNN,
        SIMP
    } Core;
} CoreID;

typedef struct rcv_impdrv_core_struc
{
    uint32_t CoreType;
    uint32_t CoreNum;
} RCvIMPDRVCOREINFO;

typedef void RCvIMPDRVCTL;

static void dump_cnn_busprio(int core, int index)
{
    cinfov("CNN%i: "
           "BUSPRIO_I0_3=0x%08x, "
           "BUSPRIO_O0_3=0x%08x, "
           "BUSPRIO_O4_7=0x%08x, "
           "BUSPRIO_3DC0_3=0x%08x, "
           "BUSPRIO_3DC4_7=0x%08x, "
           "BUSPRIO_CL=0x%08x\n",
           index,
           (unsigned int)rdbg_readCoreRegi(core, index, CNN_BUSPRIO_I0_3),
           (unsigned int)rdbg_readCoreRegi(core, index, CNN_BUSPRIO_O0_3),
           (unsigned int)rdbg_readCoreRegi(core, index, CNN_BUSPRIO_O4_7),
           (unsigned int)rdbg_readCoreRegi(core, index, CNN_BUSPRIO_3DC0_3),
           (unsigned int)rdbg_readCoreRegi(core, index, CNN_BUSPRIO_3DC4_7),
           (unsigned int)rdbg_readCoreRegi(core, index, CNN_BUSPRIO_CL));
}

static char get_bank(const uint32_t address)
{
    if ((address < 0xED000000U) || (address >= 0xED400000U))
    {
        return '_';
    }

    const char bank = (char)((address - 0xED000000) / 0x20000U);

    return (bank < 10) ? (char)('0' + bank) : (char)('A' + (bank - 10));
}

static unsigned int get_lane(const uint32_t address)
{
    return (address % 128) / 32;
}

static void print_DMAI(int core, int index, uint16_t channel)
{
    const uint32_t dmaictrl   = rdbg_readCoreRegi(core, index, CNN_DMAICTRL);
    const uint16_t dmaisa_reg = (uint16_t)(CNN_DMAISA0 + channel * 0x10U);
    const uint32_t dmaisa_val = rdbg_readCoreRegi(core, index, dmaisa_reg);
    const bool     dmai_ena   = ((dmaictrl >> (8 + channel)) & 1) == 1;

    /* DMAILx */
    const uint16_t dmail_reg = (uint16_t)(CNN_DMAIL0 + (uint16_t)channel * 0x10U);
    const uint32_t dmail_val = rdbg_readCoreRegi(core, index, dmail_reg);

    /* DMAISTx */
    const uint16_t dmaist_reg = (uint16_t)(CNN_DMAIST0 + channel * 0x10U);
    const uint32_t dmaist_val = rdbg_readCoreRegi(core, index, dmaist_reg);

    /* DMA_Cx */
    const uint16_t     dma_c_reg     = (uint16_t)(CNN_DMAIC0 + channel * 0x10U);
    const uint32_t     dma_c_val     = rdbg_readCoreRegi(core, index, dma_c_reg);
    const unsigned int bytesPerPixel = ((dma_c_val >> 25) & 0x1) + 1;

    if (channel < R_ATMLIB_CNN_DMAI_MAX_CH)
    {
        DEBUG_PRINT("[%c] DMAISA%u (0x%04x)=0x%08x(%c.%u) {w=%3up,h=%4up,s=%4up,p=%1uB}",
               dmai_ena ? 'E' : ' ',
               (unsigned int)channel,
               (unsigned int)dmaisa_reg,
               (unsigned int)dmaisa_val,
               get_bank(dmaisa_val),
               get_lane(dmaisa_val),
               dmail_val & 0xFFFU, (dmail_val >> 16) & 0xFFFFU, dmaist_val & 0xFFFFU, bytesPerPixel);
    }
}

static void print_DMAC(int core, int index, unsigned int channel)
{
    const uint32_t dmacctrl   = rdbg_readCoreRegi(core, index, CNN_DMA3DCCTRL);
    const uint16_t dmacsa_reg = (uint16_t)(CNN_DMA3DCSA0 + channel * 0x10U);
    const uint32_t dmacsa_val = rdbg_readCoreRegi(core, index, dmacsa_reg);
    const bool     dmac_ena   = ((dmacctrl >> (8 + channel)) & 1) == 1;

    /* DMAILx */
    const uint16_t dma_l_reg = (uint16_t)(CNN_DMA3DCL0 + channel * 0x10U);
    const uint32_t dma_l_val = rdbg_readCoreRegi(core, index, dma_l_reg);

    /* DMAISTx */
    const uint16_t dma_st_reg = (uint16_t)(CNN_DMA3DCST0 + channel * 0x10U);
    const uint32_t dma_st_val = rdbg_readCoreRegi(core, index, dma_st_reg);

    /* DMA_Cx */
    const uint16_t     dma_c_reg     = (uint16_t)(CNN_DMA3DCC0 + channel * 0x10U);
    const uint32_t     dma_c_val     = rdbg_readCoreRegi(core, index, dma_c_reg);
    const unsigned int bytesPerPixel = ((dma_c_val >> 25) & 0x1) + 1;

    DEBUG_PRINT("[%c] DMA3DCSA%u (0x%04x)=0x%08x(%c.%u) {w=%3up,h=%4up,s=%4up,p=%1uB}",
           dmac_ena ? 'E' : ' ',
           (unsigned int)channel,
           (unsigned int)dmacsa_reg,
           (unsigned int)dmacsa_val,
           get_bank(dmacsa_val),
           get_lane(dmacsa_val),
           dma_l_val & 0xFFFU, (dma_l_val >> 16) & 0xFFFFU, dma_st_val & 0xFFFFU, bytesPerPixel);
}

static void print_DMAO(int core, int index, unsigned int channel)
{
    const uint32_t dmaoctrl   = rdbg_readCoreRegi(core, index, CNN_DMAOCTRL);
    const uint16_t dmaosa_reg = (uint16_t)(CNN_DMAOSA0 + channel * 0x04U);
    const uint32_t dmaosa_val = rdbg_readCoreRegi(core, index, dmaosa_reg);
    const bool     dmao_ena   = ((dmaoctrl >> (8 + channel)) & 1) == 1;

    /* DMA_Lx */
    const uint16_t dma_l_reg = (uint16_t)(CNN_DMAOL0 + channel * 0x04U);
    const uint32_t dma_l_val = rdbg_readCoreRegi(core, index, dma_l_reg);

    /* DMA_STx */
    const uint16_t dma_st_reg = (uint16_t)(CNN_DMAOST0 + channel * 0x04U);
    const uint32_t dma_st_val = rdbg_readCoreRegi(core, index, dma_st_reg);

    /* DMA_Cx */
    const uint16_t     dma_c_reg     = CNN_DMAOFM;
    const uint32_t     dma_c_val     = rdbg_readCoreRegi(core, index, dma_c_reg);
    const unsigned int bytesPerPixel = ((dma_c_val >> (4 * channel + 1)) & 0x1) + 1;

    DEBUG_PRINT("[%c] DMAOSA%u(0x%04x)=0x%08x(%c.%u) {w=%3up,h=%4up,s=%4up,p=%1uB}",
           dmao_ena ? 'E' : ' ',
           (unsigned int)channel,
           (unsigned int)dmaosa_reg,
           (unsigned int)dmaosa_val,
           get_bank(dmaosa_val),
           get_lane(dmaosa_val),
           dma_l_val & 0xFFFU, (dma_l_val >> 16) & 0xFFFFU, dma_st_val & 0xFFFFU, bytesPerPixel);
}

static void dump_cnn_DMAxSA(int core, int index)
{
    for (unsigned int r = 0; r < R_ATMLIB_CNN_DMAO_MAX_CH; r++)
    {
        cinfov("CNN%i: ", index);

        if (r < R_ATMLIB_CNN_DMAI_MAX_CH)
        {
            print_DMAI(core, index, (uint16_t)r);
            DEBUG_PRINT(", ");
        }
        else
        {
            DEBUG_PRINT("                                                                    ");
        }
        print_DMAC(core, index, r);
        DEBUG_PRINT(", ");
        print_DMAO(core, index, r);
        DEBUG_PRINT("\n");
    }
}

static void dump_dma_SxxAR(int core, int index)
{
    const uint32_t s0cr = rdbg_readCoreRegi(core, index, 0x50);
    const uint32_t s1cr = rdbg_readCoreRegi(core, index, 0x70);

    const bool s0ren = (s0cr & 0x80000000U) != 0;
    const bool s1ren = (s1cr & 0x80000000U) != 0;

    const uint16_t s0sar_reg = 0x40;
    const uint16_t s1sar_reg = 0x60;
    const uint16_t d0sar_reg = 0x80;

    const uint32_t s0sar_val = rdbg_readCoreRegi(core, index, s0sar_reg);
    const uint32_t s1sar_val = rdbg_readCoreRegi(core, index, s1sar_reg);
    const uint32_t d0sar_val = rdbg_readCoreRegi(core, index, d0sar_reg);

    cinfov("DMA%i: [%c] S0SAR(0x%04x)=0x%08x(%c), [%c] S1SAR(0x%04x)=0x%08x(%c), [%c] D0SAR(0x%04x)=0x%08x(%c)\n",
           index,
           s0ren ? 'E' : ' ',
           (unsigned int)s0sar_reg,
           (unsigned int)s0sar_val,
           get_bank(s0sar_val),
           s1ren ? 'E' : ' ',
           (unsigned int)s1sar_reg,
           (unsigned int)s1sar_val,
           get_bank(s1sar_val),
           true ? 'E' : ' ',
           (unsigned int)d0sar_reg,
           (unsigned int)d0sar_val,
           get_bank(d0sar_val));
}

static void dump_cl(int core, int index, const uint32_t start, const uint32_t current, const unsigned int backtrace, const unsigned int readahead, osal_axi_bus_id_t imp_dev_axi_bus_id)
{
    char * core_name = "XXX";

    if (core == CNN)
    {
        core_name = "CNN";
    }
    else if (core == DMAC)
    {
        core_name = "DMA";
    }
    {
        uint32_t const s = MAX(start, current - backtrace * (uint32_t)sizeof(uint32_t));
        uint32_t const e = current;

        for (uint32_t p = s; p <= e; p += (uint32_t)sizeof(uint32_t))
        {
            void * ptr = NULL;

            if (findCpuPtrFromHwPtr(p, imp_dev_axi_bus_id, &ptr))
            {
                const uint32_t value = *((uint32_t *)ptr);

                cinfov("%s%i: 0x%08x (0x%08x): 0x%08x\n",
                       core_name,
                       index,
                       (unsigned int)p,
                       (unsigned int)(p - start),
                       (unsigned int)value);
            }
        }
    }
    cinfov("%s%u: -- ^^STOP^^ --\n", core_name, index);
    {
        uint32_t const s = current + (uint32_t)sizeof(uint32_t);
        uint32_t const e = current + readahead * (uint32_t)sizeof(uint32_t);

        if ((s != 0) && (e != 0))
        {
            for (uint32_t p = s; p <= e; p += (uint32_t)sizeof(uint32_t))
            {
                void * ptr = NULL;
                if (findCpuPtrFromHwPtr(p, imp_dev_axi_bus_id, &ptr))
                {
                    const uint32_t value = * ((uint32_t *)ptr);
                    cinfov("%s%i: 0x%08x (0x%08x): 0x%08x\n",
                           core_name,
                           index,
                           (unsigned int)(p),
                           (unsigned int)((p)-start),
                           value);
                }
            }
        }
        else
        {
            cwarning("Address resolution failed!\n");
        }
    }
}

static void cdbg_debug_V3H1(int const core, int const index, osal_axi_bus_id_t imp_dev_axi_bus_id) __attribute__((unused));
static void cdbg_debug_V3H1(int const core, int const index, osal_axi_bus_id_t imp_dev_axi_bus_id)
{
    unsigned int backtrace = 16;
    unsigned int readahead = 4;

    if (core == CNN)
    {
        const uint32_t vcr0 = rdbg_readCoreRegi(core, index, 0x0000U);
        const uint32_t vcr1 = rdbg_readCoreRegi(core, index, 0x0004U);
        const uint32_t clpc = rdbg_readCoreRegi(core, index, 0x0028U);
        const uint32_t sacl = rdbg_readCoreRegi(core, index, 0x0080U);

        const uint32_t cleir  = rdbg_readRegi(clpc); /* current instruction */

        const bool is_ImpcBug = (cleir & 0xFF000000U) == 0x8b000000U;

        cinfov("CNN%u: VCR0=0x%08x VCR1=0x%08x SACL=0x%08x CLPC=0x%08x\n", index, (unsigned int)vcr0, (unsigned int)vcr1, (unsigned int)sacl, (unsigned int)clpc);

        const uint32_t syncc0_3   = rdbg_readCoreRegi(core, index, 0x0900U);
        const uint32_t syncc4_7   = rdbg_readCoreRegi(core, index, 0x0904U);
        const uint32_t syncc8_11  = rdbg_readCoreRegi(core, index, 0x0908U);
        const uint32_t syncc12_15 = rdbg_readCoreRegi(core, index, 0x090CU);

        cinfov("CNN%u: syncc0_3=0x%08x syncc4_7=0x%08x syncc8_11=0x%08x syncc12_15=0x%08x\n", index, (unsigned int)syncc0_3, (unsigned int)syncc4_7, (unsigned int)syncc8_11, (unsigned int)syncc12_15);

        dump_cnn_busprio(core, index);
        dump_cnn_DMAxSA(core, index);

        if (is_ImpcBug)
        {
            /* reduce output */
            //backtrace = 16;
            //readahead = 4;
        }

        dump_cl(core, index, sacl, clpc, backtrace, readahead, imp_dev_axi_bus_id);
    }
    else if (core == CVE)
    {
        const uint32_t vcr   = rdbg_readCoreRegi(core, index, 0x0000U);
        const uint32_t dlsar = rdbg_readCoreRegi(core, index, 0x0180U);
        const uint32_t dlfar = rdbg_readCoreRegi(core, index, 0x0194U);
        const uint32_t dleir = rdbg_readCoreRegi(core, index, 0x0198U);

        const uint32_t vpcsar = rdbg_readCoreRegi(core, index, 0x0320U);
        const uint32_t vibar  = rdbg_readCoreRegi(core, index, 0x0340U);
        const uint32_t vspc   = rdbg_readCoreRegi(core, index, 0x11C0U);

        cinfov("CVE%u: VCR=0x%08x DLSAR=0x%08x DLFAR=0x%08x DLEIR=0x%08x\n", index, (unsigned int)vcr, (unsigned int)dlsar, (unsigned int)dlfar, (unsigned int)dleir);

        const uint32_t SYNCCNFR03   = rdbg_readCoreRegi(core, index, 0x04C0U);
        const uint32_t SYNCCNFR47   = rdbg_readCoreRegi(core, index, 0x04C4U);
        const uint32_t SYNCCNFR811  = rdbg_readCoreRegi(core, index, 0x04C8U);
        const uint32_t SYNCCNFR1215 = rdbg_readCoreRegi(core, index, 0x04CCU);

        cinfov("CVE%u: SYNCCNFR03=0x%08x SYNCCNFR47=0x%08x SYNCCNFR811=0x%08x SYNCCNFR1215=0x%08x\n", index, (unsigned int)SYNCCNFR03, (unsigned int)SYNCCNFR47, (unsigned int)SYNCCNFR811, (unsigned int)SYNCCNFR1215);

        cinfov("CVE%u: VPCSAR=0x%08x VIBAR=0x%08x VSPC=0x%08x\n",
               index,
               (unsigned int)vpcsar,
               (unsigned int)vibar,
               (unsigned int)vspc);

        dump_cl(core, index, dlsar, dlfar, backtrace, readahead, imp_dev_axi_bus_id);
    }
    else if (core == DMAC)
    {
        const uint32_t vcr   = rdbg_readCoreRegi(core, index, 0x0000U);
        const uint32_t prir  = rdbg_readCoreRegi(core, index, 0x0024U);
        const uint32_t clsar = rdbg_readCoreRegi(core, index, 0x0028U);
        const uint32_t clfar = rdbg_readCoreRegi(core, index, 0x00C8U);
        const uint32_t cleir = rdbg_readCoreRegi(core, index, 0x00CCU);

        cinfov("DMA%u: VCR=0x%08x CLSAR=0x%08x CLFAR=0x%08x CLEIR=0x%08x PRIR=0x%08x\n", index, (unsigned int)vcr, (unsigned int)clsar, (unsigned int)clfar, (unsigned int)cleir, (unsigned int)prir);

        const uint32_t SYNCCR0 = rdbg_readCoreRegi(core, index, 0x00E8);
        const uint32_t SYNCCR1 = rdbg_readCoreRegi(core, index, 0x00EC);
        const uint32_t SYNCCR2 = rdbg_readCoreRegi(core, index, 0x00F0);
        const uint32_t SYNCCR3 = rdbg_readCoreRegi(core, index, 0x00F4);

        cinfov("DMA%u: SYNCCR0=0x%08x SYNCCR1=0x%08x SYNCCR2=0x%08x SYNCCR3=0x%08x\n", index, (unsigned int)SYNCCR0, (unsigned int)SYNCCR1, (unsigned int)SYNCCR2, (unsigned int)SYNCCR3);

        dump_dma_SxxAR(core, index);
        dump_cl(core, index, clsar, clfar, backtrace, readahead, imp_dev_axi_bus_id);
    }
}

void cdbg_core_dump(int core, int index)
{
    if (core == CNN)
    {
        char * filename = "cnn_reg_dump.txt";
        FILE * p_file = fopen(filename, "w");

        if (NULL == p_file)
        {
            cwarningv("Failed to open '%s'!\n", filename);
            return;
        }

        for (uint32_t offset = 0; offset < 0x10000; offset += 4)
        {
            uint32_t val = rdbg_readCoreRegi(core, index, (uint16_t)offset);
            fprintf(p_file, "0x%08x 0x%08x\n", offset, val);
        }
    }
}

static void cdbg_debug_V3U1(int const core, int const index, osal_axi_bus_id_t imp_dev_axi_bus_id) __attribute__((unused));
static void cdbg_debug_V3U1(int const core, int const index, osal_axi_bus_id_t imp_dev_axi_bus_id)
{
    unsigned int backtrace = 16;
    unsigned int readahead = 4;

    if (core == CNN)
    {
        const uint32_t vcr0  = rdbg_readCoreRegi(core, index, 0x0000U);
        const uint32_t vcr1  = rdbg_readCoreRegi(core, index, 0x0004U);
        const uint32_t clpc  = rdbg_readCoreRegi(core, index, 0x0100U);
        const uint32_t sacl  = rdbg_readCoreRegi(core, index, 0x0104U);
        const uint32_t cleir = rdbg_readCoreRegi(core, index, 0x010CU);

        cinfov("CNN%u: VCR0=0x%08x VCR1=0x%08x SACL=0x%08x CLPC=0x%08x CLEIR=0x%08x\n",
               index, (unsigned int)vcr0, (unsigned int)vcr1, (unsigned int)sacl, (unsigned int)clpc, (unsigned int)cleir);

        const uint32_t syncc0_3   = rdbg_readCoreRegi(core, index, 0x0900U);
        const uint32_t syncc4_7   = rdbg_readCoreRegi(core, index, 0x0904U);
        const uint32_t syncc8_11  = rdbg_readCoreRegi(core, index, 0x0908U);
        const uint32_t syncc12_15 = rdbg_readCoreRegi(core, index, 0x090CU);

        cinfov("CNN%u: syncc0_3=0x%08x syncc4_7=0x%08x syncc8_11=0x%08x syncc12_15=0x%08x\n", index, (unsigned int)syncc0_3, (unsigned int)syncc4_7, (unsigned int)syncc8_11, (unsigned int)syncc12_15);

        dump_cnn_busprio(core, index);
        dump_cnn_DMAxSA(core, index);

        const uint32_t dmaisa   = rdbg_readCoreRegi(core, index, 0x4000U);
        const uint32_t dmaico   = rdbg_readCoreRegi(core, index, 0x4004U);
        const uint32_t dmaisa00 = rdbg_readCoreRegi(core, index, 0x4100U);
        const uint32_t dmaie    = rdbg_readCoreRegi(core, index, 0x401CU);
        const uint32_t dmais    = rdbg_readCoreRegi(core, index, 0x4020U);

        const uint32_t dma3dcsa   = rdbg_readCoreRegi(core, index, 0x5000U);
        const uint32_t dma3dcco   = rdbg_readCoreRegi(core, index, 0x5004U);
        const uint32_t dma3dcsa00 = rdbg_readCoreRegi(core, index, 0x5100U);
        const uint32_t dma3dce    = rdbg_readCoreRegi(core, index, 0x501CU);
        const uint32_t dma3dcs    = rdbg_readCoreRegi(core, index, 0x5020U);

        const uint32_t dmaosa   = rdbg_readCoreRegi(core, index, 0x6000U);
        const uint32_t dmaoco   = rdbg_readCoreRegi(core, index, 0x6004U);
        const uint32_t dmaosa00 = rdbg_readCoreRegi(core, index, 0x6100U);
        const uint32_t dmaoe    = rdbg_readCoreRegi(core, index, 0x6018U);
        const uint32_t dmaos    = rdbg_readCoreRegi(core, index, 0x601CU);
        const uint32_t dmaol    = rdbg_readCoreRegi(core, index, 0x6008U);

        const uint32_t aricsr  = rdbg_readCoreRegi(core, index, 0x1000U);
        const uint32_t arie    = rdbg_readCoreRegi(core, index, 0x1004U);
        const uint32_t ari_len = rdbg_readCoreRegi(core, index, 0x1010U);

        const uint32_t sr = rdbg_readCoreRegi(core, index, 0x0010U);
        cinfov("CNN%u: DMAISA=0x%08x, DMAICO=0x%08x,  DMAISA00=0x%08x,  DMAIE=0x%08x, DMAIS=0x%08x\n",
               index,
               (unsigned int)dmaisa, (unsigned int)dmaico, (unsigned int)dmaisa00, (unsigned int)dmaie, (unsigned int)dmais);

        cinfov("CNN%u: DMA3DSA=0x%08x, DMA3DCO=0x%08x, DMA3DSA00=0x%08x, DMA3DE=0x%08x, DMA3DS=0x%08x\n",
               index,
               (unsigned int)dma3dcsa, (unsigned int)dma3dcco, (unsigned int)dma3dcsa00, (unsigned int)dma3dce, (unsigned int)dma3dcs);

        cinfov("CNN%u: DMAOSA=0x%08x,  DMA3DCO=0x%08x, DMAOSA00=0x%08x,  DMAOE=0x%08x,  DMAOS=0x%08x,  DMAOL=0x%08x\n",
               index,
               (unsigned int)dmaosa, (unsigned int)dmaoco, (unsigned int)dmaosa00, (unsigned int)dmaoe, (unsigned int)dmaos, (unsigned int)dmaol);

        cinfov("CNN%u: ARICSR=0x%08x,  ARIE=0x%08x, ARI_LEN=0x%08x\n",
               index,
               (unsigned int)aricsr, (unsigned int)arie, (unsigned int)ari_len);

        cinfov("CNN%u: SR=0x%08x: ", index, (unsigned int)sr);
        if (sr & 0x8000)
            DEBUG_PRINT("R");

        if (sr & 0x4000)
            DEBUG_PRINT("C");

        if (sr & 0x2000)
            DEBUG_PRINT("I");

        if (sr & 0x1000)
            DEBUG_PRINT("3");

        if (sr & 0x0800)
            DEBUG_PRINT("O");

        if (sr & 0x0400)
            DEBUG_PRINT("A");

        if (sr & 0x0200)
            DEBUG_PRINT("S");

        DEBUG_PRINT("\n");

        dump_cl(core, index, sacl, clpc, backtrace, readahead, imp_dev_axi_bus_id);
    }
    else if (core == CVE)
    {
        const uint32_t vcr   = rdbg_readCoreRegi(core, index, 0x0000U);
        const uint32_t dlsar = rdbg_readCoreRegi(core, index, 0x0180U);
        const uint32_t dlfar = rdbg_readCoreRegi(core, index, 0x0194U);
        const uint32_t dleir = rdbg_readCoreRegi(core, index, 0x0198U);

        const uint32_t vpcsar = rdbg_readCoreRegi(core, index, 0x0320U);
        const uint32_t vibar  = rdbg_readCoreRegi(core, index, 0x0340U);
        const uint32_t vspc   = rdbg_readCoreRegi(core, index, 0x11C0U);

        cinfov("CVE%u: VCR=0x%08x DLSAR=0x%08x DLFAR=0x%08x DLEIR=0x%08x\n", index, (unsigned int)vcr, (unsigned int)dlsar, (unsigned int)dlfar, (unsigned int)dleir);

        const uint32_t SYNCCNFR03   = rdbg_readCoreRegi(core, index, 0x04C0U);
        const uint32_t SYNCCNFR47   = rdbg_readCoreRegi(core, index, 0x04C4U);
        const uint32_t SYNCCNFR811  = rdbg_readCoreRegi(core, index, 0x04C8U);
        const uint32_t SYNCCNFR1215 = rdbg_readCoreRegi(core, index, 0x04CCU);

        cinfov("CVE%u: SYNCCNFR03=0x%08x SYNCCNFR47=0x%08x SYNCCNFR811=0x%08x SYNCCNFR1215=0x%08x\n", index, (unsigned int)SYNCCNFR03, (unsigned int)SYNCCNFR47, (unsigned int)SYNCCNFR811, (unsigned int)SYNCCNFR1215);

        cinfov("CVE%u: VPCSAR=0x%08x VIBAR=0x%08x VSPC=0x%08x\n",
               index,
               (unsigned int)vpcsar,
               (unsigned int)vibar,
               /*(unsigned int)*((uint32_t*)gf_GetVirtAddr(vibar)),*/
               (unsigned int)vspc
               /*(unsigned int)*((uint32_t*)gf_GetVirtAddr(vibar + vspc))*/);

        dump_cl(core, index, dlsar, dlfar, backtrace, readahead, imp_dev_axi_bus_id);
    }
    else if (core == DMAC)
    {
        const uint32_t vcr   = rdbg_readCoreRegi(core, index, 0x0000U);
        const uint32_t prir  = rdbg_readCoreRegi(core, index, 0x0024U);
        const uint32_t clsar = rdbg_readCoreRegi(core, index, 0x0028U);
        const uint32_t clfar = rdbg_readCoreRegi(core, index, 0x00C8U);
        const uint32_t cleir = rdbg_readCoreRegi(core, index, 0x00CCU);

        cinfov("DMA%u: VCR=0x%08x CLSAR=0x%08x CLFAR=0x%08x CLEIR=0x%08x PRIR=0x%08x\n", index, (unsigned int)vcr, (unsigned int)clsar, (unsigned int)clfar, (unsigned int)cleir, (unsigned int)prir);

        const uint32_t SYNCCR0 = rdbg_readCoreRegi(core, index, 0x00E8);
        const uint32_t SYNCCR1 = rdbg_readCoreRegi(core, index, 0x00EC);
        const uint32_t SYNCCR2 = rdbg_readCoreRegi(core, index, 0x00F0);
        const uint32_t SYNCCR3 = rdbg_readCoreRegi(core, index, 0x00F4);

        cinfov("DMA%u: SYNCCR0=0x%08x SYNCCR1=0x%08x SYNCCR2=0x%08x SYNCCR3=0x%08x\n", index, (unsigned int)SYNCCR0, (unsigned int)SYNCCR1, (unsigned int)SYNCCR2, (unsigned int)SYNCCR3);

        dump_dma_SxxAR(core, index);
        dump_cl(core, index, clsar, clfar, backtrace, readahead, imp_dev_axi_bus_id);
    }

    cdbg_core_dump(core, index);
}

void cdbg_debug(int const core, int const index, osal_axi_bus_id_t imp_dev_axi_bus_id)
{
    rdbg_open();
#if defined(RCAR_SOC_V3U) || defined(RCAR_SOC_V3H2)
    cdbg_debug_V3U1(core, index, imp_dev_axi_bus_id);
#else
    cdbg_debug_V3H1(core, index, imp_dev_axi_bus_id);
#endif
    uint32_t vcr = 0;
    rdbg_readReg(0xFFA00000U, &vcr);
    DEBUG_PRINT("CVE0(VCR)=0x%08x\n", vcr);

    rdbg_close();
}

bool cdbg_check_TRAP(int core, int index)
{
    bool ret = false;

    if (core == CNN)
    {
        const uint32_t sr    = rdbg_readCoreRegi(core, index, 0x0010U);
        const uint32_t cleir = rdbg_readCoreRegi(core, index, 0x010CU);

        if (((sr & 0x01) == 0x01) && ((cleir & 0xFF000000U) == 0x88000000U))
        {
            ret = true;
        }
    }
    else if (core == DMAC)
    {
    }

    return ret;
}