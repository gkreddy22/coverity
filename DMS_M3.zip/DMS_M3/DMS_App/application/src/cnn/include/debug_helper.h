#ifndef __DEBUG_HELPER_H__
#define __DEBUG_HELPER_H__

#include "rcv_impdrv.h"

/*!
 * Shows a traceback of all IPs set in core_info.
 * @param rcvdrv_ctl
 * @param core_info
 */
void subsystem_traceback(RCvIMPDRVCTL* rcvdrv_ctl, RCvUint core_info);

#endif
