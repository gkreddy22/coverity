#ifndef _PB_H_
#define _PB_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>

#define PB_FORMAT_TYPE_UNSIGNED (0)
#define PB_FORMAT_TYPE_SIGNED (1)
#define PB_FORMAT_TYPE_FLOAT (2)

    /*!
 * \brief Definitions for protobuf file (pb).
 */

    typedef struct pb_clof
    {
        char *name;            /** Name of clof like "input_image_uv" or "Start_of_LayerConv3a" */
        uint32_t type;         /** 0 = memory; 1-12 = Border_masking; 13 = layer beginning (for debug); 14 = memory_channel_offset; 15-xx not assinged yet */
        uint32_t cl_offset;    /** Offset inside the commandlist in bytes */
        uint32_t memory_index; /** Index of associated memory like 2 where memories[1]= input_image_uv */
        uint32_t value;        /** clof value  (phys base + offset)*/
    } pb_clof_t;

    typedef struct pb_tile_fmt
    {
        uint16_t width;      /** width of tile in pixels */
        uint16_t height;     /** height of tile in pixels */
        uint16_t stride;     /** stride in pixels */
        uint8_t bitpp;       /** pixel bitpp format */
        uint8_t format_type; /** pixel format type 0 = unsigned int, 1 = signed int, 2 = float*/
    } pb_tile_fmt_t;

    typedef struct pb_mem_info
    {
        char *name;             /** Name of the memory */
        uint32_t base;          /** base address in physical memory */
        uint32_t frac_position; /** fractional position */
        uint32_t size;          /** size of memory block in bytes */
        uint32_t forced_stride;
        uint32_t channelCnt;
        uint32_t memres_index; /** index of corresponding memory resources */
        pb_tile_fmt_t tile;    /** tile definition */
        unsigned char *init_data;
        size_t init_data_size;
    } pb_mem_info_t;

    typedef struct pb_memres_info
    {
        char *name;            //! name of the memory ressource
        uint32_t startaddress; //! the memory address
        size_t size;           //! size in bytes
    } pb_memres_info_t;

    typedef struct pb_cmdl_info
    {
        unsigned int core_type;   //! core type
        unsigned int core_number; //! toltal number of cores of the same type used
        unsigned int syncid;      //! SyncID of the core for WUP/SLP
        size_t cl_data_size;      //! Cl data size
        const char *cmdlst_name;
        void *p_data;     //! pointer to the cl data array
        pb_clof_t *clofs; /** list of clofs */
        size_t clofs_size;
    } pb_cmdl_info_t;

    typedef struct pb_subnet_info
    {
        size_t cmdL_size; //! size of the commandlist
        pb_cmdl_info_t *cmdlistinfo;
    } pb_subnet_info_t;

    typedef struct rvxt_info_pb
    {
        size_t subnet_cout;
        pb_subnet_info_t *subnet_info;
        size_t memory_ressources_count;
        pb_memres_info_t *memory_ressources;
        size_t memories_count;
        pb_mem_info_t *memories;
        size_t entry_memories_count;
        pb_mem_info_t *entry_memories;
        size_t exit_memories_count;
        pb_mem_info_t *exit_memories;

    } rvxt_info_pb_t;

#ifdef __cplusplus
}
#endif

#endif
