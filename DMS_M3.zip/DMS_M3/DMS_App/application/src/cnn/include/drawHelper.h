#ifndef DRAW_HELPER_H
#define DRAW_HELPER_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

void drawPPMImageToFrameBuffer(const void* imageBuffer, size_t width, size_t height, size_t posX, size_t posY);
void draw8GreyScaleImageToFrameBuffer(const void* imageBuffer, size_t width, size_t height, size_t posX, size_t posY);
void draw16GreyScaleImageToFrameBuffer(const void* imageBuffer, size_t width, size_t height, size_t posX, size_t posY, bool normalize);
void drawRGB16ChannelToFrameBuffer(const uint16_t* rBuf, const uint16_t* gBuf, const uint16_t* bBuf, size_t width, size_t height, size_t posX, size_t posY, uint16_t bitmask, bool normalize);
void drawRGB8ChannelToFrameBuffer(const uint8_t* rBuf, const uint8_t* gBuf, const uint8_t* bBuf, size_t width, size_t height, size_t posX, size_t posY, uint8_t bitmask, bool normalize);

void maskBit16(const void* imageBuffer, size_t width, size_t height);

#endif   //DRAW_HELPER_H
