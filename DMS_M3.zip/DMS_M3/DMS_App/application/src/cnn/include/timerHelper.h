#ifndef _TIMERHELPER_H_
#define _TIMERHELPER_H_

#include <stddef.h>
#include <stdint.h>

uint64_t getSystimerValTick(void);
uint32_t getSystimerFreqHz(void);
uint64_t getSystimerVal_s(void);
uint64_t getSystimerVal_ms(void);
uint64_t getSystimerVal_us(void);
uint64_t getSystimerVal_ns(void);

#endif
