#ifndef __CNNIP_TARGET_PROJECT_H__
#define __CNNIP_TARGET_PROJECT_H__

//#include "../../../build/application/src/cl_bundle.pb.h"
#include "cl_bundle.pb.h"

#ifdef __cplusplus
extern "C"
{
#endif

    typedef struct
    {
        osal_memory_buffer_handle_t mem_buffer; //TEL debug
        void *virt;
        uintptr_t phys;
        size_t size;
    } mem_t;

#ifdef __cplusplus
}
#endif




#endif
