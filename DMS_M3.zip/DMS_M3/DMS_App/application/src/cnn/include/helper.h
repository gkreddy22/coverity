#ifndef _HELPER_H_
#define _HELPER_H_

#include "../.librvxtarget/ince/rvx_target/channelSetupList.h"
#include "../.librvxtarget/ince/rvx_target/rvxt_bcl.h"
#include "../.librvxtarget/ince/rvx_target/stringList.h"
#include <stdbool.h>
#include "pb.h"
#include "../.librvxtarget/ince/rvx_target/r_cl_patch_cnn.h"
#include "../.librvxtarget/ince/rvx_target/r_cl_patch_cve.h"
#include "../.librvxtarget/ince/rvx_target/r_cl_patch_dma.h"
#include "../.librvxtarget/ince/rvx_target/r_cl_patch_helper.h"
#include "../.librvxtarget/ince/rvx_target/r_cl_patch_imp.h"

#include "pb.h"
#include "../../include/common.h"
#include "rcar-xos/osal/r_osal.h"

#include "../.librvxtarget/ince/rvx_target/rvxt_execute.h"

#ifdef __cplusplus
extern "C"
{
#endif

    typedef struct
    {
        unsigned int clxN;
        unsigned int clxM;
        unsigned int clxL;
        uintptr_t cl2addr;
        bool fakeIMPCinDDR;
        uintptr_t CNNclBase;
        const char *fileNamePb;
        const char *output;
        const char *outdir;
        bool forceInit;
        unsigned int verbosity;
        int timeout_ms;
        bool no_detailed_dumping;
        bool dumpCLs;
        bool DTAenabled;
    } Cfg;

    /*!
 * @brief Setup channels as specified in BCL by data provided in list.
 */
    bool setupChannels(rvxt_info_pb_t *pbinfo, ChannelSetupList *p_channelSetupList, MemoryList *p_memoryList, 
                                            _CnnChannelDetails *CnnChannelDetails, int CnnChannelCount);
    bool R_CNN_entrychannels_set(_CnnChannelDetails *CnnChannelDetails, int CnnChannelCount);

    bool fillChannelSetupList(ChannelSetupList *p_channelSetupList);

    static e_osal_return_t configureIODevice(char *p_reg_dev_name, osal_device_handle_t *p_spmDevice);

    bool pb_cl_patch_DMA(const pb_cmdl_info_t cml_info, void *p_data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose);
    bool pb_cl_patch_IMP(const pb_cmdl_info_t cml_info, void *p_data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose);
    bool pb_cl_patch_CVE(const pb_cmdl_info_t cml_info, void *p_data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose);
    bool pb_cl_patch_CNN(const pb_cmdl_info_t cml_info, void *p_data, const size_t size, const uintptr_t base_old, const uintptr_t base_new, bool verbose);
    bool pb_cl_patch_CNN_patchGOSUB(const pb_cmdl_info_t cml_info, void *p_data, const uintptr_t base_old, const uintptr_t base_new, const size_t size, const bool verbose);

#ifdef __cplusplus
}
#endif

#endif
