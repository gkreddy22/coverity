#include <cstdlib>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

//#include "../../build/application/src/cl_bundle.pb.h"
#include "cl_bundle.pb.h"
#include <fstream>
#include <memory>
#include <sstream>
#include <string>

#include "include/helper.h"
#include ".librvxtarget/ince/md5.h"
#include "include/pb.h"
#include ".librvxtarget/ince/rvx_target/rvxt_md5.h"
#include ".librvxtarget/ince/rvx_target/stringList.h"
#include ".librvxtarget/ince/rvx_target/ui.h"
#include ".librvxtarget/ince/rvx_target/osal_helper.h"
#include ".librvxtarget/ince/rvx_target/rvxt_execute.h"
#include "common.h"

using namespace std;

extern rvxt_info_pb_t pbinfo;
//const cl_bundle_v3::cl_bundle_msg::memory_t &MemObj = model.memories(i);

#ifdef UNUSED
#elif defined(__GNUC__)
#define UNUSED(x) UNUSED_##x __attribute__((unused))
#elif defined(__LCLINT__)
#define UNUSED(x) /*@unused@*/ x
#else
#define UNUSED(x) x
#endif

//ASDCNNTOOLRC-702 - Declaration of functions that parser information from the pb file
void rvxt_pb_parseReadGraph (char * fileName, rvxt_info_pb_t * pb_info, cl_bundle_v3 :: cl_bundle_msg &model, osal_memory_manager_handle_t handle_osalmmngr, Commandlist ** commandlists);
void rvxt_pb_parsememory (cl_bundle_v3  :: cl_bundle_msg &model, rvxt_info_pb_t * pb_info);
void rvxt_pb_parsecmdlist (cl_bundle_v3 :: cl_bundle_msg &model, rvxt_info_pb_t * pb_info, osal_memory_manager_handle_t handle_osalmmngr, Commandlist ** commandlists);

/*!
 * @brief Setup input memories, must be done after CL patching.
 * @param model
 * @param size
 * @return
 */

/*ASDCNNTOOLRC-702 - rvxt_pb_parseReadGraph function takes pb filename and a pointer
* to rvxt_info_pb_t struct as arguments. It creates a cl_bundle model from the pb file
* and in-turn calls functions to parse memory related information (rvxt_pb_parsememory)
* and command list related data (rvxt_pb_parsecmdlist).
*/
void rvxt_pb_parseReadGraph(const char * fileName, rvxt_info_pb_t * pb_info, cl_bundle_v3 :: cl_bundle_msg & model, osal_memory_manager_handle_t handle_osalmmngr, Commandlist ** commandlists)
{
    try
    {
        //! Create file object pointer
        std :: fstream input(fileName, std :: ios :: in | std :: ios :: binary);

        if (! model.ParseFromIstream(&input))
        {
            cout << "Error in parsing the pb file" << endl;
        }

        input.close();
        rvxt_pb_parsememory(model, pb_info);
        rvxt_pb_parsecmdlist(model, pb_info, handle_osalmmngr, commandlists);
    }
    catch (char * ch)
    {
        cout << "Error accessing the pb file" << endl;
    }
}

/* ASDCNNTOOLRC-702 - dummyfunc is called from the cnnip_target_function
* It invokes rvxt_pb_parseReadGraph function to fetch data from pb file
* and store it in rvxt_info_pb_t structure.
*/
void pbParse(Cfg cfg, rvxt_info_pb_t * pbinfo, cl_bundle_v3 :: cl_bundle_msg &model, osal_memory_manager_handle_t handle_osalmmngr, Commandlist ** commandlists)
{

    if (NULL == cfg.fileNamePb)
    {
        cwarning("No protobuf file provided!\n");
    }

    //To read proto file and get model
    rvxt_pb_parseReadGraph(cfg.fileNamePb, pbinfo, model, handle_osalmmngr, commandlists);
}

/* ASDCNNTOOLRC-702 - rvxt_pb_parsememory is a parser function which fetches memrory and memres related 
* information from pb file and store it in rvxt_info_pb_t structure.
*/
void rvxt_pb_parsememory(cl_bundle_v3 :: cl_bundle_msg &model, rvxt_info_pb_t * pb_info)
{
    /* **************/
    /* Set memres */
    pb_info->memory_ressources_count = model.memres_size();
    pb_info->memory_ressources       = new pb_memres_info_t[model.memres_size()]; //pb_info->memory_ressources = (pb_memres_info_t*)gf_Memalign(4096, model.memres_size()* sizeof(pb_memres_info_t));

    /* ASDCNNTOOLRC-702 - This loop iteration is done to store memres (IMPC and DDR)
    * data, such as physical address and size of the memory resources from the pb model
    */

    for (unsigned int i = 0; i < pb_info->memory_ressources_count; i++)
    {
        const cl_bundle_v3 :: cl_bundle_msg :: memres_t &MemresObj = model.memres(i);
        const char * name = MemresObj.name().c_str();
        pb_info->memory_ressources[i].name         = (char *)name;
        pb_info->memory_ressources[i].size         = MemresObj.size();
        pb_info->memory_ressources[i].startaddress = MemresObj.startaddr();
    }

    /* **************/
    /* Set memories */
    pb_info->memories_count = model.memories_size();
    pb_info->memories       = new pb_mem_info_t[model.memories_size()]; //pb_info->memories = (pb_mem_info_t*)gf_Memalign(4096, model.memories_size()*sizeof(pb_mem_info_t));

    /* ASDCNNTOOLRC-702 - This loop iteration is done to store memory
    * data (DMAI, DMAO and DMAC tiles) from the pb model
    */

    for (unsigned int i = 0; i < pb_info->memories_count; i++)
    {
        const cl_bundle_v3::cl_bundle_msg::memory_t &MemObj = model.memories(i);
        const char * name  = MemObj.name().c_str();
        pb_info->memories[i].name             = (char *)name;
        pb_info->memories[i].base             = MemObj.address();
        pb_info->memories[i].size             = MemObj.size_bytes();
        pb_info->memories[i].memres_index     = MemObj.memres_index();
        pb_info->memories[i].frac_position    = MemObj.frac_pos();
        pb_info->memories[i].tile.bitpp       = (uint8_t)MemObj.bytepp();

        pb_info->memories[i].init_data_size   = MemObj.init_data().size();
        pb_info->memories[i].init_data        = new unsigned char[pb_info->memories[i].init_data_size]; //pb_info->memories[i].init_data = (unsigned char*)gf_Memalign(4096, pb_info->memories[i].init_data_size*sizeof(unsigned char));

        for (unsigned int j = 0; j < pb_info->memories[i].init_data_size; j++)
        {
            pb_info->memories[i].init_data[j] = (unsigned char)MemObj.init_data()[j];
        }

        pb_info->memories[i].tile.stride      = (MemObj.stride_size() > 0) ? (uint16_t)MemObj.stride(0) : (uint16_t)pb_info->memories[i].tile.width; //To be expanded
        pb_info->memories[i].forced_stride    = (MemObj.stride_size() > 1) ? (uint16_t)MemObj.stride(1) : 0;
        pb_info->memories[i].tile.format_type = (uint8_t)MemObj.format_type();

        pb_info->memories[i].channelCnt       = 1;
        pb_info->memories[i].tile.height      = 1;
        pb_info->memories[i].tile.width       = 1;

        if (MemObj.tensor_layout() == "WHC")
        {
            pb_info->memories[i].tile.height  = (uint16_t)MemObj.tensor_size(1);
            pb_info->memories[i].tile.width   = (uint16_t)MemObj.tensor_size(0);
            pb_info->memories[i].channelCnt   = MemObj.tensor_size(2);
        }
        else if (MemObj.tensor_layout() == "WCH")
        {
            pb_info->memories[i].tile.height  = (uint16_t)MemObj.tensor_size(2);
            pb_info->memories[i].tile.width   = (uint16_t)MemObj.tensor_size(0);
            pb_info->memories[i].channelCnt   = MemObj.tensor_size(1);
        }
        else if (MemObj.tensor_layout() == "CWH")
        {
            pb_info->memories[i].tile.height  = (uint16_t)MemObj.tensor_size(2);
            pb_info->memories[i].tile.width   = (uint16_t)MemObj.tensor_size(1);
            pb_info->memories[i].channelCnt   = MemObj.tensor_size(0);
        }
        else if (MemObj.tensor_layout() == "W")
        {
            pb_info->memories[i].tile.width   = (uint16_t)MemObj.tensor_size(0);
        }
        else if (MemObj.tensor_layout() == "WH")
        {
            pb_info->memories[i].tile.height  = (uint16_t)MemObj.tensor_size(1);
            pb_info->memories[i].tile.width   = (uint16_t)MemObj.tensor_size(0);
        }
    }

    /* ********************/
    /* Set entry_memories */
    /* ASDCNNTOOLRC-702 - This section of the code is written to store the entry memory data.
    * The indices_of_input_memories() parameter specifies the index of memres_t message in the pb model
    * which entry memory data is stored.
    */

    int entryindex;

    pb_info->entry_memories_count  = model.indices_of_input_memories_size();
    pb_info->entry_memories        = new pb_mem_info_t[pb_info->entry_memories_count];

    for (unsigned int i = 0; i < pb_info->entry_memories_count; i++)
    {
        entryindex                 = model.indices_of_input_memories(i);
        pb_info->entry_memories[i] = pb_info->memories[entryindex];
    }

    /* ******************/
    /* Set exit_memories*/
    /* ASDCNNTOOLRC-702 - This section of the code is written to store the exit memory data.
    * The indices_of_output_memories() parameter specifies the index of memres_t message in the pb model
    * which exit memory data is stored.
    */

    int exitindex;

    pb_info->exit_memories_count  = model.indices_of_output_memories_size();
    pb_info->exit_memories        = new pb_mem_info_t[pb_info->exit_memories_count];

    for (unsigned int i = 0; i < pb_info->exit_memories_count; i++)
    {
        exitindex = model.indices_of_output_memories(i);
        pb_info->exit_memories[i] = pb_info->memories[exitindex];
    }

}

/* ASDCNNTOOLRC-702 - rvxt_pb_parsecmdlist is a parser function which fetches commandlist related 
* information from pb file and store it in rvxt_info_pb_t structure.
*/
void rvxt_pb_parsecmdlist(cl_bundle_v3 :: cl_bundle_msg & model, rvxt_info_pb_t * pb_info, osal_memory_manager_handle_t handle_osalmmngr, Commandlist ** commandlists)
{
    /* ASDCNNTOOLRC-702 - Data from each cl_t message for every subnet is parsed and 
    * stored in the respective structures. This loop runs for the subnet count.
    */
    pb_info->subnet_cout = model.subnets_size();
    pb_info->subnet_info = (pb_subnet_info_t *)malloc(pb_info->subnet_cout * sizeof(pb_subnet_info_t));

    for (int itr = 0; itr < model.subnets_size(); itr++)
    {
        const cl_bundle_v3 :: cl_bundle_msg :: subnet_t &SubnetObj = model.subnets(itr);
        pb_info->subnet_info[itr].cmdL_size   = SubnetObj.commandlists_size();
        pb_info->subnet_info[itr].cmdlistinfo = (pb_cmdl_info_t *)malloc(sizeof(pb_cmdl_info_t) * SubnetObj.commandlists_size());

        for (int i = 0; i < SubnetObj.commandlists_size(); i++)
        {
            // ASDCNNTOOLRC-702 - storing sync_id, cl_data and core data from cl_t message in the cl_bundle
            const cl_bundle_v3::cl_bundle_msg::cl_t &CmdLObj = SubnetObj.commandlists(i);
            pb_info->subnet_info[itr].cmdlistinfo[i].syncid      =  CmdLObj.syncid();
            pb_info->subnet_info[itr].cmdlistinfo[i].core_type   =  CmdLObj.coretype();
            pb_info->subnet_info[itr].cmdlistinfo[i].core_number =  CmdLObj.corenumber();

            //osal_memory_buffer_handle_t cl_buffer = OSAL_MEMORY_BUFFER_HANDLE_INVALID;
            e_osal_return_t ret = R_OSAL_MmngrAlloc(handle_osalmmngr, CmdLObj.cl_data().size() * sizeof(char) + 4096 - (CmdLObj.cl_data().size() * sizeof(char)) % 4096, 4096, &( * commandlists)[i].cmd_buffer);

            if (ret != OSAL_RETURN_OK)
            {
                DEBUG_PRINT("rvxt_bcl_alloc: R_OSAL_MmngrAlloc error code: %d\n", ret);
                return;
            }

            CHECK_OK(OSAL_CHECK(R_OSAL_MmngrGetCpuPtr((*commandlists)[i].cmd_buffer, &pb_info->subnet_info[itr].cmdlistinfo[i].p_data)));

            // pb_info->subnet_info[itr].cmdlistinfo[i].p_data = gf_Malloc(CmdLObj.cl_data().size() * sizeof(char));
            memcpy(pb_info->subnet_info[itr].cmdlistinfo[i].p_data, CmdLObj.cl_data().c_str(), CmdLObj.cl_data().size());

            pb_info->subnet_info[itr].cmdlistinfo[i].cl_data_size = CmdLObj.cl_data().size();
            pb_info->subnet_info[itr].cmdlistinfo[i].cmdlst_name  = CmdLObj.name().c_str();

            //read command list offsets
            pb_info->subnet_info[itr].cmdlistinfo[i].clofs_size   = CmdLObj.clofs_size();
            pb_info->subnet_info[itr].cmdlistinfo[i].clofs        = new pb_clof_t[pb_info->subnet_info[itr].cmdlistinfo[i].clofs_size];

            for (unsigned int j = 0; j < pb_info->subnet_info[itr].cmdlistinfo[i].clofs_size; j++)
            {
                pb_info->subnet_info[itr].cmdlistinfo[i].clofs[j].name         = (char *)CmdLObj.clofs(j).name().c_str();
                pb_info->subnet_info[itr].cmdlistinfo[i].clofs[j].type         = CmdLObj.clofs(j).type();
                pb_info->subnet_info[itr].cmdlistinfo[i].clofs[j].cl_offset    = CmdLObj.clofs(j).cl_offset();
                pb_info->subnet_info[itr].cmdlistinfo[i].clofs[j].memory_index = CmdLObj.clofs(j).memory_index();
                pb_info->subnet_info[itr].cmdlistinfo[i].clofs[j].value        = CmdLObj.clofs(j).value();
            }
        }
    }
}
