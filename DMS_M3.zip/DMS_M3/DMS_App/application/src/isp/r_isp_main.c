/***********************************************************************************************************************
* Copyright [2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : isp_main.c
* Version      : 1.0.0
* Device(s)    : R-Car V3x
***********************************************************************************************************************/
/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include <stdio.h>
#include <string.h>
#include "include/r_isp_sample.h"
#include "include/r_isp_callback.h"
#include "include/r_isp_setup.h"
#include "rcar-xos/osal/r_osal.h"
#include "rcar-xos/cisp/r_cisp_version.h"
#include "rcar-xos/tisp/r_tisp_version.h"
#include "common.h"

/*======================================================================================================================
Private macro definitions
======================================================================================================================*/

/*******************************************************************************************************************//**
 * Number of use cases to be executed by the ISP Sample App
***********************************************************************************************************************/
#define ISP_SAMPLE_NB_OF_USE_CASES   1u

/*======================================================================================================================
Private function prototypes
======================================================================================================================*/
static void r_isp_get_version (void);
static e_isp_sample_return_t r_ispsample_cisp_m2m (uint8_t channel);
static uint8_t channel =0;


/***********************************************************************************************************************
* Start of function R_ISP_Execute()
***********************************************************************************************************************/
int R_ISP_Execute()
{
    e_isp_sample_return_t ret = ISP_SAMPLE_RET_FAILED;

    ret = r_ispsample_cisp_m2m(channel);

    if (ISP_SAMPLE_RET_ERR_CISP == ret)
    {
        DEBUG_PRINT("FAILED r_ispsample_cisp_m2m ");
        return FAILED;
    }

    return SUCCESS;
}

/***********************************************************************************************************************
* Start of function R_ISP_Initialize()
***********************************************************************************************************************/
int R_ISP_Initialize() {

    e_isp_sample_return_t allocate_mem_ret;
    uint16_t   cisp_ret;
    e_isp_sample_return_t   isp_memutil_ret;

    /* Allocate the required memory buffers */

    allocate_mem_ret = R_ISP_AllocateMemBuffers(channel);
    if (ISP_SAMPLE_RET_OK != allocate_mem_ret) {

        PRINT_ERROR("buffer allocation failed\n");
        return FAILED;
    }
    else
    {
        DEBUG_PRINT("buffer allocation successfully\n");
    }

    /*Init CISP SW & HW */
    cisp_ret = R_ISP_InitializeCISP(channel);

    if (CISP_RET_E_OK != cisp_ret)
    {
        PRINT_ERROR("cisp init failed\n");
        return FAILED;

    }
    else
    {
        DEBUG_PRINT("cisp init successfully\n");
    }

    /* configure CISP pipeline */

    cisp_ret = R_ISP_SetupCispM2M(channel);

    if (ISP_SAMPLE_RET_OK != cisp_ret)
    {
        PRINT_ERROR("Configure the CISP pipeline failed\n");
        return FAILED;
    }
    else
    {
        DEBUG_PRINT("Configured the CISP pipeline successfully\n");
    }

    return SUCCESS;
}


/***********************************************************************************************************************
* Start of function R_ISP_DeInitialize()
***********************************************************************************************************************/

int R_ISP_DeInitialize() {

    e_isp_sample_return_t allocate_mem_ret;
    uint16_t   cisp_ret;
    e_isp_sample_return_t isp_memutil_ret;

    /* Free the allocated memory buffers */
    allocate_mem_ret = R_ISP_DeallocateMemBuffers(channel); 
    if(ISP_SAMPLE_RET_OK == allocate_mem_ret){

        DEBUG_PRINT("freed buffer\n");
    }

     /*  De-Init CISP HW & SW */
    cisp_ret = R_ISP_FinalizeCISP(channel);

    if (CISP_RET_E_OK == cisp_ret)
    {
        DEBUG_PRINT("Step 6. De-Init CISP HW & SW - passed\n");
    }

    return SUCCESS;
}

/*======================================================================================================================
Private function definitions
======================================================================================================================*/


/***********************************************************************************************************************
* Start of function r_ispsample_cisp_m2m()
***********************************************************************************************************************/
static e_isp_sample_return_t r_ispsample_cisp_m2m(uint8_t channel)
{
    e_isp_sample_return_t ret = ISP_SAMPLE_RET_FAILED;
    uint16_t         cisp_ret = CISP_RET_E_OK;
    DEBUG_PRINT("\n*** Start Use Case: CISP M2M for ISP channel %d ***\n", channel);

    cisp_ret = R_ISP_SetEventsAndStartCISP(channel);

    if (CISP_RET_E_OK == cisp_ret)
    {
        DEBUG_PRINT(" Setup the interrupts and start the execution of the CISP HW - passed\n");

        /* . Wait for end of frame from CISP */
        R_OSAL_ThreadSleepForTimePeriod((osal_milli_sec_t)TIMEOUT_25MS_SLEEP);

        /*Save Buffer Content in a file (raw format) */
        ret = R_ISP_SaveCispOutBuffers(channel);

        /*. Stop the execution of the CISP HW */
        cisp_ret = R_CISP_Stop(channel);

        if (CISP_RET_E_OK == cisp_ret)
        {
            DEBUG_PRINT(" Stop the execution of the CISP HW - passed\n");
        }
        else
        {
            printf("R_CISP_Stop failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(cisp_ret), (uint16_t)cisp_ret);
        }
    }

    if ((CISP_RET_E_OK != cisp_ret) && (ISP_SAMPLE_RET_OK == ret))
    {
        ret = ISP_SAMPLE_RET_ERR_CISP;
    }

    return ret;
}
/***********************************************************************************************************************
* End of function r_ispsample_cisp_m2m()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function r_isp_get_version()
***********************************************************************************************************************/
static void r_isp_get_version(void)
{
    const st_cisp_version_t * p_cisp_version;
    const st_tisp_version_t * p_tisp_version;

    /* CISP Version */
    p_cisp_version = R_CISP_GetVersion();

    if (p_cisp_version != NULL)
    {
      DEBUG_PRINT("CISP Version Major: %d\n", p_cisp_version->major);
      DEBUG_PRINT("CISP Version Minor: %d\n", p_cisp_version->minor);
      DEBUG_PRINT("CISP Version Patch: %d\n", p_cisp_version->patch);
    }

    /* TISP Version */
    p_tisp_version = R_TISP_GetVersion();

    if (p_tisp_version != NULL)
    {
        DEBUG_PRINT("TISP Version Major: %d\n", p_tisp_version->major);
        DEBUG_PRINT("TISP Version Minor: %d\n", p_tisp_version->minor);
        DEBUG_PRINT("TISP Version Patch: %d\n", p_tisp_version->patch);
    }

}
/***********************************************************************************************************************
* End of function r_isp_get_version()
***********************************************************************************************************************/

/*======================================================================================================================
End of file
======================================================================================================================*/
