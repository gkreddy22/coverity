/***********************************************************************************************************************
* Copyright [2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_isp_setup.c
* Version      : 1.0.0
* Device(s)    : R-Car V3x
* Description  : Configure the ISP drivers
***********************************************************************************************************************/
/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include <stdio.h>  
#include <string.h> 
#include "include/r_isp_setup.h"
#include "include/r_isp_sample.h"
#include "include/r_isp_callback.h"
#include "common.h"
//#include "image2_raw.h"
/*======================================================================================================================
Priavte macro definitions
======================================================================================================================*/
/*******************************************************************************************************************//**
 * Device String used by the OSAL to access a specific CISP device
***********************************************************************************************************************/
#define CISP_DEVICE_STRING_0 "cisp_00" /*!< String used by OSAL IO Manager to access CISP Unit 0  */
#define CISP_DEVICE_STRING_1 "cisp_01" /*!< String used by OSAL IO Manager to access CISP Unit 1  */
#define CISP_DEVICE_STRING_2 "cisp_02" /*!< String used by OSAL IO Manager to access CISP Unit 2  */
#define CISP_DEVICE_STRING_3 "cisp_03" /*!< String used by OSAL IO Manager to access CISP Unit 3  */

/*======================================================================================================================
Public global variables
======================================================================================================================*/

/*======================================================================================================================
Private module variables
======================================================================================================================*/

static st_isp_memutil_buffer_t isp_buff_in[ISP_NUM_CHANNELS];       /* input buffer where the static image is loaded */
static st_isp_memutil_buffer_t isp_buff_outRGB[ISP_NUM_CHANNELS];   /* Output Buffer 0 RGB */
static st_isp_memutil_buffer_t isp_buff_outY[ISP_NUM_CHANNELS];     /* Output Buffer for the Luma */
static st_isp_memutil_buffer_t isp_buff_outUV[ISP_NUM_CHANNELS];    /* Output Buffer for the Croma Components */

/*======================================================================================================================
Private function prototypes
======================================================================================================================*/
static uint32_t rel_math_fix_to_fix (uint32_t fix_in, uint8_t q_in, uint8_t q_out);
static e_isp_sample_return_t r_isp_setup_cisp_buffers (uint8_t unit_index, uint16_t frame_width, uint16_t frame_height, bool cisp_m2m_uc);
static uint16_t r_isp_setup_cisp_pipeline (uint8_t unit_index);

/*======================================================================================================================
Public function definitions
======================================================================================================================*/
/***********************************************************************************************************************
 * Start of function R_ISP_AllocateMemBuffers()
 **********************************************************************************************************************/
e_isp_sample_return_t R_ISP_AllocateMemBuffers(uint8_t unit_index)
{
    e_isp_sample_return_t ret;
    char cisp_dev_str[10];

    switch (unit_index)
    {
        case 0:
            strcpy(cisp_dev_str, CISP_DEVICE_STRING_0);
            break;
        case 1:
            strcpy(cisp_dev_str, CISP_DEVICE_STRING_1);
            break;
        case 2:
            strcpy(cisp_dev_str, CISP_DEVICE_STRING_2);
            break;
        case 3:
            strcpy(cisp_dev_str, CISP_DEVICE_STRING_3);
            break;
        default:
            break;
            /* channel not supported it should never get here */
    }

    /* allocate input buffer for the first image */
    isp_buff_in[unit_index].size  = ISP_IN_BUFFER_SIZE;
    isp_buff_in[unit_index].align = 256U;    //Default-256
    ret = R_ISP_MEMUTIL_MemAlloc(&(isp_buff_in[unit_index]), cisp_dev_str);
 
    if (ISP_SAMPLE_RET_OK == ret)
    {
        printf("#DP isp_buff_outRGB[unit_index].size = ISP_OUT_BUFFER_SIZE; \n");
        isp_buff_outRGB[unit_index].size  = ISP_OUT_BUFFER_SIZE;
        isp_buff_outRGB[unit_index].align = 256U;    //Default-256
        ret = R_ISP_MEMUTIL_MemAlloc(&(isp_buff_outRGB[unit_index]), cisp_dev_str);
    }

    if (ISP_SAMPLE_RET_OK == ret)
    {
        /* Setup Output buffer to store Y component */
        isp_buff_outY[unit_index].size  = ISP_OUT_BUFFER_SIZE;
        isp_buff_outY[unit_index].align = 256U;    //Default-256
        ret = R_ISP_MEMUTIL_MemAlloc(&(isp_buff_outY[unit_index]), cisp_dev_str);
    }

    if (ISP_SAMPLE_RET_OK == ret)
    {
        /* Setup Output buffer to store UV components */
        isp_buff_outUV[unit_index].size  = ISP_OUT_BUFFER_SIZE;
        isp_buff_outUV[unit_index].align = 256U;    //Default-256
        ret = R_ISP_MEMUTIL_MemAlloc(&(isp_buff_outUV[unit_index]), cisp_dev_str);
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function R_ISP_AllocateMemBuffers()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_DeallocateMemBuffers()
 **********************************************************************************************************************/
e_isp_sample_return_t R_ISP_DeallocateMemBuffers(uint8_t unit_index)
{
    e_isp_sample_return_t  ret;

    /* Free input buffer for the first image */
    ret = R_ISP_MEMUTIL_MemFree(&(isp_buff_outUV[unit_index]));
 
    if (ISP_SAMPLE_RET_OK == ret)
    {
        ret = R_ISP_MEMUTIL_MemFree(&(isp_buff_outY[unit_index]));

        if (ISP_SAMPLE_RET_OK == ret)
        {
            /* Free Output buffer to store Y component */
            ret = R_ISP_MEMUTIL_MemFree(&(isp_buff_outRGB[unit_index]));

            if (ISP_SAMPLE_RET_OK == ret)
            {
                /* Free Output buffer to store UV components */
                ret = R_ISP_MEMUTIL_MemFree(&(isp_buff_in[unit_index]));

                if (ISP_SAMPLE_RET_OK != ret)
                {
                    PRINT_ERROR("Deallocate input buffer failed. \n");
                }
            }
            else
            {
                PRINT_ERROR("Deallocate output RGB buffer failed. \n");
            }
        }
        else
        {
            PRINT_ERROR("Deallocate output Y buffer failed. \n");
        }
    }
    else
    {
        PRINT_ERROR("Deallocate output UV buffer failed. \n");
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function R_ISP_DeallocateMemBuffers()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_SampleReturnToStr()
 **********************************************************************************************************************/
const char * R_ISP_SampleReturnToStr(e_isp_sample_return_t result)
{
    const char * ret;

    switch (result)
    {
        case ISP_SAMPLE_RET_OK:
            ret = "ISP_SAMPLE_RET_OK";
        break;
        case ISP_SAMPLE_RET_FAILED:
            ret = "ISP_SAMPLE_RET_FAILED";
        break;
        case ISP_SAMPLE_RET_ERR_OSAL:
            ret = "ISP_SAMPLE_RET_ERR_OSAL";
        break;
        case ISP_SAMPLE_RET_ERR_CISP:
            ret = "ISP_SAMPLE_RET_ERR_CISP";
        break;
        case ISP_SAMPLE_RET_ERR_TISP:
            ret = "ISP_SAMPLE_RET_ERR_TISP";
        break;
        case ISP_SAMPLE_RET_ERR_VSPX:
            ret = "ISP_SAMPLE_RET_ERR_VSPX";
        break;

        default:
            ret = "unknown";
        break;
    }

    return ret;
}
/***********************************************************************************************************************
 *  End of function R_ISP_SampleReturnToStr()
 **********************************************************************************************************************/

/* CISP Setup Functions*/
/***********************************************************************************************************************
 * Start of function R_ISP_CispReturnToStr()
 **********************************************************************************************************************/
const char * R_ISP_CispReturnToStr(uint16_t result)
{
    const char * ret;

    switch (result)
    {
        case CISP_RET_E_OK:
            ret = "CISP_RET_E_OK";
        break;
        case CISP_RET_ERR_WRONG_ARGUMENTS:
            ret = "CISP_RET_ERR_WRONG_ARGUMENTS";
        break;
        case CISP_RET_ERR_WRONG_READDATA:
            ret = "CISP_RET_ERR_WRONG_READDATA";
        break;
        case CISP_RET_ERR_REGBASEADDR:
            ret = "CISP_RET_ERR_REGBASEADDR";
        break;
        case CISP_RET_ERR_OPERATION_WRONGSTATE:
            ret = "CISP_RET_ERR_OPERATION_WRONGSTATE";
        break;
        case CISP_RET_ERR_FRABORT_SLOTSEARCH:
            ret = "CISP_RET_ERR_FRABORT_SLOTSEARCH";
        break;
        case CISP_RET_ERR_FRABORT_SLOT_NOT_CANCEL:
            ret = "CISP_RET_ERR_FRABORT_SLOT_NOT_CANCEL";
        break;
        case CISP_RET_ERR_CONTEXT_NOT_INIT:
            ret = "CISP_RET_ERR_CONTEXT_NOT_INIT";
        break;
        case CISP_RET_ERR_INPUTPORT_NOT_START:
            ret = "CISP_RET_ERR_INPUTPORT_NOT_START";
        break;
        case CISP_RET_ERR_INPUTPORT_NOT_STOP:
            ret = "CISP_RET_ERR_INPUTPORT_NOT_STOP";
        break;
        case CISP_RET_ERR_UNINTENDED_MOD_STOP_ERR:
            ret = "CISP_RET_ERR_UNINTENDED_MOD_STOP_ERR";
        break;
        case CISP_RET_ERR_OSAL:
            ret = "CISP_RET_ERR_OSAL";
        break;

        default:
            ret = "unknown";
        break;
    }

    return ret;
}

/***********************************************************************************************************************
 *  End of function R_ISP_CispReturnToStr()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_InitializeCISP()
 **********************************************************************************************************************/
uint16_t R_ISP_InitializeCISP(uint8_t unit_index)
{
    uint16_t ret;
    st_cisp_drv_usr_param_t cisp_init_cfg;

    switch (unit_index)
    {
        case 0:
            cisp_init_cfg.mutex_id = OSAL_MUTEX_CISP_00;
        break;
        case 1:
            cisp_init_cfg.mutex_id = OSAL_MUTEX_CISP_01;
        break;
        case 2:
            cisp_init_cfg.mutex_id = OSAL_MUTEX_CISP_02;
        break;
        case 3:
            cisp_init_cfg.mutex_id = OSAL_MUTEX_CISP_03;
        break;
        default:
            /* channel not supported it should never get here */
        break;
    }

    cisp_init_cfg.mutex_timeout_ms = 0;
    cisp_init_cfg.int_priority     = OSAL_INTERRUPT_PRIORITY_TYPE10;
    ret = R_CISP_Init(unit_index, &cisp_init_cfg);

    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_Open(unit_index);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_Open failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }

    }
    else
    {
        PRINT_ERROR("R_CISP_Init failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function R_ISP_InitializeCISP()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_FinalizeCISP()
 **********************************************************************************************************************/
uint16_t R_ISP_FinalizeCISP(uint8_t unit_index)
{
    uint16_t ret;

    ret = R_CISP_Close(unit_index);

    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_DeInit(unit_index);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_Close failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }

    }
    else
    {
        PRINT_ERROR("R_CISP_DeInit failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
    }

    return ret;
}

/***********************************************************************************************************************
 * End of function R_ISP_FinalizeCISP()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_SetEventsAndStartCISP()
 **********************************************************************************************************************/
uint16_t R_ISP_SetEventsAndStartCISP(uint8_t unit_index)
{
    uint16_t ret;
    st_cisp_event_int_cfg_t cisp_int_cfg;

    g_cisp_frame_start_cnt = 0u;
    g_cisp_frame_end_cnt   = 0u;
    g_cisp_stats_cnt       = 0u;
    
    /* Enable ISP Interrupts */
    memset(&cisp_int_cfg, 0x00, sizeof(st_cisp_event_int_cfg_t)); /* clear config */
    cisp_int_cfg.enable      = 1;
    cisp_int_cfg.event_flags = (1u << 8u);                        /* After MCFE */
    ret = R_CISP_SetEventCb(unit_index, CISP_FRAME_START_EV, &R_ISP_CispEventFrameStartCb, &cisp_int_cfg);
    cisp_int_cfg.event_flags = (1u << 15u);                      /* After output formatter */
    ret |= R_CISP_SetEventCb(unit_index, CISP_FRAME_END_EV, &R_ISP_CispEventFrameEndCb, &cisp_int_cfg);
    ret |= R_CISP_SetEventCb(unit_index, CISP_STAT_EV, &R_ISP_CispEventStatsCb, &cisp_int_cfg);

    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_Start(unit_index, 0);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_Start failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }

    }
    else
    {
        PRINT_ERROR("R_CISP_SetEventCb failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function R_ISP_SetEventsAndStartCISP()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_SetupCispM2M()
 **********************************************************************************************************************/
e_isp_sample_return_t R_ISP_SetupCispM2M(uint8_t unit_index)
{
    e_isp_sample_return_t    ret;
    uint16_t                 cisp_ret;
    st_cisp_input_port_cfg_t iport_cfg; /* input Port cfg */
    st_cisp_mcfe_slot_cfg_t  slot_cfg;  /* Slot cfg  */

    /* Allocate and Setup Isp buffer and Set input buffer as Filled (in case of M2M) */
    ret = r_isp_setup_cisp_buffers(unit_index, g_frame_width, g_frame_height, true);

    if (ISP_SAMPLE_RET_OK == ret)
    {
        /* Setup input Port */
        cisp_ret = R_CISP_GetInputPort(unit_index, 0, &iport_cfg);

        if (CISP_RET_E_OK == cisp_ret)
        {
            /* Setup input Port */
            iport_cfg.enable                = 0;                         /* No need in M2M mode */
            iport_cfg.input.mode            = CISP_INPUT_MODE_DIRECT;
            iport_cfg.input.mipi_id         = 0;                        /* Unused */
            iport_cfg.input.source          = 0;
            iport_cfg.buffer.mode           = CISP_BUFFER_MODE_FULL_FB; /* Mandatory for M2M */
            iport_cfg.buffer.data_width     = 8;
            iport_cfg.buffer.raw_buffer[0]  = CISP_BUFFER_NOT_USED;
            iport_cfg.buffer.raw_buffer[1]  = CISP_BUFFER_NOT_USED;
            iport_cfg.statistic.base_addr   = 0;
            iport_cfg.statistic.size        = 0;
            iport_cfg.statistic.read_units  = 0;
            cisp_ret = R_CISP_SetInputPort(unit_index, 0, &iport_cfg);

            if (CISP_RET_E_OK == cisp_ret)
            {
                /* Get and Setup MCFE */
                cisp_ret = R_CISP_GetMcfeSlot(unit_index, CISP_SLOT0, &slot_cfg);

                if (CISP_RET_E_OK == cisp_ret)
                {
                    slot_cfg.inputs[0]          = 0;                        /* RAW buffer 0 in slot 0 - First Image */
                    slot_cfg.mode               = CISP_MCFE_SLOT_RAM_INPUT;
                    slot_cfg.delay              = 20;                      /* Add small delay after slot processing */
                    slot_cfg.axi_out_buf_1[0]   = 0;                       /* Out buffer 0 */
                    slot_cfg.axi_out_buf_2[0]   = 1;                       /* Out buffer 1 */
                    slot_cfg.axi_out_buf_1[1]   = 3;                       /* Out Buffer UV (Chroma) */
                    slot_cfg.axi_out_buf_1[2]   = 2;                       /* Out Buffer Y  (Luma) */
                    cisp_ret = R_CISP_SetMcfeSlot(unit_index, CISP_SLOT0, &slot_cfg);

                    if (CISP_RET_E_OK == cisp_ret)
                    {
                        cisp_ret = r_isp_setup_cisp_pipeline(unit_index);
                    }
                    else
                    {
                        PRINT_ERROR("R_CISP_SetMcfeSlot failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(cisp_ret), (uint16_t)cisp_ret);
                    }
                }
                else
                {
                    PRINT_ERROR("R_CISP_GetMcfeSlot failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(cisp_ret), (uint16_t)cisp_ret);
                }
            }
            else
            {
                PRINT_ERROR("R_CISP_SetInputPort failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(cisp_ret), (uint16_t)cisp_ret);
            }
        }
        else
        {
            PRINT_ERROR("R_CISP_GetInputPort failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(cisp_ret), (uint16_t)cisp_ret);
        }

        if (CISP_RET_E_OK != cisp_ret)
        {
            ret = ISP_SAMPLE_RET_ERR_CISP;
        }

    }
    else
    {
        PRINT_ERROR("r_isp_setup_cisp_buffers for M2M failed. Error Code %s(%d)\n", R_ISP_SampleReturnToStr(ret), (uint16_t)ret);
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function R_ISP_SetupCispM2M()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_SaveCispOutBuffers()
 **********************************************************************************************************************/
e_isp_sample_return_t R_ISP_SaveCispOutBuffers(uint8_t unit_index)
{
    e_isp_sample_return_t  ret;
    fflush(stdout);
    gp_isp_out_y  = isp_buff_outY[unit_index].virt_addr;
    gp_isp_out_uv = isp_buff_outUV[unit_index].virt_addr;
    return ret; 
}
/***********************************************************************************************************************
 * End of function R_ISP_SaveCispOutBuffers()
 **********************************************************************************************************************/


/* TISP Setup Functions*/

/***********************************************************************************************************************
 * Start of function R_ISP_TispReturnToStr()
 **********************************************************************************************************************/
const char * R_ISP_TispReturnToStr(uint16_t result)
{
    const char * ret;

    switch (result)
    {
        case TISP_RET_E_OK:
            ret = "TISP_RET_E_OK";
        break;
        case TISP_RET_ERR_WRONG_ARGUMENTS:
            ret = "TISP_RET_ERR_WRONG_ARGUMENTS";
        break;
        case TISP_RET_ERR_WRONG_READDATA:
            ret = "TISP_RET_ERR_WRONG_READDATA";
        break;
        case TISP_RET_ERR_STATE_WRONGSEQUENCE:
            ret = "TISP_RET_ERR_STATE_WRONGSEQUENCE";
        break;
        case TISP_RET_ERR_OPERATION_WRONGSTATE:
            ret = "TISP_RET_ERR_OPERATION_WRONGSTATE";
        break;
        case TISP_RET_ERR_UNSUPPORTED_VERSION:
            ret = "TISP_RET_ERR_UNSUPPORTED_VERSION";
        break;
        case TISP_RET_ERR_OSAL:
            ret = "TISP_RET_ERR_OSAL";
        break;

        default:
            ret = "unknown";
        break;
    }

    return ret;
}
/***********************************************************************************************************************
 *  End of function R_ISP_TispReturnToStr()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_InitializeTISP()
 **********************************************************************************************************************/
uint16_t R_ISP_InitializeTISP(uint8_t unit_index)
{
    uint16_t ret;
    st_tisp_drv_usr_param_t tisp_init_cfg;

    switch (unit_index)
    {
        case 0:
            tisp_init_cfg.mutex_id = OSAL_MUTEX_TISP_00;
        break;
        case 1:
            tisp_init_cfg.mutex_id = OSAL_MUTEX_TISP_01;
        break;
        case 2:
            tisp_init_cfg.mutex_id = OSAL_MUTEX_TISP_02;
        break;
        case 3:
            tisp_init_cfg.mutex_id = OSAL_MUTEX_TISP_03;
        break;
        default:
            /*channel not supported it should never get here */
        break;
    }

    tisp_init_cfg.mutex_timeout_ms = 0;
    tisp_init_cfg.int_priority     = OSAL_INTERRUPT_PRIORITY_TYPE10;
    ret = R_TISP_Init(unit_index, &tisp_init_cfg);

    if (TISP_RET_E_OK == ret)
    {
        ret = R_TISP_Open(unit_index);

        if (TISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_TISP_Open failed. Error Code %s(%d)\n", R_ISP_TispReturnToStr(ret), (uint16_t)ret);
        }

    }
    else
    {
        PRINT_ERROR("R_TISP_Init failed. Error Code %s(%d)\n", R_ISP_TispReturnToStr(ret), (uint16_t)ret);
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function R_ISP_InitializeTISP()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_FinalizeTISP()
 **********************************************************************************************************************/
uint16_t R_ISP_FinalizeTISP(uint8_t unit_index)
{
    uint16_t ret;

    ret = R_TISP_Close(unit_index);

    if (TISP_RET_E_OK == ret)
    {
        ret = R_TISP_DeInit(unit_index);

        if (TISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_TISP_Close failed. Error Code %s(%d)\n", R_ISP_TispReturnToStr(ret), (uint16_t)ret);
        }

    }
    else
    {
        PRINT_ERROR("R_TISP_DeInit failed. Error Code %s(%d)\n", R_ISP_TispReturnToStr(ret), (uint16_t)ret);
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function R_ISP_FinalizeTISP()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function R_ISP_SetEventsAndStartTISP()
 **********************************************************************************************************************/
uint16_t R_ISP_SetEventsAndStartTISP(uint8_t unit_index, const st_tisp_event_int_cfg_t * p_tisp_event)
{
    uint16_t ret;
    
    g_tisp_event_cnt = 0u;
    ret = R_TISP_SetEventCb(unit_index, &R_ISP_TispEventCb, p_tisp_event);

    if (TISP_RET_E_OK == ret)
    {
        ret = R_TISP_Start(unit_index);

        if (TISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_TISP_Start failed. Error Code %s(%d)\n", R_ISP_TispReturnToStr(ret), (uint16_t)ret);
        }

    }
    else
    {
        PRINT_ERROR("R_TISP_SetEventCb failed. Error Code %s(%d)\n", R_ISP_TispReturnToStr(ret), (uint16_t)ret);
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function R_ISP_SetEventsAndStartTISP()
 **********************************************************************************************************************/


/*======================================================================================================================
Private function definitions
======================================================================================================================*/

/***********************************************************************************************************************
 * Start of function rel_math_fix_to_fix()
 **********************************************************************************************************************/
static uint32_t rel_math_fix_to_fix(uint32_t fix_in, uint8_t q_in, uint8_t q_out)
{
    if (q_out >= q_in)
    {
        return (fix_in << (q_out - q_in));
    }
    else
    {
        return (fix_in >> (q_in - q_out));
    }
}
/***********************************************************************************************************************
 * End of function rel_math_fix_to_fix()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function r_isp_setup_cisp_buffers()
 **********************************************************************************************************************/
static e_isp_sample_return_t r_isp_setup_cisp_buffers(uint8_t unit_index, uint16_t frame_width, uint16_t frame_height, bool cisp_m2m_uc)
{
    e_isp_sample_return_t ret = ISP_SAMPLE_RET_OK;
    st_cisp_buf_cfg_t     stconf;
    
    stconf.width  = frame_width;
    stconf.height = frame_height;

    if (true == cisp_m2m_uc)
    {
        /*input Buffer */
        stconf.line_byte_stride = ((frame_width * ISP_BIT_PER_PIXEL) >> 3U);
        stconf.bit_width        = ISP_BIT_PER_PIXEL;
        stconf.base_addr        = (uint64_t)(isp_buff_in[unit_index].phy_addr);
        ret = R_CISP_SetInBuffer(unit_index, 0, &stconf); /* set input buffer 0 */

        if (ISP_SAMPLE_RET_OK == ret)
        {
            /*copy raw data image 1 into input buffer */
            DEBUG_PRINT("Copy Raw Data Image 1 into Input Buffer 0 \r\n");
            DEBUG_PRINT("In buff size=%d\n",ISP_IN_BUFFER_SIZE);
            ret = R_ISP_MEMUTIL_CopyBuffer((uint8_t *)(isp_buff_in[unit_index].virt_addr), isp_in, ISP_IN_BUFFER_SIZE);

            if (ISP_SAMPLE_RET_OK == ret)
            {
                /* flush the Dcache in xOS2 (OSAL / Linux) */
                ret = R_ISP_MEMUTIL_MemFlush(&(isp_buff_in[unit_index]));

                if (ISP_SAMPLE_RET_OK == ret)
                {
                    /*Set input Buffer 0 status as Filled*/
                    DEBUG_PRINT("Set Input Buffer 0 as Filled \r\n");
                    ret = R_CISP_SetInBufferStatus(unit_index, 0, CISP_BUFF_FILLED);
                }

            }
            else
            {
                PRINT_ERROR("r_isp_setup_cisp_buffers Error : Memcpy Raw Data First Image failed \r\n");
            }
        }
    }

    if (ISP_SAMPLE_RET_OK == ret)
    {
        /*Output Buffer 0*/
        stconf.bit_width        = 24U;                                                 /*!< ISP output is configured as RGB888 => 8bit per color => 24bit in total >*/
        stconf.line_byte_stride = (uint32_t)((frame_width * stconf.bit_width) >> 3U);
        stconf.base_addr        = (uint64_t)(isp_buff_outRGB[unit_index].phy_addr);    /* to align */
        ret = R_CISP_SetOutBuffer(unit_index, 0, &stconf);                             /*Output Buffer 0 */
    }

    if (ISP_SAMPLE_RET_OK == ret)
    {
        /*Output Buffer 2 */
        stconf.bit_width        = 8U;
        stconf.line_byte_stride = (uint32_t)(frame_width);
        stconf.base_addr        = (uint64_t)(isp_buff_outY[unit_index].phy_addr);
        ret = R_CISP_SetOutBuffer(unit_index, 2, &stconf); /*Output Buffer 2 */
    }

    if (ISP_SAMPLE_RET_OK == ret)
    {
        /*Output Buffer 3 */
        stconf.bit_width        = 16;                       /* 8 bit x 2 components */
        stconf.width            = frame_width / 2;          /* 1/2 downsampling of the horizontal line */
        stconf.line_byte_stride = (uint32_t)(frame_width); /* 1/2 downsampling but there are 2 components */
        stconf.base_addr        = (uint64_t)(isp_buff_outUV[unit_index].phy_addr);
        ret = R_CISP_SetOutBuffer(unit_index, 3, &stconf); /*Output Buffer 3 */
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function r_isp_setup_cisp_buffers()
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Start of function r_isp_setup_cisp_pipeline()
 **********************************************************************************************************************/
static uint16_t r_isp_setup_cisp_pipeline(uint8_t unit_index)
{
    uint16_t                 ret;
    st_cisp_top_cfg_t        top_cfg;    /* Top cfg   */
    st_cisp_input_form_cfg_t iform_cfg;  /* input Formatter cfg */
    st_cisp_dg_cfg_t         dg_cfg;     /* Digital gain cfg*/
    st_cisp_gamma_dl_cfg_t   gdl_cfg;    /* Gamma DL cfg */
    st_cisp_raw_fe_cfg_t     rawfe_cfg;  /* Raw Front End cfg */

    st_cisp_pipe_np_cfg_t    np_cfg;     /* Noise Profile cfg */
    uint8_t                  orig_np_lut[CISP_RAWFE_NP_LUT_SIZE];
    uint8_t                  np_lut[CISP_RAWFE_NP_LUT_SIZE] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x08, 0x0C, 0x0E, 0x11, 0x13, 0x15, 0x16, 0x17, 
                                                                  0x18, 0x1A, 0x1B, 0x1B, 0x1C, 0x1D, 0x1E, 0x1E, 0x1F, 0x20, 0x20, 0x21, 0x21, 0x22, 0x22, 0x23, 
                                                                  0x23, 0x24, 0x24, 0x24, 0x25, 0x25, 0x25, 0x26, 0x26, 0x26, 0x27, 0x27, 0x27, 0x28, 0x28, 0x28, 
                                                                  0x29, 0x29, 0x29, 0x29, 0x2A, 0x2A, 0x2A, 0x2A, 0x2A, 0x2B, 0x2B, 0x2B, 0x2B, 0x2C, 0x2C, 0x2C, 
                                                                  0x2C, 0x2C, 0x2D, 0x2D, 0x2D, 0x2D, 0x2D, 0x2D, 0x2E, 0x2E, 0x2E, 0x2E, 0x2E, 0x2E, 0x2F, 0x2F, 
                                                                  0x2F, 0x2F, 0x2F, 0x2F, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x31, 0x31, 0x31, 0x31, 0x31, 
                                                                  0x31, 0x31, 0x31, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x33, 0x33, 0x33, 0x33, 0x33, 
                                                                  0x33, 0x33, 0x33, 0x33, 0x33, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x35 };
    st_cisp_sinter_cfg_t     sint_cfg;   /*sinter cfg*/
    st_cisp_sinter_rs_cfg_t  sint_rs_cfg;/*sinter rs cfg */
    uint8_t                  sint_rs_lut[CISP_SINT_RS_LUT_SIZE] = {10};
    st_cisp_ca_cfg_t         chr_ab_cfg; /*Chromatic aberration */
    st_cisp_wb_cfg_t         wb_cfg;     /* White Balance cfg */
    st_cisp_lin_off_cfg_t    lin_off;    /* Linear black offset cfg */
    st_cisp_dem_cfg_t        dem_cfg;    /* demosaic Config cfg */
    st_cisp_dem_np_cfg_t     dem_np_cfg;
    uint8_t                  dem_np_lut[CISP_DEM_NP_LUT_SIZE] = {0x02, 0x08, 0x0C, 0x0E, 0x11, 0x13, 0x15, 0x16, 0x17, 0x18, 0x1A, 0x1B, 0x1B, 0x1C, 0x1D, 0x1E, 
                                                                    0x1E, 0x1F, 0x20, 0x20, 0x21, 0x21, 0x22, 0x22, 0x23, 0x23, 0x24, 0x24, 0x24, 0x25, 0x25, 0x25, 
                                                                    0x26, 0x26, 0x26, 0x27, 0x27, 0x27, 0x28, 0x28, 0x28, 0x29, 0x29, 0x29, 0x29, 0x2A, 0x2A, 0x2A, 
                                                                    0x2A, 0x2A, 0x2B, 0x2B, 0x2B, 0x2B, 0x2C, 0x2C, 0x2C, 0x2C, 0x2C, 0x2D, 0x2D, 0x2D, 0x2D, 0x2D, 
                                                                    0x2D, 0x2E, 0x2E, 0x2E, 0x2E, 0x2E, 0x2E, 0x2F, 0x2F, 0x2F, 0x2F, 0x2F, 0x2F, 0x30, 0x30, 0x30, 
                                                                    0x30, 0x30, 0x30, 0x30, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x32, 0x32, 0x32, 0x32, 
                                                                    0x32, 0x32, 0x32, 0x32, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x34, 0x34, 
                                                                    0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35 };
    st_cisp_out_form_cfg_t   outf_cfg;   /* Output Formatter cfg */
    uint32_t                 rgb_lut[CISP_OUTF_LUT_SIZE] = { 0x00000, 0x002c0, 0x005c0, 0x00be1, 0x01221, 0x018c1, 0x01f82, 0x02862, 0x03163, 0x038e3, 0x04084, 0x04804, 0x04fa5, 0x057a5, 0x05fa6, 0x06686, 
                                                                0x06da7, 0x07447, 0x07b07, 0x08128, 0x08768, 0x08d49, 0x09329, 0x098c9, 0x09e8a, 0x0a3ca, 0x0a92a, 0x0ae0b, 0x0b32b, 0x0b80b, 0x0bceb, 0x0c16c, 
                                                                0x0c60c, 0x0ca6c, 0x0ceed, 0x0d32d, 0x0d74d, 0x0db6d, 0x0dfae, 0x0e3ce, 0x0e7ee, 0x0ebae, 0x0efaf, 0x0f34f, 0x0f6ef, 0x0fa6f, 0x0fe0f, 0x10190, 
                                                                0x104f0, 0x10830, 0x10b70, 0x10e90, 0x111b1, 0x114d1, 0x117f1, 0x11b11, 0x11e11, 0x12132, 0x12432, 0x12712, 0x12a12, 0x12cf2, 0x12ff2, 0x132b3, 
                                                                0x135b3, 0x13853, 0x13ab3, 0x13d53, 0x13ff3, 0x142b4, 0x14554, 0x147d4, 0x14a54, 0x14cd4, 0x14f34, 0x151b4, 0x153f5, 0x15655, 0x158d5, 0x15b15, 
                                                                0x15d55, 0x15f95, 0x161b5, 0x163f6, 0x16616, 0x16836, 0x16a56, 0x16c76, 0x16e76, 0x17076, 0x17296, 0x17497, 0x17697, 0x17897, 0x17a77, 0x17c77, 
                                                                0x17e57, 0x18037, 0x18217, 0x183f7, 0x185d8, 0x187b8, 0x18978, 0x18b38, 0x18cd8, 0x18e98, 0x19058, 0x191f8, 0x19398, 0x19539, 0x196b9, 0x19859, 
                                                                0x199d9, 0x19b59, 0x19cd9, 0x19e79, 0x19ff9, 0x1a159, 0x1a2b9, 0x1a419, 0x1a57a, 0x1a6ba, 0x1a81a, 0x1a97a, 0x1aada, 0x1ac1a, 0x1ad5a, 0x1ae9a, 
                                                                0x1afda, 0x1b11a, 0x1b25a, 0x1b37a, 0x1b49a, 0x1b5db, 0x1b6fb, 0x1b83b, 0x1b95b, 0x1ba7b, 0x1bb9b, 0x1bcbb, 0x1bdbb, 0x1bedb, 0x1bffb, 0x1c11b, 
                                                                0x1c21b, 0x1c31b, 0x1c43b, 0x1c55b, 0x1c65c, 0x1c75c, 0x1c85c, 0x1c95c, 0x1ca5c, 0x1cb5c, 0x1cc5c, 0x1cd5c, 0x1ce3c, 0x1cf3c, 0x1d01c, 0x1d11c, 
                                                                0x1d1fc, 0x1d2dc, 0x1d3dc, 0x1d4bc, 0x1d59c, 0x1d67c, 0x1d75d, 0x1d83d, 0x1d91d, 0x1d9fd, 0x1dabd, 0x1db9d, 0x1dc5d, 0x1dd3d, 0x1ddfd, 0x1dedd, 
                                                                0x1df9d, 0x1e05d, 0x1e11d, 0x1e1dd, 0x1e27d, 0x1e33d, 0x1e3fd, 0x1e4bd, 0x1e55d, 0x1e61d, 0x1e6bd, 0x1e75e, 0x1e7fe, 0x1e89e, 0x1e93e, 0x1e9be, 
                                                                0x1ea5e, 0x1eafe, 0x1eb7e, 0x1ec1e, 0x1ecbe, 0x1ed3e, 0x1edbe, 0x1ee5e, 0x1eede, 0x1ef5e, 0x1efde, 0x1f05e, 0x1f0de, 0x1f15e, 0x1f1be, 0x1f23e, 
                                                                0x1f2be, 0x1f31e, 0x1f39e, 0x1f3fe, 0x1f45e, 0x1f4de, 0x1f53e, 0x1f59e, 0x1f5fe, 0x1f65e, 0x1f6be, 0x1f71e, 0x1f75e, 0x1f7bf, 0x1f81f, 0x1f85f, 
                                                                0x1f8bf, 0x1f8ff, 0x1f95f, 0x1f99f, 0x1f9ff, 0x1fa3f, 0x1fa7f, 0x1fadf, 0x1fb1f, 0x1fb5f, 0x1fb9f, 0x1fbdf, 0x1fc1f, 0x1fc5f, 0x1fc7f, 0x1fcdf, 
                                                                0x1fcff, 0x1fd3f, 0x1fd7f, 0x1fd9f, 0x1fddf, 0x1fe1f, 0x1fe3f, 0x1fe5f, 0x1fe9f, 0x1fedf, 0x1feff, 0x1ff1f, 0x1ff3f, 0x1ff7f, 0x1ff9f, 0x1ffbf, 
                                                                0x1ffff };
    st_cisp_out_cfg_t        out_cfg;    /* Axi output formatter cfg */
    
    /* Set ISP Scheduler */
    ret = R_CISP_SetScheduler(unit_index, CISP_SCHED_MANUAL);

    if (CISP_RET_E_OK != ret)
    {
        PRINT_ERROR("R_CISP_SetScheduler failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
    }
    else
    {
        /* Set Top - Set Color Plane of the first  Pixel (R, Gr,Gb, B) */
        ret = R_CISP_GetTop(unit_index, CISP_HARDWARE, &top_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetTop failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            top_cfg.active_width  = g_frame_width;
            top_cfg.active_height = g_frame_height;
            top_cfg.cfa_pattern   = CISP_CFA_RGGB;
            top_cfg.rggb_start    = CISP_RGGB_RGRGBB;
            ret = R_CISP_SetTop(unit_index, CISP_HARDWARE, &top_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetTop failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }

        }
    }

    /* Set input Formatter */
    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_GetInputForm(unit_index, CISP_HARDWARE, &iform_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetInputForm failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            iform_cfg.enable      = 1;
            iform_cfg.mode        = CISP_IFORM_LINEAR;
            iform_cfg.bit_width   = CISP_IFORM_8BITS;
            DEBUG_PRINT("CISP_IFORM_8BITS=%d\n",CISP_IFORM_8BITS);
            iform_cfg.black_level = 0;
            ret = R_CISP_SetInputForm(unit_index, CISP_HARDWARE, &iform_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetInputForm failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }
        }
    }
    /* Set Digital gain, */
    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_GetDigitalGain(unit_index, CISP_HARDWARE, &dg_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetDigitalGain failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            dg_cfg.enable = 1;
            dg_cfg.gain   = 0x104;
            dg_cfg.offset = 0;
            ret = R_CISP_SetDigitalGain(unit_index, CISP_HARDWARE, &dg_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetDigitalGain failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }

        }
    }
    /* Gamma DL and Inv Gamma DL */

    if (CISP_RET_E_OK == ret)
    {
        gdl_cfg.enable             = 1;
        gdl_cfg.alpha              = rel_math_fix_to_fix(1, 0, 12); /* 10.12 fixed format */
        gdl_cfg.black_level_before = 0x00;
        gdl_cfg.black_level_after  = 0x0F0000;
        ret = R_CISP_SetGammaDL(unit_index, CISP_HARDWARE, &gdl_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_SetGammaDL failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            gdl_cfg.enable             = 1;
            gdl_cfg.alpha              = 0x1000000 / rel_math_fix_to_fix(1, 0, 12); /* 10.12 fixed format */
            gdl_cfg.black_level_before = 0x0F0000;
            gdl_cfg.black_level_after  = 0x00;
            ret = R_CISP_SetInvGammaDL(unit_index, CISP_HARDWARE, &gdl_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetInvGammaDL failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }
        }
    }

    /*Raw Frontend */
    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_GetRawFE(unit_index, CISP_HARDWARE, &rawfe_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetRawFE failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            rawfe_cfg.enable                = 0;   /* Currently disabled */
            rawfe_cfg.bright_disable        = 0;
            rawfe_cfg.dark_disable          = 0;
            rawfe_cfg.dyn_dp_blending       = 0;
            rawfe_cfg.dyn_dp_enable         = 0;
            rawfe_cfg.dp_slope              = 0x200,
            rawfe_cfg.dp_threshold          = 0x40;
            rawfe_cfg.dyn_dp_threshold      = 0x2660;
            rawfe_cfg.ge_enable             = 0;
            rawfe_cfg.ge_sensitivity        = 0x80;
            rawfe_cfg.ge_slope              = 0xAA;
            rawfe_cfg.ge_strength           = 0;
            rawfe_cfg.ge_threshold          = 0x400;
            rawfe_cfg.dyn_dp_line_threshold = 0x150;
            rawfe_cfg.rfe_l2_disable        = 0;
            rawfe_cfg.dyn_dp_show           = 0;
            rawfe_cfg.sigma_in              = 0;
            rawfe_cfg.long_exp_threshold    = 0x30;
            rawfe_cfg.short_exp_threshold   = 0;
            ret = R_CISP_SetRawFE(unit_index, CISP_HARDWARE, &rawfe_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetRawFE failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }

        }
    }
    /* Pipeline Noise Profile */

    if (CISP_RET_E_OK == ret)
    {
        np_cfg.lut.p_entry = orig_np_lut;
        np_cfg.lut.size    = CISP_RAWFE_NP_LUT_SIZE;
        ret = R_CISP_GetRawFeNp(unit_index, CISP_HARDWARE, &np_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetRawFeNp failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            np_cfg.exp_thresh       = 0xFFFF;
            np_cfg.long_ratio       = 4;
            np_cfg.black_offset     = 0;
            np_cfg.below_black_mode = 0;
            np_cfg.short_ratio      = 0x20;
            np_cfg.lut.p_entry      = np_lut;
            np_cfg.lut.size         = CISP_RAWFE_NP_LUT_SIZE;
            ret = R_CISP_SetRawFeNp(unit_index, CISP_HARDWARE, &np_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetRawFeNp failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }
        }
    }
    /* Set sinter */

    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_GetSinter(unit_index, CISP_HARDWARE, &sint_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetSinter failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            sint_cfg.enable           = 1;
            sint_cfg.intensity_config = 0x07;
            sint_cfg.strength_1       = 0xBE;
            sint_cfg.strength_4       = 0xFF;
            sint_cfg.thresh_1h        = 0x05;
            sint_cfg.thresh_1v        = 0x05;
            sint_cfg.thresh_4h        = 0x0A;
            sint_cfg.thresh_4v        = 0x0A;
            sint_cfg.thresh_long      = 0x30;
            sint_cfg.thresh_short     = 0;
            ret = R_CISP_SetSinter(unit_index, CISP_HARDWARE, &sint_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetSinter failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }
            else
            {
                sint_rs_cfg.enable          = 1;
                sint_rs_cfg.center_x        = 0x280;
                sint_rs_cfg.center_y        = 0x168;
                sint_rs_cfg.off_center_mult = 0x100;
                sint_rs_cfg.lut.p_entry     = sint_rs_lut;
                sint_rs_cfg.lut.size        = CISP_SINT_RS_LUT_SIZE;
                ret = R_CISP_SetSinterRs(unit_index, CISP_HARDWARE, &sint_rs_cfg);

                if (CISP_RET_E_OK != ret)
                {
                    PRINT_ERROR("R_CISP_SetSinterRs failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
                }
                else
                {
                    /*sinter Noise Profile = Raw Frontenf Noise profile */
                    ret = R_CISP_SetSinterNp(unit_index, CISP_HARDWARE, &np_cfg);

                    if (CISP_RET_E_OK != ret)
                    {
                        PRINT_ERROR("R_CISP_SetSinterNp failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
                    }
                }
            }
        }
    }
    /* Chromatic Aberration */

    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_GetChrAb(unit_index, CISP_HARDWARE, &chr_ab_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetChrAb failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            chr_ab_cfg.enable       = 0;   /* Currently disabled */
            chr_ab_cfg.mesh_height  = 0x40;
            chr_ab_cfg.mesh_width   = 0x40;
            chr_ab_cfg.line_offset  = 0x06;
            chr_ab_cfg.plane_offset = 0x1000;
            chr_ab_cfg.mesh_scale   = 0;
            ret = R_CISP_SetChrAb(unit_index, CISP_HARDWARE, &chr_ab_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetChrAb failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }
        }
    }
    /* White Balance */

    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_GetWhiteBalance(unit_index, CISP_HARDWARE, &wb_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetWhiteBalance failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            wb_cfg.enable  = 1;
            wb_cfg.gain[0] = 0x0077;//0x0247;
            wb_cfg.gain[1] = 0x007F;
            wb_cfg.gain[2] = 0x007F;
            wb_cfg.gain[3] = 0x009B;
            ret = R_CISP_SetWhiteBalance(unit_index, CISP_HARDWARE, &wb_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetWhiteBalance failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }
        }
    }
    /*linear black offset  */

    if (CISP_RET_E_OK == ret)
    {
        lin_off.enable    = 1;
        lin_off.offset[0] = 0x00;
        lin_off.offset[1] = 0x00;
        lin_off.offset[2] = 0x00;
        lin_off.offset[3] = 0x00;
        ret = R_CISP_SetLinearOffset(unit_index, CISP_HARDWARE, &lin_off);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_SetLinearOffset failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
    }
    /* Set demosaic */

    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_GetDemosaic(unit_index, CISP_HARDWARE, &dem_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetDemosaic failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            dem_cfg.enable               = 1;
            dem_cfg.rggb.aa.offset       = 0x800;
            dem_cfg.rggb.aa.slope        = 0xAA;
            dem_cfg.rggb.aa.thresh       = 0x64;
            dem_cfg.rggb.ac.offset       = 0;
            dem_cfg.rggb.ac.slope        = 0xCF;
            dem_cfg.rggb.ac.thresh       = 0x1B3;
            dem_cfg.rggb.fc_alias_slope  = 0x55;
            dem_cfg.rggb.fc_alias_thresh = 0;
            dem_cfg.rggb.fc_slope        = 0x82;
            dem_cfg.rggb.luminance_th    = 0x96;
            dem_cfg.rggb.thresh_min_d    = 0x7CCC;
            dem_cfg.rggb.thresh_min_ud   = 0x7CCC;
            dem_cfg.rggb.sad_amplifier   = 0x10;
            dem_cfg.rggb.sat.offset      = 0;
            dem_cfg.rggb.sat.slope       = 0x5D;
            dem_cfg.rggb.sat.thresh      = 0x171;
            dem_cfg.rggb.sharp_str_d     = 0x2D;
            dem_cfg.rggb.sharp_str_ld    = 0x2D;
            dem_cfg.rggb.sharp_str_ldu   = 0x2D;
            dem_cfg.rggb.sharp_str_lu    = 0x19;
            dem_cfg.rggb.sharp_str_ud    = 0x19;
            dem_cfg.rggb.sharp_algorithm = 1;
            dem_cfg.rggb.uu.offset       = 0;
            dem_cfg.rggb.uu.slope        = 0xA5;
            dem_cfg.rggb.uu.thresh       = 0xD2;
            dem_cfg.rggb.va.offset       = 0x800;
            dem_cfg.rggb.va.slope        = 0xAF;
            dem_cfg.rggb.va.thresh       = 0xD2;
            dem_cfg.rggb.vh.offset       = 0x800;
            dem_cfg.rggb.vh.slope        = 0xBE;
            dem_cfg.rggb.vh.thresh       = 0xDC;
            ret = R_CISP_SetDemosaic(unit_index, CISP_HARDWARE, &dem_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetDemosaic failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }
            else
            {
                dem_np_cfg.noise_profile_offset = 0x03;
                dem_np_cfg.black_offset         = 0;
                dem_np_cfg.below_black_mode     = 0;
                dem_np_cfg.lut.p_entry          = dem_np_lut;
                dem_np_cfg.lut.size             = CISP_DEM_NP_LUT_SIZE;
                ret = R_CISP_SetDemosaicNP(unit_index, CISP_HARDWARE, &dem_np_cfg);

                if (CISP_RET_E_OK != ret)
                {
                    PRINT_ERROR("R_CISP_SetDemosaicNP failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
                }
            }
        }
    }
    /* Set Output Formatter */

    if (CISP_RET_E_OK == ret)
    {
        memset(&outf_cfg, 0x00, sizeof(st_cisp_out_form_cfg_t)); /* careful may not be OS abstract */
        ret = R_CISP_GetOutForm(unit_index, CISP_HARDWARE, &outf_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetOutForm failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            outf_cfg.enable                                 = 1;
            outf_cfg.hsrgbyuv.rgb_to_rgb.enable             = 1;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[0][0]            = 0x016E;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[0][1]            = 0x805E;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[0][2]            = 0x8010;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[0][3]            = 0;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[1][0]            = 0x801B;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[1][1]            = 0x012F;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[1][2]            = 0x8014;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[1][3]            = 0;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[2][0]            = 0x0028;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[2][1]            = 0x80FD;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[2][2]            = 0x01D5;
            outf_cfg.hsrgbyuv.rgb_to_rgb.c[2][3]            = 0;
            outf_cfg.hsrgbyuv.rgb_to_rgb.b[0]               = 0;
            outf_cfg.hsrgbyuv.rgb_to_rgb.b[1]               = 0;
            outf_cfg.hsrgbyuv.rgb_to_rgb.b[2]               = 0;
            outf_cfg.hsrgbyuv.lut.enable                    = 1; 
            outf_cfg.hsrgbyuv.lut.p_entry                   = (uint32_t *)rgb_lut;
            outf_cfg.hsrgbyuv.lut.size                      = CISP_OUTF_LUT_SIZE;
            outf_cfg.hsrgbyuv.yuv.lpf.enable                = 1;
            outf_cfg.hsrgbyuv.yuv.lpf.horizontal_downsample = 1;
            outf_cfg.hsrgbyuv.yuv.mode                      = CISP_OUTF_YUV_MODE_MATRIX;   /* (BT.709) */
            /* RGB to yuv color conversion for HDTV (BT.709) */
            /* http://www.equasys.de/colorconversion.html */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.enable         = 1;
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.c[0][0]        = 0x002F;    /*  0.183 (47,  0x002F) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.c[0][1]        = 0x009D;    /*  0.614 (157, 0x009D) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.c[0][2]        = 0x0010;    /*  0.062 (16,  0x0010) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.c[1][0]        = 0x801A;    /* -0.101 (26,  0x801A) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.c[1][1]        = 0x8057;    /* -0.339 (87,  0x8057) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.c[1][2]        = 0x0070;    /*  0.439 (112, 0x0070) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.c[2][0]        = 0x0070;    /*  0.439 (112, 0x0070) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.c[2][1]        = 0x8066;    /* -0.399 (102, 0x8066) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.c[2][2]        = 0x800A;    /* -0.040 (10,  0x800A)*/
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.b[0]           = 0x00400;   /*  16/256  (1024, 0x00400) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.b[1]           = 0x02000;   /*  128/256 (8192, 0x02000) */
            outf_cfg.hsrgbyuv.yuv.rgb_to_yuv.b[2]           = 0x02000;   /*  128/256 (8192, 0x02000) */
            /* The following for YUV420 */
            outf_cfg.luv.lpf.enable                         = 1;
            outf_cfg.luv.lpf.horizontal_downsample          = 1;
            outf_cfg.luv.lpf.horizontal_filter              = 0;
            outf_cfg.luv.lpf.vertical_downsample            = 1;
            outf_cfg.luv.enable_xyz_to_luv                  = 0;
            /* RGB to yuv color conversion for HDTV (BT.709) */
            /* http://www.equasys.de/colorconversion.html */
            outf_cfg.luv.rgb2xyz.enable                     = 1;
            outf_cfg.luv.rgb2xyz.c[0][0]                    = 0x002F;   /*  0.183 (47,  0x002F) */
            outf_cfg.luv.rgb2xyz.c[0][1]                    = 0x009D;   /*  0.614 (157, 0x009D) */
            outf_cfg.luv.rgb2xyz.c[0][2]                    = 0x0010;   /*  0.062 (16,  0x0010) */
            outf_cfg.luv.rgb2xyz.c[0][3]                    = 0;
            outf_cfg.luv.rgb2xyz.c[1][0]                    = 0x801A;   /* -0.101 (26,  0x801A) */
            outf_cfg.luv.rgb2xyz.c[1][1]                    = 0x8057;   /* -0.339 (87,  0x8057) */
            outf_cfg.luv.rgb2xyz.c[1][2]                    = 0x0070;   /*  0.439 (112, 0x0070) */
            outf_cfg.luv.rgb2xyz.c[1][3]                    = 0;
            outf_cfg.luv.rgb2xyz.c[2][0]                    = 0x0070;   /*  0.439 (112, 0x0070) */
            outf_cfg.luv.rgb2xyz.c[2][1]                    = 0x8066;   /* -0.399 (102, 0x8066) */
            outf_cfg.luv.rgb2xyz.c[2][2]                    = 0x800A;   /* -0.040 (10,  0x800A) */
            outf_cfg.luv.rgb2xyz.c[2][3]                    = 0;
            outf_cfg.luv.rgb2xyz.b[0]                       = 0x00400;   /*  16/256  (1024, 0x00400) */
            outf_cfg.luv.rgb2xyz.b[1]                       = 0x02000;   /*  128/256 (8192, 0x02000) */
            outf_cfg.luv.rgb2xyz.b[2]                       = 0x02000;   /*  128/256 (8192, 0x02000) */
            ret = R_CISP_SetOutForm(unit_index, CISP_HARDWARE, &outf_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetOutForm failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }

        }
    }
    /* Set Axi Output */

    if (CISP_RET_E_OK == ret)
    {
        ret = R_CISP_GetAxiOut(unit_index, CISP_HARDWARE, &out_cfg);

        if (CISP_RET_E_OK != ret)
        {
            PRINT_ERROR("R_CISP_GetAxiOut failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
        }
        else
        {
            out_cfg.mode_select[0] = CISP_AXI_RGB888;
            out_cfg.msb_align[0]   = 0;
            out_cfg.mode_select[2] = CISP_AXI_YUV_Y12;   /*  original : CISP_AXI_YUV_Y12 expmnt:  CISP_AXI_RAW_DATA8 ,See TRM */
            out_cfg.msb_align[2]   = 1;
            out_cfg.mode_select[1] = CISP_AXI_YUV_UV8;
            out_cfg.msb_align[1]   = 0;
            ret = R_CISP_SetAxiOut(unit_index, CISP_HARDWARE, &out_cfg);

            if (CISP_RET_E_OK != ret)
            {
                PRINT_ERROR("R_CISP_SetAxiOut failed. Error Code %s(%d)\n", R_ISP_CispReturnToStr(ret), (uint16_t)ret);
            }

        }
    }

    return ret;
}
/***********************************************************************************************************************
 * End of function r_isp_setup_cisp_pipeline()
 **********************************************************************************************************************/

/*======================================================================================================================
End of file
======================================================================================================================*/
