/***********************************************************************************************************************
* Copyright [2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_isp_memutil.h
* Version      : 1.0.0
* Product Name : ISP Sample Application
* Device(s)    : R-Car V3x
* Description  : utility functions for handling the memory buffers used by the ISP Sample Application
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 0.1.0   10.08.2020 Initial version
*         : 1.0.0   30.11.2021 Added VSPX usage and align code to the Renesas coding guidelines (ESTISPRSWPRO-416) 
***********************************************************************************************************************/
#ifndef R_ISP_MEMUTIL_H
/* Multiple inclusion protection macro */
#define R_ISP_MEMUTIL_H

/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include "r_isp_defs.h"
#include "rcar-xos/osal/r_osal.h"

/*******************************************************************************************************************//**
 * @ingroup ISP_SAMPLE_API
 * @defgroup ISP_MEMUTIL_API ISP Sample Application Mem Utility API Definitions
 *
 * @{
 **********************************************************************************************************************/

/*======================================================================================================================
Public macro definitions
======================================================================================================================*/
/*This is currently hard coded into rcar-env\renesas\os\osal_wrapper\src\target\linux\r_osal_memory.c
We need to match it as flushing can only be done on multiples of cache lines.*/
#define CACHE_LINE_SIZE_BYTES   64u

/*======================================================================================================================
Public type definitions
======================================================================================================================*/

/*******************************************************************************************************************//**
 * @struct st_isp_memutil_mem_mgr_hdl_t
 * Wrapper typedef for OSAL Mem Manager handle type
 ***********************************************************************************************************************/
typedef osal_memory_manager_handle_t st_isp_memutil_mem_mgr_hdl_t;


/*******************************************************************************************************************//**
 * @struct st_isp_memutil_buffer_t
 * Typedef used as ISP Input or Output buffer
 ***********************************************************************************************************************/
typedef struct
{
    osal_memory_buffer_handle_t osal_buf_handle;    /*!< OSAL Mem Manager Handle. Ref to OSAL documentation */
    void                        * virt_addr;         /*!< buffer virtual qddress */
    uintptr_t                   phy_addr;           /*!< buffer physical address the HW can work with */
    size_t                      size;               /*!< buffer size requested when allocating, may be smaller than size allocated */
    size_t                      size_allocated;     /*!< buffer size used when flushing the entire buffer as it will be a multiple of cache lines.*/
    size_t                      align;              /*!< buffer alignment */
} st_isp_memutil_buffer_t;

/*======================================================================================================================
Public global variables
======================================================================================================================*/

/*======================================================================================================================
Public global functions
======================================================================================================================*/

/*******************************************************************************************************************//**
* @brief            Wrapper for calling OSAL MMNGR Alloc API
* @call             R_OSAL_MmngrAlloc,R_OSAL_MmngrGetCpuPtr, R_OSAL_IoGetAxiBusIdFromDeviceName, R_OSAL_MmngrGetHwAddr
* @param            p_buffer - Buffer to be allocated 
* @param            p_devstr - Device String Used to Open the device
* @return           execution result (e_isp_sample_return_t)
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_MemAlloc (st_isp_memutil_buffer_t * p_buffer, char * p_devstr);

/*******************************************************************************************************************//**
* @brief            Wrapper for calling OSAL MMNGR Dealloc API
* @call             R_OSAL_MmngrDealloc
* @param            p_buffer - Buffer to be freed 
* @return           execution result (e_isp_sample_return_t)
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_MemFree (st_isp_memutil_buffer_t * p_buffer);

/*******************************************************************************************************************//**
* @brief            Wrapper for calling OSAL MMNGR Flush API
* @call             R_OSAL_MmngrFlush
* @param            p_buffer - Buffer to be flushed 
* @return           execution result (e_isp_sample_return_t)
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_MemFlush (st_isp_memutil_buffer_t * p_buffer);

/*******************************************************************************************************************//**
* @brief            Wrapper for calling OSAL MMNGR Invalidate API
* @call             R_OSAL_MmngrInvalidate
* @param            p_buffer - Buffer to be invalidated 
* @return           execution result (e_isp_sample_return_t)
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_MemInvalidate (st_isp_memutil_buffer_t * p_buffer);


/*******************************************************************************************************************//**
* @brief            Copy size bytes from p_src buffer into p_dest buffer
* @call             None
* @param            p_dest - Pointer to the Destination Buffer
* @param            p_src - Pointer to the Source Buffer
* @param            size  - size in byte of the data to be copied.
* @return           execution result (e_isp_sample_return_t)
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_CopyBuffer (uint8_t * p_dest, const uint8_t * p_src, uint32_t size);

/*******************************************************************************************************************//**
* @brief            Save an OSAL Mem Manager allocated buffer in a file
* @call             open, write, close, R_ISP_MEMUTIL_MemInvalidate
* @param            p_buffer - Pointer to the buffer to be saved
* @param            size - Size of the buffer in bytes
* @param            filename - Name of the file where the buffer is saved
* @return           execution result (e_isp_sample_return_t)
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_SaveBuffer (st_isp_memutil_buffer_t * p_buffer, size_t size, char * filename);

/*******************************************************************************************************************//**
* @brief            Compare 2 Buffer allocated with the OSAL Mem Manager
* @call             R_ISP_MEMUTIL_MemInvalidate, memcmp
* @param            p_buffer1, p_buffer2 - Pointer to the buffers to be compared
* @param            size - Size of the buffer in bytes
* @return           execution result (e_isp_sample_return_t) - OK is returned only if the buffers are equal
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_CompareBuffer(st_isp_memutil_buffer_t *p_buffer1, 
                                                    st_isp_memutil_buffer_t *p_buffer2, size_t size);

/** @} */ /* End of ISP_MEMUTIL_API */

#endif /* End of multiple inclusion protection macro R_ISP_MEMUTIL_H */

/*======================================================================================================================
End of File
======================================================================================================================*/

