/***********************************************************************************************************************
* Copyright [2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_isp_defs.h
* Version      : 1.0.0
* Product Name : ISP Sample Application
* Device(s)    : R-Car V3x
* Description  : Common types and macros definitions for the ISP Sample Application
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 1.0.0   01.12.2021 Initial version.
***********************************************************************************************************************/
#ifndef R_ISP_TYPES_H
/* Multiple inclusion protection macro */
#define R_ISP_TYPES_H

#define ORGINAL 0

#include "common.h"

/*======================================================================================================================
Public macro definitions
======================================================================================================================*/
#define R_ISPSAMPLE_BUFF0_FILENAME "buff0.raw" /*!< Filename for the ISP outbuff0    */
#define R_ISPSAMPLE_BUFF1_FILENAME "buff1.raw" /*!< Filename for the ISP outbuff1    */

#define R_ISPSAMPLE_BUFF2_FILENAME "buffY.raw"
#define R_ISPSAMPLE_BUFF3_FILENAME "buffUV.raw"


/* Maximum number of units based on target configuration */
#if   defined (RCAR_V3M)
#define ISP_NUM_CHANNELS        1U /*!< Total Number of Channel available in HW */
#elif defined (RCAR_V3H1) || defined (RCAR_V3H2)
#define ISP_NUM_CHANNELS        2U /*!< Total Number of Channel available in HW */
#elif defined (RCAR_V3U)
#define ISPSAMPLE_DEVICE        ISPSAMPLE_DEVICE_V3U
#define ISP_NUM_CHANNELS        4U /*!< Total Number of Channel available in HW */
#else
#error ispsample: Error cannot find any HW define
#endif


/*******************************************************************************************************************//**
 * OSAL Mutexes
***********************************************************************************************************************/
#define OSAL_MUTEX_CISP_00           (0x6000u)     /*!< The number is assigned by the OSAL configuration layer */
#define OSAL_MUTEX_CISP_01           (0x6001u)
#define OSAL_MUTEX_CISP_02           (0x6004u)
#define OSAL_MUTEX_CISP_03           (0x6005u)

#define OSAL_MUTEX_TISP_00           (0x6002u)
#define OSAL_MUTEX_TISP_01           (0x6003u)
#define OSAL_MUTEX_TISP_02           (0x6006u)
#define OSAL_MUTEX_TISP_03           (0x6007u)

#define OSAL_MUTEX_VSPX_00           (0x6008u)
#define OSAL_MUTEX_VSPX_01           (0x6009u)
#define OSAL_MUTEX_VSPX_02           (0x600Au)
#define OSAL_MUTEX_VSPX_03           (0x600Bu)

/*******************************************************************************************************************//**
 * @def OSAL_THREAD_ISP_TASK
 * OSAL Thread ID for ISP Sample App
***********************************************************************************************************************/
#define OSAL_THREAD_ISP_TASK         (0x6000u)     /*!< The number is assigned by the OSAL configuration layer */

/*******************************************************************************************************************//**
 * Frame size definition
***********************************************************************************************************************/
//#define FRAME_WIDTH      (1280U)   /*!< Width of the camera frame / image to be processed (pixel)  */
//#define FRAME_HEIGHT     (720U) /*!< Height of the camera frame / image to be processed (pixel) */

/*******************************************************************************************************************//**
 * ISP Buffers size definition
***********************************************************************************************************************/
#define ISP_BIT_PER_PIXEL            (8U)   /*!< Number of bit per pixel in the static test image */
#define ISP_BUFFER_SIZE_BIT          (g_frame_width * g_frame_height * ISP_BIT_PER_PIXEL)
#define ISP_IN_BUFFER_SIZE           (ISP_BUFFER_SIZE_BIT >> 3U)
#define ISP_OUT_BUFFER_SIZE          (g_frame_width * g_frame_height * 3) /*!< 1 byte for each primary colours (Red, Green, Blue) */

/*======================================================================================================================
Public type definitions
======================================================================================================================*/
/*******************************************************************************************************************//**
 * @enum e_isp_sample_return_t 
 * Enumerated type for the ISP Samples possible return values
 ***********************************************************************************************************************/
typedef enum
{
    ISP_SAMPLE_RET_OK        = 0u,   /*!< ISP Sample application run successfully */
    ISP_SAMPLE_RET_FAILED    = 1u,   /*!< ISP Sample application run with failures */
    ISP_SAMPLE_RET_ERR_OSAL  = 2u,   /*!< OSAL API returned error */
    ISP_SAMPLE_RET_ERR_CISP  = 3u,   /*!< CISP driver API returned error */
    ISP_SAMPLE_RET_ERR_TISP  = 4u,   /*!< TISP driver API returned error */
    ISP_SAMPLE_RET_ERR_VSPX  = 5u    /*!< VSPX driver API returned error */
} e_isp_sample_return_t;



#endif      /* End of multiple inclusion protection macro R_ISP_TYPES_H */
extern char image_location[30];
/*======================================================================================================================
End of File
======================================================================================================================*/
