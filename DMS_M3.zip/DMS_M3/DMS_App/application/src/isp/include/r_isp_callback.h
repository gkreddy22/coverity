/***********************************************************************************************************************
* Copyright [2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_isp_callback.h
* Version      : 1.0.0
* Product Name : ISP Sample Application
* Device(s)    : R-Car V3x
* Description  : ISP User Callback Functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 0.1.0   31.08.2020 Initial version   
*         : 0.2.0   13.10.2021 Updated to add frame end callback function (ESTISPRSWPRO-744) 
*         : 1.0.0   30.11.2021 Added VSPX usage and align code to the Renesas coding guidelines (ESTISPRSWPRO-416)  
***********************************************************************************************************************/
#ifndef R_ISP_CALLBACK_H
/* Multiple inclusion protection macro */
#define R_ISP_CALLBACK_H

/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include "r_isp_defs.h"
#include "rcar-xos/cisp/r_cisp.h"
#include "rcar-xos/tisp/r_tisp.h"

/*======================================================================================================================
Public global variables
======================================================================================================================*/
extern uint32_t g_cisp_frame_start_cnt;
extern uint32_t g_cisp_frame_end_cnt;
extern uint32_t g_cisp_stats_cnt;
extern uint32_t g_tisp_event_cnt;

/*======================================================================================================================
Public global functions
======================================================================================================================*/

/*******************************************************************************************************************//**
 * @brief           CISP Start Frame callback
 * @warning         None
 * @param           slot - Not Used
 * @param           event - Not Used
 * @param           status  - Not Used
 * @return          None
 *********************************************************************************************************************/
extern void R_ISP_CispEventFrameStartCb (uint8_t slot, e_cisp_event_type_t event, uint32_t status);

/*******************************************************************************************************************//**
 * @brief           CISP Statistic ready event callback
 * @warning         None
 * @param           slot - Not Used
 * @param           event - Not Used
 * @param           status  - Not Used
 * @return          None
 *********************************************************************************************************************/
extern void R_ISP_CispEventStatsCb (uint8_t slot, e_cisp_event_type_t event, uint32_t status);

/*******************************************************************************************************************//**
 * @brief           CISP End Frame callback
 * @warning         None
 * @param           slot - Not Used
 * @param           event - Not Used
 * @param           status  - Not Used
 * @return          None
 *********************************************************************************************************************/
extern void R_ISP_CispEventFrameEndCb (uint8_t slot, e_cisp_event_type_t event, uint32_t status);

/*******************************************************************************************************************//**
 * @brief           TISP Event callback
 * @warning         None
 * @param           status  - Not Used
 * @return          None
 *********************************************************************************************************************/
extern void R_ISP_TispEventCb (u_tisp_event_t status);


#endif /* End of multiple inclusion protection macro R_ISP_CALLBACK_H */

/*======================================================================================================================
End of File
======================================================================================================================*/
