/***********************************************************************************************************************
* Copyright [2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_isp_setup.h
* Version      : 1.0.0
* Product Name : ISP Sample Application 
* Device(s)    : R-Car V3x
* Description  : Configure the ISP drivers
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 0.1.0   01.09.2020 Initial version
*         : 1.0.0   30.11.2021 Added VSPX usage and align code to the Renesas coding guidelines (ESTISPRSWPRO-416) 
***********************************************************************************************************************/
#ifndef R_ISP_SETUP_H
/* Multiple inclusion protection macro */
#define R_ISP_SETUP_H

/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include <stdint.h>
#include "r_isp_defs.h"
#include "rcar-xos/cisp/r_cisp.h"
#include "rcar-xos/tisp/r_tisp.h"

/*======================================================================================================================
Public global functions
======================================================================================================================*/
/*******************************************************************************************************************//**
 * @brief           Allocate ISP Sample App required memory buffers
 * @warning         None
 * @param[in]       unit_index  index of the ISP HW unit (ISP channel)
 * @return          execution result (e_isp_sample_return_t)
 *********************************************************************************************************************/
extern e_isp_sample_return_t R_ISP_AllocateMemBuffers (uint8_t unit_index);

/*******************************************************************************************************************//**
 * @brief           Deallocate ISP Sample App required memory buffers
 * @warning         None
 * @param[in]       unit_index  index of the ISP HW unit (ISP channel)
 * @return          execution result (e_isp_sample_return_t)
 *********************************************************************************************************************/
extern e_isp_sample_return_t R_ISP_DeallocateMemBuffers (uint8_t unit_index);

/*******************************************************************************************************************//**
 * @brief           Convert the ISP Sample return value to string
 * @warning         None
 * @param[in]       result  ISP sample returned value
 * @retval          string corresponding to e_isp_sample_return_t
 *********************************************************************************************************************/
extern const char * R_ISP_SampleReturnToStr (e_isp_sample_return_t result);

/* CISP Setup Functions*/
/*******************************************************************************************************************//**
 * @brief           Convert the CISP API return value to string
 * @warning         None
 * @param[in]       result  CISP API returned value
 * @retval          string corresponding to the CISP API returned constant value (uint16_t)
 *********************************************************************************************************************/
extern const char * R_ISP_CispReturnToStr (uint16_t result);

/*******************************************************************************************************************//**
 * @brief           Initialize the CISP DRV SW and the CISP HW for the requested device unit
 * @warning         None
 * @call            R_CISP_Init, R_CISP_Open
 * @param[in]       unit_index  index of the CISP HW unit
 * @return          execution result (uint16_t)
 *********************************************************************************************************************/
extern uint16_t R_ISP_InitializeCISP (uint8_t unit_index);

/*******************************************************************************************************************//**
 * @brief           Finalize the CISP HW and the CISP DRV SW for the requested device unit
 * @warning         None
 * @call            R_CISP_Close, R_CISP_DeInit
 * @param[in]       unit_index  index of the CISP HW unit
 * @return          execution result (uint16_t)
 *********************************************************************************************************************/
extern uint16_t R_ISP_FinalizeCISP (uint8_t unit_index);

/*******************************************************************************************************************//**
 * @brief           Enable the CISP events and start the CISP HW execution
 * @warning         None
 * @call            R_CISP_SetEventCb, R_CISP_Start
 * @param[in]       unit_index  index of the CISP HW unit
 * @return          execution result (uint16_t)
 *********************************************************************************************************************/
extern uint16_t R_ISP_SetEventsAndStartCISP (uint8_t unit_index);

/*******************************************************************************************************************//**
 * @brief           Setup the CISP to stream the image via the VSPX
 * @warning         None
 * @call            R_CISP_SetInBuffer, R_CISP_SetOutBuffer,
 *                  R_CISP_GetInputPort/R_CISP_SetInputPort, R_CISP_GetMcfeSlot/R_CISP_SetMcfeSlot, 
 *                  R_CISP_SetScheduler, R_CISP_GetTop/R_CISP_SetTop, R_CISP_GetInputForm/R_CISP_SetInputForm,
 *                  R_CISP_GetDigitalGain/R_CISP_SetDigitalGain, R_CISP_SetGammaDL, R_CISP_SetInvGammaDL,
 *                  R_CISP_GetRawFE/R_CISP_SetRawFE, R_CISP_GetRawFeNp/R_CISP_SetRawFeNp,
 *                  R_CISP_GetSinter/R_CISP_SetSinter, R_CISP_SetSinterRs, R_CISP_SetSinterNp, 
 *                  R_CISP_GetChrAb/R_CISP_SetChrAb, R_CISP_GetWhiteBalance/R_CISP_SetWhiteBalance, 
 *                  R_CISP_SetLinearOffset, R_CISP_GetDemosaic/R_CISP_SetDemosaic,R_CISP_SetDemosaicNP, 
 *                  R_CISP_GetOutForm/R_CISP_SetOutForm, R_CISP_GetAxiOut/R_CISP_SetAxiOut
 * @param[in]       unit_index  index of the CISP HW unit
 * @return          execution result (e_isp_sample_return_t)
 *********************************************************************************************************************/
extern e_isp_sample_return_t R_ISP_SetupCispM2M (uint8_t unit_index);

/*******************************************************************************************************************//**
 * @brief           Save the CISP output buffers content in a file (raw format)
 * @warning         None
 * @call            open, write, close, R_ISP_MEMUTIL_MemInvalidate
 * @param[in]       unit_index  index of the CISP HW unit
 * @return          execution result (uint16_t)
 *********************************************************************************************************************/
extern e_isp_sample_return_t R_ISP_SaveCispOutBuffers (uint8_t unit_index);

/* TISP Setup Functions*/
/*******************************************************************************************************************//**
 * @brief           Convert the TISP API return value to string
 * @warning         None
 * @param[in]       result  TISP API returned value
 * @retval          string corresponding to the TISP API returned constant value (uint16_t)
 *********************************************************************************************************************/
extern const char * R_ISP_TispReturnToStr (uint16_t result);

/*******************************************************************************************************************//**
 * @brief           Initialize the TISP DRV SW and the TISP HW for the requested device unit
 * @warning         None
 * @call            R_TISP_Init, R_TISP_Open
 * @param[in]       unit_index  index of the TISP HW unit
 * @return          execution result (uint16_t)
 *********************************************************************************************************************/
extern uint16_t R_ISP_InitializeTISP (uint8_t unit_index);

/*******************************************************************************************************************//**
 * @brief           Finalize the TISP HW and the TISP DRV SW for the requested device unit
 * @warning         None
 * @call            R_TISP_Close, R_TISP_DeInit
 * @param[in]       unit_index  index of the TISP HW unit
 * @return          execution result (uint16_t)
 *********************************************************************************************************************/
extern uint16_t R_ISP_FinalizeTISP (uint8_t unit_index);

/*******************************************************************************************************************//**
 * @brief           Enable the TISP events and start the TISP HW execution
 * @warning         None
 * @call            R_TISP_SetEventCb, R_TISP_Start
 * @param[in]       unit_index  index of the TISP HW unit
 * @return          execution result (uint16_t)
 *********************************************************************************************************************/
extern uint16_t R_ISP_SetEventsAndStartTISP (uint8_t unit_index, const st_tisp_event_int_cfg_t * p_tisp_event);

#endif /* End of multiple inclusion protection macro R_ISP_SETUP_H */

/*======================================================================================================================
End of File
======================================================================================================================*/

