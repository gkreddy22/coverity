/***********************************************************************************************************************
* Copyright [2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : isp_sample.h
* Version      : 1.0.0
* Product Name : ISP Sample Application 
* Device(s)    : R-Car V3x
* Description  : Header File for the ISP Sample Application 
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 0.1.0   05.08.2020 Initial version
*         : 0.2.0   01.09.2020 Moved some Api to the isp_utils and isp_setup file 
*         : 1.0.0   30.11.2021 Added VSPX usage and align code to the Renesas coding guidelines (ESTISPRSWPRO-416) 
***********************************************************************************************************************/
#ifndef R_ISP_SAMPLE_H
/* Multiple inclusion protection macro */
#define R_ISP_SAMPLE_H

/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include <stdint.h>
#include "r_isp_memutil.h"
#include "r_isp_defs.h"

/*======================================================================================================================
Public macro definitions
======================================================================================================================*/

/*======================================================================================================================
Public global functions
======================================================================================================================*/

/*******************************************************************************************************************//**
* @brief            The Main thread run by the OSAL
* @details
* @param            parg - Thread / Task User Argument - ISP channel used to process the image
* @return           execution result (e_ip_sample_retuint64_trn_t)
***********************************************************************************************************************/
int64_t main_task (void * parg);

/*******************************************************************************************************************//**
* @brief            The Main Api called to run the ISP specific sample
* @details
* @param            channel - ISP channel used to process the image in different use cases
* @return           execution result (e_isp_sample_return_t)
***********************************************************************************************************************/
int R_ISP_Initialize ();
int R_ISP_DeInitialize ();
int R_ISP_Execute ();


#endif /* End of multiple inclusion protection macro R_ISP_SAMPLE_H */

/*======================================================================================================================
End of File
======================================================================================================================*/
