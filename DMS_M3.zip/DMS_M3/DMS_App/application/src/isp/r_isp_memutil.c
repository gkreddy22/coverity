/***********************************************************************************************************************
* Copyright [2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_isp_memutil.c
* Version      : 1.0.0
* Product Name : ISP Sample Application
* Device(s)    : R-Car V3x
* Description  : utility functions for handling the memory buffers used by the ISP Sample Application
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 0.1.0   10.08.2020 Initial version
*         : 1.0.0   30.11.2021 Added VSPX usage and align code to the Renesas coding guidelines (ESTISPRSWPRO-416) 
***********************************************************************************************************************/

/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include "include/r_isp_memutil.h"
#include "common.h"
/*======================================================================================================================
Private module variables
======================================================================================================================*/
static st_isp_memutil_mem_mgr_hdl_t g_isp_mem_hdl = NULL;

/*======================================================================================================================
Public function definitions
======================================================================================================================*/

/***********************************************************************************************************************
* Start of function R_ISP_MEMUTIL_MemAlloc()
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_MemAlloc(st_isp_memutil_buffer_t * p_buffer, char * p_devstr)
{
    e_isp_sample_return_t ret = ISP_SAMPLE_RET_FAILED;
    e_osal_return_t   osal_ret;
    osal_axi_bus_id_t e_axi_id;
    size_t            size_to_allocate;

    /*OSAL requires a minimum of 64 byte alignment*/
    if (p_buffer->align < 64u)
    {
        p_buffer->align = 64u;
    }

    /*Allocate an integer number of cache lines.*/
    if ((p_buffer->size % CACHE_LINE_SIZE_BYTES) == 0)
    {
        size_to_allocate = p_buffer->size;
    }
    else
    {
        /*Increase allocation so it is an integer number of cache lines*/
        size_to_allocate = p_buffer->size + (CACHE_LINE_SIZE_BYTES - (p_buffer->size % CACHE_LINE_SIZE_BYTES));
    }  

    if ((p_buffer != NULL) && (p_buffer->size > 0U) && (p_devstr != NULL))
    {
        osal_ret = R_OSAL_MmngrAlloc(handle_osalmmngr, size_to_allocate, p_buffer->align, &(p_buffer->osal_buf_handle));

        if (OSAL_RETURN_OK == osal_ret)
        {
            /* get virtual address */
            osal_ret = R_OSAL_MmngrGetCpuPtr(p_buffer->osal_buf_handle, &(p_buffer->virt_addr));

            if (OSAL_RETURN_OK == osal_ret)
            {
                osal_ret = R_OSAL_IoGetAxiBusIdFromDeviceName(p_devstr, &e_axi_id);

                if (OSAL_RETURN_OK == osal_ret)
                {
                    /* get physical address */
                    osal_ret = R_OSAL_MmngrGetHwAddr(p_buffer->osal_buf_handle, e_axi_id, &(p_buffer->phy_addr));

                    if (OSAL_RETURN_OK == osal_ret)
                    {
                        osal_ret = R_OSAL_MmngrGetSize(p_buffer->osal_buf_handle, &p_buffer->size_allocated);
                    }
                }
                else
                {
                    printf("R_ISP_MEMUTIL_MemAlloc Error: R_OSAL_IoGetAxiBusIdFromDeviceName failed for device: %s\n", p_devstr);
                }
            }
        }

        if (OSAL_RETURN_OK == osal_ret)
        {
            ret = ISP_SAMPLE_RET_OK;
        }
        else
        {
            /* OSAL Mem Manager Alloc failed */
            printf("R_ISP_MEMUTIL_MemAlloc Error: OSAL Mem Manager Alloc error %d\r\n", osal_ret);
            ret = ISP_SAMPLE_RET_ERR_OSAL;
        }
    }
    else if (p_buffer == NULL)
    {
        /* User Buffer null / not initilized (no size / alignment passed by Caller) */
        printf("R_ISP_MEMUTIL_MemAlloc Error: User Buffer NULL \r\n");
    }
    else if (p_devstr == NULL)
    {
        printf("R_ISP_MEMUTIL_MemAlloc Error: Device String is Null. Pass a valid device string\n");
    }
    else
    {
        printf("R_ISP_MEMUTIL_MemAlloc Error: User Buffer need to have a size greater than 0 \r\n");
    }

    return ret;
}
/***********************************************************************************************************************
* End of function R_ISP_MEMUTIL_MemAlloc()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function R_ISP_MEMUTIL_MemFree()
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_MemFree(st_isp_memutil_buffer_t * p_buffer)
{
    e_isp_sample_return_t ret = ISP_SAMPLE_RET_FAILED;
    e_osal_return_t       osal_ret;

    if (p_buffer != NULL) 
    {
            p_buffer->osal_buf_handle = NULL;
            p_buffer->size            = 0;
            p_buffer->virt_addr       = 0U;
            p_buffer->phy_addr        = 0U;
            ret = ISP_SAMPLE_RET_OK;
    }
    else
    {
        /* User Buffer not allocated. Nothing to free */
        printf("R_ISP_MEMUTIL_MemFree Error: User Buffer not allocated. Nothing to free\r\n");
    }

    return ret;
}
/***********************************************************************************************************************
* End of function R_ISP_MEMUTIL_MemFree()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function R_ISP_MEMUTIL_MemFlush()
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_MemFlush(st_isp_memutil_buffer_t * p_buffer)
{
    e_isp_sample_return_t  ret = ISP_SAMPLE_RET_FAILED;
    e_osal_return_t        osal_ret;

    if (p_buffer != NULL)
    {
        osal_ret = R_OSAL_MmngrFlush(p_buffer->osal_buf_handle, (size_t)0U, p_buffer->size_allocated);

        if (OSAL_RETURN_OK == osal_ret)
        {
            ret = ISP_SAMPLE_RET_OK;
        }
        else
        {
            /* Fail to flush the p_buffer */
            printf("R_ISP_MEMUTIL_MemFlush Error: Fail to flush p_buffer error %d\r\n", osal_ret);
            ret = ISP_SAMPLE_RET_ERR_OSAL;
        }
    }
    else
    {
        /* User Buffer not allocated. Nothing to free */
        printf("R_ISP_MEMUTIL_MemFlush Error: User Buffer not allocated. Nothing to flush \r\n");
    }

    return ret;
}
/***********************************************************************************************************************
* End of function R_ISP_MEMUTIL_MemFlush()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function R_ISP_MEMUTIL_MemInvalidate()
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_MemInvalidate(st_isp_memutil_buffer_t * p_buffer)
{
    e_isp_sample_return_t  ret = ISP_SAMPLE_RET_FAILED;
    e_osal_return_t        osal_ret;

    if (p_buffer != NULL)
    {
        osal_ret = R_OSAL_MmngrInvalidate(p_buffer->osal_buf_handle, (size_t)0U, p_buffer->size_allocated);

        if (OSAL_RETURN_OK == osal_ret)
        {
            ret = ISP_SAMPLE_RET_OK;
        }
        else
        {
            /* Fail to flush the p_buffer */
            printf("R_ISP_MEMUTIL_MemInvalidate Error: Fail to invalidate p_buffer error %d\r\n", osal_ret);
            ret = ISP_SAMPLE_RET_ERR_OSAL;
        }
    }
    else
    {
        /* User Buffer not allocated. Nothing to invalidate */
        printf("R_ISP_MEMUTIL_MemInvalidate Error: User Buffer not allocated. Nothing to invalidate \r\n");
    }

    return ret;
}
/***********************************************************************************************************************
* End of function R_ISP_MEMUTIL_MemInvalidate()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function R_ISP_MEMUTIL_CopyBuffer()
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_CopyBuffer(uint8_t * p_dest, const uint8_t * p_src, uint32_t size)
{
    e_isp_sample_return_t ret = ISP_SAMPLE_RET_FAILED;
    uint32_t offset;
    uint32_t i = 0;

    if ((p_dest != NULL) && (p_src != NULL) && (size > 0))
    {
        printf("Size = %d\n", size);

        for (offset = 0; size >= (offset + 4096); offset += 4096)
        {
            memcpy(p_dest + offset, p_src + offset, 4096);
            R_OSAL_ThreadSleepForTimePeriod(5);
            i++;
        }

        printf(" %d chunks of 4K data copied \n", i);

        if (size > offset)
        {
            memcpy(p_dest + offset, p_src + offset, size - offset);
            printf("All data copied\n");
        }

        ret = ISP_SAMPLE_RET_OK;
    }
    else
    {
        printf("Error on using R_ISP_MEMUTIL_CopyBuffer\r\n");
    }

    return ret;
}
/***********************************************************************************************************************
* End of function R_ISP_MEMUTIL_CopyBuffer()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function R_ISP_MEMUTIL_SaveBuffer()
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_SaveBuffer(st_isp_memutil_buffer_t * p_buffer, size_t size, char * filename)
{
    e_isp_sample_return_t ret = ISP_SAMPLE_RET_FAILED;
    int    fd;
    size_t written_bytes;

    if ((p_buffer != NULL) && (size > 0U))
    {
        /* Open file descriptor for writing */
        fd = open((const char *)(filename), O_WRONLY | O_CREAT | O_TRUNC, 0755);

        if (fd >= 0)
        {
            /* Invalidate Cache to read from main memory */
            ret = R_ISP_MEMUTIL_MemInvalidate(p_buffer);

            if (ISP_SAMPLE_RET_OK == ret)
            {
                /* write on a file pointed by fd */
                written_bytes = (size_t)write(fd, p_buffer->virt_addr, (uint32_t)(size));

                if (written_bytes != size)
                {
                    printf("Error on using R_ISP_MEMUTIL_SaveBuffer: Can't write to file\r\n");
                }

                /* Close file descriptor */
                (void)close(fd);
            }
            else
            {
                printf("Error on using R_ISP_MEMUTIL_SaveBuffer: Can't Invalidate the cache\r\n");
            }
        }
        else
        {
            /* return error as I can't open file on the target filesystem */
            printf("Error on using R_ISP_MEMUTIL_SaveBuffer: Can't open file on the target filesystem\r\n");
        }
    }
    else
    {
        printf("Error on using R_ISP_MEMUTIL_SaveBuffer\r\n");
    }

   return ret;
}
/***********************************************************************************************************************
* End of function R_ISP_MEMUTIL_SaveBuffer()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function R_ISP_MEMUTIL_CompareBuffer()
***********************************************************************************************************************/
e_isp_sample_return_t R_ISP_MEMUTIL_CompareBuffer(st_isp_memutil_buffer_t * p_buffer1, st_isp_memutil_buffer_t * p_buffer2, size_t size)
{
    e_isp_sample_return_t ret = ISP_SAMPLE_RET_FAILED;

    if ((p_buffer1 != NULL) && (p_buffer2 != NULL) && (size > 0U))
    {
        /* Invalidate cache for both buffers */
        ret = R_ISP_MEMUTIL_MemInvalidate(p_buffer1);

        if (ISP_SAMPLE_RET_OK == ret)
        {
            ret = R_ISP_MEMUTIL_MemInvalidate(p_buffer2);

            if (ISP_SAMPLE_RET_OK == ret)
            {

                if (memcmp(p_buffer1->virt_addr, p_buffer2->virt_addr, size) != 0)
                {
                    printf("R_ISP_MEMUTIL_CompareBuffer: Buffer's Content different \n");
                }

            }
            else
            {
                printf("R_ISP_MEMUTIL_CompareBuffer: Unable to invalidate cache for one of the buffers\n");
                ret = ISP_SAMPLE_RET_ERR_OSAL;
            }
        }
    }
    else
    {
        printf("R_ISP_MEMUTIL_CompareBuffer: Input Arguments Error\n");
    }

    return ret;
}
/***********************************************************************************************************************
* End of function R_ISP_MEMUTIL_CompareBuffer()
***********************************************************************************************************************/

/*======================================================================================================================
End of file
======================================================================================================================*/
