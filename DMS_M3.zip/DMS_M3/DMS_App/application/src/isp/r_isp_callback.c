/***********************************************************************************************************************
* Copyright [2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : r_isp_callback.c
* Version      : 1.0.0
* Product Name : ISP Sample Application
* Device(s)    : R-Car V3x
* Description  : ISP User Callback Functions
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 0.1.0   31.08.2020 Initial version  
*         : 0.2.0   13.10.2021 Updated to add frame end callback function (ESTISPRSWPRO-744)
*         : 1.0.0   30.11.2021 Added VSPX usage and align code to the Renesas coding guidelines (ESTISPRSWPRO-416)
***********************************************************************************************************************/
/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include <stdio.h>
#include <string.h>
#include "include/r_isp_callback.h"
#include "include/r_isp_sample.h"
#include "rcar-xos/osal/r_osal.h"

/*======================================================================================================================
Public global variables
======================================================================================================================*/
uint32_t g_cisp_frame_start_cnt     = 0;
uint32_t g_cisp_frame_end_cnt       = 0;
uint32_t g_cisp_stats_cnt           = 0;
uint32_t g_tisp_event_cnt           = 0;

/*======================================================================================================================
Private module variables
======================================================================================================================*/
static st_osal_time_t g_cisp_ts_start, g_cisp_ts_end;

/*======================================================================================================================
Private function prototypes
======================================================================================================================*/
static void r_isp_get_time_stamp (st_osal_time_t * const p_ts);


/*======================================================================================================================
Public function definitions
======================================================================================================================*/
/***********************************************************************************************************************
* Start of function R_ISP_CispEventFrameStartCb()
***********************************************************************************************************************/
void R_ISP_CispEventFrameStartCb(uint8_t slot, e_cisp_event_type_t event, uint32_t status)
{
    (void)slot;
    (void)event;
    (void)status;

    g_cisp_frame_start_cnt++;
    /* printf ("CISP Frame Start callback:%d \n",g_cisp_frame_start_cnt); */
    r_isp_get_time_stamp(&g_cisp_ts_start);
}
/***********************************************************************************************************************
* End of function R_ISP_CispEventFrameStartCb()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function R_ISP_CispEventFrameEndCb()
***********************************************************************************************************************/
void R_ISP_CispEventFrameEndCb(uint8_t slot, e_cisp_event_type_t event, uint32_t status)
{
    (void)slot;
    (void)event;
    (void)status;

    g_cisp_frame_end_cnt++;
    /* printf ("CISP Frame End callback:%d \n",g_cisp_frame_end_cnt); */
    r_isp_get_time_stamp(&g_cisp_ts_end);
}
/***********************************************************************************************************************
* End of function R_ISP_CispEventFrameEndCb()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function R_ISP_CispEventStatsCb()
***********************************************************************************************************************/
void R_ISP_CispEventStatsCb(uint8_t slot, e_cisp_event_type_t event, uint32_t status)
{
    (void)slot;
    (void)event;
    (void)status;

    g_cisp_stats_cnt++;
    /* printf ("CISP Statistics callback:%d \n",g_cisp_stats_cnt); */
}
/***********************************************************************************************************************
* End of function R_ISP_CispEventStatsCb()
***********************************************************************************************************************/

/***********************************************************************************************************************
* Start of function R_ISP_TispEventCb()
***********************************************************************************************************************/
void R_ISP_TispEventCb(u_tisp_event_t status)
{
    (void)status;

    g_tisp_event_cnt++;
    /* printf ("TISP event callback:%d \n", g_tisp_event_cnt); */
}
/***********************************************************************************************************************
* End of function R_ISP_TispEventCb()
***********************************************************************************************************************/

/*======================================================================================================================
Private function definitions
======================================================================================================================*/
/***********************************************************************************************************************
* Start of function r_isp_get_time_stamp()
***********************************************************************************************************************/
static void r_isp_get_time_stamp(st_osal_time_t * const p_ts)
{
    e_osal_return_t     osal_ret;
    e_osal_clock_type_t clock_precision;

    if (p_ts != NULL)
    {
        clock_precision = OSAL_CLOCK_TYPE_HIGH_RESOLUTION;
        osal_ret        = R_OSAL_ClockTimeGetTimeStamp(clock_precision, p_ts);

        if (OSAL_RETURN_OK != osal_ret)
        {
            printf("R_OSAL_ClockTimeGetTimeStamp Error %d\r\n",osal_ret);
        }

    }
    else
    {
        printf("Error on using r_isp_get_time_stamp: TimeStamp pointer null \r\n");
    }
}
/***********************************************************************************************************************
* End of function r_isp_get_time_stamp()
***********************************************************************************************************************/

/*======================================================================================================================
End of file
======================================================================================================================*/
