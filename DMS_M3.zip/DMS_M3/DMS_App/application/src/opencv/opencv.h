/*********************************************************************************************************************
* File Name    : opencv.h
* Version      : 1.0.0
* Product Name : DMS Application
* Device(s)    : R-Car V3h2
* Description  : Header File
*********************************************************************************************************************/

/*********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 1.0.0   20.05.2022 Initial version 
*********************************************************************************************************************/
#ifndef OPENCV_H_
#define OPENCV_H_

#include "common.h"

#define ACT_STR_MAXLEN  (25)
#define MAX_ACT_NO      (10)

const char dr_action[MAX_ACT_NO][ACT_STR_MAXLEN] = {"Drinking water",
                            "Hair and Makeup",
                            "Looking Down",
                            "Phone call left",
                            "Phone call right",
                            "Reach Back Seat",
                            "Reach Side",
                            "Safe Drive",
                            "Talking to Passenger"
                            };

#endif