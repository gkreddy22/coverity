/*********************************************************************************************************************
* File Name    : DisplayImage.cpp
* Version      : 1.0.0
* Product Name : DMS Application
* Device(s)    : R-Car V3h2
* Description  : DisplayImage Main File
*********************************************************************************************************************/

/*********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 1.0.0   20.05.2022 Initial version 
*********************************************************************************************************************/
#include <stdio.h>
#include <opencv2/opencv.hpp>

#include "common.h"
#include "opencv.h"
#include "customize.h"

using namespace cv;

extern "C" int f_opencv_execute(_driverActivity act, int det_accuracy);

int f_opencv_execute(_driverActivity act, int det_accuracy)
{
    memcpy((void *)opencv_buffer, (void *)opencv_in, g_frame_width * g_frame_height * 2);

    int font_size = g_customize.DMS_Text_Size;
    Scalar font_Color_safe;
    Scalar font_Color_others;
    Mat image(g_frame_height, g_frame_width, CV_8UC2, opencv_buffer);
    Point text_position(g_customize.DMS_Text_Position_X, g_customize.DMS_Text_Position_Y);

    if(strcmp("Green", g_customize.DMS_Text_Color_Safe) == 0){
        font_Color_safe = cv::Scalar(200, 5);
    }
    else{
        font_Color_safe = cv::Scalar(200, 255);
    }

    if(strcmp("Green", g_customize.DMS_Text_Color_Others) == 0){
        font_Color_others = cv::Scalar(200, 5);
    }
    else{
        font_Color_others = cv::Scalar(200, 255);
    }

    if((act == eSafeDrive) && g_customize.DMS_Act_SafeDrive)
    {
        cv::putText(image, dr_action[act], text_position, g_customize.DMS_Text_Font, font_size, font_Color_safe, 2, true);
    }
    else if((act == eDrinkingWater) && g_customize.DMS_Act_Drinking)
    {
        cv::putText(image, dr_action[act], text_position, g_customize.DMS_Text_Font, font_size, font_Color_others, 2, true);
    }
    else if((act == eHairnMakeUp) && g_customize.DMS_Act_Hair_Makeup)
    {
        cv::putText(image, dr_action[act], text_position, g_customize.DMS_Text_Font, font_size, font_Color_others, 2, true);
    }
    else if((act == eLookingDown) && g_customize.DMS_Act_Look_Down)
    {
        cv::putText(image, dr_action[act], text_position, g_customize.DMS_Text_Font, font_size, font_Color_others, 2, true);
    }
    else if((act == eCallLeft) && g_customize.DMS_Act_Phone_call_Left)
    {
        cv::putText(image, dr_action[act], text_position, g_customize.DMS_Text_Font, font_size, font_Color_others, 2, true);
    }
    else if((act == eCallRight) && g_customize.DMS_Act_Phone_call_Right)
    {
        cv::putText(image, dr_action[act], text_position, g_customize.DMS_Text_Font, font_size, font_Color_others, 2, true);
    }
    else if((act == eReachSide) && g_customize.DMS_Act_Reach_Side)
    {
        cv::putText(image, dr_action[act], text_position, g_customize.DMS_Text_Font, font_size, font_Color_others, 2, true);
    }
    else if((act == eReachBack) && g_customize.DMS_Act_Reach_Backseat)
    {
        cv::putText(image, dr_action[act], text_position, g_customize.DMS_Text_Font, font_size, font_Color_others, 2, true);
    }
    else if((act == eTalkintoPassenger) && g_customize.DMS_Act_Talking_Passenger)
    {
        cv::putText(image, dr_action[act], text_position, g_customize.DMS_Text_Font, font_size, font_Color_others, 2, true);
    } 
    else
    {
        /* Do Nothing */
    }

    return SUCCESS;
}
