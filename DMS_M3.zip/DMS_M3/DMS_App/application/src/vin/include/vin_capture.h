/*********************************************************************************************************************
* File Name    : vin_capture.c
* Version      : 1.0.0
* Product Name : DMS Application
* Device(s)    : R-Car V3h2
* Description  : Video Output header File
*********************************************************************************************************************/

/*********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 1.0.0   20.05.2022 Initial version 
*********************************************************************************************************************/
int R_VIN_Initialize ();
int R_VIN_Open ();
int R_VIN_SetUpVideoInput (void);
int R_VIN_Execute ();
int R_VIN_DeInitialize ();
int R_VIN_Close (void);