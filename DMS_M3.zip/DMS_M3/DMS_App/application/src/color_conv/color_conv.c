/*********************************************************************************************************************
* File Name    : yuv2rgb_main.c
* Version      : 1.0.0
* Product Name : DMS Application
* Device(s)    : R-Car V3h2
* Description  : yuv to rgb conversion
*********************************************************************************************************************/

/********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 1.0.0   20.05.2022 Initial version 
*********************************************************************************************************************/

/*===================================================================================================================
Includes <System Includes> , "Project Includes"
====================================================================================================================*/

#include <stdio.h>
#include <string.h>
#include "common.h"
#include "customize.h"

static void Conv_YUYV2RGB(unsigned char * yuyv, unsigned char * bgr, int width, int height);

/********************************************************************************************************************
* Start of function yuv2rgb_main()
*********************************************************************************************************************/

int yuv2rgb_main(void *ptr) 
{
    Conv_YUYV2RGB(ptr, cnn_rgb_buffer, g_customize.IMR_Resize_Width, g_customize.IMR_Resize_Height);                //conversion function 
    return 0;
}

static void Conv_YUYV2RGB(unsigned char * yuyv, unsigned char * bgr, int width, int height)
{
    int z = 0;
    int x;
    int yline;
 
    for (yline = 0; yline < height; yline++) {
        for (x = 0; x < width; x++) 
        {
                int r, g, b;
                int y, u, v;
            if (!z)
                y = yuyv[0] << 8;
            else 
                y = yuyv[2] << 8;

                u = yuyv[1] - 128;
                v = yuyv[3] - 128;
                            
                r = (y + (359 * v)) >> 8;
                g = (y - (88 * u) - (183 * v)) >> 8;
                b = (y + (454 * u)) >> 8;
                            
         *(bgr++) = (unsigned char)((r > 255) ? 255 : ((r < 0) ? 0 : r));
         *(bgr++) = (unsigned char)((g > 255) ? 255 : ((g < 0) ? 0 : g));
         *(bgr++) = (unsigned char)((b > 255) ? 255 : ((b < 0) ? 0 : b));
 
            if (z++) {
                z = 0;
            yuyv += 4;
            }
        }
    }
}

int y_uv2yuyv(char *pdst, char * py, char * puv, int width, int height)
{
    int i;

    for(i = 0; i<width*height; i=i+2 ){
        /* y */
        *pdst++ = py[i];
        
        /* u */
        *pdst++ = puv[i]; 
        
        /* y1 */
        *pdst++ = py[i+1]; 
        
        /* v */
        *pdst++ = puv[i+1]; 
    }

    return SUCCESS;
}
