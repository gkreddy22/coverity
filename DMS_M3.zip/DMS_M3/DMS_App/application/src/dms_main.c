/***********************************************************************************************************************
* File Name    : main.c
* Version      : 1.0.0
* Product Name : DMS Application
* Device(s)    : R-Car V3h2
* Description  : Main Application File
***********************************************************************************************************************/

/***********************************************************************************************************************
* History : Version DD.MM.YYYY Description
*         : 1.0.0   20.05.2022 Initial version 
***********************************************************************************************************************/

/*======================================================================================================================
Includes <System Includes> , "Project Includes"
======================================================================================================================*/
#include "rcar-xos/rcar_xos_config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/stat.h>
#include "common.h"
#include "customize.h"
/**********************************************************************************************************************
 Exported global variables and functions
 *********************************************************************************************************************/
unsigned char * isp_in          = NULL;
unsigned char * imr_ldc_in      = NULL;
unsigned char * imr_res_in      = NULL;
unsigned char * cnn_in          = NULL;
unsigned char * opencv_in       = NULL;
unsigned char * vout_in         = NULL;
unsigned char * vin_out_buffer  = NULL;
unsigned char * isp_buffer      = NULL;
unsigned char * imr_ldc_buffer  = NULL;
unsigned char * opencv_buffer   = NULL;
unsigned char * cnn_rgb_buffer  = NULL;
int det_accuracy                = 0;
int64_t g_frame_width           = 0;
int64_t g_frame_height          = 0;
uint32_t us_CNN                 = 0;
uint32_t us_VIN                 = 0;
uint32_t us_ISP                 = 0;
uint32_t us_LDC                 = 0;
uint32_t us_REZ                 = 0;
uint32_t us_OCV                 = 0;
uint32_t us_VOUT                = 0;
uint32_t us_YUVRGB              = 0;
bool g_debug_save_flag          = false;
bool is_thread_exit             = false;
st_customize_t g_customize;
_driverActivity driverActivity  = eNone;
osal_mutex_handle_t mtx_handle  = OSAL_MUTEX_HANDLE_INVALID;
void * gp_isp_out_y;
void * gp_isp_out_uv;
systemstatus dmsStatus;

int64_t R_Init_Modules();
int64_t R_Deinit_Modules();
int64_t R_Capture_Task();
int64_t R_VOUT_Task();
int64_t R_CTRL_Task();
int64_t R_CNN_Task();
int64_t R_IMR_Task();
int f_opencv_execute(_driverActivity act, int det_accuracy);

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static int64_t R_Debug_Image_save();
static int64_t R_Log_File_Save();
static int64_t R_DMS_SystemInit();
static int64_t buffer_map();
static void sigint_handler(int signum);
static void DmsModuleInitFlags();

/* Function Name : main */
/******************************************************************************************************************//**
 * @brief       main function
 * @param[in]   argc            unused  
 * @param[in]   argv            unused
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
***********************************************************************************************************************/
int main(int argc, char * argv[]) 
{

    (void)argc; /* unused */
    (void)argv; /* unused */
    int ret;

    DmsModuleInitFlags();

    do 
    {
        signal(SIGINT, sigint_handler);
        ret = R_CustomizeLoad(&g_customize,DMS_CustomizeFile);
        if (FAILED == ret)
        {
            PRINT_ERROR("Failed R_CustomizeLoad \n");
            R_CustomizeInit(&g_customize);
        }


        if (g_customize.CNN_NumberOfChannels > 3)
        {
            PRINT_ERROR("Maximum supported channel number is 3\n");
            break;
        }

        R_CustomizePrint(&g_customize);

        ret = R_CustomizeValidate(&g_customize);
        if (FAILED == ret)
        {
            PRINT_ERROR("Failed R_CustomizeLoad \n");
            break;
        }

        ret = R_DMS_SystemInit();
        if (FAILED == ret)
        {
            PRINT_ERROR("R_DMS_SystemInit failed\n");
            break;
        }

        ret = buffer_map();
        if (FAILED == ret)
        {
            PRINT_ERROR("buffer_map failed\n");
            break;
        }
        /* OSAL Initialize */
        e_osal_return_t osal_ret,ret_osal;
        osal_ret= R_OSAL_Initialize();
        if (OSAL_RETURN_OK != osal_ret)
        {
            PRINT_ERROR("OSAL Initialization failed with error %d\n", osal_ret);
            break;
        }

        ret = init_mmgr();
        if (ret)
        {
            ret_osal = R_OSAL_Deinitialize();
            if (OSAL_RETURN_OK != ret_osal )
            {
                PRINT_ERROR("Failed R_OSAL_Deinitialize ret=%d\n", ret_osal);
            }
            break;
        }

        ret = R_Init_Modules();
        if (FAILED == ret)
        {
       
            R_Deinit_Modules();
            PRINT_ERROR("Failed R_Init_Modules ret\n");
            break;
        }
    
        /* Create Capture thread */
        osal_thread_handle_t    capture_thrd_hndl         = OSAL_THREAD_HANDLE_INVALID;
        int64_t                 thrd_return_value = -1;
        st_osal_thread_config_t capture_thrd_cfg;
        capture_thrd_cfg.func       = R_Capture_Task;
        capture_thrd_cfg.priority   = OSAL_THREAD_PRIORITY_TYPE1;
        capture_thrd_cfg.stack_size = 0x2000;
        capture_thrd_cfg.task_name  = "R_Capture_Task";
        capture_thrd_cfg.userarg    = NULL;

        /* Create IMR thread */
        osal_thread_handle_t    imr_thrd_hndl         = OSAL_THREAD_HANDLE_INVALID;
        int64_t                 imr_thrd_return_value = -1;
        st_osal_thread_config_t imr_thrd_cfg;
        imr_thrd_cfg.func       = R_IMR_Task;
        imr_thrd_cfg.priority   = OSAL_THREAD_PRIORITY_TYPE0;
        imr_thrd_cfg.stack_size = 0x2000;
        imr_thrd_cfg.task_name  = "R_IMR_Task";
        imr_thrd_cfg.userarg    = NULL;

        /* Create CNN thread */
        osal_thread_handle_t    cnn_thrd_hndl         = OSAL_THREAD_HANDLE_INVALID;
        int64_t                 cnn_thrd_return_value = -1;
        st_osal_thread_config_t cnn_thrd_cfg;
        cnn_thrd_cfg.func       = R_CNN_Task;
        cnn_thrd_cfg.priority   = OSAL_THREAD_PRIORITY_TYPE0;
        cnn_thrd_cfg.stack_size = 0x2000;
        cnn_thrd_cfg.task_name  = "R_CNN_Task";
        cnn_thrd_cfg.userarg    = NULL;


        /* Create Vout thread */
        osal_thread_handle_t    vout_thrd_hndl         = OSAL_THREAD_HANDLE_INVALID;
        int64_t                 vout_thrd_return_value = -1;
        st_osal_thread_config_t vout_thrd_cfg;
        vout_thrd_cfg.func       = R_VOUT_Task;
        vout_thrd_cfg.priority   = OSAL_THREAD_PRIORITY_TYPE0;
        vout_thrd_cfg.stack_size = 0x2000;
        vout_thrd_cfg.task_name  = "R_VOUT_Task";
        vout_thrd_cfg.userarg    = NULL;

        /* Create control thread */
        osal_thread_handle_t    ctrl_thrd_hndl         = OSAL_THREAD_HANDLE_INVALID;
        int64_t                 ctrl_thrd_return_value = -1;
        st_osal_thread_config_t ctrl_thrd_cfg;
        ctrl_thrd_cfg.func       = R_CTRL_Task;
        ctrl_thrd_cfg.priority   = OSAL_THREAD_PRIORITY_TYPE0;
        ctrl_thrd_cfg.stack_size = 0x2000;
        ctrl_thrd_cfg.task_name  = "R_CTRL_Task";
        ctrl_thrd_cfg.userarg    = NULL;

        /* mutex handle */
        
        osal_ret= R_OSAL_ThsyncMutexCreate((osal_mutex_id_t)MUTEX_ID_NO1, &mtx_handle);
        if (OSAL_RETURN_OK != osal_ret)
        {
            PRINT_ERROR("Failed R_OSAL_ThsyncMutexCreate %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }
        /* START_THREAD: Thread starts */

        /* Start control Thread */
        osal_ret = R_OSAL_ThreadCreate(&ctrl_thrd_cfg, 0xf003, &ctrl_thrd_hndl);
        if (OSAL_RETURN_OK != osal_ret)
        {
            PRINT_ERROR("OSAL Control thread creation failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }

        /* Start Capture Thread */
        osal_ret = R_OSAL_ThreadCreate(&capture_thrd_cfg, 0xf000, &capture_thrd_hndl);
        if (OSAL_RETURN_OK != osal_ret)
        {
            is_thread_exit=true;
            PRINT_ERROR("OSAL capture thread creation failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }
        
        /* Start IMR Thread */
        osal_ret = R_OSAL_ThreadCreate(&imr_thrd_cfg, 0xf004, &imr_thrd_hndl);
        if (OSAL_RETURN_OK != osal_ret)
        {
            PRINT_ERROR("OSAL IMR thread creation failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }
        /* Start CNN Thread */
        osal_ret = R_OSAL_ThreadCreate(&cnn_thrd_cfg, 0xf001, &cnn_thrd_hndl);
        if (OSAL_RETURN_OK != osal_ret)
        {
            is_thread_exit=true;
            PRINT_ERROR("OSAL capture thread creation failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }
      
        /* Start vout Thread */
        osal_ret = R_OSAL_ThreadCreate(&vout_thrd_cfg, 0xf002, &vout_thrd_hndl);
        if (OSAL_RETURN_OK != osal_ret)
        {
            is_thread_exit=true;
            PRINT_ERROR("OSAL vout thread creation failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }

        /* wait until capture thread */
        osal_ret = R_OSAL_ThreadJoin(capture_thrd_hndl, &thrd_return_value);
        if (OSAL_RETURN_OK != osal_ret)
        {
            PRINT_ERROR("OSAL capture thread join failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }

        osal_ret = R_OSAL_ThreadJoin(imr_thrd_hndl, &imr_thrd_return_value);
        if (OSAL_RETURN_OK != osal_ret)
        {
            PRINT_ERROR("OSAL imr thread join failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }

        /*Wait until CNN Thread*/
        osal_ret = R_OSAL_ThreadJoin(cnn_thrd_hndl, &cnn_thrd_return_value);
        if (OSAL_RETURN_OK != osal_ret)
        {
            PRINT_ERROR("OSAL capture thread join failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }

        /* wait until VOUT thread finished */
        osal_ret = R_OSAL_ThreadJoin(vout_thrd_hndl, &vout_thrd_return_value);
        if (OSAL_RETURN_OK != osal_ret)
        {
            PRINT_ERROR("OSAL vout thread join failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }

        printf("Please press Enter to Exit \n");
        /* wait until control thread finished */
        osal_ret = R_OSAL_ThreadJoin(ctrl_thrd_hndl, &ctrl_thrd_return_value);
        if (OSAL_RETURN_OK != osal_ret)
        {
            PRINT_ERROR("OSAL control thread join failed with error %d\n", osal_ret);
            R_Deinit_Modules();
            break;
        }
        
        /* De-Initialize */
        R_Deinit_Modules();
    }
    while(0);
    printf("DMS App terminated successfully.\n");

    return SUCCESS;

}
/**********************************************************************************************************************
 End of function main
 *********************************************************************************************************************/


/* Function Name : R_Capture_Task */
/******************************************************************************************************************//**
 * @brief       Capture thread
 * @param[in]   none
 * @param[out]  none
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
***********************************************************************************************************************/

int64_t R_Capture_Task()
{
    int ret = INVALID;
    struct timeval  mod_starttime, mod_endtime;
    
    while(!is_thread_exit)
    {
        if(true==g_customize.VIN_Enable)
        {
            if (0 != g_customize.Proc_Time)
            {
                gettimeofday(&mod_starttime,NULL);
            }
            ret = R_VIN_Execute();

            if (FAILED == ret)
            {
                PRINT_ERROR("Failed R_VIN_Execute \n");
                is_thread_exit = true;
                return FAILED;
            }
            if (0 != g_customize.Proc_Time)
            {
                gettimeofday(&mod_endtime,NULL);
                us_VIN = ((uint32_t)mod_endtime.tv_sec-(uint32_t)mod_starttime.tv_sec)*1000*1000;
                us_VIN +=((uint32_t)mod_endtime.tv_usec-(uint32_t)mod_starttime.tv_usec);
                if (2 == g_customize.Proc_Time)
                {
                    printf("VIN Execute took %d mili seconds\n", us_VIN/1000);
                }
            }
        }
        if (true == g_customize.ISP_Enable )
        {
            if (0 != g_customize.Proc_Time)
            {
                gettimeofday(&mod_starttime,NULL);
            }
            ret = R_ISP_Execute();
            if(FAILED == ret)
            {
                PRINT_ERROR("Failed R_ISP_Execute \n");
                is_thread_exit = true;
                return FAILED;
            }

            if (0 != g_customize.Proc_Time)
            {
                gettimeofday(&mod_endtime,NULL);
                us_ISP = ((uint32_t)mod_endtime.tv_sec-(uint32_t)mod_starttime.tv_sec)*1000*1000;
                us_ISP +=((uint32_t)mod_endtime.tv_usec-(uint32_t)mod_starttime.tv_usec);
                if (2 == g_customize.Proc_Time)
                {
                    printf("ISP Execute took %d mili seconds\n", us_ISP/1000);
                }
            }
            ret = y_uv2yuyv(isp_buffer, (char *)gp_isp_out_y, (char *)gp_isp_out_uv, g_frame_width, g_frame_height);
            if(FAILED == ret)
            {
                PRINT_ERROR("Failed y_uv2yuyv Conversion \n");
                is_thread_exit = true;
                return FAILED;
            }
        }

        R_OSAL_ThreadSleepForTimePeriod ((osal_milli_sec_t)TIMEOUT_5MS_SLEEP);

    }
    return SUCCESS;
}

/**********************************************************************************************************************
 End of function R_Capture_Task
 *********************************************************************************************************************/
 
/* Function Name : R_IMR_Task */
/******************************************************************************************************************//**
 * @brief       IMR Thread
 * @param[in]   none
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
 *********************************************************************************************************************/
 
int64_t R_IMR_Task()
{
    int ret;
    struct timeval  mod_starttime, mod_endtime;

    R_OSAL_ThreadSleepForTimePeriod ((osal_milli_sec_t)TIMEOUT_50MS_SLEEP);
    while(!is_thread_exit)
    {
        if (true == g_customize.IMR_LDC)
        {

            if (0 != g_customize.Proc_Time)
            {
                gettimeofday(&mod_starttime,NULL);\
            }
            ret = R_IMR_ExecuteLDC();
            if (FAILED == ret)
            {
                PRINT_ERROR("Failed R_IMR_ExecuteLDC \n");
                is_thread_exit = true;
                return FAILED;
            }

            if (0 != g_customize.Proc_Time)
            {
                gettimeofday(&mod_endtime,NULL);
                us_LDC = ((uint32_t)mod_endtime.tv_sec-(uint32_t)mod_starttime.tv_sec)*1000*1000;
                us_LDC +=((uint32_t)mod_endtime.tv_usec-(uint32_t)mod_starttime.tv_usec);

                if (2 == g_customize.Proc_Time)
                {
                    printf("LDC took %d mili seconds\n", us_LDC/1000);
                }
            }

        }

        if (0 != g_customize.Proc_Time)
        {
            gettimeofday(&mod_starttime,NULL);
        }
        ret = R_IMR_ExecuteResize();
        if (FAILED == ret)
        {
            PRINT_ERROR("Failed R_IMR_ExecuteResize \n");
            is_thread_exit = true;
            return FAILED;
        }
        if (0 != g_customize.Proc_Time)
        {
            gettimeofday(&mod_endtime,NULL);
            us_REZ = ((uint32_t)mod_endtime.tv_sec-(uint32_t)mod_starttime.tv_sec)*1000*1000;
            us_REZ +=((uint32_t)mod_endtime.tv_usec-(uint32_t)mod_starttime.tv_usec);
            if (2 == g_customize.Proc_Time)
            {
                printf("IMR Resize took %d mili seconds\n", us_REZ/1000);
            }
        }
        R_OSAL_ThreadSleepForTimePeriod ((osal_milli_sec_t)TIMEOUT_5MS_SLEEP);

    }
    return SUCCESS;
}
/**********************************************************************************************************************
 End of function R_IMR_Task
 *********************************************************************************************************************/

/* Function Name : R_VOUT_Task */
/******************************************************************************************************************//**
 * @brief       Display Thread
 * @param[in]   none
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
 *********************************************************************************************************************/
int64_t R_VOUT_Task()
{   
    int ret = INVALID;
    struct timeval  mod_starttime, mod_endtime;

    R_OSAL_ThreadSleepForTimePeriod ((osal_milli_sec_t)TIMEOUT_50MS_SLEEP);

    while(!is_thread_exit)
    {
        if (0 != g_customize.Proc_Time)
        {
            gettimeofday(&mod_starttime,NULL);
        }

        ret = f_opencv_execute(driverActivity, det_accuracy);
        if (FAILED == ret)
        {
            is_thread_exit = true;
            PRINT_ERROR("Failed f_opencv_execute \n");
            return FAILED;
        }
        if (0 != g_customize.Proc_Time)
        {
            gettimeofday(&mod_endtime,NULL);
            us_OCV = ((uint32_t)mod_endtime.tv_sec-(uint32_t)mod_starttime.tv_sec)*1000*1000;
            us_OCV +=((uint32_t)mod_endtime.tv_usec-(uint32_t)mod_starttime.tv_usec);
            if (2 == g_customize.Proc_Time)
            {
                printf("OpenCV took %d mili seconds\n", us_OCV/1000);
            }
        }
        if (0 != g_customize.Proc_Time)
        {
            gettimeofday(&mod_starttime,NULL);
        }

        ret = execute();
        if (FAILED == ret)
        {
            is_thread_exit = true;
            PRINT_ERROR("Failed Vout execute \n");
            return FAILED;
        }

        R_OSAL_ThreadSleepForTimePeriod ((osal_milli_sec_t)TIMEOUT_10MS_SLEEP);
        if (0 != g_customize.Proc_Time)
        {
            gettimeofday(&mod_endtime,NULL);
            us_VOUT = ((uint32_t)mod_endtime.tv_sec-(uint32_t)mod_starttime.tv_sec)*1000*1000;
            us_VOUT +=((uint32_t)mod_endtime.tv_usec-(uint32_t)mod_starttime.tv_usec);
            if (2 == g_customize.Proc_Time)
            {
                printf("VOUT took %d mili seconds (10 ms sleep)\n", us_VOUT/1000);
            }
        }
    }

    return SUCCESS;

}
/**********************************************************************************************************************
 End of function R_VOUT_Task
 *********************************************************************************************************************/
 
/* Function Name :R_CNN_Task  */
/******************************************************************************************************************//**
 * @brief       CNN thread
 * @param[in]   none
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
***********************************************************************************************************************/
int64_t R_CNN_Task()
{ 
    int ret = INVALID;
    struct timeval mod_starttime, mod_endtime;

    R_OSAL_ThreadSleepForTimePeriod ((osal_milli_sec_t)TIMEOUT_50MS_SLEEP);

    while(!is_thread_exit)
    {
        if (0 != g_customize.Proc_Time)
        {
            gettimeofday(&mod_starttime,NULL);
        }
        ret = cnn_application_exec();
        if (FAILED == ret)
        {
            is_thread_exit = true;
            PRINT_ERROR("Failed cnn_application_exec \n");
            return FAILED;
        }
        if (0 != g_customize.Proc_Time)
        {
            gettimeofday(&mod_endtime,NULL);
            us_CNN = ((uint32_t)mod_endtime.tv_sec-(uint32_t)mod_starttime.tv_sec)*1000*1000;
            us_CNN +=((uint32_t)mod_endtime.tv_usec-(uint32_t)mod_starttime.tv_usec);
            if (2 == g_customize.Proc_Time)
            {
                printf("CNN took %d mili seconds\n", us_CNN/1000);
                printf("CNN Performance :%f FPS \n", (1000000.0/us_CNN));
            }
        }
        if(g_debug_save_flag == true)
        {
            R_Debug_Image_save();
        }

        R_OSAL_ThreadSleepForTimePeriod ((osal_milli_sec_t)TIMEOUT_1MS_SLEEP);
    }

    return 0;
}
/**********************************************************************************************************************
 End of function R_CNN_Task
 *********************************************************************************************************************/


/* Function Name : R_CTRL_Task */
/******************************************************************************************************************//**
 * @brief       User control thread
 * @param[in]   none
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
 *********************************************************************************************************************/
int64_t R_CTRL_Task()
{
    char user_in[DATA_LEN_64]="";
    
    while(!is_thread_exit)
    {

        fgets(user_in, sizeof(user_in), stdin);
        if( strncmp(user_in,"x",1) == 0)
        {
            is_thread_exit=true;
            if(is_thread_exit)
            {
                break;
            }
        }
        else if ( strncmp(user_in,"save",4) == 0)
        {
            g_debug_save_flag = true;
        }
        else if ( strncmp(user_in,"p",1) == 0)
        {
            if (0 != g_customize.Proc_Time)
            {
                printf("Performance Details\n");
                if(true==g_customize.VIN_Enable)
                {
                    printf("VIN             : %d ms\n", us_VIN/1000);
                }
                if(true==g_customize.ISP_Enable)
                {
                    printf("ISP             : %d ms\n", us_ISP/1000);
                }
                if (true == g_customize.IMR_LDC)
                {
                    printf("IMR LDC         : %d ms\n", us_LDC/1000);
                }
                printf("IMR RES         : %d ms\n", us_REZ/1000);
                printf("yuv2rgb_main    : %d ms\n", us_YUVRGB/1000);
                printf("CNN             : %d ms\n", us_CNN/1000);
                printf("OpenCV          : %d ms\n", us_OCV/1000);
                printf("VOUT            : %d ms\n", us_VOUT/1000);
                printf("CNN Performance : %f FPS \n", (1000000.0/us_CNN));
                printf("\n");
            }
            else
            {
                printf("Performance calculations not enabled.\n");
                printf("To Enable, change \"Proc_Time\" to 1 \n");
            }
        }
    }
    return 0;
}
/**********************************************************************************************************************
 End of function R_CTRL_Task
 *********************************************************************************************************************/


/* Function Name : R_Init_Modules */
/******************************************************************************************************************//**
 * @brief       Module Initialization 
 * @param[in]   none
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
 *********************************************************************************************************************/
int64_t R_Init_Modules()
{
    int ret = INVALID;
    int pad = 0;
    char csi_ch[64];
    char media_cmd1[256];
    char media_cmd2[256];

    /* media control system call */
    g_debug_save_flag = false;

    if(g_customize.VIN_Device < 4)
    {
        strcpy(csi_ch, "feaa0000.csi_00");
        pad = g_customize.VIN_Device + 1;
    }
    else
    {
        strcpy(csi_ch, "feab0000.csi_01");
        pad = g_customize.VIN_Device - 3;
    }

    
    system("media-ctl -d /dev/media0 -r");
    sprintf(media_cmd1, "media-ctl -d /dev/media0 -l \"'rcar_csi2 %s':%d -> 'VIN%d output':0 [1]\"", csi_ch, pad, g_customize.VIN_Device);
    sprintf(media_cmd2, "media-ctl -d /dev/media0 -V \"'rcar_csi2 %s':%d [fmt:UYVY8_2X8/1280x800 field:none\"]", csi_ch, pad);
  

    system(media_cmd1);
    system(media_cmd2);

    /* Initialize all modules */
    ret = R_VIN_Initilize();
    if (FAILED == ret)
    {
        dmsStatus.vin.status=FAILED;
        PRINT_ERROR("Failed R_VIN_Initilize \n");
        return FAILED;
    }

    ret = R_IMR_Init();
    if (FAILED == ret)
    {
        dmsStatus.imr_ldc.status=FAILED;
        dmsStatus.imr_rs.status=FAILED;
        PRINT_ERROR("Failed R_IMR_Init \n");
        return FAILED;
    }

    if (true == g_customize.IMR_LDC)
    {
        ret = R_IMR_SetupLDC();
        if (FAILED == ret)
        {
            PRINT_ERROR("Failed R_IMR_SetupLDC \n");
            return FAILED;
        }
    }

    ret = R_IMR_SetupResize();
    if (FAILED == ret)
    {
        PRINT_ERROR("Failed R_IMR_SetupResize \n");
        return FAILED;
    }

    ret = vout_init();
    if (FAILED == ret)
    {
        dmsStatus.vout.status=FAILED;
        PRINT_ERROR("Failed vout_init \n");
        return FAILED;
    }

    ret = cnn_application_init();
    if (FAILED == ret)
    {
        dmsStatus.cnn.status=FAILED;
        PRINT_ERROR("Failed cnn_application_init \n");
        return FAILED;
    }
    if (true == g_customize.ISP_Enable  )
    {
        ret = R_ISP_Initialize();
        if (FAILED == ret)
        {
            dmsStatus.isp.status=FAILED;
            PRINT_ERROR("Failed ISP_init \n");
            return FAILED;
        }
    }

    return SUCCESS;
}

/**********************************************************************************************************************
 End of function R_Init_Modules
 *********************************************************************************************************************/


/* Function Name : R_Deinit_Modules */
/******************************************************************************************************************//**
 * @brief       Module deinitialization
 * @param[in]   none
 * @param[out]  none
 * @retval      true            success
 * @retval      false           fail
 *********************************************************************************************************************/
int64_t R_Deinit_Modules()
{
    int ret = INVALID;

    free(vin_out_buffer);
    if (SUCCESS == dmsStatus.vin.status)
    {
        R_VIN_DeInitialize();
    }

    if (true == g_customize.ISP_Enable)
    {
        ret = R_ISP_DeInitialize();
        if (FAILED == ret)
        {
            PRINT_ERROR("Failed R_ISP_DeInitialize \n");
            return FAILED;
        }
    }

    free(imr_ldc_buffer);
    free(cnn_rgb_buffer);
    R_IMR_Deinit();

    if (SUCCESS == dmsStatus.cnn.status)
    {
        R_CNN_DeInitialize();
    }

    free(opencv_buffer);
    if (SUCCESS == dmsStatus.vout.status)
    {
        vout_deinit();
    }
    deinit_mmgr();

    R_OSAL_Deinitialize();

    return SUCCESS;
}
/**********************************************************************************************************************
 End of function R_Deinit_Modules
 *********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: R_Debug_Image_save
* Description  : Saving output image of all modules
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static int64_t R_Debug_Image_save()
{
    char filename[DATA_LEN_128];
    char foldername[DATA_LEN_64];
    FILE *g_fp;
    int g_size = (g_frame_width * g_frame_height) * BPP_YUV;
    struct tm* tm;
    time_t now;

    now = time(0);                                          // get current time
    tm = localtime(&now);                                   // get time structure

    sprintf(foldername, "dms_log_%02d_%02d_%04d_%d_%d_%d", tm->tm_mon+1, tm->tm_mday, tm->tm_year+1900, tm->tm_hour, tm->tm_min, tm->tm_sec);
    
    mkdir(foldername,0777);

    sprintf(filename, "%s/vin_capture_buffer",foldername);
    g_fp = fopen(filename, "wb");
    printf("writing %s to a file!\n",filename);    
    fwrite(vin_out_buffer, sizeof(unsigned char), (size_t) g_size, g_fp);
    fclose(g_fp);

    memset(filename, 0 , sizeof(filename));
    sprintf(filename, "%s/imr_ldc_buffer",foldername);
    g_fp = fopen(filename, "wb");
    printf("writing %s to a file!\n",filename);
    fwrite(imr_ldc_buffer, sizeof(unsigned char), (size_t) g_size, g_fp);
    fclose(g_fp);

    memset(filename, 0 , sizeof(filename));
    sprintf(filename, "%s/vout_buffer",foldername);
    g_fp = fopen(filename, "wb");
    printf("writing %s to a file!\n",filename);
    fwrite(opencv_buffer, sizeof(unsigned char), (size_t) g_size, g_fp);
    fclose(g_fp);

    memset(filename, 0 , sizeof(filename));
    sprintf(filename, "%s/cnn_rgb_buffer",foldername);
    g_size = (g_customize.IMR_Resize_Width * g_customize.IMR_Resize_Height) * BPP_RGB;
    g_fp = fopen(filename, "wb");
    printf("writing %s to a file!\n",filename);
    fwrite(cnn_rgb_buffer, sizeof(unsigned char), (size_t) g_size, g_fp);
    fclose(g_fp);

    memset(filename, 0 , sizeof(filename));
    sprintf(filename, "%s/cnn_log_values.txt",foldername);
    g_fp = fopen(filename, "wb");
    printf("writing %s to a file!\n",filename);
    fprintf(g_fp, "%02d_%02d_%04d_%d_%d_%d: index=%d", tm->tm_mon+1, tm->tm_mday, tm->tm_year+1900, tm->tm_hour, tm->tm_min, tm->tm_sec,driverActivity);
    fclose(g_fp);
    g_debug_save_flag = false;
    return 0;
}
/**********************************************************************************************************************
 End of function R_Debug_Image_save
 *********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: R_DMS_SystemInit
* Description  : DMS system Initialisation
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static int64_t R_DMS_SystemInit()
{

    g_frame_width = g_customize.Frame_Width;
    g_frame_height = g_customize.Frame_Height;

    vin_out_buffer = (char *) malloc(g_frame_width * g_frame_height * BPP_YUV);
    if(NULL == vin_out_buffer)
    {
        DEBUG_PRINT("Failed to allocate cnn_rgb_buffer Buffer \n");
        return FAILED;
    }
    
    isp_buffer = (char *) malloc(g_frame_width * g_frame_height * BPP_YUV);
    if(NULL == isp_buffer)
    {
        DEBUG_PRINT("Failed to allocate isp_buffer Buffer \n");
        return FAILED;
    }

    cnn_rgb_buffer = (char *) malloc(g_customize.IMR_Resize_Width * g_customize.IMR_Resize_Height * BPP_RGB);
    if(NULL == cnn_rgb_buffer)
    {
        DEBUG_PRINT("Failed to allocate cnn_rgb_buffer Buffer \n");
        return FAILED;
    }

    imr_ldc_buffer = (char *) malloc(g_frame_width * g_frame_height * BPP_YUV);
    if(NULL == imr_ldc_buffer)
    {
        DEBUG_PRINT("Failed to allocate imr_ldc_buffer Buffer \n");
        return FAILED;
    }

    opencv_buffer = (char *) malloc(g_frame_width * g_frame_height * BPP_YUV);
    if(NULL == opencv_buffer)
    {
        DEBUG_PRINT("Failed to allocate opencv_buffer Buffer \n");
        return FAILED;
    }

    return SUCCESS;
}
/**********************************************************************************************************************
 End of function R_DMS_SystemInit
 *********************************************************************************************************************/



/***********************************************************************************************************************
* Function Name: buffer_map
* Description  : Customization 
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static int64_t buffer_map()
{
    /* IMR LDC Input Customization */
    if (false == g_customize.VIN_Enable)
    {
        printf("[%s]\n",g_customize.Frame_File_Name);
        FILE *buf_fp = NULL;
        buf_fp = fopen(g_customize.Frame_File_Name, "rb");
        if (NULL == buf_fp)
        {
            PRINT_ERROR("Input Frame not found [%s]\n",g_customize.Frame_File_Name);
            return FAILED;
        }

        if(true == g_customize.ISP_Enable)
        {
            fread(isp_buffer, sizeof(unsigned char), g_frame_height*g_frame_width*BPP_Y, buf_fp);
        }
        else
        {
            fread(vin_out_buffer, sizeof(unsigned char), g_frame_height*g_frame_width*BPP_YUV, buf_fp);
        }

        fclose(buf_fp);
    }

    /* ISP Input Customization */
    if (true == g_customize.VIN_Enable )
    {
        isp_in = vin_out_buffer;
    }
    else
    {
        isp_in = isp_buffer;
    }

    /* IMR LDC Input Customization */
    if (true == g_customize.ISP_Enable)
    {

        imr_ldc_in = isp_buffer;
    }
    else if (true == g_customize.VIN_Enable )
    {
        imr_ldc_in = vin_out_buffer;
    }
    else
    {
        imr_ldc_in = vin_out_buffer; 
    }

    /* IMR Resize Input Customization */
    if (true == g_customize.IMR_LDC )
    {
        imr_res_in = imr_ldc_buffer;
    }
    else if (true == g_customize.ISP_Enable )
    {
        imr_res_in = isp_buffer;
    }
    else if (true == g_customize.VIN_Enable )
    {
        imr_res_in = vin_out_buffer;
    }
    else
    {
        imr_res_in = vin_out_buffer;
    }

    cnn_in = cnn_rgb_buffer;
   
    /* OpenCV Input Customization */
    if (true == g_customize.IMR_LDC )
    {
        opencv_in = imr_ldc_buffer;
    }
    else if (true == g_customize.VIN_Enable )
    {
        opencv_in = vin_out_buffer;
    }
    else
    {
        opencv_in = isp_buffer;
    }

    /* Vout Input Customization */
    if (true == g_customize.DMS_Text )
    {
        vout_in = opencv_buffer;
    }
    else if (true == g_customize.IMR_LDC )
    {
        vout_in = imr_ldc_buffer;
    }
    else if (true == g_customize.VIN_Enable )
    {
        vout_in = vin_out_buffer;
    }
    else
    {
        vout_in = opencv_buffer;
    }

    return SUCCESS;
}
/**********************************************************************************************************************
 End of function buffer_map *********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: sigint_handler
* Description  : thread exit
* Arguments    : int signum
* Return Value : None
***********************************************************************************************************************/
static void sigint_handler(int signum) 
{
   is_thread_exit = true;
   signal(SIGINT, sigint_handler);
 }
/***********************************************************************************************************************
* End of function sigint_handler
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: DmsModuleInitFlags
* Description  : Module init Flags
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void DmsModuleInitFlags()
{

    dmsStatus.vin.status = INVALID;
    dmsStatus.imr_ldc.status = INVALID;
    dmsStatus.imr_rs.status = INVALID;
    dmsStatus.isp.status = INVALID;
    dmsStatus.vout.status = INVALID;
}
/***********************************************************************************************************************
* End of function DmsModuleInitFlags
***********************************************************************************************************************/

